using System;
using System.Collections.Generic;
using Unity.Cinemachine.Hybrid;
using Unity.Entities;
using Unity.Entities.Hybrid;
using UnityEngine;

namespace Cinecast.CM.Hybrid
{
    [RequireComponent(typeof(CmTargetAuthoring))]
    public class TrackerSpawnPoint : EntityBehaviourAuthoringBase
    {
        [Serializable]
        public struct SpawnPoint
        {
            public CMCameraType CameraType;
            public string Hint;
            public Vector3 ExtraTargetOffset;
        }
        public List<SpawnPoint> m_SpawnPoints = new List<SpawnPoint>();

        protected override void PullFromEntity(Entity entity, ConversionContext context) {}

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            var b = context.EntityManager.AddBuffer<TrackerSpawnPointData>(entity);
            b.Clear();
            b.Capacity = Mathf.Max(1, m_SpawnPoints.Count);
            foreach (var element in m_SpawnPoints)
                b.Add(new TrackerSpawnPointData
                {
                    CameraType = element.CameraType,
                    Hint = element.Hint,
                    ExtraTargetOffset = element.ExtraTargetOffset
                });
        }
    }
}
