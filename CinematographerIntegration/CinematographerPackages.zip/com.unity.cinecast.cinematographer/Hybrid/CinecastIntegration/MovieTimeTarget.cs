using Unity.Cinemachine.Hybrid;
using UnityEngine;

namespace Cinecast.CM.Hybrid
{
    [RequireComponent(typeof(CmTargetAuthoring))]
    public class MovieTimeTarget : MonoBehaviour
    {
    }
}
