using System;
using System.Collections.Generic;
using Unity.Cinemachine.Core;
using Unity.Entities;
using UnityEngine;
using Unity.Cinemachine.Hybrid;
using Unity.Collections;
using Unity.Mathematics;
using Unity.Cinecast.Cinematographer.Core;

using Unity.Entities.Hybrid;

namespace Cinecast.CM.Hybrid
{
    public class SpawnTrackers : EntityBehaviour
    {
        [Serializable]
        public struct TemplateAssignment
        {
            public CMCameraType Type;
            public string Hint;
            public GameObject Template;
        }

        //[TypedStableReferenceProperty(typeof(CmChannelBindingKey))]
        public CmChannelBindingKey DestinationChannel;
        public List<TemplateAssignment> Templates;

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            // The referenced prefab will have been converted due to DeclareReferencedPrefabs.
            // So here we simply map the game object to an entity reference to that prefab.
            var temp = new List<SpawnTrackerTemplate>();
            foreach (var t in Templates)
            {
                if (t.Template != null)
                {
                    temp.Add(new SpawnTrackerTemplate
                    {
                        ChannelBinding = DestinationChannel == null ? StableKey.Default : DestinationChannel.StableKey,
                        Type = t.Type,
                        Hint = t.Hint,
                        Prefab = context.GetPrimaryEntityForPrefab(t.Template)
                    });
                }
            }

            var buffer = context.EntityManager.AddBuffer<SpawnTrackerTemplate>(entity);
            foreach (var t in temp) buffer.Add(t);
        }

        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
        }

        public void Despawn()
        {
            var world = ClientHooks.DefaultWorld;
            if (world != null)
            {
                // Delete all spawned trackers
                var m = world.EntityManager;
                var query = m.CreateEntityQuery(new EntityQueryDesc
                    { All = new ComponentType[] { typeof(SpawnedTracker) }});
                m.DestroyEntity(query);

                // Delete the spawned indicators to trigger a respawn on the targets
                query = m.CreateEntityQuery(new EntityQueryDesc
                    { All = new ComponentType[] { typeof(TrackerSpawnedForTarget) }});
                m.RemoveComponent(query, typeof(TrackerSpawnedForTarget));
            }
        }

        public void Respawn()
        {
            Despawn();
            Reconvert();
        }

        void OnEnable()
        {
            Respawn();
        }

        void OnDisable()
        {
            Despawn();
        }
    }

    [Serializable]
    public struct TrackerSpawnPointData : IBufferElementData
    {
        public CMCameraType CameraType;
        public FixedString32Bytes Hint;
        public float3 ExtraTargetOffset;
    }

    [Serializable]
    struct SpawnTrackerTemplate : IBufferElementData
    {
        public StableKey ChannelBinding;
        public CMCameraType Type;
        public FixedString32Bytes Hint;
        public Entity Prefab;
    }

    [Serializable]
    struct TrackerSpawnedForTarget : ISystemStateComponentData
    {
        public StableKey Key;
    }

    [Serializable]
    struct SpawnedTracker : IComponentData {}

    [UpdateBefore(typeof(CmTargetSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class SpawnTrackersSystem : SystemBase
    {
        EntityQuery m_spawnerQuery;
        EntityQuery m_danglingStateQuery;
        EntityQuery m_spawnPointQuery;
        EntityCommandBufferSystem m_EcbSource;

        protected override void OnCreate()
        {
            m_EcbSource = World.GetExistingSystem<EndSimulationEntityCommandBufferSystem>();
            m_spawnerQuery = GetEntityQuery(
                ComponentType.ReadOnly<SpawnTrackerTemplate>());
            m_danglingStateQuery = GetEntityQuery(
                ComponentType.Exclude<TrackerSpawnPointData>(),
                ComponentType.ReadOnly<TrackerSpawnedForTarget>());
        }

        protected override void OnUpdate()
        {
            if (m_spawnPointQuery.CalculateEntityCount() != 0 && m_spawnerQuery.CalculateEntityCount() != 0)
            {
                var spawners = m_spawnerQuery.ToEntityArray(Allocator.TempJob);
                var buffer = GetBuffer<SpawnTrackerTemplate>(spawners[0]);
                spawners.Dispose();
                var numTemplates = buffer.Length;
                if (numTemplates == 0)
                    return;

                // Make a copy because structural changes
                var templates = new NativeArray<SpawnTrackerTemplate>(numTemplates, Allocator.TempJob);
                for (int i = 0; i < numTemplates; ++i)
                    templates[i] = buffer[i];

                //var parallelWriterECB = m_EcbSource.CreateCommandBuffer().AsParallelWriter();
                Entities
                    .WithName("SpawnTrackersJob")
                    .WithStructuralChanges()
                    .WithStoreEntityQueryInField(ref m_spawnPointQuery)
                    .WithDisposeOnCompletion(templates)
                    .WithNone<TrackerSpawnedForTarget>()
                    .WithAll<CmTarget>()
                    .ForEach((
                        Entity entity,
                        DynamicBuffer<TrackerSpawnPointData> spawnTypes,
                        ref StableKeyData targetKey) =>
                    {
                        // Cache the spawn list because we will do structural changes
                        var typesList = new NativeArray<TrackerSpawnPointData>(spawnTypes.Length, Allocator.Temp);
                        for (int i = 0; i < spawnTypes.Length; ++i)
                            typesList[i] = spawnTypes[i];

                        for (int i = 0; i < typesList.Length; ++i)
                        {
                            // Count the templates with matching type and hint
                            int selectedTemplate = -1;
                            int numMatching = 0;
                            int numMatchingWithHint = 0;
                            for (int j = 0; j < numTemplates; ++j)
                            {
                                if (templates[j].Type == typesList[i].CameraType)
                                {
                                    ++numMatching;
                                    if (selectedTemplate < 0)
                                        selectedTemplate = j;
                                    if (typesList[i].Hint == templates[j].Hint)
                                    {
                                        ++numMatchingWithHint;
                                        selectedTemplate = j;
                                        break;
                                    }
                                }
                            }
                            Entity prefab = Entity.Null;
                            if (numMatching > 0)
                            {
                                // If there are multiple matches, choose one
                                if (numMatchingWithHint != 1 && numMatching > 1)
                                {
                                    // If none with matching hint, then ignore the hint
                                    if (numMatchingWithHint != 0)
                                       numMatching = numMatchingWithHint;
                                    selectedTemplate = -1;
                                    var targetIndex = numMatching % i;
                                    for (int j = 0; j < numTemplates; ++j)
                                    {
                                        if (templates[j].Type == typesList[i].CameraType 
                                            && (numMatchingWithHint == 0 || typesList[i].Hint == templates[j].Hint))
                                        {
                                            if (++selectedTemplate == targetIndex)
                                            {
                                                selectedTemplate = j;
                                                break;
                                            }
                                        }
                                    }
                                }
                                prefab = templates[selectedTemplate].Prefab;
                            }
                            if (prefab != Entity.Null)
                            {
                                var tracker = EntityManager.Instantiate(prefab);
        #if UNITY_EDITOR
                                EntityManager.SetName(tracker, $"{EntityManager.GetName(tracker)} {EntityManager.GetName(entity)}");
        #endif
                                // Follow the target
                                EntityManager.AddComponentData(tracker, new FollowTarget { Target = targetKey.Value });

                                // Look at the right thing
                                if (!EntityManager.HasComponent<StoryThreadTracker>(tracker))
                                    Debug.LogError($"Camera template is missing StoryThreadTracker component");
                                else
                                {
                                    var settings = EntityManager.GetComponentData<StoryThreadTracker>(tracker);
                                    if (!settings.AutoLookAt)
                                        EntityManager.AddComponentData(tracker, new LookAtTarget { Target = targetKey.Value });
                                    else
                                    {
                                        // Looks at itself as a target group!  weird but true...
                                        var key = new StableKeyData { Value = StableKey.GenerateUnique() };
                                        EntityManager.AddComponentData(tracker, key);
                                        EntityManager.AddComponentData(tracker, new CmTarget());
                                        EntityManager.AddComponentData(tracker, new LookAtTarget { Target = key.Value });
                                    }
                                }
                                EntityManager.SetSharedComponentData(
                                    tracker, new NodeChannelAssignment { ChannelId = templates[selectedTemplate].ChannelBinding });

                                // Assign the Camera Type for possible filtering
                                EntityManager.AddComponentData(tracker, new DirectorFilter
                                {
                                    CameraType = (int)typesList[i].CameraType,
                                    FollowTarget = targetKey.Value
                                });
                                EntityManager.AddComponentData(tracker, new TransitionQuality());

                                // If an extra offset was specified, add it to the FollowControl component's offset
                                if (!typesList[i].ExtraTargetOffset.AlmostZero())
                                {
                                    if (EntityManager.HasComponent<HardLockToTarget>(tracker))
                                    {
                                        var follow = EntityManager.GetComponentData<HardLockToTarget>(tracker);
                                        follow.Offset += typesList[i].ExtraTargetOffset;
                                        EntityManager.SetComponentData(tracker, follow);
                                    }
                                    else if (EntityManager.HasComponent<FollowControl>(tracker))
                                    {
                                        var follow = EntityManager.GetComponentData<FollowControl>(tracker);
                                        follow.FollowOffset += typesList[i].ExtraTargetOffset;
                                        EntityManager.SetComponentData(tracker, follow);
                                    }
                                    else
                                        Debug.LogError("ExtraOffset was specified for tracker, but no FollowControl "
                                            + $"or HardLockToTarget component was present in the prefab");
                                }

                                // Mark it as spawned by us
                                EntityManager.AddComponentData(tracker, new SpawnedTracker());
                            }
                            // Spawned!
                            EntityManager.AddComponentData(entity, new TrackerSpawnedForTarget { Key = targetKey.Value } );
                        }
                    }).Run();
            }

            // Despawn trackers for deleted spawn points
            if (!m_danglingStateQuery.IsEmpty)
            {
                var ecb = m_EcbSource.CreateCommandBuffer().AsParallelWriter();
                var a = m_danglingStateQuery.ToComponentDataArray<TrackerSpawnedForTarget>(Allocator.TempJob);
                Entities
                    .WithName("DespawnTrackersJob")
                    .WithNativeDisableParallelForRestriction(a)
                    .WithDisposeOnCompletion(a)
                    .ForEach((
                        Entity entity, int entityInQueryIndex, 
                        ref LookAtTarget lookAt, ref FollowTarget follow) =>
                    {
                        for (int i = 0; i < a.Length; ++i)
                        {
                            if (a[i].Key == lookAt.Target || a[i].Key == follow.Target)
                            {
                                ecb.DestroyEntity(entityInQueryIndex, entity);
                                break;
                            }
                        }
                    }).ScheduleParallel();
                m_EcbSource.AddJobHandleForProducer(Dependency);

                EntityManager.RemoveComponent<TrackerSpawnedForTarget>(m_danglingStateQuery);
            }
        }
    }
}
