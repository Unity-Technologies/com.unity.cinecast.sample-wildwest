using UnityEngine;
using Unity.Cinemachine.Hybrid;

namespace Cinecast.CM.Hybrid
{
    public interface IFreeRoamInputProvider
    {
        public Vector3 GetPositionInput();
        public Vector3 GetRotationInput();
        public bool GetTurboInput();
        public float GetZoomInput();
    }

    [RequireComponent(typeof(CmCameraAuthoring))]
    public class FreeRoamCameraController : MonoBehaviour
    {
        // GML todo: what if new input system?
        class DefaultInput : IFreeRoamInputProvider
        {
            public Vector3 GetPositionInput() 
            {
                return new Vector3(
                    Input.GetAxisRaw("Horizontal"), 
                    Input.GetKey(KeyCode.Space) ? 1 : Input.GetKey(KeyCode.C) ? -1 : 0,
                    Input.GetAxisRaw("Vertical"));
            }
            public Vector3 GetRotationInput() 
            { 
                if (!Input.GetMouseButton(1))
                    return Vector3.zero;
                return new Vector3(
                    -Input.GetAxisRaw("Mouse Y"),
                    Input.GetAxisRaw("Mouse X"), 
                    0); 
            }
            public bool GetTurboInput() 
            { 
                return Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift); 
            }
            public float GetZoomInput()
            {
                return -Input.GetAxisRaw("Mouse ScrollWheel");
            }
        }

        [Tooltip("Camera form which to take the initial state.  Leave blank to use Camera.main")]
        public Camera InitialStateSource;

        public float WalkSpeed;
        public float RunSpeed;
        public float LookSpeed;
        public float ZoomSpeed;
        public float MinFOV;
        public float MaxFOV;

        public float PositionDamping;

        IFreeRoamInputProvider m_InputProvider;
        Vector3 m_Velocity;
        Vector3 m_SmoothDampVel;
        float m_fov;
        CmCameraAuthoring m_Tracker;

        void Reset()
        {
            InitialStateSource = null; 
            WalkSpeed = 5f;
            RunSpeed = 15f;
            LookSpeed = 10f;
            ZoomSpeed = 20f;
            MinFOV = 10;
            MaxFOV = 110;

            PositionDamping = 0.5f;
            m_Velocity = m_SmoothDampVel = Vector3.zero;
        }

        void OnEnable()
        {
            m_Tracker = GetComponent<CmCameraAuthoring>();
            var target = InitialStateSource;
            if (target == null)
                target = Camera.main;
            if (target != null)
            {
                transform.position = target.transform.position;
                transform.rotation = target.transform.rotation;
                m_fov = target.fieldOfView;
            }
            m_Velocity = m_SmoothDampVel = Vector3.zero;

            m_InputProvider = GetComponent<IFreeRoamInputProvider>();
            if (m_InputProvider == null)
                m_InputProvider = new DefaultInput();

        }

        void LateUpdate()
        {
            var moveSpeed = (m_InputProvider.GetTurboInput() ? RunSpeed : WalkSpeed);
            var moveInput = m_InputProvider.GetPositionInput() * moveSpeed;
            Vector3 lookInput = m_InputProvider.GetRotationInput() * LookSpeed;

            // Apply the rotation
            var rot = (Quaternion.AngleAxis(lookInput.y, Vector3.up) * m_Tracker.State.RawOrientation).eulerAngles;
            var tilt = (rot.x + lookInput.x);
            while (tilt > 180)
                tilt -= 360;
            rot.x = Mathf.Clamp(tilt, -89, 89);
            rot.z = 0;
            transform.rotation = Quaternion.Euler(rot);

            // Apply the position
            var velocity = transform.rotation * moveInput;
            m_Velocity = Vector3.SmoothDamp(m_Velocity, velocity, ref m_SmoothDampVel, PositionDamping);
            transform.position += m_Velocity * Time.deltaTime;

            // Handle the lens
            m_fov = Mathf.Clamp(m_fov + m_InputProvider.GetZoomInput() * ZoomSpeed, MinFOV, MaxFOV);
            var lens = m_Tracker.Lens;
            lens.FieldOfView = m_fov;
            m_Tracker.Lens = lens;
        }
    }
}
