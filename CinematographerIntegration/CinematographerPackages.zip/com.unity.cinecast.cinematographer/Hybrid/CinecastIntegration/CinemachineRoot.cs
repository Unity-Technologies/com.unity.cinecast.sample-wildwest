using System.Collections.Generic;
using Cinecast.Api.Playback;
using Cinecast.Api.Poi;
using Cinecast.Api.Settings;
using Cinecast.Api.Spectator;
using Cinecast.Core.Api.Discovery;
using Cinecast.Implementation.Application;
using Unity.Assertions;
using Unity.Cinecast.Cinematographer.Hybrid;
using Unity.Entities;
using UnityEngine;

namespace Cinecast.CM.Hybrid
{
    public class CinemachineRoot : MonoBehaviour
    {
        /// <summary>
        /// Get the singleton instance of this class
        /// </summary>
        public static CinemachineRoot Instance { get; private set; }

        CinecastObserver m_CinecastObserver;
        CinecastObserver.CinemachineSettings m_Settings;
        static CinecastObserver.CinecastServices s_CinecastServices;

        void Awake()
        {
            Instance = this;
            m_Settings = new CinecastObserver.CinemachineSettings 
            {
                StoryManager = GetComponentInChildren<StoryManagerSettingsAuthoring>(true),
                ShotQuality = GetComponentInChildren<StoryThreadShotQualityTuningAuthoring>(true),
                Transition = GetComponentInChildren<TransitionQualityTuningAuthoring>(true),
                Director = GetComponentInChildren<DirectorTuningAuthoring>(true),
            };

            Assert.IsNotNull(m_Settings.StoryManager, "StoryManagerSettingsAuthoring component is required somewhere in the children");
            Assert.IsNotNull(m_Settings.ShotQuality, "StoryThreadShotQualityTuningAuthoring component is required somewhere in the children");
            Assert.IsNotNull(m_Settings.Transition, "TransitionQualityTuningAuthoring component is required somewhere in the children");
            Assert.IsNotNull(m_Settings.Director, "DirectorTuningAuthoring component is required somewhere in the children");

            m_CinecastObserver = GetComponentInChildren<CinecastObserver>(true);
            Assert.IsNotNull(m_CinecastObserver, "CinecastObserver component is required somewhere in the children");

            // In case async cinecast initialization is already complete
            ConnectToCinecast();
        }

        void OnDestroy()
        {
            m_CinecastObserver.Shutdown();

            if (IsCinecastStarted)
            {
                var discovery = SDKRuntimeCinecast.Instance.Discovery;
                discovery.Release(s_CinecastServices.InterestService);
                discovery.Release(s_CinecastServices.PoiPlaybackService);
                discovery.Release(s_CinecastServices.AppSettingsService);
                discovery.Release(s_CinecastServices.PlaybackSessionService);
                discovery.Release(s_CinecastServices.WatcherService);
            }
            
            if (Instance == this)
                Instance = null;
        }

        public static async void OnCinecastStarted(CinecastObserver.ICameraService cameraService) 
        { 
            var discovery = SDKRuntimeCinecast.Instance.Discovery;
            s_CinecastServices = new CinecastObserver.CinecastServices
            {
                InterestService = await discovery.Resolve<IInterestCacheProvider>(DiscoveryOptions.Required).ConfigureAwait(false),
                PoiPlaybackService = await discovery.Resolve<IPoiPlaybackService>(DiscoveryOptions.Required).ConfigureAwait(false),
                AppSettingsService = await discovery.Resolve<IAppSettingsService>(DiscoveryOptions.Required).ConfigureAwait(false),
                PlaybackSessionService = await discovery.Resolve<IPlaybackService>(DiscoveryOptions.Required).ConfigureAwait(false),
                WatcherService = await discovery.Resolve<IWatcherService>(DiscoveryOptions.Required).ConfigureAwait(false),
                CameraService = cameraService
            }; 

            // In case Start() has already run before this async callback
            if (Instance != null)
                Instance.ConnectToCinecast();
        }

        bool IsCinecastStarted => s_CinecastServices.InterestService != null;
        void ConnectToCinecast()
        {
            if (IsCinecastStarted && !m_CinecastObserver.IsStarted)
                m_CinecastObserver.Startup(m_Settings, s_CinecastServices);
        }
        
        /// <summary>
        /// Client calls this to enable/disable Cinemachine cameras.
        /// Disabling frees up resources used by CM.
        /// </summary>
        /// <param name="enableCM"></param>
        public void Enable(bool enableCM)
        {
            // Enable/disable the children
            foreach (Transform t in transform)
                t.gameObject.SetActive(enableCM);

            if (!enableCM)
                m_CinecastObserver.Shutdown();
            else 
                ConnectToCinecast();
        }

        /// <summary>
        /// Set the POIs on which to focus attention.  
        /// All the leaf POIs descendants will be added to the focus list.
        /// Previous focus POIs will be cleared first.
        /// </summary>
        /// <param name="targetID">The focus POI (may be empty)</param>
        /// <returns>Returns the StableKeys for the leaf targets that were implicated</returns>
        public IReadOnlyList<StableKey> SetFocusPOIs(IReadOnlyList<string> targets)
        {
            return m_CinecastObserver.SetFocusPOIs(targets);
        }

        /// <summary>
        /// Set the POIs from whose POV to prioritize.  
        /// All the leaf POIs descendants will be added to the follow list.
        /// Previous follow POIs will be cleared first.
        /// </summary>
        /// <param name="targetID">The follow POI (may be empty)</param>
        /// <returns>Returns the StableKeys for the leaf targets that were implicated</returns>
        public IReadOnlyList<StableKey> SetFollowTargetFilter(IReadOnlyList<string> targets)
        {
            return m_CinecastObserver.SetFollowTargetFilter(targets);
        }

        /// <summary>
        /// Set the camera type filter.  Cameras not of this type will be de-prioritized.
        /// </summary>
        /// <param name="cameraType">The desired camera type</param>
        public void SetCameraTypeFilter(IReadOnlyList<int> filter)
        {
            m_CinecastObserver.SetCameraTypeFilter(filter);
        }
    }
}
