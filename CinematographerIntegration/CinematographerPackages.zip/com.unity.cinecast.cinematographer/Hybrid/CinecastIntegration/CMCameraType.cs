namespace Cinecast.CM.Hybrid
{
    /// <summary>
    /// Placeholder for generated type
    /// </summary>
    public enum CMCameraType
    {
        None,
        Type1,
        Type2,
        Type3,
        Type4,
        Type5,
        Type6,
        Type7,
        Type8,
        Type9,
        Type10,
        Type11,
        Type12,
        Type13,
        Type14,
        Type15
    }
}
