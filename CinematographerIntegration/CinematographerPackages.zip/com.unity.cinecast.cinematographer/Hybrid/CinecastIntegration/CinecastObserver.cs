#if UNITY_EDITOR
#define SHOW_DEBUG_TEXT
#endif

using System;
using System.Collections.Generic;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Cinecast.Cinematographer.Core;
using Unity.Cinecast.Cinematographer.Hybrid;
using Unity.Entities;
using Unity.Collections;
using Unity.Mathematics;
using Cinecast.Api.Playback;
using Cinecast.Api.Poi;
using Cinecast.Api.Settings;
using Cinecast.Api.Spectator;
using Cinecast.Api.Server.Api;
using System.Linq;
using Unity.Assertions;
using Unity.Jobs;

namespace Cinecast.CM.Hybrid
{
    public class CinecastObserver : MonoBehaviour
    {
        [Tooltip("Hack to force a minimum interest value for POIs.  Set to 0 to disable.")]
        public float MinimumInterest;
        
        public interface ICameraService
        {
            int GetCameraEnumValue(string cameraName);
            void OnSelectionChanged(IReadOnlyList<int> selectedCameraTypes, IReadOnlyList<StableKey> selectedPOIs);
        }

        public struct CinemachineSettings
        {
            public StoryManagerSettingsAuthoring StoryManager;
            public StoryThreadShotQualityTuningAuthoring ShotQuality;
            public TransitionQualityTuningAuthoring Transition;
            public DirectorTuningAuthoring Director;
        }
        static CinemachineSettings s_Settings;

        public struct CinecastServices
        {
            public IInterestCacheProvider InterestService;
            public IPoiPlaybackService PoiPlaybackService;
            public IAppSettingsService AppSettingsService;
            public IPlaybackService PlaybackSessionService;
            public IWatcherService WatcherService;
            public ICameraService CameraService;
        }
        static CinecastServices s_Cinecast;

        StoryManagerSystem m_StoryManager;
        UpdateLookaheadSystem m_UpdateLookahead;
        bool m_IsDirty;

        void Awake()
        {
            m_StoryManager = ClientHooks.DefaultWorld.GetOrCreateSystem<StoryManagerSystem>();
            m_UpdateLookahead = ClientHooks.DefaultWorld.GetOrCreateSystem<UpdateLookaheadSystem>();
        }

        void OnDestroy()
        {
            Shutdown();
        }
        
        void OnEnable()
        {
            if (m_UpdateLookahead != null)
                m_UpdateLookahead.Reset = true;
            m_IsDirty = true;
        }

        void Update()
        {
            m_UpdateLookahead.MinimumInterestHack = MinimumInterest;
            if (m_IsDirty && IsStarted)
            {
                RefreshCinecastInfo();
                m_IsDirty = false;
            }
        }

        public bool IsStarted => m_StoryManager != null && s_Settings.Director != null && s_Cinecast.InterestService != null;

        public void Startup(CinemachineSettings settings, CinecastServices services)
        {
            s_Settings = settings;
            s_Cinecast = services;

            Assert.IsNotNull(s_Cinecast.InterestService, "Cinecast InterestService is null");
            Assert.IsNotNull(s_Cinecast.PoiPlaybackService, "Cinecast PoiPlaybackService is null");
            Assert.IsNotNull(s_Cinecast.AppSettingsService, "Cinecast AppSettingsService is null");
            Assert.IsNotNull(s_Cinecast.PlaybackSessionService, "Cinecast PlaybackSessionService is null");
            Assert.IsNotNull(s_Cinecast.WatcherService, "Cinecast WatcherService is null");

            s_Cinecast.InterestService.OnFrameUpdated += OnFrameUpdated;
            s_Cinecast.WatcherService.OnSelectionsUpdated += OnSelectionsUpdated;
        }

        public void Shutdown()
        {
            if (s_Cinecast.InterestService != null)
            {
                s_Cinecast.InterestService.OnFrameUpdated -= OnFrameUpdated;
                s_Cinecast.WatcherService.OnSelectionsUpdated -= OnSelectionsUpdated;
            }
            s_Cinecast = new CinecastServices();
            s_Settings = new CinemachineSettings();
        }

        IReadOnlyDictionary<IPoiTypeCameraRef, ClientPOITypeCameraResponse> m_CameraDefinitions;
        List<string> m_EmptyList = new List<string>();
        List<string> m_PoiSelectionCache = new List<string>();
        List<int> m_CameraTypeSelectionCache = new List<int>();

        void RefreshCinecastInfo()
        {
            // Get the playback FPS
            var session = s_Cinecast.PlaybackSessionService.GetSessionInfo();
            if (!session.Item1)
                m_StoryManager.CurrentFPS = 60; // just assume this so we don't poop out
            else
                m_StoryManager.CurrentFPS = session.Item2.Fps;

            UpdatePresentationSettings(s_Cinecast.AppSettingsService.GetPresentationSettings());

            m_CameraDefinitions = s_Cinecast.AppSettingsService.GetCameraDefinitions();
            var cameras = s_Cinecast.WatcherService.GetCameraSelections();
            bool isPovType = cameras.Count > 0;
            m_CameraTypeSelectionCache.Clear();
            for (int i = 0; i < cameras.Count; ++i)
            {
                if (!m_CameraDefinitions.TryGetValue(cameras[i], out ClientPOITypeCameraResponse c))
                    isPovType = false;
                else
                {
                    if (c.CameraType.ToLower() != "pov") // GML hack need defined constant here!
                        isPovType = false;
                    if (s_Cinecast.CameraService != null)
                        m_CameraTypeSelectionCache.Add(s_Cinecast.CameraService.GetCameraEnumValue(c.ReferenceId));
                }
            }
            SetCameraTypeFilter(m_CameraTypeSelectionCache);

            // We interpret POI selection differently depending on camera type selected
            m_PoiSelectionCache.Clear();
            m_PoiSelectionCache.Add(s_Cinecast.WatcherService.GetPoiSelection());
            IReadOnlyList<StableKey> targets;
            if (isPovType)
            {
                // POV camera type
                SetFocusPOIs(m_EmptyList);
                targets = SetFollowTargetFilter(m_PoiSelectionCache);
            }
            else
            {
                // Non-POV camera type
                targets = SetFocusPOIs(m_PoiSelectionCache);
                SetFollowTargetFilter(m_EmptyList);
            }
            // User callback
            if (s_Cinecast.CameraService != null)
                s_Cinecast.CameraService.OnSelectionChanged(m_CameraTypeSelectionCache, targets);

            // GML this is not great, maybe there's a better way
            m_UpdateLookahead.RefreshPreferredLookAt(s_Cinecast.PoiPlaybackService);

            // Recompute the lookahead shot qualities, because they are dependent on the POI selection
            m_UpdateLookahead.Reset = true;
            //m_UpdateLookahead.RecomputeLookahead();
        }

        void UpdatePresentationSettings(PresentationSettingResponse settings)
        {
            var shotSettings = s_Settings.ShotQuality.Value;
            shotSettings.Settings.HitchcockWeight = settings.HitchcockWeight;
            shotSettings.Settings.ActionVisibilityWeight = settings.ActionVisibilityWeight;
            //shotSettings.Settings.FacingQualityWeight = settings.FacingQualityWeight;
            shotSettings.Settings.OptimalDistanceQualityBoost = settings.OptimalDistanceQualityBoost;
            shotSettings.Settings.CameraStabilityScale = settings.CameraStabilityScale;
            shotSettings.Settings.PitchSteepnessLimit = new float2(70, 85); //settings.PitchSteepnessLimitMin, settings.PitchSteepnessLimitMax)
            s_Settings.ShotQuality.Value = shotSettings;

            var transitionSettings = s_Settings.Transition.Value;
            transitionSettings.Settings.DirectorLineCutWeight = settings.DirectorLineCutWeight;
            transitionSettings.Settings.JumpCutWeight = settings.JumpCutWeight;
            transitionSettings.Settings.LookAtCutWeight = settings.LookAtCutWeight;
            transitionSettings.Settings.MoveCutWeight = settings.MoveCutWeight;
            transitionSettings.Settings.PositionCutWeight = settings.PositionCutWeight;
            s_Settings.Transition.Value = transitionSettings;

            var directorSettings = s_Settings.Director.Value;
            directorSettings.Settings.ShotQualityWeight = settings.ShotQualityWeight;
            directorSettings.Settings.TransitionQualityWeight = settings.TransitionQualityWeight;
            directorSettings.Settings.AverageShotLength = settings.AverageShotLength;
            directorSettings.Settings.MaxLookaheadTime = settings.MaxLookaheadTime;
            directorSettings.Settings.PreferredLens = new float2(0, 180);
            s_Settings.Director.Value = directorSettings;
        }

        private void OnSelectionsUpdated(object sender, System.EventArgs e)
        {
            m_IsDirty = true;
        }

        private void OnFrameUpdated(object sender, FrameVersionArgs fv)
        {
            if (m_StoryManager != null && m_UpdateLookahead != null)
            {
                // If the timeline was scrubbed back or far enough forward, reset lookahead and history
                var previousFrame = m_StoryManager.MovieTimeFrameNumber;
                if (fv.FrameIndex < previousFrame || fv.FrameIndex > previousFrame + 20)
                    m_UpdateLookahead.Reset = true;
                m_StoryManager.MovieTimeFrameNumber = fv.FrameIndex;

                // Update FPS.  GML this is problematic if the FPS changes
                var fps = m_StoryManager.CurrentFPS == 0 ? 24 : m_StoryManager.CurrentFPS;
                ClientHooks.CurrentTimeOverride = fv.FrameIndex / (double)fps;

                // Queue up the data for the current POI version
                if (!QueueCacheUpdateForFrame(fv.FrameIndex, fv.FrameIndex, out long lastCachedFrame))
                {
                    // If nothing to queue, see if there are some frames available for the next POI version
                    var gameTimeFrame = m_StoryManager.GameTimeFrameNumber;
                    if (lastCachedFrame >= fv.FrameIndex && lastCachedFrame < gameTimeFrame)
                        QueueCacheUpdateForFrame(lastCachedFrame, fv.FrameIndex, out _);
                }
            }
        }

        bool QueueCacheUpdateForFrame(long frameIndex, long currentMoveTimeFrame, out long nextUncachedFrame)
        {
            // Get the state of the current cache and compare it with the available frames
            var cmPoiVersion = CinemachinePoi.PoiVersion;
            var cachedRange = new FrameRange();
            PoiDataCache.Snapshot snapshot;
            lock (m_UpdateLookahead.DataCache) 
            { 
                if (m_UpdateLookahead.DataCache.CmPoiVersion != cmPoiVersion)
                    m_UpdateLookahead.DataCache.Dispose();
                cachedRange = m_UpdateLookahead.DataCache.CachedRange;
                snapshot = m_UpdateLookahead.DataCache.NewSnapshot; 
            }

            // Identify the frames we need to cache
            snapshot.FrameRange = s_Cinecast.InterestService.GetVersionRange(frameIndex);
#if SHOW_DEBUG_TEXT
            if (snapshot.FrameRange.FrameCount == 0)
                m_UpdateLookahead.DebugLog($"No data available at frame {frameIndex}");
#endif
            snapshot.FrameRange.TrimPastHistory(math.max(currentMoveTimeFrame, cachedRange.EndRange()));
            if (snapshot.FrameRange.FrameCount == 0)
            {
                nextUncachedFrame = cachedRange.EndRange();
                return false;
            }
            // Create the snapshot
            var poiVersion = s_Cinecast.InterestService.GetPoiVersionForFrame(frameIndex);
            CreatePoiIndexLookup(ref snapshot, poiVersion, cmPoiVersion, snapshot.FrameRange.FrameCount);

            // If there's not enough space in the cache, grow it
            var neededLength = snapshot.PoiCount * snapshot.FrameRange.FrameCount;
            if (!snapshot.FrameData.IsCreated || snapshot.FrameData.Length < neededLength)
            {
                if (snapshot.FrameData.IsCreated)
                    snapshot.FrameData.Dispose();
                snapshot.FrameData = new NativeArray<InterestFrameData>(neededLength, Allocator.Persistent);
            }

            // Fetch the data
            s_Cinecast.InterestService.GetPoiDataForFrames(snapshot.FrameRange, ref snapshot.FrameData);

#if false && SHOW_DEBUG_TEXT
            // GML NO Commit - sanity check
            int badCount = 0;
            for (int i = 0; i < neededLength; ++i)
            {
                var r = snapshot.FrameData[i].Rotation;
                if (math.abs(math.lengthsq(new float4(r.x, r.y, r.z, r.w)) - 1.0f) > 0.01f)
                {
                    var data = snapshot.FrameData[i];
                    data.Rotation = Quaternion.identity;
                    snapshot.FrameData[i] = data;
                    ++badCount;
                }
            }
            if (badCount > 0)
                Debug.LogError($"<color=red>[CinecastObserver] Got {100*badCount/neededLength}%</color> "
                    + $"{badCount} invalid quaternions out of {neededLength}");
#endif

            lock (m_UpdateLookahead.DataCache) 
            {
                m_UpdateLookahead.DataCache.NewSnapshot = snapshot;
                m_UpdateLookahead.DataCache.CachedRange.Append(snapshot.FrameRange);
                m_UpdateLookahead.DataCache.CmPoiVersion = cmPoiVersion;
#if SHOW_DEBUG_TEXT
                m_UpdateLookahead.DebugLog(
                    $"Cache Updated: ({m_UpdateLookahead.DataCache.CachedRange.FirstIndex} "
                        + $"- {m_UpdateLookahead.DataCache.CachedRange.EndRange() - 1})");
#endif
            }
            nextUncachedFrame = snapshot.FrameRange.EndRange();
            return true;
        }

        List<StableKey> m_PoiStableKeyCache = new List<StableKey>();
        void CreatePoiIndexLookup(
            ref PoiDataCache.Snapshot snapshot, int poiVersion, long cmPoiVersion, int frameCount)
        {
            // Get the POI id list for this poi version
            if (snapshot.PoiIds == null || snapshot.PoiIds.Count == 0
                || snapshot.PoiVersion != poiVersion 
                || snapshot.CinemachinePoiVersion != cmPoiVersion)
            {
                snapshot.PoiVersion = poiVersion;
                snapshot.CinemachinePoiVersion = cmPoiVersion;
                if (snapshot.PoiIds == null)
                    snapshot.PoiIds = new List<string>();
                s_Cinecast.InterestService.GetPoiIds(poiVersion, ref snapshot.PoiIds);
            }

            snapshot.PoiCount = snapshot.PoiIds.Count;
            if (!snapshot.KeyToIndex.IsCreated || snapshot.KeyToIndex.Capacity < snapshot.PoiCount) 
            {
                if (snapshot.KeyToIndex.IsCreated)
                    snapshot.KeyToIndex.Dispose();
                snapshot.KeyToIndex = new NativeHashMap<StableKey, int>(snapshot.PoiCount, Allocator.Persistent);
            }

            m_PoiStableKeyCache.Clear();
            CinemachinePoi.GetPoiStableKeys(snapshot.PoiIds, m_PoiStableKeyCache);
            snapshot.KeyToIndex.Clear();
            for (int i = 0; i < snapshot.PoiCount; ++i)
            {
                var key = m_PoiStableKeyCache[i];
                if (key.IsValid)
                    snapshot.KeyToIndex.Add(key, i * frameCount);
            }
        }

        void GetLeafPOIs(IReadOnlyList<string> targets, List<StableKey> result)
        {
            result.Clear();
            if (s_Cinecast.PoiPlaybackService == null)
                return;
            foreach (var targetID in targets)
            {
                // Get the leaf POIs
                if (string.IsNullOrEmpty(targetID))
                    continue;
                var relateds = s_Cinecast.PoiPlaybackService.GetRelatedIds(targetID, true);
                foreach (var id in relateds)
                {
                    // it's a leaf if the set of related ids contains only itself
                    var r2 = s_Cinecast.PoiPlaybackService.GetRelatedIds(id, true);
                    if (r2.Count == 1 && CinemachinePoi.LookupKey(id, out var key) && key.IsValid)
                        result.Add(key);
                }
            }
        }

        List<StableKey> m_FocusTargetsCache = new List<StableKey>();

        /// <summary>
        /// Set the POIs on which to focus attention.  
        /// All the leaf POIs descendants will be added to the focus list.
        /// Previous focus POIs will be cleared first.
        /// </summary>
        /// <param name="targetID">The focus POI (may be empty)</param>
        /// <returns>Returns the StableKeys for the leaf targets that were implicated</returns>
        public IReadOnlyList<StableKey> SetFocusPOIs(IReadOnlyList<string> targets)
        {
            GetLeafPOIs(targets, m_FocusTargetsCache);
            if (IsStarted)
            {
                s_Settings.Director.DirectorSystem.SetFocusTargets(m_FocusTargetsCache);
                m_UpdateLookahead.SetFocusTargets(m_FocusTargetsCache);
            }
            return m_FocusTargetsCache;
        }

        List<StableKey> m_FollowTargetsCache = new List<StableKey>();

        /// <summary>
        /// Set the POIs from whose POV to prioritize.  
        /// All the leaf POIs descendants will be added to the follow list.
        /// Previous follow POIs will be cleared first.
        /// </summary>
        /// <param name="targetID">The follow POI (may be empty)</param>
        /// <returns>Returns the StableKeys for the leaf targets that were implicated</returns>
        public IReadOnlyList<StableKey> SetFollowTargetFilter(IReadOnlyList<string> targets)
        {
            GetLeafPOIs(targets, m_FollowTargetsCache);
            if (IsStarted)
            {
                s_Settings.Director.DirectorSystem.SetFollowTargets(m_FollowTargetsCache);
                s_Settings.Director.DirectorSystem.SuspendShotPacing(m_FollowTargetsCache.Count == 1);
            }
            return m_FollowTargetsCache;
        }

        /// <summary>
        /// Set the camera type filter.  Cameras not of this type will be de-prioritized.
        /// </summary>
        /// <param name="cameraType">The desired camera type</param>
        public void SetCameraTypeFilter(IReadOnlyList<int> filter)
        {
            if (IsStarted)
                s_Settings.Director.DirectorSystem.SetCameraTypeFilter(filter);
        }
    }

    class PoiDataCache
    {
        public struct Snapshot
        {
            public NativeHashMap<StableKey, int> KeyToIndex;
            public NativeArray<InterestFrameData> FrameData;
            public FrameRange FrameRange;
            public int PoiCount;
            public int PoiVersion;
            public long CinemachinePoiVersion;
            public List<string> PoiIds;
        }

        public Snapshot QueuedSnapshot;
        public Snapshot NewSnapshot;
        public FrameRange CachedRange;
        public long CmPoiVersion;

        public void Dispose()
        {
            DisposeSnapshot(ref QueuedSnapshot);
            DisposeSnapshot(ref NewSnapshot);
            CachedRange = new FrameRange();
            CmPoiVersion = 0;
        }

        static void DisposeSnapshot(ref Snapshot snapshot)
        {
            if (snapshot.KeyToIndex.IsCreated)
                snapshot.KeyToIndex.Dispose();
            if (snapshot.FrameData.IsCreated)
                snapshot.FrameData.Dispose();
            snapshot.FrameRange = new FrameRange();
            snapshot.PoiCount = 0;
            snapshot.PoiVersion = 0;
            snapshot.CinemachinePoiVersion = 0;
            if (snapshot.PoiIds != null)
                snapshot.PoiIds.Clear();
        }
    }

    static class FrameRangeExtensions
    {
        public static long EndRange(this ref FrameRange range) => range.FirstIndex + range.FrameCount;
        public static void TrimPastHistory(this ref FrameRange range, long trimBefore)
        {
            int delta = (int)(trimBefore - range.FirstIndex);
            if (delta > 0)
            {
                range.FirstIndex += delta;
                range.FrameCount = math.max(range.FrameCount - delta, 0);
            }
        }

        public static void Append(this ref FrameRange range, FrameRange other)
        {
            if (range.FrameCount > 0 && range.FirstIndex <= other.FirstIndex)
            {
                var delta = (int)(range.EndRange() - other.FirstIndex);
                if (delta >= 0)
                {
                    range.FrameCount += math.max(other.FrameCount - delta, 0);
                    return;
                }
            }
            range = other; // not contiguous - just replace
        }
    }

    // This system pushes POI values to the Story threads - filling their lookahead buffers
    // GML TODO: merge this into StoryManagerSystem, less job scheduling
    [UpdateBefore(typeof(StoryManagerSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    partial class UpdateLookaheadSystem : SystemBase
    {
        public bool Reset 
        { 
            get => m_Reset; 
            set 
            { 
                if (!m_Reset && value)
                {
                    Dependency.Complete(); // make sure users of QueuedSnapshot have done their work // GML todo: is this right?
                    lock (DataCache) { DataCache.Dispose(); }
                }
                m_Reset = value; 
            }
        }
        public PoiDataCache DataCache = new PoiDataCache();
        public float MinimumInterestHack { get; set; }

        public void SetFocusTargets(IReadOnlyList<StableKey> targets)
        {
            m_PreviousDependency.Complete();
            if (m_FocusTargets.Count() < targets.Count)
            {
                m_FocusTargets.Dispose();
                m_FocusTargets = new NativeHashSet<StableKey>(targets.Count, Allocator.Persistent);
            }
            m_FocusTargets.Clear();
            foreach (var t in targets)
                m_FocusTargets.Add(t);
        }

#if SHOW_DEBUG_TEXT
        public static bool FrameCacheDebugLogging = true;
        public void DebugLog(string msg)
        {
            Debug.Log($"<color=magenta>[CinecastObserver] frame {m_StoryManager.MovieTimeFrameNumber}:</color> {msg}");
        }
#endif

        EntityQuery m_StoryThreadQuery;
        StoryManagerSystem m_StoryManager;
        bool m_Reset;
        List<ShotQualityTuning> m_qualitySettings = new List<ShotQualityTuning>(2);
        NativeHashSet<StableKey> m_FocusTargets;
        JobHandle m_PreviousDependency;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_StoryManager = World.GetOrCreateSystem<StoryManagerSystem>();
            m_FocusTargets = new NativeHashSet<StableKey>(16, Allocator.Persistent);
        }

        protected override void OnDestroy()
        {
            lock (DataCache)
            {
                DataCache.Dispose();
            }
            m_FocusTargets.Dispose();
        }

        public void RefreshPreferredLookAt(IPoiPlaybackService playbackService)
        {
            // Refresh POI preferred view (GML is there not a better way than this?)
            Entities.WithoutBurst().ForEach((ref StoryThread storyThread, in StableKeyData key) => 
            { 
                if (CinemachinePoi.LookupId(key.Value, out var id))
                {
                    if (playbackService.GetPoiType(id, out var result))
                    {
                        storyThread.PreferredView = (StoryThread.ViewHemisphere)result.PreferredViewingAngle;
                    }
                }
            }).Run();
        }

        protected override void OnUpdate()
        {
            if (Reset)
            { 
#if SHOW_DEBUG_TEXT
                if (FrameCacheDebugLogging)
                {
                    FrameRange range;
                    lock (DataCache) { range = DataCache.CachedRange; }
                    DebugLog($" Reset ---- Frame = {m_StoryManager.MovieTimeFrameNumber} " 
                        + $"-------- CachedFrames = {range.FirstIndex} - {range.EndRange() - 1}");
                }
#endif
                // Kill all lookahead and history
                Entities
                    .ForEach((
                        DynamicBuffer<StoryLookaheadInfo> lookaheadData,
                        ref StoryLookaheadWindow lookahead) =>
                    {
                        lookahead.Clear(lookaheadData);
                    })
                    .Run();

                // Invalidate previous state
                Entities.ForEach((ref CmChannelState state) => { state.PreviousStateIsValid = false; }).Run();
                Entities.ForEach((ref NodeUpdateState state) => { state.PreviousFrameDataIsValid = false; }).Run();

                m_StoryManager.DesiredLookaheadTime = 0;
            }

            Dependency.Complete(); // make sure users of QueuedSnapshot have done their work // GML todo: is this right?
            PoiDataCache.Snapshot snapshot;
            lock (DataCache)
            {
                Reset = false;
                if (DataCache.NewSnapshot.FrameRange.FrameCount == 0)
                    snapshot = DataCache.QueuedSnapshot;
                else
                {
                    snapshot = DataCache.NewSnapshot;
                    DataCache.NewSnapshot = DataCache.QueuedSnapshot;
                    DataCache.QueuedSnapshot = snapshot;
                }
            }
            if (snapshot.FrameRange.FrameCount > 0)
            {
                m_qualitySettings.Clear();
                EntityManager.GetAllUniqueSharedComponentData(m_qualitySettings);
                if (m_qualitySettings.Count < 2)
                    return;
                
                var qualitySettings = m_qualitySettings[m_qualitySettings.Count-1].Settings;

                var minimumInterest = MinimumInterestHack;
                var minimumRadius = qualitySettings.MinimumTargetRadius;
                var frameData = snapshot.FrameData;
                var frameRange = snapshot.FrameRange;
                var keyToIndex = snapshot.KeyToIndex;

                var focusTargets = m_FocusTargets;
                var numFocusTargets = focusTargets.Count();
                var focusBaseMultiplier = math.select(1.0f, 0.4f, numFocusTargets > 0);
                var focusTargetBoost = math.select(0f, 0.6f / numFocusTargets, numFocusTargets > 0);

                Entities
                    .WithStoreEntityQueryInField(ref m_StoryThreadQuery)
                    .WithReadOnly(frameData)
                    .WithReadOnly(keyToIndex)
                    .WithReadOnly(focusTargets)
                    .WithAll<StoryThread>()
                    .ForEach((
                        Entity entity,
                        DynamicBuffer<StoryLookaheadInfo> lookaheadData,
                        ref StoryLookaheadWindow lookahead,
                        in StableKeyData key) =>
                    {
                        if (keyToIndex.TryGetValue(key.Value, out int dataStart))
                        {
                            long afterHeadFrame = lookahead.IsEmpty() 
                                ? frameRange.FirstIndex : lookahead.HeadTimeFrame(lookaheadData) + 1;
                            var startIndex = math.max(0, (int)(afterHeadFrame - frameRange.FirstIndex));
                            for (var i = startIndex; i < frameRange.FrameCount; ++i)
                            {
                                var info = frameData[dataStart + i];
                                var frame = frameRange.FirstIndex + i;
                                var interest = math.max(minimumInterest, info.NormalizedInterest);
                                lookahead.AddHead(lookaheadData, new StoryLookaheadInfo
                                {
                                    Info = new StoryLookaheadInfo.TargetInfo
                                    {
                                        Value = interest * focusBaseMultiplier 
                                            + math.select(0, focusTargetBoost, focusTargets.Contains(key.Value)),
                                        Position = info.Position,
                                        Rotation = info.Rotation,
                                        Radius = math.max(minimumRadius, info.Radius)
                                    },
                                    FrameNumber = frame
                                });
                            }
                        }
                    })
                    .ScheduleParallel();

                m_PreviousDependency = Dependency;
            }
        }

        // When user POI selection has changed, the lookahead shot qualities need to get 
        // recomputed because the POI intresets change as a funtion of POI selection
        // (POIs selected by the user are inherently more interesting)
        public void RecomputeLookahead()
        {
            if (m_StoryManager.LookaheadFrames == 0)
                return;

#if SHOW_DEBUG_TEXT
            DebugLog("Recomputing lookahed" );
#endif
            // Kill shot pacing
            Entities.ForEach((ref CmChannelState state) => { state.PreviousStateIsValid = false; }).Run();

            // Reset POI lookahead buffers
            Entities
                .WithAll<StoryThread, StoryThreadState>()
                .ForEach((
                    DynamicBuffer<StoryLookaheadInfo> lookaheadData,
                    ref StoryLookaheadWindow lookahead) =>
                {
                    lookahead.ResetGameTime(lookaheadData);
                })
                .Run();

            // Clear all camera lookahead buffers
            Entities
                .WithAll<StoryThreadTracker>()
                .ForEach((
                    DynamicBuffer<StoryLookaheadInfo> lookaheadData,
                    ref StoryLookaheadWindow lookahead) =>
                {
                    lookahead.Clear(lookaheadData);
                })
                .Run();
                    
            // Resimulate the lookahead buffer 
            var lookaheadTime = m_StoryManager.DesiredLookaheadTime;
            var stepSize = 2 * lookaheadTime / m_StoryManager.LookaheadFrames; // skip frames for efficiency
            for (m_StoryManager.DesiredLookaheadTime = 0; 
                m_StoryManager.DesiredLookaheadTime < lookaheadTime - stepSize; 
                m_StoryManager.DesiredLookaheadTime += stepSize)
            {
                CinemachineSystemBase.ManualUpdate(World);
            }
            m_StoryManager.DesiredLookaheadTime = lookaheadTime;
        }

#if UNITY_EDITOR
        const string RangeLogMenuName = "Cinecast/Cinemachine/Debug/DIsplay Frame Range Log Messages";
        [UnityEditor.MenuItem(RangeLogMenuName)]
        private static void FrameRangeLogMessagesMenu()
        {
            FrameCacheDebugLogging = !FrameCacheDebugLogging;
        }
  
        [UnityEditor.MenuItem(RangeLogMenuName, true)]
        private static bool FrameRangeLogMessagesMenuValidate()
        {
            UnityEditor.Menu.SetChecked(RangeLogMenuName, FrameCacheDebugLogging);
            return true;
        }

        [UnityEditor.MenuItem("Cinecast/Cinemachine/Debug/Nullify POI Interests")]
        static void ZapAllInterestsMenu() 
        { 
            ClientHooks.DefaultWorld.GetOrCreateSystem<UpdateLookaheadSystem>().ZapAllInterests();
        }

        private void ZapAllInterests()
        {
            Dependency.Complete();
            Entities
                .WithAll<StoryThread>()
                .ForEach((DynamicBuffer<StoryLookaheadInfo> lookaheadData) =>
                {
                    for (int i = 0; i < lookaheadData.Length; ++i)
                    {
                        var v = lookaheadData[i];
                        v.Info.Value = 0;
                        lookaheadData[i] = v;
                    }
                })
                .Run();
        }
#endif
    }
}
