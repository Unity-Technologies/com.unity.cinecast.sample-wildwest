using System.Collections.Generic;
using System.Threading;
using Unity.Cinecast.Cinematographer.Hybrid;
using Unity.Entities;
using Unity.Entities.Hybrid;
using UnityEngine;

namespace Cinecast.CM.Hybrid
{
    [RequireComponent(typeof(StoryThreadAuthoring))]
    public class CinemachinePoi : MonoBehaviour
    {
        static Dictionary<string, StableKey> s_Id2Key = new Dictionary<string, StableKey>();
        static Dictionary<StableKey, string> s_Key2Id = new Dictionary<StableKey, string>();

        /// <summary>
        /// This sequence number gets updated every time a CinemachinePoi is initialized
        /// </summary>
        static public long PoiVersion { get => Interlocked.Read(ref s_PoiVersion); }

        static long s_PoiVersion;

        public static bool LookupKey(string poi_id, out StableKey key)
        {
            lock (s_Id2Key)
            {
                if (s_Id2Key.TryGetValue(poi_id, out key))
                    return true;
                key = StableKey.Default;
                return false;
            }
        }

        public static bool LookupId(StableKey key, out string poi_id)
        {
            lock (s_Key2Id)
            {
                if (s_Key2Id.TryGetValue(key, out poi_id))
                    return true;
                poi_id = string.Empty;
                return false;
            }
        }

        // Can call from thread
        public static int GetPoiStableKeys(List<string> poi_ids, List<StableKey> result)
        {
            int numFound = 0;
            lock (s_Id2Key)
            {
                int numPois = poi_ids.Count;
                for (int i = 0; i < numPois; ++i)
                {
                    if (s_Id2Key.TryGetValue(poi_ids[i], out var key))
                        ++numFound;
                    else
                        key = StableKey.Default;
                    result.Add(key);
                }
            }
            return numFound;
        }

        string m_POI_id;
        string m_POI_name;

        public void Initialize(string POI_id, string POI_name)
        {
            gameObject.SetActive(true);
            m_POI_id = POI_id;
            m_POI_name = POI_name;
            var key = GetComponent<StableID>().Value;

            lock (s_Id2Key) 
            {
                s_Id2Key.Add(m_POI_id, key); 
                s_Key2Id.Add(key, m_POI_id); 
                Interlocked.Increment(ref s_PoiVersion);
            }
        }

#if UNITY_EDITOR
        /// <summary>
        ///  Set the entity name so that it shows up nicely in the debugging
        /// </summary>
        bool m_NameInitialized = false;
        public void Update()
        {
            if (!m_NameInitialized && m_POI_name.Length != 0)
            {
                gameObject.name = m_POI_name;
                var eb = GetComponent<EntityBehaviour>();
                if (eb != null && eb.IsSynchronized)
                {
                    eb.SynchronizedWorld.EntityManager.SetName(eb.SynchronizedEntity, m_POI_name);
                    m_NameInitialized = true;
                }
            }
        }
#endif

        void OnDestroy()
        {
            if (m_POI_id.Length != 0)
            {
                lock (s_Id2Key) 
                { 
                    if (s_Id2Key.TryGetValue(m_POI_id, out var key))
                        s_Key2Id.Remove(key); 
                    s_Id2Key.Remove(m_POI_id); 
                    Interlocked.Increment(ref s_PoiVersion);
                }
            }
        }
    }
}
