using Unity.Collections;
using Unity.Entities;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Cinecast.Cinematographer.Core;

namespace Unity.Cinecast.Cinematographer.Hybrid
{
    public class CinemachineDebugVisualizer : MonoBehaviour
    {
        public bool LiveCamsOnly;
        public Color VisibleTargetColor;

        public Mesh CameraMesh;
        public Color CameraActiveColor;
        public Color CameraInactiveColor;

        public bool ShowCellGrid;
        public Color CellGridColor;

#if UNITY_EDITOR

        World World { get { return ClientHooks.DefaultWorld; } }

        void Reset()
        {
            LiveCamsOnly = false;
            VisibleTargetColor = new Color(0, 0, 1, 0.2f);

            CameraMesh = null;
            CameraActiveColor = new Color(1, 0, 0, 0.8f);
            CameraInactiveColor = new Color(0.2f, 0.2f, 0.2f, 0.2f);

            ShowCellGrid = true;
            CellGridColor = new Color(0.5f, 0.5f, 0, 0.5f);
        }

        Mesh m_Mesh;

        private void OnDisable()
        {
            var system = World?.GetExistingSystem<CMDebugVisualizerSystem>();
            if (system != null)
                system.Enabled = false;
        }

        void OnDrawGizmos()
        {
            if (World == null)
                return;

            if (m_Mesh == null)
                m_Mesh = new Mesh();

            m_Mesh.Clear();
            var system = World.GetOrCreateSystem<CMDebugVisualizerSystem>();
            system.Enabled = isActiveAndEnabled;
            system.LiveNodesOnly = LiveCamsOnly;
            if (isActiveAndEnabled)
            {
                int numNodes = system.GetData(m_Mesh, out var nodeInfo);
                if (m_Mesh.vertexCount > 1)
                {
                    Gizmos.color = VisibleTargetColor;
                    Gizmos.DrawWireMesh(m_Mesh);
                }
                if (numNodes > 0)
                {
                    if (CameraMesh != null)
                    {
                        var rot = transform.rotation;
                        var scale = transform.localScale;
                        for (int i = 0; i < numNodes; ++i)
                        {
                            Gizmos.color = nodeInfo[i].NumTargets == 0 ? CameraInactiveColor : CameraActiveColor;
                            Gizmos.DrawMesh(CameraMesh, nodeInfo[i].Position, nodeInfo[i].Rotation * rot, scale);
                        }
                    }
                    if (ShowCellGrid)
                    {
                        Gizmos.color = CellGridColor;
                        for (int i = 0; i < numNodes; ++i)
                            if (nodeInfo[i].NumTargets > 0 && (!LiveCamsOnly || nodeInfo[i].IsLive))
                                Gizmos.DrawSphere(nodeInfo[i].Position, nodeInfo[i].SearchRadius);
                    }
                }
            }
        }
#endif
    }


#if UNITY_EDITOR
    partial class CMDebugVisualizerSystem : SystemBase
    {
        EntityQuery m_nodeQuery;
        EntityQuery m_storyThreadQuery;

        public bool LiveNodesOnly { get; set; }

        public struct NodeInfo
        {
            public Entity Entity;
            public Vector3 Position;
            public Quaternion Rotation;
            public int NumTargets;
            public float SearchRadius;
            public bool IsLive;
        }

        NativeArray<Vector3> m_Vertices;
        NativeArray<Vector3> m_Normals;
        NativeArray<int> m_Indices;
        NativeArray<NodeInfo> m_NodeInfo;
        NativeArray<int> m_Counts;

        public int GetData(Mesh mesh, out NativeArray<NodeInfo> nodeInfo)
        {
            Dependency.Complete();
            mesh.Clear();
            if (m_Indices.IsCreated && m_Indices.Length > 0)
            {
                mesh.SetVertices(m_Vertices.GetSubArray(0, m_Counts[kVertices]));
                mesh.SetNormals(m_Normals.GetSubArray(0, m_Counts[kVertices]));
                mesh.SetIndices(m_Indices.GetSubArray(0, m_Counts[kIndices]), MeshTopology.Lines, 0);
                nodeInfo = m_NodeInfo.GetSubArray(0, m_Counts[kNodes]);
                return m_Counts[kNodes];
            }
            nodeInfo = m_NodeInfo;
            return 0;
        }

        void Deallocate()
        {
            if (m_Vertices.IsCreated)
                m_Vertices.Dispose();
            if (m_Normals.IsCreated)
                m_Normals.Dispose();
            if (m_Indices.IsCreated)
                m_Indices.Dispose();
            if (m_NodeInfo.IsCreated)
                m_NodeInfo.Dispose();
            if (m_Counts.IsCreated)
                m_Counts.Dispose();
        }

        protected override void OnCreate()
        {
            m_nodeQuery = GetEntityQuery(
                ComponentType.ReadOnly<PositionState>(),
                ComponentType.ReadOnly<StoryThreadTracker>(),
                ComponentType.ReadOnly<StoryThreadTrackerSystemBase.VisibleTarget>(),
                ComponentType.ReadOnly<NodeUpdateState>());

            m_storyThreadQuery = GetEntityQuery(
                ComponentType.ReadOnly<StoryThreadState>(),
                ComponentType.ReadOnly<StableKeyData>(),
                ComponentType.ReadOnly<StoryLookaheadWindow>(),
                ComponentType.ReadOnly<StoryLookaheadInfo>());

            Enabled = false;
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            Deallocate();
        }

        const int kVertices = 0;
        const int kIndices = 1;
        const int kNodes = 2;

        protected override void OnUpdate()
        {
            var nodeCount = m_nodeQuery.CalculateEntityCount();
            var storyThreadCount = m_storyThreadQuery.CalculateEntityCount();
            if (storyThreadCount == 0 || nodeCount == 0)
                return;

            int maxVertices = (storyThreadCount + 1) * nodeCount;
            if (!m_Vertices.IsCreated || m_Vertices.Length < maxVertices || m_NodeInfo.Length < nodeCount)
            {
                Deallocate();
                m_Vertices = new NativeArray<Vector3>(maxVertices, Allocator.Persistent);
                m_Normals = new NativeArray<Vector3>(maxVertices, Allocator.Persistent);
                m_Indices = new NativeArray<int>(maxVertices * 2, Allocator.Persistent);
                m_NodeInfo = new NativeArray<NodeInfo>(nodeCount, Allocator.Persistent);
                m_Counts = new NativeArray<int>(3, Allocator.Persistent);
            }
            m_Counts[kVertices] = m_Counts[kIndices] = m_Counts[kNodes] = 0;
            bool liveNodesOnly = LiveNodesOnly;

            var vertices = m_Vertices;
            var normals = m_Normals;
            var indices = m_Indices;
            var nodeInfo = m_NodeInfo;
            var counts = m_Counts;

            Entities
                .WithName("BuildMeshJob")
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    DynamicBuffer<StoryThreadTrackerSystemBase.VisibleTarget> targets,
                    in StoryThreadTracker tracker,
                    in PositionState posState,
                    in NodeUpdateState updateState) =>
                {
                    var n = counts[kNodes];
                    nodeInfo[n] = new NodeInfo
                    {
                        Entity = entity,
                        Position = posState.GetCorrectedPosition(),
                        Rotation = posState.GetCorrectedRotation(),
                        NumTargets = targets.Length,
                        SearchRadius = tracker.SearchRadius,
                        IsLive = updateState.IsLive
                    };
                    if ((!liveNodesOnly || updateState.IsLive) && targets.Length > 0)
                    {
                        var p0 = counts[kVertices];
                        var t = counts[kIndices];

                        vertices[p0] = nodeInfo[n].Position;
                        normals[p0] = new Vector3(0, 1, 0);

                        for (int i = 0; i < targets.Length; ++i)
                        {
                            var p1 = p0 + i + 1;
                            vertices[p1] = targets[i].Info.Position;
                            indices[t++] = p0;
                            indices[t++] = p1;
                        }
                        counts[kVertices] += targets.Length + 1;
                        counts[kIndices] = t;
                    }
                    counts[kNodes] = n + 1;
                }).Schedule();
        }
    }
#endif
}
