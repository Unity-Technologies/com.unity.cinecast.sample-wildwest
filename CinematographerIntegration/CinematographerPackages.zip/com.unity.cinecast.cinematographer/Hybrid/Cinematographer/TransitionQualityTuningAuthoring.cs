using Unity.Mathematics;
using UnityEngine;
using Unity.Cinecast.Cinematographer.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinecast.Cinematographer.Hybrid
{
    [DisallowMultipleComponent]
    [AddComponentMenu("Cinecast/Cinematographer/Transition Quality Tuning")]
    public class TransitionQualityTuningAuthoring : SharedComponentAuthoringBase<TransitionQualityTuning>
    {
        protected override void OnValidate()
        {
            var s = m_Value.Settings;
            s.DirectorLineCutWeight = math.max(0, s.DirectorLineCutWeight);
            s.JumpCutWeight = math.max(0, s.JumpCutWeight);
            s.LookAtCutWeight = math.max(0, s.LookAtCutWeight);
            s.MoveCutWeight = math.max(0, s.MoveCutWeight);
            s.PositionCutWeight = math.max(0, s.PositionCutWeight);
            m_Value.Settings = s;
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new TransitionQualityTuning
            {
                Settings = new TransitionQualityTuning.QualitySettings
                {
                    DirectorLineCutWeight = 1f,
                    JumpCutWeight = 0.5f,
                    LookAtCutWeight = 0.25f,
                    MoveCutWeight = 0.25f,
                    PositionCutWeight = 0.25f,
                }
            };
            base.Reset();
        }
    }
}
