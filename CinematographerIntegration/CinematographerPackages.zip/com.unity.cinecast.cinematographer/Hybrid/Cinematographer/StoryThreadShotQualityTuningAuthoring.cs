using Unity.Mathematics;
using UnityEngine;
using Unity.Cinecast.Cinematographer.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinecast.Cinematographer.Hybrid
{
    [DisallowMultipleComponent]
    [AddComponentMenu("Cinecast/Cinematographer/Story Thread Shot Quality Tuning")]
    public class StoryThreadShotQualityTuningAuthoring : SharedComponentAuthoringBase<ShotQualityTuning>
    {
        protected override void OnValidate()
        {
            var s = m_Value.Settings;
            s.HitchcockWeight = math.max(0, s.HitchcockWeight);
            s.ActionVisibilityWeight = math.max(0, s.ActionVisibilityWeight);
            s.FacingQualityWeight = math.max(0, s.FacingQualityWeight);
            s.OptimalDistanceQualityBoost = math.max(0, s.OptimalDistanceQualityBoost);
            s.CameraStabilityScale = math.max(0, s.CameraStabilityScale);
            var x = math.clamp(s.PitchSteepnessLimit.x, 0, 90);
            s.PitchSteepnessLimit = new float2(x, math.clamp(s.PitchSteepnessLimit.y, x, 90));
            s.MinimumTargetRadius = math.max(0.05f, s.MinimumTargetRadius);
            m_Value.Settings = s;
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new ShotQualityTuning
            {
                Settings = new ShotQualityTuning.QualitySettings
                {
                    HitchcockWeight = 1.0f,
                    ActionVisibilityWeight = 1.0f,
                    FacingQualityWeight = 1.0f,
                    OptimalDistanceQualityBoost = 1.2f,
                    CameraStabilityScale = 1,
                    PitchSteepnessLimit = new float2 { x = 70f, y = 85f },
                    MinimumTargetRadius = 0.25f
                }
            };
            base.Reset();
        }
    }
}
