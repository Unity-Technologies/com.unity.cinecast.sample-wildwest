using Unity.Mathematics;
using UnityEngine;
using Unity.Cinecast.Cinematographer.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinecast.Cinematographer.Hybrid
{
    [DisallowMultipleComponent]
    [AddComponentMenu("Cinecast/Cinematographer/Story Manager Settings")]
    public class StoryManagerSettingsAuthoring : SharedComponentAuthoringBase<StoryManagerSettings>
    {
        public void Validate() { OnValidate(); }

        protected override void OnValidate()
        {
            m_Value.ThreadStarvationBoostAmount = math.clamp(m_Value.ThreadStarvationBoostAmount, 0, 1);
            m_Value.ThreadStarvationGrowthTime = math.max(1, m_Value.ThreadStarvationGrowthTime);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new StoryManagerSettings
            {
                ThreadStarvationBoostAmount = 1,
                ThreadStarvationGrowthTime = 6
            };
            base.Reset();
        }
    }
}
