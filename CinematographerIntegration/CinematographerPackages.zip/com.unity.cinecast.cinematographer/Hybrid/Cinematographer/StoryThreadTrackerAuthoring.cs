using Unity.Mathematics;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Entities;
using Unity.Cinemachine.Hybrid;
using Unity.Cinecast.Cinematographer.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinecast.Cinematographer.Hybrid
{
    [DisallowMultipleComponent]
    [CameraExtension]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinecast/Cinematographer/Story Thread Tracker")]
    public class StoryThreadTrackerAuthoring : ComponentAuthoringBase<StoryThreadTracker>
    {
        protected override void OnValidate()
        {
            m_Value.SearchRadius = math.max(0, m_Value.SearchRadius);
            m_Value.MinimumTargetDistance = math.max(0.1f, m_Value.MinimumTargetDistance);
            //m_Value.RefreshInterval = math.max(0, m_Value.RefreshInterval);
            m_Value.CameraTargetStickiness = math.max(0, m_Value.CameraTargetStickiness);
            m_Value.AngularHysteresis = math.max(0, m_Value.AngularHysteresis);
            m_Value.FollowTargetFixedScale = math.clamp(m_Value.FollowTargetFixedScale, 0, 1);
            m_Value.GroupMemberBlendTime = math.max(0, m_Value.GroupMemberBlendTime);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new StoryThreadTracker
            {
                SearchRadius = 100f,
                MinimumTargetDistance = 0.5f,
                //RefreshInterval = 0f,
                AutoLookAt = true,
                CameraTargetStickiness = 1.0f,
                AngularHysteresis = 5,
                FollowTargetFixedScale = 0,
#if CINEMACHINE_UNITY_PHYSICS
                OcclusionLayers = 1,
#endif
#if CINEMACHINE_LEGACY_PHYSICS
                LegacyOcclusionLayers = 1,
#endif
                GroupMemberBlendTime = 1
            };
            base.Reset();
        }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            base.PushToEntity(entity, context);
            context.EntityManager.AddBuffer<StoryLookaheadInfo>(entity);
            context.EntityManager.AddComponentData(entity, new StoryLookaheadWindow());
        }
    }
}

