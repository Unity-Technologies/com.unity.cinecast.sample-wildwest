using Unity.Mathematics;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Cinecast.Cinematographer.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinecast.Cinematographer.Hybrid
{
    [DisallowMultipleComponent]
    [AddComponentMenu("Cinecast/Cinematographer/Director Tuning")]
    public class DirectorTuningAuthoring : SharedComponentAuthoringBase<DirectorTuning>
    {
        public DirectorSystem DirectorSystem => ClientHooks.DefaultWorld.GetOrCreateSystem<DirectorSystem>();

        public void Validate() 
        { 
            OnValidate();
        }

        protected override void OnValidate()
        {
            var s = m_Value.Settings;
            s.ShotQualityWeight = math.max(0, s.ShotQualityWeight);
            s.TransitionQualityWeight = math.max(0, s.TransitionQualityWeight);
            s.AverageShotLength = math.max(0, s.AverageShotLength);
            s.MaxLookaheadTime = math.max(0, s.MaxLookaheadTime);
            var x = math.clamp(s.PreferredLens.x, 0, 179);
            s.PreferredLens = new float2(x, math.clamp(s.PreferredLens.y, x, 179));
            m_Value.Settings = s;
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new DirectorTuning
            {
                Settings = new DirectorTuning.DirectorSettings
                {
                    ShotQualityWeight = 1,
                    TransitionQualityWeight = 1,
                    AverageShotLength = 6,
                    MaxLookaheadTime = 4,
                    PreferredLens = new float2(0, 179)
                }
            };
            base.Reset();
        }
    }
}
