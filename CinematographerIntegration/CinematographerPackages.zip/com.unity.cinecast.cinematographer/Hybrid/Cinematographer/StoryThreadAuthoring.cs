using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Entities;
using Unity.Cinecast.Cinematographer.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinecast.Cinematographer.Hybrid
{
    [DisallowMultipleComponent]
    [RequireComponent(typeof(CmTarget))]
    [AddComponentMenu("Cinecast/Cinematographer/Story Thread")]
    public class StoryThreadAuthoring : ComponentAuthoringBase<StoryThread>
    {
        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            base.PushToEntity(entity, context);
            context.EntityManager.AddBuffer<StoryLookaheadInfo>(entity);
            context.EntityManager.AddComponentData(entity, new StoryLookaheadWindow());
        }
    }
}
