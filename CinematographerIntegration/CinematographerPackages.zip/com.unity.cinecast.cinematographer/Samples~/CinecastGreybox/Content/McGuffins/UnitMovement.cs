﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace Cinecast.CM.Samples
{
    public class UnitMovement : MonoBehaviour
    {
        public Transform moveTarget;
        public float remainingDistance = 0f;
        private NavMeshAgent agent;
        private Animator animator;

        void Awake()
        {
            agent = GetComponent<NavMeshAgent>();
            animator = GetComponent<Animator>();
            StartCoroutine(DoUnitMove());
        }
        
        private IEnumerator DoUnitMove()
        {
            while ( true)
            {
                var randomWait = Random.Range(1f, 5f);
                yield return new WaitForSeconds(randomWait);
                agent.SetDestination(moveTarget.position);
            }
        }

        private void Update()
        {
            var currentSpeed = agent.velocity.magnitude;
            animator.SetFloat("Speed", currentSpeed);
        }
    }
}