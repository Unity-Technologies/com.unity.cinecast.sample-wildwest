﻿using System.Collections.Generic;
using UnityEngine;
using Unity.Entities;
using Unity.Collections;
using Unity.Mathematics;
using Unity.Cinemachine.Core;
using Unity.Cinecast.Cinematographer.Core;
using Unity.Cinecast.Cinematographer.Hybrid;

namespace Cinecast.CM.Samples
{

public class CinecastRoot : MonoBehaviour
{
    public bool ShowGui = true;

    DirectorTuningAuthoring m_DirectorTuning;
    StoryManagerSettingsAuthoring m_StoryManagerSettings;

    private void Start()
    {
        m_DirectorTuning = FindObjectOfType<DirectorTuningAuthoring>();
        m_StoryManagerSettings = FindObjectOfType<StoryManagerSettingsAuthoring>();

        if (m_DirectorTuning == null)
            Debug.LogError("Cinecast: Missing DirectorTuning component");
        if (m_StoryManagerSettings == null)
            Debug.LogError("Cinecast: Missing StoryManager Settings component");
    }

#if UNITY_EDITOR
    private void OnGUI()
    {
        if (m_DirectorTuning == null || m_StoryManagerSettings == null || !ShowGui)
            return;

        var world = ClientHooks.DefaultWorld;
        if (world == null)
            return;
        var m = world.EntityManager;

        var d = m_DirectorTuning.Value.Settings;
       // var focusTarget = m_StoryManagerSettings.Value.FocusOverrideTarget;

        float w = Screen.width / 7;
        float h = 24;

        Rect r = new Rect(0, Screen.height - h, w, h);
        //if (focusTarget != Entity.Null)
        //    GUI.Label(r, m.GetName(focusTarget), GUI.skin.box);

        r.x = 3 * r.width;
        GUI.Label(r, d.AverageShotLength.ToString("0.0") + " sec", GUI.skin.box);

        r.x = Screen.width - 2 * r.width;
//        if (d.m_LensMode != Cinematographer.LensMode.Auto)
//            GUI.Label(r, d.m_LensMode.ToString(), GUI.skin.box);

        r.x += r.width;
//        if (d.m_CameraMode != Cinematographer.CameraMode.Auto)
//            GUI.Label(r, d.m_CameraMode.ToString(), GUI.skin.box);
    }
#endif

    // Controls to switch camera mode and player focus
    private void Update()
    {
        if (m_DirectorTuning == null || m_StoryManagerSettings == null)
            return;

        var m = World.DefaultGameObjectInjectionWorld?.EntityManager;
        if (m == null)
            return;

        var d = m_DirectorTuning.Value.Settings;
        var storySettings = m_StoryManagerSettings.Value;
        bool setD = false;
        bool setS = false;

        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            d.AverageShotLength += 0.5f;
            setD = true;
        }
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            d.AverageShotLength = Mathf.Max(0.5f, d.AverageShotLength - 0.5f);
            setD = true;
        }

        // player selection
        var players = GetPlayers();
        if (Input.GetKeyDown(KeyCode.BackQuote))
        {
//            storySettings.FocusOverrideTarget = Entity.Null;
//            d.ForceNewShot();
            setS = true;
        }
        for (int i = 0; i < math.min(10, players.Count); ++i)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1 + i))
            {
//                storySettings.FocusOverrideTarget = players[i];
//                d.ForceNewShot();
                setS = true;
            }
        }

        // Reset everything
        if (Input.GetKeyDown(KeyCode.Space))
        {
//            storySettings.FocusOverrideTarget = Entity.Null;
//            d.m_CameraMode = Cinematographer.CameraMode.Auto;
//            d.m_LensMode = Cinematographer.LensMode.Auto;
//            d.ForceNewShot();
            setS = true;
        }

/*
        if (Input.GetKeyDown(KeyCode.Backslash))
        {
            d.m_CameraMode = Cinematographer.CameraMode.Auto;
            d.m_LensMode = Cinematographer.LensMode.Auto;
            d.ForceNewShot();
        }
        if (Input.GetKeyDown(KeyCode.RightBracket))
        {
            d.m_CameraMode = Cinematographer.CameraMode.Head;
            d.m_LensMode = Cinematographer.LensMode.Auto;
            d.ForceNewShot();
        }
        if (Input.GetKeyDown(KeyCode.LeftBracket))
        {
            d.m_CameraMode = Cinematographer.CameraMode.Roaming;
            d.m_LensMode = Cinematographer.LensMode.Auto;
            d.ForceNewShot();
        }
        if (Input.GetKeyDown(KeyCode.P))
        {
            d.m_CameraMode = Cinematographer.CameraMode.Static;
            d.m_LensMode = Cinematographer.LensMode.Wide;
            d.ForceNewShot();
        }
        if (Input.GetKeyDown(KeyCode.O))
        {
            d.m_CameraMode = Cinematographer.CameraMode.Static;
            d.m_LensMode = Cinematographer.LensMode.Medium;
            d.ForceNewShot();
        }
        if (Input.GetKeyDown(KeyCode.I))
        {
            d.m_CameraMode = Cinematographer.CameraMode.Static;
            d.m_LensMode = Cinematographer.LensMode.Narrow;
            d.ForceNewShot();
        }
*/
        if (setD)
        {
            var vD = m_DirectorTuning.Value;
            vD.Settings = d;
            m_DirectorTuning.Value = vD;
            m_DirectorTuning.Validate();
        }
        if (setS)
        {
            m_StoryManagerSettings.Value = storySettings;
            m_StoryManagerSettings.Validate();
        }
    }

    List<Entity> m_PlayerList = new List<Entity>();
    List<Entity> GetPlayers()
    {
        var m = World.DefaultGameObjectInjectionWorld.EntityManager;
        var storyThreadQuery = m.CreateEntityQuery(ComponentType.ReadOnly<StoryThread>());
        var threads = storyThreadQuery.ToEntityArray(Allocator.TempJob);
        m_PlayerList.Clear();
        for (int i = 0; i < threads.Length; ++i)
//            if (m.GetComponentData<StoryThread>(threads[i]).IsMainCharacter)
                m_PlayerList.Add(threads[i]);
        threads.Dispose();
        return m_PlayerList;
    }
}

}
