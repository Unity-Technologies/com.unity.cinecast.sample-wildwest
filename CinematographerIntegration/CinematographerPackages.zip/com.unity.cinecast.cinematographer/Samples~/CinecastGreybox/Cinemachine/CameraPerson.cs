﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace Cinecast.CM.Samples
{
    [System.Serializable]
    public class CameraPerson : MonoBehaviour
    {
        public Transform moveTarget;
        public Vector3 offset = new Vector3();
        private NavMeshAgent agent;

        void Start()
        {
            agent = GetComponent<NavMeshAgent>();
        }

        private void Update()
        {
            var targetPos = moveTarget.position + offset;
            agent.SetDestination(targetPos);
            var pos = transform.position;
            Debug.DrawRay(pos, targetPos - pos, new Color(1, 1, 1, 0.5f));
        }
    }
}
