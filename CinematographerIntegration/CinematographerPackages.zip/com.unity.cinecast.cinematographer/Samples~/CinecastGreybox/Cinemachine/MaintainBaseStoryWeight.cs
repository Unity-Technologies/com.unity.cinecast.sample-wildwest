﻿using Unity.Entities;
using System;
using Unity.Cinemachine.Core;
using Unity.Transforms;
using Unity.Cinecast.Cinematographer.Core;
using Unity.Entities.Hybrid;

namespace Cinecast.CM.Samples
{
    class MaintainBaseStoryWeight : ComponentAuthoringBase<BaseStoryWeight> {} 

    [Serializable]
    struct BaseStoryWeight : IComponentData 
    {
        public VolatileWeight WeightDefinition;
    } 
    
    partial class MaintainBaseStoryWeightSystem : SystemBase
    {
        StoryManagerSystem m_StoryManager;
        int m_CurrentFrame;

        protected override void OnCreate()
        {
            m_StoryManager = World.GetOrCreateSystem<StoryManagerSystem>();
            m_CurrentFrame = 0;
        }

        protected override void OnUpdate()
        {
            var frame = ++m_CurrentFrame;
            m_StoryManager.MovieTimeFrameNumber = frame;

            Entities
                .ForEach((
                    Entity entity,
                    DynamicBuffer<StoryLookaheadInfo> lookaheadData,
                    ref StoryLookaheadWindow lookahead,
                    in CmTarget target,
                    in LocalToWorld l2w,
                    in BaseStoryWeight template) =>
                {
                    lookahead.AddHead(lookaheadData, new StoryLookaheadInfo
                    {
                        Info = new StoryLookaheadInfo.TargetInfo
                        {
                            Position = l2w.Position,
                            Rotation = l2w.Rotation,
                            Radius = target.Radius,
                            Value = template.WeightDefinition.Amount
                        },
                        FrameNumber = frame
                    });
                })
                .Run();
        }
    }
}
