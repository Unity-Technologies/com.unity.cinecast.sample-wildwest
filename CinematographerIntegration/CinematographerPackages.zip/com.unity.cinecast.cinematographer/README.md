# Cinecast Cinematographer

This package builds on top of [Cinemachine.DOTS](https://github.cds.internal.unity3d.com/unity/dots/tree/master/Packages/com.unity.cinemachine.dots) and [Cinecast](https://github.cds.internal.unity3d.com/unity/com.unity.cinecast) to deliver procedural cinematography for games.

Procedural cinematography consists of smart cameras that intelligently track their targets and evaluate the quality of their shots - taking into account the current story value of the targets within their frames - plus a Director module that chooses the best shots in real time and assembles them into a cinematic sequence while respecting common cinematographic rules governing the quality of the shot sequence.

This automatically-generated edit can be used to generate cutscene, or replays, or if integrated with the Cinecast platform it can provide the basis for a spectator's cinematic experience of a game. The generated sequence can be influenced by the spectator, who has the option to control such things as shot type, focus targets, shot length, and the like.

Furthermore, when used with Cinecast, the Director module can look ahead into the future and generate proactive edits, so the cameras can get to the important action just as it's about to happen, instead of just after it happens.

## Requirements

Assuming that your game has implemented Cinecast POIs with nontrivial interest events, procedural cameras can be authored using this kit.  

For scalability (a complex scene may have hundreds or even thousands of active procedural cameras, each doing raycasts and evaluating shot quality) Procedural Cinematography is implemented in DOTS, using the still-in-development Cinemachine.DOTS package. This does not mean that your game must be implemented in DOTS. Cinemachine.DOTS can work equally well in pure-DOTS and DOTS/GameObject hybrid games.  
The only prerequisite is that the game be built in a version of Unity that supports DOTS.  Currently, that's the DOTS-aware version of 2020.3 LTS and (soon) 2021.3 LTS.
