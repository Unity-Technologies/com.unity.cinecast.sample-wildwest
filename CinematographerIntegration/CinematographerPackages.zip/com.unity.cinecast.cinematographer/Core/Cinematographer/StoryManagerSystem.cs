using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System.Runtime.CompilerServices;
using System;
using System.Threading;
using Unity.Collections.LowLevel.Unsafe;
using System.Collections.Generic;
using UnityEngine;
using Unity.Cinemachine.Core;

namespace Unity.Cinecast.Cinematographer.Core
{
    [Serializable]
    [InternalBufferCapacity(4)]
    public struct VolatileWeight : IBufferElementData
    {
        public enum DecayType { Linear, Exponential };

        /// <summary>
        /// An ID to uniquely identify the weight category.  Different categories
        /// may decay differently.  Client manages these IDs, which for best performance
        /// should be contiguous.
        /// </summary>
        [UnityEngine.Tooltip("An ID to uniquely identify the weight category.  Different categories "
            + "may decay differently.  Client manages these IDs, which for best performance "
            + "should be contiguous.")]
        public int Id;

        /// <summary>
        /// Current amount of the weight which is decaying over time
        /// </summary>
        [UnityEngine.Tooltip("Current amount of the weight which is decaying over time.")]
        public float Amount;

        /// <summary>
        /// The manner of decay
        /// </summary>
        [UnityEngine.Tooltip("The manner of decay.")]
        public DecayType Decay;

        /// <summary>
        /// The rate at which decay occurs.  This is interpreted differently depending on the decay type:
        ///  - Linear decay: this is the amount per second that evaporates
        ///  - Exponential decay: this is the time after which there will be a negligible amount remaining
        /// </summary>
        [UnityEngine.Tooltip("The rate at which decay occurs.  This is interpreted differently depending "
            + "on the decay type:\n"
            + " - Linear decay: this is the amount per second that evaporates\n"
            + " - Exponential decay: this is the time after which there will be a negligible amount remaining.")]
        public float DecayRate;

        /// <summary>
        /// Cap on amount - attempts to add more than this will be ignored.  0 means no cap.
        /// </summary>
        public float MaxAmount;
    }

    static class VolatileWeightExtensions
    {
        /// <summary>
        /// Decay the amount over deltaTime.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float PerformDecay(this VolatileWeight vw, float deltaTime)
        {
            const float Epsilon = MathHelpers.Epsilon;
            const float kExponentialDecayConstant = 4.60517018599f; // Log(1/0.01) where 0.01 = negligible residual
            vw.Amount = math.select(
                math.select(
                    vw.Amount / math.exp(kExponentialDecayConstant * deltaTime / vw.DecayRate),
                    0,
                    vw.DecayRate < Epsilon || math.abs(vw.Amount) < Epsilon),
                vw.Amount - math.min(vw.Amount, vw.DecayRate * deltaTime),
                vw.Decay == VolatileWeight.DecayType.Linear);
            // Clamp to max, if any
            var max = math.select(vw.Amount, vw.MaxAmount, vw.MaxAmount > 0);
            vw.Amount = math.min(vw.Amount, max);
            return vw.Amount;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float DecayInterest(this DynamicBuffer<VolatileWeight> weights, float deltaTime)
        {
            float sum = 0;
            for (int i = 0; i < weights.Length; ++i)
            {
                var v = weights[i];
                sum += v.PerformDecay(deltaTime);
                weights[i] = v;
            }
            return sum;
        }
    }

    /// <summary>
    /// Settings that control how the story manager processes StoryThreads, accumulating interest,
    /// emotional value, and Urgency.  Urgency represents how important it is for a POI to be
    /// on-screen, and is computed by combining a POIs story interest with its starvation value.
    /// Starvation increases while the POI is offscreen, and goes to 0 when the POI is on-screen.
    /// Note: emotional value is not implemented yet. 
    /// </summary>
    [Serializable]
    public struct StoryManagerSettings : ISharedComponentData
    {
        [Tooltip("How much interest to accumulate for a POI over the starvation time when the POI is not "
            + "visible on-screen.  Starvation growth only occurs for a POI if it has nonzero interest.  "
            + "It represents story value generated as a result of the POI being starved "
            + "for screen time, for the purpose of ensuring that low-interest POIs get occasional "
            + "screen time despite being less interesting than other things.  "
            + "POI starvation immediately returns to 0 whenever the POI is on-screen.")]
        [Range(0, 1)]
        public float ThreadStarvationBoostAmount;

        [Tooltip("The time (in seconds) over which the thread starvation amount for a POI grows to "
            + "its full value.  The POI needs to be offscreen continuously for this length of time "
            + "in order for its starvation boost amount to reach its maximum value.")]
        public float ThreadStarvationGrowthTime;
    }

    [Serializable]
    public struct StoryThread : IComponentData
    {
        public enum ViewHemisphere
        {
            None,
            Front,
            Behind,
            TopDown,
            BottomUp,
            LeftSide,
            RightSide
        }
        public ViewHemisphere PreferredView;
    }

    [Serializable]
    public struct StoryThreadState : IComponentData
    {
        /// <summary>
        /// Interest level - Controlled by the dev, to focus on a specific thread judged relevant.
        /// This is used as part of the weighting algorithm when calculating urgency
        /// </summary>
        public float InterestLevel;

#if false // Future expansion
        /// <summary>
        /// Emotional color.  The precise meanings of the axes are chosen by the dev.
        /// One possibility:
        ///  x - Stress/Calm axis (tension)
        ///  y - Fear/Confidence axis (control)
        ///  z - Negative/Positive axis (attitude)
        /// </summary>
        public float3 Emotion;
#endif

        /// <summary>
        /// Time of last nonzero interest
        /// </summary>
        public double TimeLastNonzeroInterest;

        /// <summary>
        /// Time when last on-screen time began
        /// </summary>
        public double TimeLastNotSeen;

        /// <summary>
        /// Time when last on-screen time ended
        /// </summary>
        public double TimeLastSeen;

        /// <summary>
        /// Is the story thread currently visible on-screen?
        /// </summary>
        public bool IsLive;

        /// <summary>
        /// This amount increases while live, decreases otherwise
        /// </summary>
        internal VolatileWeight ScreenSatisfaction;

        /// <summary>
        /// Urgency - This is a combination of InterestLevel and ScreenSatisfaction.
        /// It represents how important it is to put this StoryThread on-screen immediately.
        /// The Urgency evolution function is non-trivial and is configurable.
        /// </summary>
        public float Urgency;
    }


    [UpdateBefore(typeof(CmTargetSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public unsafe partial class StoryManagerSystem : CinemachineSystemBase
    {
        TransitionQualitySystem m_TransitionQualitySystem;

        EntityQuery m_missingStateQuery;

        // There are 3 values maintained:
        // m_UrgencySumAccumulator[0] == sum(urgencies)
        // m_UrgencySumAccumulator[1] == current Frame
        // m_UrgencySumAccumulator[2] == current FPS
        long* m_UrgencySumAccumulator;

        public long MovieTimeFrameNumber
        {
            get => Interlocked.Read(ref *(m_UrgencySumAccumulator + 1));
            set => Interlocked.Exchange(ref *(m_UrgencySumAccumulator + 1), value);
        }

        public long CurrentFPS
        {
            get => Interlocked.Read(ref *(m_UrgencySumAccumulator + 2));
            set => Interlocked.Exchange(ref *(m_UrgencySumAccumulator + 2), value);
        }

        public float DesiredLookaheadTime { get; set; }
        public long LookaheadFrames => math.max(0, (long)math.round(CurrentFPS * DesiredLookaheadTime));
        public long GameTimeFrameNumber => MovieTimeFrameNumber + LookaheadFrames;

        List<StoryManagerSettings> m_ManagerSettings = new List<StoryManagerSettings>();

        protected override void OnCreate()
        {
            m_TransitionQualitySystem = World.GetOrCreateSystem<TransitionQualitySystem>();

            m_missingStateQuery = GetEntityQuery(
                ComponentType.ReadOnly(typeof(StoryThread)),
                ComponentType.Exclude<StoryThreadState>());

            m_UrgencySumAccumulator = (long*)UnsafeUtility.Malloc(
                3 * sizeof(long), UnsafeUtility.AlignOf<long>(), Allocator.Persistent);

            MovieTimeFrameNumber = 0;
            CurrentFPS = 0;
        }

        protected override void OnDestroy()
        {
            UnsafeUtility.Free(m_UrgencySumAccumulator, Allocator.Persistent);
            m_UrgencySumAccumulator = null;
            base.OnDestroy();
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Before processing new positions we capture current camera data from previous frame
            m_TransitionQualitySystem.SnapshotCurrentCameraStateAndTargets();

            m_ManagerSettings.Clear();
            EntityManager.GetAllUniqueSharedComponentData(m_ManagerSettings);
            if (m_ManagerSettings.Count < 2)
                return;
            var settings = m_ManagerSettings[m_ManagerSettings.Count-1];

            // Add any missing state components
            EntityManager.AddComponent(m_missingStateQuery, ComponentType.ReadWrite<StoryThreadState>());

            // Tick the threads
            *m_UrgencySumAccumulator = 0;

            var now = ClientHooks.GetCurrentTime(World);
            var deltaTime = ClientHooks.GetDeltaTime(World);
            var threadStarvationBoostAmount = settings.ThreadStarvationBoostAmount;
            var threadStarvationGrowthTime = settings.ThreadStarvationGrowthTime;
            var movieTimeFrame = MovieTimeFrameNumber;
            var gameTimeFrame = GameTimeFrameNumber;
            var urgencySumAccumulator = m_UrgencySumAccumulator;
            var backbufferStart = movieTimeFrame - LookaheadFrames;

            const float kUrgencyMultiplier = 1000; // Need for normalizing using longs

            Entities
                .WithName("StoryTickJob")
                .WithNativeDisableUnsafePtrRestriction(urgencySumAccumulator)
                .ForEach((
                    DynamicBuffer<StoryLookaheadInfo> lookaheadData,
                    ref StoryLookaheadWindow lookahead,
                    ref StoryThreadState state,
                    in StoryThread storyThread) =>
                {
                    if (state.IsLive)
                        state.TimeLastSeen = now;
                    else
                        state.TimeLastNotSeen = now;

                    // We compute the urgency as a weird hybrid: GameTime interest combined
                    // with MovieTime screen starvation.  This is a compromise because there is
                    // no way to know GameTime screen starvation as screen time is inherently
                    // a MovieTime concept.
                    float interest = 0;
                    if (!lookahead.IsEmpty())
                    {
                        // Advance game time 
                        while (lookahead.GameTimeFrame(lookaheadData) < gameTimeFrame)
                            if (!lookahead.AdvanceGameTime(lookaheadData))
                                break; // not enough lookahead data

                        // Advance movie time 
                        while (lookahead.MovieTimeFrame(lookaheadData) < movieTimeFrame)
                            if (!lookahead.AdvanceMovieTime(lookaheadData))
                                break; // not enough lookahead data

                        // Measure GameTime interest
                        interest = lookahead.GameTimeValue(lookaheadData).Info.Value;

                        // Trim past history, keeping a buffer for prewariming
                        while (lookahead.NumFrames > 1 && lookahead.TailTimeFrame(lookaheadData) < backbufferStart)
                            lookahead.RemoveTail(lookaheadData);
                    }

                    // Compute the movie time urgency
                    float starvationBoost = 0;
                    if (state.IsLive)
                        state.ScreenSatisfaction.Amount = threadStarvationBoostAmount;
                    else if (interest > 0 && threadStarvationBoostAmount > 0)
                    {
                        state.ScreenSatisfaction.DecayRate = threadStarvationGrowthTime;
                        starvationBoost = threadStarvationBoostAmount - state.ScreenSatisfaction.PerformDecay(deltaTime);
                    }

                    if (interest > 0)
                        state.TimeLastNonzeroInterest = now;

                    state.InterestLevel = interest;
                    state.Urgency = (interest + starvationBoost) * kUrgencyMultiplier;
                    Interlocked.Add(ref *urgencySumAccumulator, (long)math.round(state.Urgency));

                    // Take this opportunity to reset IsLive - will get set at the end of the frame
                    state.IsLive = false;
                })
                .ScheduleParallel();

            Entities
                .WithName("NormalizeStoryJob")
                .WithNativeDisableUnsafePtrRestriction(urgencySumAccumulator)
                .ForEach((ref StoryThreadState state) =>
                {
                    var sum = *urgencySumAccumulator;
                    state.Urgency = math.select(0, state.Urgency / sum, sum > 0);
                })
                .ScheduleParallel();
        }
    }
}
