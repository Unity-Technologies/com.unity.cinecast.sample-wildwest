using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System;
using UnityEngine;
using System.Runtime.CompilerServices;
using Unity.Cinemachine.Core;

namespace Unity.Cinecast.Cinematographer.Core
{
    [Serializable]
    public struct StoryThreadTracker : IComponentData
    {
        public float SearchRadius;
        public float MinimumTargetDistance;
        //public float RefreshInterval;   // GML TODO: Time between refreshes - 0 for continuous

        public bool AutoLookAt;
        public float CameraTargetStickiness;
        public float AngularHysteresis;
        public float FollowTargetFixedScale;
#if CINEMACHINE_UNITY_PHYSICS
        [UnityPhysicsLayerMask]
        public int OcclusionLayers;
#endif
#if CINEMACHINE_LEGACY_PHYSICS
        public UnityEngine.LayerMask LegacyOcclusionLayers;
#endif
        public float GroupMemberBlendTime;

        /// <summary>If greater than zero, a higher score will be given to shots when the target
        /// is closer to this distance.  Set this to zero to disable this feature</summary>
        [Tooltip("If greater than zero, a higher score will be given to shots when "
            + "the target is closer to this distance.  Set this to zero to disable this feature.")]
        public float OptimalTargetDistance;
    }

    public abstract partial class StoryThreadTrackerSystemBase : CinemachineSystemBase
    {
        // GML todo: make private
        [InternalBufferCapacity(8)]
        public struct VisibleTarget : IBufferElementData
        {
            public StoryLookaheadInfo.TargetInfo Info;
            public StableKey StableKey;
            public Entity Entity;
            public float Scale;
        }

        protected struct StoryThreadTrackerState : IComponentData
        {
            public double LastRefreshTime;
            public Entity GameTimeStickyTarget;
            public double GameTimeStickyTargetStartTime;
        }

        struct SpacePartitionTargetItem
        {
            public StoryLookaheadInfo.TargetInfo TargetInfo;
            public StableKey StableKey;
            public Entity Entity;
        }

        // GML todo: make a proper space partition (this one is fake and will not scale with many POIs)
        static NativeArray<SpacePartitionTargetItem> m_SpacePartition = new NativeArray<SpacePartitionTargetItem>();

        EntityQuery m_nodeQuery;
        EntityQuery m_storyThreadQuery;

#if CINEMACHINE_UNITY_PHYSICS
        Physics.Systems.BuildPhysicsWorld m_physicsWorldSystem;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_physicsWorldSystem = World.GetOrCreateSystem<Physics.Systems.BuildPhysicsWorld>();
        }

        protected override void OnStartRunning()
        {
            base.OnStartRunning();
            Physics.Systems.PhysicsRuntimeExtensions.RegisterPhysicsRuntimeSystemReadOnly(this);
        }
#endif

        protected override void OnDestroy()
        {
            base.OnDestroy();
            if (m_SpacePartition.IsCreated)
                m_SpacePartition.Dispose();
        }

        int AllocateSpacePartition()
        {
            var storyThreadCount = m_storyThreadQuery.CalculateEntityCount();
            if (storyThreadCount > 0)
            {
                if (m_SpacePartition.IsCreated)
                {
                    if (m_SpacePartition.Length == storyThreadCount)
                        return storyThreadCount;
                    m_SpacePartition.Dispose();
                }
                m_SpacePartition = new NativeArray<SpacePartitionTargetItem>(storyThreadCount, Allocator.Persistent);
            }
            return storyThreadCount;
        }

        protected void CollectTargetsGameTime()
        {
            // Build space partition in game time
            if (AllocateSpacePartition() == 0)
                return;

            var spacePartition = m_SpacePartition;
            Entities
                .WithName("HashPositionsGameTimeJob")
                .WithStoreEntityQueryInField(ref m_storyThreadQuery)
                .WithAll<StoryThread, StoryThreadState>()
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    DynamicBuffer<StoryLookaheadInfo> data,
                    in StoryLookaheadWindow lookahead,
                    in StableKeyData key) =>
                {
                    if (!lookahead.IsEmpty())
                    {
                        // GML todo: what about urgency???  we're ignoring it in game time
                        spacePartition[entityInQueryIndex] = new SpacePartitionTargetItem
                        {
                            TargetInfo = lookahead.GameTimeValue(data).Info,
                            Entity = entity,
                            StableKey = key.Value
                        };
                    }
                })
                .Schedule(); // faster in single thread

#if CINEMACHINE_UNITY_PHYSICS
            var collisionWorld = m_physicsWorldSystem.PhysicsWorld.CollisionWorld;
#endif
            var timeNow = ClientHooks.GetCurrentTime(World);

            Entities
                .WithName("CollectTargetsGameTimeJob")
#if CINEMACHINE_UNITY_PHYSICS
                .WithReadOnly(collisionWorld)
#endif
                .WithReadOnly(spacePartition)
                .WithAll<StoryLookaheadWindow, StoryLookaheadInfo>()
                .ForEach((
                    DynamicBuffer<VisibleTarget> visibleTargets, 
                    ref StoryThreadTrackerState state,
                    in StoryThreadTracker settings,
                    in FollowTargetState follow, // this holds a gametime position
                    in PositionState posState,
                    in NodeUpdateState updateState) =>
                {
                    // GML todo: Round-robin the target collection
//                        if (updateState.PreviousFrameDataIsValid && timeNow - state.LastRefreshTime < settings.RefreshInterval)
//                            return;
                    state.LastRefreshTime = timeNow;

                    var oldTargets = new NativeHashSet<Entity>(visibleTargets.Length, Allocator.Temp);
                    for (int i = 0; i < visibleTargets.Length; ++i)
                        oldTargets.Add(visibleTargets[i].Entity);
                    visibleTargets.Clear();

                    var camPos = posState.GetCorrectedPosition();
                    var camFwd = math.forward(posState.GetCorrectedRotation());

                    // Get the nearby items 
                    var fixedFollowTarget = settings.FollowTargetFixedScale > 0 ? follow.Value.Entity : Entity.Null;
                    var nearbyItems = new NativeList<SpacePartitionTargetItem>(spacePartition.Length, Allocator.Temp);
                    GetItemsInSphere(
                        spacePartition, camPos, nearbyItems, settings.MinimumTargetDistance,
                        settings.SearchRadius, fixedFollowTarget);

                    if (settings.AutoLookAt)
                    {
                        // The sticky target is used as a base from which to measure angles of other visible targets.
                        // If this is < 0 then no targets are visible
                        var stickyTargetIndex = ProcessStickyTarget(
                            nearbyItems, ref state, settings.CameraTargetStickiness, timeNow);
                        if (stickyTargetIndex < 0)
                            return; // no targets
                        // Have we just changed sticky target?
                        if (state.GameTimeStickyTargetStartTime == timeNow)
                            camFwd = math.normalizesafe(nearbyItems[stickyTargetIndex].TargetInfo.Position - camPos, camFwd);
                    }

                    // Find other targets that are in view
                    // Use an average of H and V FOV, because we don't know the exact orientation of the camera. GML: NOT TRUE ANYMORE!
                    var maxFov = math.radians(posState.MaxFOV);
                    var fov2 = new float2(math.atan(math.tan(maxFov) * updateState.Aspect), maxFov);
                    var halfFov = (fov2.x + fov2.y) * 0.25f;
                    var halfFovHysteresis = halfFov - math.radians(settings.AngularHysteresis) / 2;
                    var tanHalfFov = math.tan(halfFov);
                    for (int i = 0; i < nearbyItems.Length; ++i)
                    {
                        var item = nearbyItems[i];

                        float scale = settings.FollowTargetFixedScale;
                        if (item.Entity != fixedFollowTarget) // assume fixed follow target is visible
                        {
                            // Check for on-screen and compute scale
                            var dir = item.TargetInfo.Position - camPos;
                            var distance = math.length(dir);
                            if (distance < item.TargetInfo.Radius + 0.01f)
                                continue;
                            dir /= distance;
                            scale = item.TargetInfo.Radius / (tanHalfFov * distance);
                            if (scale < 0.001f)
                                continue;
                            var max = math.select(halfFovHysteresis, halfFov, !oldTargets.IsCreated || oldTargets.Contains(item.Entity));
                            if (MathHelpers.AngleUnit(dir, camFwd) > max)
                                continue; // target outside of screen
#if CINEMACHINE_UNITY_PHYSICS
                            var collisionLayerMask = unchecked((uint)settings.OcclusionLayers);
                            if (collisionLayerMask != 0 && IsTargetOccluded(
                                    item.Entity, item.TargetInfo.Position, camPos,
                                    collisionWorld, collisionLayerMask))
                                continue;
#endif
                        }
                        visibleTargets.Add(new VisibleTarget
                        {
                            Info = item.TargetInfo,
                            StableKey = item.StableKey,
                            Entity = item.Entity,
                            Scale = scale,
                        });
                    }
                })
                .ScheduleParallel();

#if CINEMACHINE_LEGACY_PHYSICS
            CullOccludedTargets(spacePartition.Length);
#endif

            // Rebuild space partition in movie time - we do it here to improve parallelism
            Entities
                .WithName("HashPositionsMovieTimeJob")
                .WithAll<StoryThread, StoryThreadState>()
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    DynamicBuffer<StoryLookaheadInfo> data,
                    in StoryLookaheadWindow lookahead,
                    in StableKeyData key) =>
                {
                    if (!lookahead.IsEmpty())
                    {
                        // GML todo: what about urgency???  we're ignoring it in game time
                        spacePartition[entityInQueryIndex] = new SpacePartitionTargetItem
                        {
                            TargetInfo = lookahead.MovieTimeValue(data).Info,
                            Entity = entity,
                            StableKey = key.Value
                        };
                    }
                })
                .Schedule(); // faster in single thread
        }

        static int ProcessStickyTarget(
            NativeList<SpacePartitionTargetItem> nearbyItems,
            ref StoryThreadTrackerState state, float targetStickiness,
            double timeNow)
        {
            var stickyTarget = state.GameTimeStickyTarget;
            if (timeNow - state.GameTimeStickyTargetStartTime > targetStickiness)
                stickyTarget = Entity.Null;

            int bestIndex = -1;
            float bestUrgency = 0;

            for (int i = 0; i < nearbyItems.Length; ++i)
            {
                // If sticky target is present, use it
                if (nearbyItems[i].Entity == stickyTarget)
                {
                    bestIndex = i;
                    break;
                }
                // Else use the best target as a new sticky target
                if (nearbyItems[i].TargetInfo.Value >= bestUrgency)
                {
                    bestIndex = i;
                    bestUrgency = nearbyItems[i].TargetInfo.Value;
                }
            }

            if (bestIndex < 0)
            {
                state.GameTimeStickyTarget = Entity.Null;
                state.GameTimeStickyTargetStartTime = 0;
            }
            else if (nearbyItems[bestIndex].Entity != stickyTarget)
            {
                // We lost the old sticky target but have a new one
                state.GameTimeStickyTarget = nearbyItems[bestIndex].Entity;
                state.GameTimeStickyTargetStartTime = timeNow;
            }
            return bestIndex;
        }

        protected void CollectTargetsMovieTime()
        {
            // Space partition has already been built in movie time
            if (!m_SpacePartition.IsCreated || m_SpacePartition.Length == 0)
                return;

            var spacePartition = m_SpacePartition;

#if CINEMACHINE_UNITY_PHYSICS
            var collisionWorld = m_physicsWorldSystem.PhysicsWorld.CollisionWorld;
#endif

            Entities
                .WithName("CollectTargetsMovieTimeJob")
#if CINEMACHINE_UNITY_PHYSICS
                .WithReadOnly(collisionWorld)
#endif
                .WithReadOnly(spacePartition)
                .ForEach((
                    DynamicBuffer<VisibleTarget> visibleTargets,
                    DynamicBuffer<StoryLookaheadInfo> lookaheadData, 
                    in StoryLookaheadWindow lookahead,
                    in StoryThreadTracker settings,
                    in FollowTargetState follow, // this holds a gametime position
                    in NodeUpdateState updateState) =>
                {
                    visibleTargets.Clear();
                    if (lookahead.IsEmpty())
                        return;

                    var v = lookahead.MovieTimeValue(lookaheadData).Info;
                    var camPos = v.Position;
                    var camFwd = math.forward(v.Rotation);
                    var fov = math.radians(v.Radius);

                    // Get the nearby items 
                    // Use an average of H and V FOV, because we don't know the exact orientation of the camera. GML: NOT TRUE ANYMORE!
                    var fixedFollowTarget = settings.FollowTargetFixedScale > 0 ? follow.Value.Entity : Entity.Null;
                    var nearbyItems = new NativeList<SpacePartitionTargetItem>(spacePartition.Length, Allocator.Temp);
                    var fov2 = new float2(math.atan(math.tan(fov) * updateState.Aspect), fov);
                    var halfFov = (fov2.x + fov2.y) * 0.25f;
                    GetItemsinCone(
                        spacePartition, camPos, camFwd, halfFov, settings.MinimumTargetDistance,
                        settings.SearchRadius, nearbyItems, fixedFollowTarget);

                    // Compute scale, test for occlusion, and add to visible targets
                    var tanHalfFov = math.tan(halfFov);
                    for (int i = 0; i < nearbyItems.Length; ++i)
                    {
                        var item = nearbyItems[i];
                        float scale = settings.FollowTargetFixedScale;
                        if (item.Entity != fixedFollowTarget)
                        {
                            var dir = item.TargetInfo.Position - camPos;
                            var distance = math.length(dir);
                            if (distance < item.TargetInfo.Radius + 0.01f)
                                continue;
                            dir /= distance;
                            scale = item.TargetInfo.Radius / (tanHalfFov * distance);
                            if (scale < 0.001f)
                                continue;
#if CINEMACHINE_UNITY_PHYSICS
                            var collisionLayerMask = unchecked((uint)settings.OcclusionLayers);
                            if (collisionLayerMask != 0 && IsTargetOccluded(
                                    item.Entity, item.TargetInfo.Position, camPos,
                                    collisionWorld, collisionLayerMask))
                                continue;
#endif
                        }
                        visibleTargets.Add(new VisibleTarget
                        {
                            Info = item.TargetInfo,
                            StableKey = item.StableKey,
                            Entity = item.Entity,
                            Scale = scale,
                        });
                    }
                })
                .ScheduleParallel();

#if CINEMACHINE_LEGACY_PHYSICS
            CullOccludedTargets(spacePartition.Length);
#endif
        }

        static void GetItemsInSphere(
            NativeArray<SpacePartitionTargetItem> spacePartition,
            float3 camPos, NativeList<SpacePartitionTargetItem> items,
            float minDistance, float maxDistance, Entity forceIncludeTarget)
        {
            var min2 = minDistance * minDistance;
            var max2 = maxDistance * maxDistance;
            for (int i = 0; i < spacePartition.Length; ++i)
            {
                var d2 = math.lengthsq(spacePartition[i].TargetInfo.Position - camPos);
                if (d2 >= min2 && d2 <= max2 || forceIncludeTarget == spacePartition[i].Entity)
                    items.Add(spacePartition[i]);
            }
        }

        static void GetItemsinCone(
            NativeArray<SpacePartitionTargetItem> spacePartition,
            float3 camPos, float3 camFwd, float halfFovRadians,
            float minDistance, float maxDistance,
            NativeList<SpacePartitionTargetItem> items,
            Entity forceIncludeTarget)
        {
            var min2 = minDistance * minDistance;
            var max2 = maxDistance * maxDistance;
            for (int i = 0; i < spacePartition.Length; ++i)
            {
                var pos = spacePartition[i].TargetInfo.Position;
                var d2 = math.lengthsq(pos - camPos);
                if (d2 >= min2 && d2 <= max2
                    && (spacePartition[i].Entity == forceIncludeTarget
                        || MathHelpers.AngleUnit(math.normalize(pos - camPos), camFwd) < halfFovRadians))
                    items.Add(spacePartition[i]);
            }
        }

#if CINEMACHINE_UNITY_PHYSICS
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static bool IsTargetOccluded(
            Entity targetEntity, float3 start, float3 end,
            Physics.CollisionWorld collisionWorld, uint layerMask)
        {
            if (collisionWorld.Bodies.Length == 0)
                return false;
            var input = new Physics.RaycastInput()
            {
                Start = start,
                End = end,
                Filter = new Physics.CollisionFilter()
                {
                    BelongsTo = unchecked(layerMask),
                    CollidesWith = unchecked(layerMask),
                    GroupIndex = 0
                }
            };
            return CollisionHelpers.RaycastNearestIgnoreEntity(
                collisionWorld, input, targetEntity, out Physics.RaycastHit hitInfo);
        }
#endif

#if CINEMACHINE_LEGACY_PHYSICS
        unsafe void CullOccludedTargets(int storyThreadCount)
        {
            int numNodes = m_nodeQuery.CalculateEntityCount();
            var maxTargets = storyThreadCount * numNodes;
            if (maxTargets == 0)
                return;

            // These will be deallocated by the final job
            var raycastCommands = new NativeArray<UnityEngine.RaycastCommand>(maxTargets, Allocator.TempJob);
            var raycastHits = new NativeArray<UnityEngine.RaycastHit>(maxTargets, Allocator.TempJob);
            var indexMap = new NativeHashMap<Entity, int>(numNodes + 1, Allocator.TempJob);
            indexMap[Entity.Null] = 0; // use this value as a counter

            Entities
                .WithName("SetupCullOccludedTargetsJob")
                .WithStoreEntityQueryInField(ref m_nodeQuery)
                .WithAll<NodeChannelAssignment, StoryLookaheadWindow>()
                .ForEach((
                    Entity entity,
                    DynamicBuffer<VisibleTarget> targets,
                    in StoryThreadTracker settings,
                    in PositionState posState) =>
                {
                    if (settings.LegacyOcclusionLayers == 0)
                        return;

                    var raycastIndex = indexMap[Entity.Null];
                    indexMap[entity] = raycastIndex;

                    var camPos = posState.GetCorrectedPosition();
                    int numTargets = targets.Length;
                    for (int i = 0; i < numTargets; ++i)
                    {
                        // cast back towards the camera to filter out target's collider
                        float3 dir = camPos - targets[i].Info.Position;
                        float distance = math.length(dir);
                        dir /= distance;
                        raycastCommands[raycastIndex++] = new UnityEngine.RaycastCommand(
                            targets[i].Info.Position + targets[i].Info.Radius * dir, dir,
                            math.max(0, distance - targets[i].Info.Radius), settings.LegacyOcclusionLayers);
                    }
                    indexMap[Entity.Null] = raycastIndex;
                })
                .Schedule();
                Dependency = UnityEngine.RaycastCommand.ScheduleBatch(raycastCommands, raycastHits, 32, Dependency);

            Entities
                .WithName("CullOccludedTargetsJob")
                .WithDisposeOnCompletion(raycastHits)
                .WithDisposeOnCompletion(raycastCommands)
                .WithDisposeOnCompletion(indexMap)
                .WithReadOnly(raycastHits)
                .WithReadOnly(raycastCommands)
                .WithReadOnly(indexMap)
                .WithAll<NodeChannelAssignment, StoryLookaheadWindow, PositionState>()
                .ForEach((
                    Entity entity,
                    DynamicBuffer<VisibleTarget> targets,
                    in StoryThreadTracker settings) =>
                {
                    // GML hack workaround for bug DOTS-3634: reference it so raycastCommands can be deallocated
                    var foo = raycastCommands[0].layerMask;

                    if (settings.LegacyOcclusionLayers != 0)
                    {
                        if (indexMap.TryGetValue(entity, out var raycastIndex))
                        {
                            for (int i = targets.Length - 1; i >= 0; --i) 
                            {
                                if (raycastHits[raycastIndex + i].normal != UnityEngine.Vector3.zero)
                                    targets.RemoveAtSwapBack(i);
                            }
                        }
                    }
                })
                .Schedule();
        }
#endif
    }
}
