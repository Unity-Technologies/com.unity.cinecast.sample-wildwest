using Unity.Entities;
using Unity.Cinemachine.Core;

namespace Unity.Cinecast.Cinematographer.Core
{
    [UpdateAfter(typeof(NodeBlendStackSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class StoryThreadEndFrameUpdateSystem : CinemachineSystemBase
    {
        EntityQuery m_nodeQuery;

        protected override void OnUpdate()
        {
            base.OnUpdate();

            if (m_nodeQuery.CalculateEntityCount() == 0)
                return;

            var threads = GetComponentDataFromEntity<StoryThreadState>(false);

            Entities
                .WithName("MarkThreadsLive")
                .WithStoreEntityQueryInField(ref m_nodeQuery)
                .WithAll<NodeChannelAssignment, StoryThreadTracker>()
                .ForEach((
                    DynamicBuffer<StoryThreadTrackerSystemBase.VisibleTarget> targets,
                    in NodeUpdateState updateState) =>
                {
                    if (updateState.IsLive)
                    {
                        for (int i = 0; i < targets.Length; ++i)
                        {
                            if (threads.HasComponent(targets[i].Entity))
                            {
                                var th = threads[targets[i].Entity];
                                th.IsLive = true;
                                threads[targets[i].Entity] = th;
                            }
                        }
                    }
                }).Schedule();
        }
    }
}
