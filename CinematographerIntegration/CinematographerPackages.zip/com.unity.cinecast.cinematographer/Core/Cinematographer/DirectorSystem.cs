using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Unity.Collections;
using UnityEngine;
using Unity.Cinemachine.Core;

namespace Unity.Cinecast.Cinematographer.Core
{
    /// <summary>
    /// These global settings control how the shot sequence is determined, based
    /// on input shot quality measurements and preferred shot type filters.
    /// </summary>
    [Serializable]
    public struct DirectorTuning : ISharedComponentData 
    {
        [Serializable]
        public struct DirectorSettings
        {
            [Tooltip("Relative importance of Shot Quality compared to Transition Quality.  "
                + "The final camera quality will be a combination of Shot Quality and Transition Quality, "
                + "weighted in proportion to the assigned weight specified in this setting")]
            public float ShotQualityWeight;

            [Tooltip("Relative importance of Transition Quality compared to Shot Quality.  "
                + "The final camera quality will be a combination of Shot Quality and Transition Quality, "
                + "weighted in proportion to the assigned weight specified in this setting.  "
                + "Transition Quality is defined as the quality of the cut between the current active "
                + "shot and the proposed shot.")]
            public float TransitionQualityWeight;

            [Tooltip("The desired average shot length (in seconds).  This value can be adjusted "
                + "dynamically to control the pacing of the shot sequence.  Shots are not "
                + "guaranteed to be exactly this length but will on average respect this constraint.  "
                + "Quality considerations can override the pacing rule.")]
            public float AverageShotLength;

            [Tooltip("POI lookahead is driven automatically by the average shot length.  However, this "
                + "setting can be used to specify an upper limit on the lookahead, to avoid spending "
                + "too many resources, and to limit the potential lag between the game and the spectator event.")]
            public float MaxLookaheadTime;

            [Tooltip("The Lens filter.  This is intended to be adjusted dynamically as the game progresses.  "
                + "Cameras whose FOVs are within this range will be preferred.")]
            [Float2AsRangeProperty]
            public float2 PreferredLens;
        }
        [HideFoldout]
        public DirectorSettings Settings;
    }

    [Serializable]
    public struct DirectorFilter : IComponentData
    {
        /// <summary>
        /// A client-defined value for filtering camera types.
        /// The 0 value is reserved to mean "not set".
        /// </summary>
        public int CameraType;

        /// <summary>
        /// The POI that the camera is following
        /// </summary>
        public StableKey FollowTarget;
    }

    [Serializable]
    public struct DirectorState : IComponentData
    {
        // For analysis of final quality
        public enum AnalysisCode
        {
            None = 0,
            PacingDominates     = 1,    // Pacing rule overrules selection of this shot (colored magenta in the monitor)
            NoValidTargets      = 2,    // Shot does not contain desired POIs
            FailsCameraTypeFilter = 4,  // Camera is not the desired type
            FailsFollowFilter   = 8,    // Camera is not following the desired target
            FailsLensFilter     = 16,   // Camera does not have the desired FOV
            LowMovieTimeQuality = 32,   // Shot has low quality at movie time
            //DataBufferNotFull   = 64,  // Sausage is not long enough (minimum required is 90% of lookahead time)
            //NotUpdatedThisFrame = 128, // Shot does not have a quality measure for this game time frame
        };
        public AnalysisCode Code;
    }

    [UpdateAfter(typeof(TransitionQualitySystem))]
    [UpdateBefore(typeof(CmChannelSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class DirectorSystem : CinemachineSystemBase
    {
        CmChannelSystem m_channelSystem;
        StoryManagerSystem m_storyManagerSystem;
        EntityQuery m_missingStateQuery;
        List<DirectorTuning> m_Settings = new List<DirectorTuning>();

        JobHandle m_PreviousDependency;
        NativeHashSet<StableKey> m_FocusTargets;
        NativeHashSet<StableKey> m_FollowTargets;
        NativeList<int> m_CameraTypeFilter;

        bool m_SuspendShotPacing;

        public void SetFocusTargets(IReadOnlyList<StableKey> targets)
        {
            m_PreviousDependency.Complete();
            if (m_FocusTargets.Count() < targets.Count)
            {
                m_FocusTargets.Dispose();
                m_FocusTargets = new NativeHashSet<StableKey>(targets.Count, Allocator.Persistent);
            }
            m_FocusTargets.Clear();
            foreach (var t in targets)
                m_FocusTargets.Add(t);
        }

        public void SetFollowTargets(IReadOnlyList<StableKey> targets)
        {
            m_PreviousDependency.Complete();
            if (m_FollowTargets.Count() < targets.Count)
            {
                m_FollowTargets.Dispose();
                m_FollowTargets = new NativeHashSet<StableKey>(targets.Count, Allocator.Persistent);
            }
            m_FollowTargets.Clear();
            foreach (var t in targets)
                m_FollowTargets.Add(t);
        }

        public void SetCameraTypeFilter(IReadOnlyList<int> cameraTypes)
        {
            m_PreviousDependency.Complete();
            if (m_CameraTypeFilter.Capacity < cameraTypes.Count)
            {
                m_CameraTypeFilter.Dispose();
                m_CameraTypeFilter = new NativeList<int>(cameraTypes.Count, Allocator.Persistent);
            }
            m_CameraTypeFilter.Clear();
            foreach (var t in cameraTypes)
                m_CameraTypeFilter.Add(t);
        }

        public void GetFilterState(
            List<StableKey> focusTargets,
            List<StableKey> followTargets, 
            List<int> cameraTypes)
        {
            focusTargets.Clear();
            foreach (var i in m_FocusTargets)
                focusTargets.Add(i);
            followTargets.Clear();
            foreach (var i in m_FollowTargets)
                followTargets.Add(i);
            cameraTypes.Clear();
            foreach (var i in m_CameraTypeFilter)
                cameraTypes.Add(i);
        }

        public void SuspendShotPacing(bool suspend)
        {
            m_SuspendShotPacing = suspend;
        }

        protected override void OnCreate()
        {
            base.OnCreate();
            m_FocusTargets = new NativeHashSet<StableKey>(16, Allocator.Persistent);
            m_FollowTargets = new NativeHashSet<StableKey>(16, Allocator.Persistent);
            m_CameraTypeFilter = new NativeList<int>(16, Allocator.Persistent);
            m_channelSystem = World.GetOrCreateSystem<CmChannelSystem>();
            m_storyManagerSystem = World.GetOrCreateSystem<StoryManagerSystem>();
            m_missingStateQuery = GetEntityQuery(
                ComponentType.ReadWrite<DirectorFilter>(),
                ComponentType.Exclude<DirectorState>());
        }

        protected override void OnDestroy()
        {
            m_FocusTargets.Dispose();
            m_FollowTargets.Dispose();
            m_CameraTypeFilter.Dispose();
            base.OnDestroy();
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            EntityManager.AddComponent(m_missingStateQuery,
                ComponentType.ReadWrite<DirectorState>());

            m_Settings.Clear();
            EntityManager.GetAllUniqueSharedComponentData(m_Settings);
            if (m_Settings.Count < 2)
                return;

            bool focusTargetsIsEmpty = m_FocusTargets.IsEmpty;
            if (!focusTargetsIsEmpty)
            {
                var focusTargets = m_FocusTargets;

                // Handle the case where tracker is looking directly at a target, no group
                Entities
                    .WithName("DirectorFilterCharactersJob")
                    .WithReadOnly(focusTargets)
                    .WithNone<CmTargetGroupBufferElement>()
                    .WithAll<NodeUpdateState>()
                    .ForEach((
                        ref DirectorState directorState,
                        in LookAtTarget lookAt) =>
                    {
                        directorState.Code = (DirectorState.AnalysisCode)math.select(
                            (int)DirectorState.AnalysisCode.NoValidTargets,
                            (int)DirectorState.AnalysisCode.None,
                            focusTargets.Contains(lookAt.Target));
                    })
                    .ScheduleParallel();

                // Handle the case where tracker is looking at a group
                Entities
                    .WithName("DirectorFilterCharactersGroupJob")
                    .WithReadOnly(focusTargets)
                    .WithAll<NodeUpdateState, LookAtTarget>()
                    .ForEach((
                        ref DirectorState directorState,
                        in DynamicBuffer<CmTargetGroupBufferElement> groupMembers) =>
                    {
                        directorState.Code = DirectorState.AnalysisCode.NoValidTargets;
                        for (int i = 0; i < groupMembers.Length; ++i)
                        {
                            if (groupMembers[i].Weight > 0.5f && focusTargets.Contains(groupMembers[i].StableKey))
                            {
                                directorState.Code = DirectorState.AnalysisCode.None;
                                break;
                            }
                        }
                    })
                    .ScheduleParallel();

                m_PreviousDependency = Dependency;
            }

            var settings = m_Settings[m_Settings.Count-1].Settings;

            // Drive the story lookahead time to cover the desired shot length
            var desiredLookhead = math.clamp(settings.AverageShotLength * 0.8f, 0, settings.MaxLookaheadTime);
            m_storyManagerSystem.DesiredLookaheadTime += MathHelpers.Damp(
                desiredLookhead - m_storyManagerSystem.DesiredLookaheadTime,
                desiredLookhead, ClientHooks.GetDeltaTime(World));

            var followTargets = m_FollowTargets;
            var cameraFilter = m_CameraTypeFilter;
            bool suspendShotPacing = m_SuspendShotPacing;

            var channels = m_channelSystem.GetChannelsForFiltering();
            for (int i = 0; i < channels.Count; ++i)
            {
                var activeNode = channels[i].State.ActiveNode;
                var activeDuration = math.max(0, ClientHooks.GetCurrentTime(World) - channels[i].State.ActivationTime);
                var previousStateIsValid = channels[i].State.PreviousStateIsValid;

                Entities
                    .WithName("DirectorJob")
                    .WithSharedComponentFilter(channels[i].Filter)
                    .WithReadOnly(followTargets)
                    .WithReadOnly(cameraFilter)
                    .ForEach((
                        Entity entity, 
                        DynamicBuffer<StoryLookaheadInfo> lookaheadData,
                        ref DirectorState directorState,
                        ref NodeUpdateState updateState,
                        in StoryLookaheadWindow lookahead,
                        in TransitionQuality transitionQuality,
                        in PositionState posState,
                        in DirectorFilter directorFilter) =>
                    {
                        // Make sure the director state code is initialized
                        directorState.Code = (DirectorState.AnalysisCode)math.select(
                            (int)directorState.Code, (int)DirectorState.AnalysisCode.None, focusTargetsIsEmpty);

                        updateState.ShotQuality *= lookahead.GetAverageLookaheadValue();
                        var immediateQuality = lookahead.IsEmpty() ? 0 : lookahead.MovieTimeValue(lookaheadData).Info.Value;
                        if (immediateQuality < 0.2f && updateState.ShotQuality > 0.2f)
                            directorState.Code |= DirectorState.AnalysisCode.LowMovieTimeQuality;

                        // Get the base quality
                        var q = updateState.ShotQuality * settings.ShotQualityWeight;
                        q += transitionQuality.Value * settings.TransitionQualityWeight * immediateQuality;
                        var weightSum = settings.ShotQualityWeight + settings.TransitionQualityWeight;
                        q = math.select(0, q / weightSum, weightSum > 0.001f);

                        // Process focus targets
                        q *= math.select(0.01f, 1, (directorState.Code & DirectorState.AnalysisCode.NoValidTargets) == 0);

                        // Preferred camera type
                        if (cameraFilter.Length > 0)
                        {
                            if (cameraFilter.Contains(directorFilter.CameraType))
                                q += 0.1f;
                            else
                            {
                                q *= 0.01f;
                                directorState.Code |= DirectorState.AnalysisCode.FailsCameraTypeFilter;
                            }
                        }
                        
                        // Preferred Follow target
                        if (followTargets.Count() > 0)
                        {
                            if (followTargets.Contains(directorFilter.FollowTarget))
                                q += 0.1f;
                            else
                            {
                                q *= 0.01f;
                                directorState.Code |= DirectorState.AnalysisCode.FailsFollowFilter;
                            }
                        }
                        // Preferred FOV
                        if (posState.Lens.FOV < settings.PreferredLens.x || posState.Lens.FOV > settings.PreferredLens.y)
                        {
                            q *= 0.01f;
                            directorState.Code |= DirectorState.AnalysisCode.FailsLensFilter;
                        }

                        // Shot pacing
                        if (!suspendShotPacing && previousStateIsValid && entity == activeNode && settings.AverageShotLength > 0)
                        {
                            var pacingMultiplier = GetPacingMultiplierForCurrent((float)activeDuration, settings.AverageShotLength);
                            q *= pacingMultiplier;
                            if (entity == activeNode && pacingMultiplier > 1)
                                directorState.Code |= DirectorState.AnalysisCode.PacingDominates;
                        }
                        updateState.ShotQuality = math.min(1.01f, q);
                    })
                    .ScheduleParallel();
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float GetPacingMultiplierForCurrent(float activeDuration, float averageShotLength)
        {
#if false // GML experiment
            //-((x/(d/2))-1)^3 + 2
            float d = (activeDuration / (averageShotLength / 2)) - 1;
            float m = -(d * d * d) + 2;
#else
            double m = averageShotLength / (activeDuration + 0.01);
#endif
            return (float)math.select(1.0, m, averageShotLength > 0.01f);
        }
    }
}
