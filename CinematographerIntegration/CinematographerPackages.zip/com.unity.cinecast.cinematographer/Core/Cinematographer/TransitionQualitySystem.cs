using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System.Runtime.CompilerServices;
using System;
using System.Collections.Generic;
using UnityEngine;
using Unity.Cinemachine.Core;

namespace Unity.Cinecast.Cinematographer.Core
{
    [Serializable]
    public struct TransitionQualityTuning : ISharedComponentData
    {
        /// <summary>
        /// These global settings control how the quality of shot transitions is evaluated.
        /// A shot transition is a camera cut from shot A to shot B.  The desire is to make
        /// shot transitions as comfortable and cinematic as possible, and this is done by
        /// respecting some cinematographic rules, whose relative importances are defined here.
        /// </summary>
        [Serializable]
        public struct QualitySettings
        {
            /// <summary>Weight of the Director Line Cut Rule.</summary>
            [Tooltip("Relative importance of the Director Line Cut Rule compared to the other weights in this settings object.\n\n"
                + "The Director Line Cut Rule states: \"The camera should stay on one side of an imaginary "
                + "line between two subjects so that each subject always appears to be facing the same direction, "
                + "regardless of where the camera is positioned.\n\n" 
                + "The quality of the shot will be determined in accordance with this rule, in proportion to the "
                + "assigned weight specified in this setting.")]
            public float DirectorLineCutWeight;

            /// <summary>Weight of the Jumnp Cut Rule.</summary>
            [Tooltip("Relative importance of avoiding Jump Cuts compared to the other weights in this settings object.\n\n"
                + "A Jump Cut is an abrupt transition, typically in a sequential clip that makes the subject "
                + "appear to jump from one spot to the other, without continuity. This can happen when two "
                + "sequential shots of the same subject in the same scene are cut together from camera positions "
                + "that vary only slightly.\n\n" 
                + "The quality of the shot will be determined in accordance with this rule, in proportion to the "
                + "assigned weight specified in this setting.")]
            public float JumpCutWeight;

            /// <summary>Weight of look at cut.</summary>
            [Tooltip("Relative importance of avoiding wildly varying subject orientations on the screen when cutting "
                + "between shots that share some subjects.\n\n"
                + "The quality of the shot will be determined in accordance with this rule, in proportion to the "
                + "assigned weight specified in this setting.")]
            public float LookAtCutWeight;

            /// <summary>Weight of move cut.</summary>
            [Tooltip("Relative importance of avoiding wildly varying subject motion on the screen when cutting "
                + "between shots that share some subjects.\n\n"
                + "The quality of the shot will be determined in accordance with this rule, in proportion to the "
                + "assigned weight specified in this setting."
                + "\nNote: this is currently unimplemented.")]
            public float MoveCutWeight;

            /// <summary>Weight of position cut.</summary>
            [Tooltip("Relative importance of avoiding wildly varying subject positions on the screen when cutting "
                + "between shots that share some subjects.\n\n"
                + "The quality of the shot will be determined in accordance with this rule, in proportion to the "
                + "assigned weight specified in this setting.")]
            public float PositionCutWeight;
        }
        [HideFoldout]
        public QualitySettings Settings;
    }

    [Serializable]
    public struct TransitionQuality : IComponentData
    {
        public const float DefaultValue = 1;
        public float Value;
    }

    [UpdateAfter(typeof(CameraFinalizeSystem))]
    [UpdateBefore(typeof(CmChannelSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class TransitionQualitySystem : StoryThreadTrackerSystemBase
    {
        CmChannelSystem m_channelSystem;
        StoryManagerSystem m_storyManagerSystem;

        List<TransitionQualityTuning> m_qualitySettings = new List<TransitionQualityTuning>();

        struct CameraInfo
        {
            public float3 Position;
            public float3 Velocity;
            public float2 Fov2;
            public quaternion Rotation;
            public float3 Fwd;
            public float4x4 World2CamPersp;
        }

        struct TargetInfo
        {
            public StoryLookaheadInfo.TargetInfo Info;
            public Entity Entity;
            public float Scale;
            public float3 Fwd;
            public float3 Velocity;
        }

        class CurrentCameraAndTargetInfo
        {
            public CameraInfo CameraInfo;
            public NativeArray<TargetInfo> TargetInfo;
        }
        List<CurrentCameraAndTargetInfo> m_CurrentCameraAndTargetInfo = new List<CurrentCameraAndTargetInfo>();

        void DisposeSnapshots()
        {
            for (int i = 0; i < m_CurrentCameraAndTargetInfo.Count; ++i)
            {
                var a = m_CurrentCameraAndTargetInfo[i].TargetInfo;
                if (a.IsCreated)
                    a.Dispose();
            }
            m_CurrentCameraAndTargetInfo.Clear();
        }

        /// <summary>
        /// This must be called early in the frame, before game time target calculations begin,
        /// because this snapshot must be of MovieTime data.
        /// </summary>
        internal void SnapshotCurrentCameraStateAndTargets()
        {
            Dependency.Complete();
            DisposeSnapshots();
            var channels = m_channelSystem.GetChannelsForFiltering();
            for (int i = 0; i < channels.Count; ++i)
            {
                var currentNode = channels[i].State.ActiveNode;
                if (!World.SafeHasComponent<VisibleTarget>(currentNode))
                    m_CurrentCameraAndTargetInfo.Add(new CurrentCameraAndTargetInfo());
                else
                {
                    var aspect = channels[i].Settings.Aspect;

                    // Get info about the current active shot
                    m_CurrentCameraAndTargetInfo.Add(new CurrentCameraAndTargetInfo
                    {
                        CameraInfo = GetCameraInfo(EntityManager.GetComponentData<PositionState>(currentNode), aspect),
                        TargetInfo = GetInfoForTargets(
                            Allocator.TempJob, EntityManager.GetBuffer<VisibleTarget>(currentNode))
                    });
                }
            }
        }

        protected override void OnCreate()
        {
            base.OnCreate();
            m_channelSystem = World.GetOrCreateSystem<CmChannelSystem>();
            m_storyManagerSystem = World.GetOrCreateSystem<StoryManagerSystem>();
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            DisposeSnapshots();
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            m_qualitySettings.Clear();
            EntityManager.GetAllUniqueSharedComponentData(m_qualitySettings);
            if (m_qualitySettings.Count < 2)
                return;

            var channels = m_channelSystem.GetChannelsForFiltering();
            if (m_CurrentCameraAndTargetInfo.Count != channels.Count)
                return;

            // Convert PositionState to MovieTime values for display
            var currentFrameInt = m_storyManagerSystem.MovieTimeFrameNumber;

            // GML TODO:
            // 1. Don't use UnityEngine
            // 2. Make interpolation/extrapolation/none selectable (per-tracker?)
            var lerpAmount = (UnityEngine.Time.timeAsDouble - UnityEngine.Time.fixedTimeAsDouble) / UnityEngine.Time.fixedDeltaTime;
            double currentFrame = lerpAmount + currentFrameInt;

            Entities
                .WithName("SetMovieTimeStateJob")
                .WithAll<NodeChannelAssignment, StoryThreadTracker>()
                .ForEach((
                    DynamicBuffer<StoryLookaheadInfo> lookaheadData,
                    ref PositionState posState,
                    in StoryLookaheadWindow lookahead) =>
                {
                    if (lookahead.NumFrames > 1)
                    {
                        // Interpolate
                        var startIndex = math.select(
                            lookaheadData.ComputeIndex(lookahead.TailIndex, lookahead.MovieTimeOffset -1), 
                            lookahead.TailIndex, 
                            lookahead.MovieTimeOffset == 0);
                        var v0 = lookaheadData[startIndex];
                        var v1 = v0;
                        for (int i = 0; i < lookahead.LookheadWindowNumFrames; ++i)
                        {
                            v1 = lookaheadData[lookaheadData.ComputeIndex(lookahead.TailIndex, lookahead.MovieTimeOffset + i)];
                            if (v1.FrameNumber >= currentFrame)
                                break;
                            v0 = v1;
                        }
                        
                        var t = math.select(
                            (float)((currentFrame - v0.FrameNumber) / (v1.FrameNumber - v0.FrameNumber)),
                            0, v1.FrameNumber <= v0.FrameNumber);
                        posState.RawPosition = math.lerp(v0.Info.Position, v1.Info.Position, t);
                        posState.RawRotation = math.slerp(v0.Info.Rotation, v1.Info.Rotation, t);
                        posState.Lens.FOV = math.lerp(v0.Info.Radius, v1.Info.Radius, t);
                        posState.PositionCorrection = float3.zero;
                        posState.RotationCorrection = quaternion.identity;
                    }
                })
                .ScheduleParallel();
                
            // Note: this must happen using Movie Time target data, so we can't use
            // the target group or the VisibleTarget already collected for game time :(
            if (m_storyManagerSystem.GameTimeFrameNumber > currentFrameInt)
                CollectTargetsMovieTime();

            // Now we have VisibleTarget in Movie Time - we can evaluate
            EvaluateTransitionQuality(channels);
        }

        void EvaluateTransitionQuality(List<CmChannelSystem.ChannelIterationInfo> channels)
        {
            var settings = m_qualitySettings[m_qualitySettings.Count-1].Settings;
            var weightSum = settings.DirectorLineCutWeight
                + settings.JumpCutWeight + settings.LookAtCutWeight
                + settings.MoveCutWeight + settings.PositionCutWeight;

            for (int i = 0; i < channels.Count; ++i)
            {
                var currentNode = channels[i].State.ActiveNode;

                // Get info about the current active shot
                var currentCameraInfo = m_CurrentCameraAndTargetInfo[i].CameraInfo;
                var currentTargetInfo = m_CurrentCameraAndTargetInfo[i].TargetInfo;

                if (!World.SafeHasComponent<VisibleTarget>(currentNode) || !currentTargetInfo.IsCreated)
                {
                    // Current shot has no knowledge of targets - transition evaluation is impossible
                    Entities
                        .WithName("DefaultTransitionQualityJob")
                        .WithSharedComponentFilter(channels[i].Filter)
                        .WithAll<LookAtTargetState, PositionState>()
                        .ForEach((ref TransitionQuality quality) =>
                        {
                            quality.Value = TransitionQuality.DefaultValue;
                        })
                        .ScheduleParallel();
                        continue;
                }

                var aspect = channels[i].Settings.Aspect;

                Entities
                    .WithName("TransitionQualityJob")
                    .WithSharedComponentFilter(channels[i].Filter)
                    .WithReadOnly(currentTargetInfo)
                    .ForEach((
                        Entity entity, 
                        DynamicBuffer<VisibleTarget> visibleTargets,
                        ref TransitionQuality quality,
                        in PositionState posState) =>
                    {
                        if (entity == currentNode)
                        {
                            quality.Value = TransitionQuality.DefaultValue;
                            return;
                        }

                        var cameraInfo = GetCameraInfo(posState, aspect);
                        var targetInfo = GetInfoForTargets(Allocator.Temp, visibleTargets);

                        float q = 1;
                        if (targetInfo.Length != 0 && currentTargetInfo.Length != 0)
                        {
                            NativeArray<int> sharedTargets = new NativeArray<int>(
                                currentTargetInfo.Length * 2, Allocator.Temp);
                            int numShared = GetSharedTargets(targetInfo, sharedTargets, currentTargetInfo);

                            float cutCost = settings.DirectorLineCutWeight * EvaluateDirectorLineCutCost(
                                sharedTargets, numShared, cameraInfo, targetInfo,
                                currentTargetInfo, currentCameraInfo);
                            cutCost +=  settings.JumpCutWeight * EvaluateJumpCutCost(
                                sharedTargets, numShared, cameraInfo, targetInfo,
                                currentTargetInfo, currentCameraInfo);
                            cutCost += settings.LookAtCutWeight * EvaluateLookAtCutCost(
                                sharedTargets, numShared, cameraInfo, targetInfo,
                                currentTargetInfo, currentCameraInfo);
            #if false
                            // TODO GML: add when velocities are valid
                            if (settings.MoveCutWeight > 0)
                                cutCost += settings.MoveCutWeight * EvaluateMoveCutCost(
                                    sharedTargets, numShared, cameraInfo, subtargetInfo,
                                    currentTargetInfo, currentCameraInfo);
            #endif
                            cutCost += settings.PositionCutWeight * EvaluatePositionCutCost(
                                sharedTargets, numShared, cameraInfo, targetInfo,
                                currentTargetInfo, currentCameraInfo);

                            q = 1 - (cutCost / weightSum);
                        }
                        quality.Value = q;
                    })
                    .ScheduleParallel();
            };
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static CameraInfo GetCameraInfo(in PositionState posState, float aspect)
        {
            var pos = posState.GetCorrectedPosition();
            var rot = posState.GetCorrectedRotation();
            var fov = math.radians(posState.Lens.FOV);

            var matCam = math.inverse(float4x4.TRS(pos, rot, new float3(1, 1, 1)));
            var perspMatCam = float4x4.PerspectiveFov(
                fov, aspect, posState.Lens.NearClip, posState.Lens.FarClip);

            return new CameraInfo
            {
                Position = pos,
                Velocity = float3.zero, // GML todo: put velocity in posState
                Fov2 = new float2(math.atan(math.tan(fov) * aspect), fov),
                Rotation = rot,
                World2CamPersp = math.mul(perspMatCam, matCam),
                Fwd = math.forward(rot)
            };
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static NativeArray<TargetInfo> GetInfoForTargets(
            Allocator allocator,
            DynamicBuffer<VisibleTarget> visibleTargets)
        {
            var info = new NativeArray<TargetInfo>(visibleTargets.Length, allocator);
            for (int i = 0; i < visibleTargets.Length; ++i)
            {
                var t = visibleTargets[i];
                info[i] = new TargetInfo
                {
                    Info = t.Info,
                    Entity = t.Entity,Scale = t.Scale,
                    Fwd = math.forward(t.Info.Rotation),
                    Velocity = float3.zero
                };
            }
            return info;
        }

        static int GetSharedTargets(
            in NativeArray<TargetInfo> targets, NativeArray<int> shared,
            in NativeArray<TargetInfo> currentTargetInfo)
        {
            int numShared = 0;
            int index = 0;
            for (int i = 0; i < currentTargetInfo.Length; ++i)
            {
                for (int j = 0; j < targets.Length; ++j)
                {
                    if (currentTargetInfo[i].Entity == targets[j].Entity)
                    {
                        shared[index++] = i; // current target
                        shared[index++] = j; // maps to this target
                        ++numShared;
                        break;
                    }
                }
            }
            return numShared;
        }

        /// <summary>
        /// Evaluate director line cut cost from one shot to another.
        /// </summary>
        /// <param name="sharedTargets">List of shared target indices within both shots</param>
        /// <returns>Transition cost. 0==great, 1==shit</returns>
        static float EvaluateDirectorLineCutCost(
            in NativeArray<int> sharedTargets, int numShared,
            in CameraInfo cameraInfo, in NativeArray<TargetInfo> targets,
            in NativeArray<TargetInfo> currentTargetInfo,
            in CameraInfo currentCameraInfo)
        {
            if (numShared == 1)
            {
                var tA = currentTargetInfo[sharedTargets[0]];
                var tB = targets[sharedTargets[0+1]];
                float xA = math.mul(currentCameraInfo.World2CamPersp, new float4(tA.Fwd, 1)).x;
                float xB = math.mul(cameraInfo.World2CamPersp, new float4(tB.Fwd, 1)).x;
                return math.select(0, 1, xA * xB < 0);
            }

            float rule180Cost = 0f;
            float sumScale = 0f;
            numShared <<= 1; // two indices per shared target
            for (int i = 0; i < numShared; i += 2)
            {
                // Get first target within previous frame
                var tA1 = currentTargetInfo[sharedTargets[i]];
                var tB1 = targets[sharedTargets[i+1]];
                float3 pA1 = math.mul(currentCameraInfo.World2CamPersp, new float4(tA1.Info.Position, 1)).xyz;
                float3 pB1 = math.mul(cameraInfo.World2CamPersp, new float4(tB1.Info.Position, 1)).xyz;
                float scale1 = currentTargetInfo[sharedTargets[i]].Scale;

                // Get other targets within previous frame
                for (int j = i + 2; j < numShared; j += 2)
                {
                    var tA2 = currentTargetInfo[sharedTargets[j]];
                    var tB2 = targets[sharedTargets[j+1]];
                    float3 pA2 = math.mul(currentCameraInfo.World2CamPersp, new float4(tA2.Info.Position, 1)).xyz;
                    float3 pB2 = math.mul(cameraInfo.World2CamPersp, new float4(tB2.Info.Position, 1)).xyz;

                    // Compute cost
                    float scale = math.min(scale1, currentTargetInfo[sharedTargets[j]].Scale);
                    sumScale += scale;
                    if ((pA1.x - pA1.x) * (pB1.x - pB2.x) < 0f)
                        rule180Cost += scale;
                }
            }
            rule180Cost /= math.select(1, sumScale, sumScale > 0.01f);
            return rule180Cost;
        }

        const float kScaleDistThreshold = 2f;
        const float kAngleThreshold = 30f;
        const float kSafeAngle = 20f;

        /// <summary>
        /// Evaluate jump cut cost from one shot to another.
        /// </summary>
        /// <returns>Transition cost. 0==great, 1==shit</returns>
        static float EvaluateJumpCutCost(
            in NativeArray<int> sharedTargets, int numShared,
            in CameraInfo cameraInfo, in NativeArray<TargetInfo> targets,
            in NativeArray<TargetInfo> currentTargetInfo,
            in CameraInfo currentCameraInfo)
        {
            float jumpCutCost = 0f;
            numShared <<= 1; // two indices per shared target
            for (int i = 0; i < numShared; i += 2)
            {
                // Distance between both cameras
                float distance1 = math.length(currentCameraInfo.Position - currentTargetInfo[sharedTargets[i]].Info.Position);
                float distance2 = math.length(cameraInfo.Position - targets[sharedTargets[i+1]].Info.Position);

                // GML TODO : use radius of target instead of 1
                float scale1 = 1 / (distance1 * math.atan(currentCameraInfo.Fov2.y * 0.5f));
                float scale2 = 1 / (distance2 * math.atan(cameraInfo.Fov2.y * 0.5f));
                float scaleFactor = math.select(scale1 / scale2, scale2 / scale1, scale1 < scale2);

                // Angle between both cameras
                float angle = MathHelpers.AngleUnit(currentCameraInfo.Fwd, cameraInfo.Fwd);
                if (kScaleDistThreshold > 1 && scaleFactor < kScaleDistThreshold && angle < kAngleThreshold)
                {
                    float distanceCost = (kScaleDistThreshold - scaleFactor) / (kScaleDistThreshold-1);
                    float angleCost = (kAngleThreshold - angle) / kAngleThreshold;
                    jumpCutCost += angleCost * distanceCost;
                }
            }
            return jumpCutCost;
        }

        /// <summary>
        /// Evaluate look at cut cost from one shot to another.
        /// </summary>
        /// <param name="sharedTargets">List of shared targets within both shots</param>
        /// <returns>Transition cost. 0==great, 1==shit</returns>
        static float EvaluateLookAtCutCost(
            in NativeArray<int> sharedTargets, int numShared,
            in CameraInfo cameraInfo, in NativeArray<TargetInfo> targets,
            in NativeArray<TargetInfo> currentTargetInfo,
            in CameraInfo currentCameraInfo)
        {
            float ruleLookAtCost = 0f;

            float sumScale = 0f;
            numShared <<= 1; // two indices per shared target
            for (int i = 0; i < numShared; i += 2)
            {
                var tA = currentTargetInfo[sharedTargets[i]];
                var tB = targets[sharedTargets[i+1]];
                float2 xA = math.mul(currentCameraInfo.World2CamPersp, new float4(tA.Fwd, 1)).xy;
                float2 xB = math.mul(cameraInfo.World2CamPersp, new float4(tB.Fwd, 1)).xy;
                float minScale = math.min(tA.Scale, tB.Scale);
                sumScale += minScale;
                if (xA.x * xB.x < 0f)
                {
                    xA = math.normalizesafe(xA, new float2(0, 1));
                    xB = math.normalizesafe(xB, new float2(0, 1));
                    float angle = math.min(math.abs(AngleUnit(xA, new float2(0, 1))), math.abs(AngleUnit(xA, new float2(0, -1))));
                    float angle2 = math.min(math.abs(AngleUnit(xB, new float2(0, 1))), math.abs(AngleUnit(xB, new float2(0, -1))));
                    ruleLookAtCost += minScale * math.min(kSafeAngle, math.min(angle, angle2)) / kSafeAngle;
                }
            }
            ruleLookAtCost /= math.select(1, sumScale, sumScale > 0.01f);
            return ruleLookAtCost;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float AngleUnit(float2 a, float2 b) { return math.acos(math.dot(a, b)); }

        /// <summary>
        /// Evaluate move cut cost from one shot to another.
        /// </summary>
        /// <returns>Transition cost. 0==great, 1==shit</returns>
        static float EvaluateMoveCutCost(
            in NativeArray<int> sharedTargets, int numShared,
            in CameraInfo cameraInfo, in NativeArray<TargetInfo> targets,
            in NativeArray<TargetInfo> currentTargetInfo,
            in CameraInfo currentCameraInfo)
        {
            float ruleMoveCost = 0f;
            float sumScale = 0f;
            numShared <<= 1; // two indices per shared target
            for (int i = 0; i < numShared; i += 2)
            {
                var tA = currentTargetInfo[sharedTargets[i]];
                var tB = targets[sharedTargets[i+1]];

                float2 vA = math.mul(currentCameraInfo.World2CamPersp, new float4(tA.Velocity, 1)).xy;
                float2 vB = math.mul(cameraInfo.World2CamPersp, new float4(tB.Velocity, 1)).xy;
                float scale = math.min(tA.Scale, tB.Scale);
                sumScale += scale;
                if (vA.x * vB.x < 0)
                {
                    vA = math.normalizesafe(vA, new float2(0, 1));
                    vB = math.normalizesafe(vB, new float2(0, 1));
                    float angle = math.min(math.abs(AngleUnit(vA, new float2(0, 1))), math.abs(AngleUnit(vA, new float2(0, -1))));
                    float angle2 = math.min(math.abs(AngleUnit(vB, new float2(0, 1))), math.abs(AngleUnit(vB, new float2(0, -1))));
                    ruleMoveCost += scale * math.min(kSafeAngle, math.min(angle, angle2)) / kSafeAngle;
                }
            }
            ruleMoveCost /= math.select(1, sumScale, sumScale > 0.01f);
            return ruleMoveCost;
        }

        /// <summary>
        /// Evaluate position cut cost from one shot to another.
        /// </summary>
        /// <param name="sharedTargets">List of shared targets within both shots</param>
        /// <returns>Transition cost. 0==great, 1==shit</returns>
        static float EvaluatePositionCutCost(
            in NativeArray<int> sharedTargets, int numShared,
            in CameraInfo cameraInfo, in NativeArray<TargetInfo> targets,
            in NativeArray<TargetInfo> currentTargetInfo,
            in CameraInfo currentCameraInfo)
        {
            float rulePositionCost = 0f;
            float sumScale = 0f;

            numShared <<= 1; // two indices per shared target
            for (int i = 0; i < numShared; i += 2)
            {
                var tA = currentTargetInfo[sharedTargets[i]];
                var tB = targets[sharedTargets[i+1]];

                float3 pA = math.mul(currentCameraInfo.World2CamPersp, new float4(tA.Info.Position, 1)).xzy;
                float3 pB = math.mul(cameraInfo.World2CamPersp, new float4(tB.Info.Position, 1)).xyz;

                if (pA.x > -1f && pB.x > -1f && pA.x < 1f && pB.x < 1f
                    && pA.y > -1f && pB.y > -1f && pA.y < 1f && pB.y < 1f)
                {
                    float scale = math.min(tA.Scale, tB.Scale);
                    sumScale += scale;
                    rulePositionCost += math.min(math.length(pA - pB), 1f) * scale;
                }
            }
            rulePositionCost /= math.select(1, sumScale, sumScale > 0.01f);
            return rulePositionCost;
        }
    }
}


