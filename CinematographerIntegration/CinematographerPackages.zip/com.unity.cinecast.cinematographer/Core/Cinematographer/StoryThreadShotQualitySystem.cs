using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.CompilerServices;
using Unity.Cinemachine.Core;

namespace Unity.Cinecast.Cinematographer.Core
{
    [Serializable]
    public struct ShotQualityTuning : ISharedComponentData
    {
        /// <summary>
        /// These global settings control how a quality score is assigned to each camera as
        /// a function of what POIs it is looking at and how it is looking at them.
        /// </summary>
        [Serializable]
        public struct QualitySettings
        {
            /// <summary>Weight of Hitchcock rule.</summary>
            [Tooltip("Relative importance of the Hitchcock Rule compared to the other weights in this settings object.\n\n"
                + "The Hitchcock rule states: \"The size of any object in your frame should be proportional to its "
                + "importance to the story at that moment\". Essentially, subjects of greater importance should be "
                + "permitted a larger scale while items of little importance should be restricted to smaller sizes."
                + "The quality of the shot will be determined in accordance with this rule, in proportion to the "
                + "assigned weight specified in this setting")]
            public float HitchcockWeight;

            /// <summary>Weight of action visibility rule.</summary>
            [Tooltip("Relative importance of the Action Visibility Rule compared to the other weights in this settings object.\n\n"
                + "The Action Visibility Rule states: \"The quality of the shot is the sum of the interest values "
                + "of all the POIs visible in the shot\".  The quality of the shot will be determined in accordance with this "
                + "rule, in proportion to the assigned weight specified in this setting")]
            public float ActionVisibilityWeight;

            /// <summary>Weight of facing rule.</summary>
            [Tooltip("Relative importance of the Facing Rule compared to the other weights in this settings object.\n\n"
                + "The Facing Rule states: \"The quality of the shot decreases as the visible POIs face away from the camera.\n\n"
                + "It is assumed that POIs are better seen from the front.  The quality of the shot will be determined in "
                + "accordance with this rule, in proportion to the assigned weight specified in this setting.\n"
                + "Note: This setting is currently unused.")]
            public float FacingQualityWeight;

            /// <summary>Artificially boost interest this much if target is close to optimal distance.</summary>
            [Tooltip("Boost the shot quality of a POI by this multiplicative factor when the POI is positioned "
                + "at the per-camera optimal target distance (which may be unspecified for a camera, in which case this "
                + "setting is ignored).  The quality boost interpolates back to 1 as the target moves away from this "
                + "optimal distance.  Use a value of 1 for no quality boost, or > 1 for preferring shots with targets positioned "
                + "close to that camera's optimal distance, and < 1 for avoiding such shots.")]
            public float OptimalDistanceQualityBoost;

            /// <summary>How important is camera stability?</summary>
            [Tooltip("Cameras can rate their own stability (for example, if a camera is rushing to catch up with "
                + "its target, or significantly displaced by occlusion resolution, it can choose to degrade its "
                + "own stability rating).  This parameter is used to control how much the stability rating affects "
                + "the shot quality.  It is applied multiplicatively to the camera stability rating.  "
                + "Use 0 for no effect, 1 for full effect.")]
            public float CameraStabilityScale;

            /// <summary>Angle range over which quality degrades because camera angle is too steep.  0 is horizontal</summary>
            [Tooltip("Angle range over which quality degrades because camera pitch is too steep.  "
                + "This is used to filter out cameras that are looking straight up or down.  If camera angle with "
                + "the horizontal is below the first value in the range, camera has full quality.  If angle"
                + "is greater than the second value in the range, camera has 0 quality.  In between, the "
                + "quality is lerped.  An angle of 0 is horizontal, and an angle of 90 is vertical.")]
            [Float2AsRangeProperty]
            public float2 PitchSteepnessLimit;

            /// <summary>Minimumn target radius, to use in the event that client does not define a target radius</summary>
            [Tooltip("Minimumn target radius, to use in the event that client does not define a target radius. "
                + "If the target radius is too small, then the cameras will not be able to identify the target.")]
            public float MinimumTargetRadius;
        }
        [HideFoldout]
        public QualitySettings Settings;
    }

    [UpdateAfter(typeof(CameraFinalizeSystem))]
    [UpdateBefore(typeof(TransitionQualitySystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    partial class StoryThreadShotQualitySystem : CinemachineSystemBase
    {
        StoryManagerSystem m_storyManagerSystem;
        List<ShotQualityTuning> m_qualitySettings = new List<ShotQualityTuning>(2);

        protected override void OnCreate()
        {
            m_storyManagerSystem = World.GetOrCreateSystem<StoryManagerSystem>();
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            m_qualitySettings.Clear();
            EntityManager.GetAllUniqueSharedComponentData(m_qualitySettings);
            if (m_qualitySettings.Count < 2)
                return;

            // Evaluate quality at game time
            var qualitySettings = m_qualitySettings[m_qualitySettings.Count-1].Settings;
            var qualityWeightSum = qualitySettings.HitchcockWeight
                + qualitySettings.ActionVisibilityWeight + qualitySettings.FacingQualityWeight;

            var pitchLimits = new float2(
                math.sin(math.radians(qualitySettings.PitchSteepnessLimit.x)),
                math.sin(math.radians(qualitySettings.PitchSteepnessLimit.y)));
            pitchLimits.y = math.max(pitchLimits.x, pitchLimits.y);

            var gameTimeFrame = m_storyManagerSystem.GameTimeFrameNumber;
            var movieTimeFrame = m_storyManagerSystem.MovieTimeFrameNumber;
            var backbufferStart = movieTimeFrame - 20; // Make sure there's at least some backbuffer (we only need one valid frame)

            Entities
                .WithName("EvaluateQualityJob")
                .WithAll<NodeChannelAssignment>()
                .ForEach((
                    DynamicBuffer<StoryThreadTrackerSystemBase.VisibleTarget> targets,
                    DynamicBuffer<StoryLookaheadInfo> lookaheadData,
                    ref StoryLookaheadWindow lookahead,
                    in StoryThreadTracker settings,
                    in PositionState posState) =>
                {
                    // Trim history
                    while (lookahead.NumFrames > 1 && lookahead.TailTimeFrame(lookaheadData) < backbufferStart)
                        lookahead.RemoveTail(lookaheadData);

                    // Advance movie time 
                    if (lookahead.NumFrames > 1)
                    {
                        while (lookahead.MovieTimeFrame(lookaheadData) < movieTimeFrame)
                            if (!lookahead.AdvanceMovieTime(lookaheadData))
                                break; // not enough lookahead data
                    }
                    // Keep frmaes monotonically increasing
                    if (!lookahead.IsEmpty() && lookahead.HeadTimeFrame(lookaheadData) >= gameTimeFrame)
                        return;

                    float quality = 0;
                    var camPos = posState.GetCorrectedPosition();
                    var camRot = posState.GetCorrectedRotation();
                    var camFwd = math.forward(camRot);

                    // Collect info about all subtargets
                    Entity stickyTargetEntity = Entity.Null;
                    float sumScales = 0;
                    for (int i = 0; i < targets.Length; ++i)
                        sumScales += targets[i].Scale;
                    if (sumScales > 0)
                    {
                        quality += EvaluateHitchcockQuality(targets, sumScales) * qualitySettings.HitchcockWeight;
                        quality += EvaluateActionVisibilityQuality(
                            targets, camPos, qualitySettings, settings.OptimalTargetDistance) * qualitySettings.ActionVisibilityWeight;
                        //GML TODO: quality += EvaluateFacingQuality(targets, camFwd) * qualitySettings.FacingQualityWeight;
                        quality /= qualityWeightSum;

                        // Final adjustments for camera stability and pitch
                        float cameraStability = 1; // 0..1, represents camera happiness.  1 is default // GML TODO: where does this live?
                        quality *= math.lerp(1, cameraStability, qualitySettings.CameraStabilityScale);
                        quality *= GetCameraPitchQuality(camFwd, pitchLimits);
                    }
                    lookahead.AddHead(lookaheadData, new StoryLookaheadInfo
                    {
                        Info = new StoryLookaheadInfo.TargetInfo
                        {
                            Value = quality,
                            Position = camPos,
                            Rotation = camRot,
                            Radius = posState.Lens.FOV
                        },
                        FrameNumber = gameTimeFrame,
                    });
                    lookahead.AdvanceGameTime(lookaheadData); // Game time is always at head

                })
                .ScheduleParallel();
        }

        /// <summary>
        /// Evaluate Hitchcock rule.
        /// </summary>
        /// <returns>Quality of Hitchcock rule. 1==great, 0==shit</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float EvaluateHitchcockQuality(DynamicBuffer<StoryThreadTrackerSystemBase.VisibleTarget> targets, float sumScale)
        {
            // We get score for every visible target, weighted by urgency and target distance
            float hitchcockCost = 0;
            for (int i = 0; i < targets.Length; ++i)
            {
                var t = targets[i];
                float relativeImportance = t.Info.Value;
                float relativeScale = t.Scale / sumScale;
                hitchcockCost += math.abs(relativeImportance - relativeScale);
            }
            return 1f - hitchcockCost;
        }

#if false // GML TODO: need BetterSeenFromBehind property on POIs
        /// <summary>
        /// Evaluate Facing rule.
        /// </summary>
        /// <returns>Quality of Facing rule. 1==great, 0==shit</returns>
        static float EvaluateFacingQuality(DynamicBuffer<StoryThreadTrackerSystemBase.VisibleTarget> targets, float3 camFwd)
        {
            // We get score for every visible target, weighted by urgency and target distance
            float facingQuality = 0;
            float sumOfImportance = 0;
            for (int i = 0; i < targets.Length; ++i)
            {
                var t = targets[i];
                sumOfImportance += t.Info.Value;
                float dot = math.dot(camFwd, math.mul(t.Info.Rotation, new float3(0, 0, 1)));
                dot = math.select(-dot, dot, t.storyThread.BetterSeenFromBehind);
                facingQuality += t.Info.Value * math.max(dot, 0);
            }
            facingQuality /= math.select(1, sumOfImportance, sumOfImportance > 0.001f);
            return facingQuality;
        }
#endif

        /// <summary>
        /// Evaluate action visibility rule.
        /// </summary>
        /// <returns>Quality of action visibility rule. 1==great, 0==shit</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float EvaluateActionVisibilityQuality(
            DynamicBuffer<StoryThreadTrackerSystemBase.VisibleTarget> targets, float3 camPos,
            in ShotQualityTuning.QualitySettings settings, float optimalTargetDistance)
        {
            float actionVisibilityQuality = 0;
            for (int i = 0; i < targets.Length; ++i)
            {
                var t = targets[i];
                float relativeImportance = t.Info.Value;
                actionVisibilityQuality
                    += relativeImportance * GetQualityBoostForTargetDistance(
                        t.Info.Position, camPos, optimalTargetDistance, settings);
            }
            return actionVisibilityQuality;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float GetQualityBoostForTargetDistance(
            float3 targetPos, float3 cameraPos, float optimalTargetDistance,
            in ShotQualityTuning.QualitySettings settings)
        {
            return ShotQualityUtils.GetQualityBoostForOptimalTargetDistance(
                targetPos, cameraPos, optimalTargetDistance, settings.OptimalDistanceQualityBoost - 1f);
        }

        // Filter out situation where the camera angle is too steep
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float GetCameraPitchQuality(float3 camFwdUnit, float2 pitchLimits)
        {
            float dot = math.abs(math.dot(math.up(), camFwdUnit));
            return math.select(
                math.select(
                    math.lerp(1, 0, (dot - pitchLimits.x) / (pitchLimits.y - pitchLimits.x)),
                    0,
                    dot >= pitchLimits.y),
                1, dot <= pitchLimits.x);
        }
    }
}
