using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Transforms;
using Unity.Cinemachine.Core;

namespace Unity.Cinecast.Cinematographer.Core
{
    [UpdateBefore(typeof(CmTargetGroupBlendSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class StoryThreadTrackerSystem : StoryThreadTrackerSystemBase
    {
        EntityQuery m_missingTargetsQuery;
        EntityQuery m_missingGroupQuery;
        EntityQuery m_missingBlendGroupQuery;
        EntityQuery m_missingStateQuery;

        protected override void OnCreate()
        {
            base.OnCreate();

            m_missingTargetsQuery = GetEntityQuery(
                ComponentType.ReadOnly<StoryThreadTracker>(),
                ComponentType.Exclude<VisibleTarget>());

            m_missingGroupQuery = GetEntityQuery(
                ComponentType.ReadOnly<StoryThreadTracker>(),
                ComponentType.Exclude<CmTargetGroupBufferElement>());

            m_missingBlendGroupQuery = GetEntityQuery(
                ComponentType.ReadOnly<StoryThreadTracker>(),
                ComponentType.Exclude<CmTargetGroupBlendElement>());

            m_missingStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<StoryThreadTracker>(),
                ComponentType.Exclude<StoryThreadTrackerState>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            if (m_missingTargetsQuery.CalculateEntityCount() > 0)
            {
                var entities = m_missingTargetsQuery.ToEntityArray(Allocator.TempJob);
                for (int i = 0; i < entities.Length; ++i)
                    EntityManager.AddBuffer<VisibleTarget>(entities[i]);
                entities.Dispose();
            }

            if (m_missingGroupQuery.CalculateEntityCount() > 0)
            {
                var entities = m_missingGroupQuery.ToEntityArray(Allocator.TempJob);
                for (int i = 0; i < entities.Length; ++i)
                    EntityManager.AddBuffer<CmTargetGroupBufferElement>(entities[i]);
                entities.Dispose();
            }

            if (m_missingBlendGroupQuery.CalculateEntityCount() > 0)
            {
                var entities = m_missingBlendGroupQuery.ToEntityArray(Allocator.TempJob);
                for (int i = 0; i < entities.Length; ++i)
                    EntityManager.AddBuffer<CmTargetGroupBlendElement>(entities[i]);
                entities.Dispose();
            }

            EntityManager.AddComponent(m_missingStateQuery,
                ComponentType.ReadWrite<StoryThreadTrackerState>());

            // Restore GameTime camera state from previous frame
            Entities
                .WithName("RestoreGameTimeStateJob")
                .WithAll<NodeChannelAssignment, VisibleTarget, StoryThreadTracker>()
                .ForEach((
                    DynamicBuffer<StoryLookaheadInfo> lookaheadData,
                    ref PositionState posState,
                    ref LocalToWorld l2w,
                    in StoryLookaheadWindow lookahead) =>
                {
                    if (!lookahead.IsEmpty())
                    {
                        var v = lookahead.GameTimeValue(lookaheadData).Info;
                        posState.RawPosition = v.Position;
                        posState.RawRotation = v.Rotation;
                        posState.Lens.FOV = v.Radius;
                        posState.PositionCorrection = float3.zero;
                        posState.RotationCorrection = quaternion.identity;

                        l2w.Value = float4x4.TRS(v.Position, v.Rotation, l2w.Value.GetScaleFromTRS());
                    }
                })
                .ScheduleParallel();

            // Locate POI targets for each camera
            CollectTargetsGameTime();

            // Groups will contain game time positions for targets
            Entities
                .WithName("BlendIntoTargetGroupJob")
                .ForEach((
                    DynamicBuffer<CmTargetGroupBufferElement> members,
                    DynamicBuffer<CmTargetGroupBlendElement> blends,
                    DynamicBuffer<VisibleTarget> targets,
                    in StoryThreadTracker settings,
                    in NodeUpdateState updateState) =>
                {
                    blends.Clear();
                    if (updateState.PreviousFrameDataIsValid)
                    {
                        var blendTime = settings.GroupMemberBlendTime;
                        for (int i = 0; i < targets.Length; ++i)
                        {
                            blends.Add(new CmTargetGroupBlendElement
                            {
                                StableKey = targets[i].StableKey,
                                TargetWeight = 1,
                                BlendDuration = blendTime
                            });
                        }
                        // Add the default blend out instruction
                        blends.Add(new CmTargetGroupBlendElement { BlendDuration = blendTime });
                    }
                    else
                    {
                        members.Clear();
                        for (int i = 0; i < targets.Length; ++i)
                        {
                            members.Add(new CmTargetGroupBufferElement
                            {
                                StableKey = targets[i].StableKey,
                                Weight = 1
                            });
                        }
                    }
                })
                .ScheduleParallel();
        }
    }
}
