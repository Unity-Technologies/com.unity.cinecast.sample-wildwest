#if false // GML TODO: make proper space partition
using System.Runtime.CompilerServices;
using Unity.Collections;
using Unity.Mathematics;
using Unity.Entities;
using Unity.Cinemachine.Core;

namespace Unity.Cinecast.Cinematographer.Core
{
    public struct StoryThreadSpacePartition
    {
        public struct TargetItem
        {
            public StoryLookaheadInfo.TargetInfo TargetInfo;
            public StableKey StableKey;
            public Entity Entity;
        }

        readonly NativeMultiHashMap<int, TargetItem> m_HashMap;
        readonly float m_CellSize;
        readonly float m_SearchRadius;

        public StoryThreadSpacePartition(float searchRadius, int count, Allocator allocator)
        {
            m_HashMap = new NativeMultiHashMap<int, TargetItem>(count, allocator);
            m_CellSize =math.max(searchRadius, 1) * 2;
            m_SearchRadius = searchRadius;
        }

        public void Dispose()
        {
            m_HashMap.Dispose();
        }

        public struct ParallelWriter
        {
            NativeMultiHashMap<int, TargetItem>.ParallelWriter m_writer;
            float m_cellSize;

            public ParallelWriter(NativeMultiHashMap<int, TargetItem>.ParallelWriter writer, float cellSize)
            {
                m_writer = writer;
                m_cellSize = cellSize;
            }

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public void Add(TargetItem item)
            {
                m_writer.Add(HashPosition(item.TargetInfo.Position, m_cellSize), item);
            }
        }

        public ParallelWriter AsParallelWriter() => new ParallelWriter(m_HashMap.AsParallelWriter(), m_CellSize);
        public int Count() => m_HashMap.Count();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static int HashPosition(float3 pos, float cellSize)
        {
            return (int)math.hash(new int3(math.floor(pos / cellSize)));
        }

        public int GetNearbyItems(float3 camPos, NativeArray<TargetItem> items, float minimumTargetDistance)
        {
            var hash = HashPosition(camPos, m_CellSize);
            int itemCount = 0;

            var r = m_SearchRadius;
            float3 delta;
            float3 p = camPos;
            p.x -= r; delta.x = math.select(-r, r, HashPosition(p, m_CellSize) == hash); p = camPos;
            p.y -= r; delta.y = math.select(-r, r, HashPosition(p, m_CellSize) == hash); p = camPos;
            p.z -= r; delta.z = math.select(-r, r, HashPosition(p, m_CellSize) == hash); p = camPos;

            for (int x = 0; x < 2; ++x)
            {
                for (int y = 0; y < 2; ++y)
                {
                    for (int z = 0; z < 2; ++z)
                    {
                        var h = HashPosition(p, m_CellSize);
                        GetItemsInCellWithinRadius(
                            h, camPos, items, ref itemCount, minimumTargetDistance);
                        p.z += delta.z;
                    }
                    p.z = camPos.z;
                    p.y += delta.y;
                }
                p.y = camPos.y;
                p.x += delta.x;
            }

            return itemCount;
        }

        void GetItemsInCellWithinRadius(
            int hash, float3 camPos, 
            NativeArray<TargetItem> items, ref int itemsCount,
            float minimumTargetDistance)
        {
            float r2 = m_SearchRadius * m_SearchRadius;
            var mind2 = minimumTargetDistance * minimumTargetDistance;
            if (m_HashMap.TryGetFirstValue(hash, out TargetItem item, out NativeMultiHashMapIterator<int> it))
            {
                do
                {
                    var d2 = math.distancesq(camPos, item.TargetInfo.Position);
                    if (d2 >= mind2 && d2 <= r2)
                        items[itemsCount++] = item;
                }
                while (m_HashMap.TryGetNextValue(out item, ref it));
            }
        }
    }
}
#endif
