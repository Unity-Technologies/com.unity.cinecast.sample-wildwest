using UnityEditor;
using UnityEngine;
using Unity.Entities;
using Unity.Collections;
using Unity.Mathematics;
using System.Runtime.CompilerServices;
using System.Collections.Generic;
using Unity.Cinemachine.Core;
using Unity.Cinecast.Cinematographer.Core;
using Unity.Cinecast.Cinematographer.Hybrid;

namespace Unity.Cinecast.Cinematographer.Editor
{
    public class CinemachineMonitorWindow : EditorWindow
    {
        [MenuItem("Cinecast/Cinemachine/Open Monitor Window")]
        private static void OpenWindow()
        {
            CinemachineMonitorWindow window = EditorWindow.GetWindow<CinemachineMonitorWindow>();
            window.titleContent = new GUIContent("Cinemachine Monitor");
            window.Show();
        }

        static float s_NodeQualityThreshold = 10;

        GUIStyle m_LineStyle;
        GUIStyle m_LineStyleBold;
        Color m_HeaderColor = new Color(0.4f, 0.4f, 0.4f);
        Color m_BkgColor = new Color(0.27f, 0.27f, 0.27f); // ack! no better way than this?
        Color m_FgColor;
        Color m_DimFgColor;

        const float hSpace = 3;

        World World => ClientHooks.DefaultWorld;

        private void OnEnable()
        {
            wantsLessLayoutEvents = true;
            autoRepaintOnSceneChange = true;
            wantsMouseMove = false;
            m_LineStyle = null;
            m_FgColor = Color.Lerp(Color.Lerp(Color.red, Color.yellow, 0.8f), m_BkgColor, 0.6f);
            m_DimFgColor = Color.Lerp(m_FgColor, m_BkgColor, 0.7f);
        }

        private void OnDisable()
        {
            var system = World?.GetExistingSystem<CMMonitorWindowSystem>();
            if (system != null)
                system.Enabled = false;
        }

        void OnGUI()
        {
            if (m_LineStyle == null)
            {
                m_LineStyle = new GUIStyle(EditorStyles.miniLabel);
                m_LineStyle.margin = new RectOffset(0, 0, 0, 0);
                m_LineStyle.contentOffset = Vector2.zero;

                m_LineStyleBold = new GUIStyle(m_LineStyle);
                m_LineStyleBold.fontStyle = FontStyle.Bold;
            }

            if (Application.isPlaying && World != null)
            {
                var system = World.GetOrCreateSystem<CMMonitorWindowSystem>();
                system.Enabled = true;
                system.GetData(out var threadInfo, out var nodeInfo);
                DrawThreadList(threadInfo);
                DrawFilterState();
                DrawCameraList(nodeInfo);
            }
        }

        Rect GetListLineRect(int numLines = 1)
        {
            var rect = EditorGUILayout.GetControlRect(true, (EditorGUIUtility.singleLineHeight - 6) * numLines);
            rect.height /= numLines;
            rect.y -= 3;
            return rect;
        }

        void DrawHistogramValue(Rect rect, bool bold, int3 value, float maxValue, string text)
        {
            rect.height -= 2;
            EditorGUI.DrawRect(rect, m_BkgColor);

            Rect r = rect; 
            r.height /= 2; r.height -= 1;
            r.width = Mathf.Max(1, rect.width * value.x / maxValue);
            EditorGUI.DrawRect(r, bold ? m_FgColor : m_DimFgColor);

            r.y += r.height;
            r.width = Mathf.Max(1, rect.width * value.y / maxValue);
            EditorGUI.DrawRect(r, bold ? m_FgColor : m_DimFgColor);
                
            r.height += 2;
            EditorGUI.LabelField(rect, text, bold? m_LineStyleBold: m_LineStyle);
        }

        private void DrawThreadList(NativeArray<CMMonitorWindowSystem.ThreadInfo> threads)
        {
            DrawThreadsHeaderAndGetColWidths(out float fixedSize, out float growingSize);
            var numLines = threads.IsCreated ? threads.Length : 0;
            if (numLines == 0)
                return;

            var m = World.EntityManager;
            var rect = GetListLineRect(numLines);
            float maxY = Event.current.type == EventType.Repaint ? position.height : 0;
            for (int i = 0; i < numLines; ++i, rect.y += rect.height)
            {
                if (rect.y > maxY)
                    break;

                var info = threads[i];
                var style = info.IsLive ? m_LineStyleBold : m_LineStyle;

                var r = rect;
                r.height += 1;
                r.width = growingSize - hSpace;
                EditorGUI.LabelField(r, $"{m.GetName(info.Entity)} ({info.Entity.Index}, {info.Entity.Version})", style);

                r.x += r.width + hSpace; r.width = fixedSize - hSpace;
                EditorGUI.LabelField(r, info.OffscreenTime.ToString(), style);

                r.x += r.width + hSpace; r.width = fixedSize - hSpace;
                DrawHistogramValue(r, info.IsLive, info.ReportedInterestValue, 100, info.ReportedInterest.ToString());

                r.x += r.width + hSpace; r.width = fixedSize - hSpace;
                DrawHistogramValue(r, info.IsLive, info.UrgencyValue, 100, info.Urgency.ToString());

                r.x += r.width + hSpace; r.width = fixedSize - hSpace;
                EditorGUI.LabelField(r, info.LookaheadFrames.ToString(), style);
            }
        }

        List<StableKey> m_FocusTargetCache = new List<StableKey>();
        List<StableKey> m_FollowTargetCache = new List<StableKey>();
        List<int> m_CameraFilterCache = new List<int>();

        void DrawFilterState()
        {
            var system = World.GetOrCreateSystem<DirectorSystem>();
            system.GetFilterState(m_FocusTargetCache, m_FollowTargetCache, m_CameraFilterCache);
            var stableIdLookup = World.GetOrCreateSystem<StableIDEntityManager>();
            
            var rect = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
            string msg = $"Filter: LookAt = [";
            foreach (var i in m_FocusTargetCache)
                msg += $"{World.EntityManager.GetName(stableIdLookup.LookupEntityNow(i))} ";
            msg += "] Follow = [";
            foreach (var i in m_FollowTargetCache)
                msg += $"{World.EntityManager.GetName(stableIdLookup.LookupEntityNow(i))} ";
            msg += "] Camera = [";
            foreach (var i in m_CameraFilterCache)
                msg += $"{i} ";
            msg += "]";
            EditorGUI.LabelField(rect, msg);
        }

        GUIContent m_ThreadLabel = new GUIContent("\nPOI");
        GUIContent m_InactiveLabel = new GUIContent("Offscreen\nTime");
        GUIContent m_InterestLabel = new GUIContent("Interest\nMov/Gam/Avg");
        GUIContent m_UrgencyLabel = new GUIContent("\nUrgency");
        GUIContent m_LookaheadLabel = new GUIContent("Lookahead\nFrames");

        void DrawThreadsHeaderAndGetColWidths(out float fixedSize, out float growingSize)
        {
            int numCols = 5;        // total number of columns
            int numFixedCols = 4;   // number of non-growing columns

            Rect rect = EditorGUILayout.GetControlRect(true, 2 * EditorGUIUtility.singleLineHeight);

            fixedSize = growingSize = rect.width / numCols;
            float maxFixedWidth = EditorGUIUtility.singleLineHeight * 5;
            if (fixedSize > maxFixedWidth)
            {
                fixedSize = maxFixedWidth;
                growingSize = (rect.width - (numFixedCols * fixedSize)) / (numCols - numFixedCols);
            }

            EditorGUI.DrawRect(rect, m_HeaderColor);

            rect.width = growingSize;
            EditorGUI.LabelField(rect, m_ThreadLabel);

            rect.x += rect.width; rect.width = fixedSize;
            EditorGUI.LabelField(rect, m_InactiveLabel);

            rect.x += rect.width; rect.width = fixedSize;
            EditorGUI.LabelField(rect, m_InterestLabel);

            rect.x += rect.width; rect.width = fixedSize;
            EditorGUI.LabelField(rect, m_UrgencyLabel);

            rect.x += rect.width; rect.width = fixedSize;
            EditorGUI.LabelField(rect, m_LookaheadLabel);
        }

        private void DrawCameraList(NativeArray<CMMonitorWindowSystem.NodeInfo> nodes)
        {
            var numNodes = nodes.IsCreated ? nodes.Length : 0;
            if (numNodes == 0)
                return;

            var storyManagerSystem = World.SafeGetSystem<StoryManagerSystem>();
            var currentFrame = storyManagerSystem.MovieTimeFrameNumber;
            DrawNodesHeaderAndGetColWidths(numNodes, currentFrame, out float fixedSize, out float growingSize);

            var m = World.EntityManager;
            var rect = GetListLineRect(numNodes);
            float maxY = Event.current.type == EventType.Repaint ? position.height : 0;
            bool haveCurrent = false;
            for (int i = 0; i < numNodes; ++i)
            {
                if (rect.y > maxY)
                    break;

                var oldColor = GUI.color;

                // Make sure we show the live one before the end of the panel
                while (!haveCurrent && rect.y > maxY - EditorGUIUtility.singleLineHeight && !nodes[i].IsLive && ++i < numNodes)
                    ;
                if (i >= numNodes)
                    break;
                var info = nodes[i];
                if (info.IsLive)
                {
                    haveCurrent = true;
                    GUI.color = Color.green;
                }
                else if (info.FinalQualityValue < s_NodeQualityThreshold)
                    continue;

                var r = rect;
                r.height += 1;
                r.width = growingSize - hSpace;
                EditorGUI.LabelField(r, $"{m.GetName(info.Entity)} ({info.Entity.Index}, {info.Entity.Version})", m_LineStyle);

                r.x += r.width + hSpace; r.width = fixedSize - hSpace;
                EditorGUI.LabelField(r, info.DebugCode.ToString(), m_LineStyle);

                r.x += r.width + hSpace; r.width = fixedSize - hSpace;
                EditorGUI.LabelField(r, info.NumTargetsValue.ToString(), m_LineStyle);

                r.x += r.width + hSpace; r.width = fixedSize;
                DrawHistogramValue(r, true, info.QualityValue, 100, info.Quality.ToString());

                r.x += r.width + hSpace; r.width = fixedSize;
                DrawHistogramValue(r, true, info.FinalQualityValue, 100, info.FinalQuality.ToString());

                r.x += r.width + hSpace; r.width = fixedSize - hSpace;
                EditorGUI.LabelField(r, info.LookaheadFrames.ToString(), m_LineStyle);

                // Next line
                GUI.color = oldColor;
                rect.y += rect.height;
            }
        }

        GUIContent m_HideTargetlessCamsLabel = new GUIContent("Quality Threshold");

        void DrawNodesHeaderAndGetColWidths(int numNodes, long currentFrame, out float fixedSize, out float growingSize)
        {
            int numCols = 6;        // total number of columns
            int numFixedCols = 5;   // number of fixed size columns

            Rect r = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);

            fixedSize = growingSize = r.width / numCols;
            float maxFixedWidth = EditorGUIUtility.singleLineHeight * 5;
            if (fixedSize > maxFixedWidth)
            {
                fixedSize = maxFixedWidth;
                growingSize = (r.width - (numFixedCols * fixedSize)) / (numCols - numFixedCols);
            }


            // Save space: squeeze all this shit on one line
            r.width /= 4; r.width -= hSpace;
            GUI.Label(r, $"Active cameras: {numNodes}");
            r.x += r.width + hSpace;
            GUI.Label(r, $"Current Frame: {currentFrame}");
            r.x += r.width + hSpace;
            r.width *= 2;
            s_NodeQualityThreshold = EditorGUI.Slider(r, m_HideTargetlessCamsLabel, s_NodeQualityThreshold, 0, 100);

            r = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight * 2);

            EditorGUI.DrawRect(r, m_HeaderColor);
            r.width = growingSize;
            EditorGUI.LabelField(r, "\nCamera Name");
            r.x += r.width; r.width = fixedSize;
            EditorGUI.LabelField(r, "Debug Code\nQL FT0P");
            r.x += r.width; r.width = fixedSize;
            EditorGUI.LabelField(r, "\nTargets");
            r.x += r.width; r.width = fixedSize;
            EditorGUI.LabelField(r, "Quality:\nMov/Gam/Avg");
            r.x += r.width; r.width = fixedSize;
            EditorGUI.LabelField(r, "Director\nQuality");
            r.x += r.width; r.width = fixedSize;
            EditorGUI.LabelField(r, "Lookahead\nFrames");
        }
    }

    [UpdateAfter(typeof(StoryThreadEndFrameUpdateSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    [AlwaysUpdateSystem]
    partial class CMMonitorWindowSystem : SystemBase
    {
        EntityQuery m_nodeQuery;
        EntityQuery m_storyThreadQuery;

        public struct ThreadInfo
        {
            public Entity Entity;
            public bool IsLive;
            public FixedString32Bytes OffscreenTime;
            public FixedString32Bytes ReportedInterest;
            public FixedString32Bytes Urgency;
            public FixedString32Bytes LookaheadFrames;
            public int3 ReportedInterestValue; // movie/game/avg
            public int UrgencyValue;
        }

        public struct NodeInfo
        {
            public Entity Entity;
            public bool IsLive;
            public int NumTargetsValue;
            public int3 QualityValue; // movie/game/avg
            public int FinalQualityValue;
            public FixedString32Bytes DebugCode;
            public FixedString32Bytes NumTargets;
            public FixedString32Bytes Quality; // movie/lookaheadAvg
            public FixedString32Bytes FinalQuality;
            public FixedString32Bytes LookaheadFrames;
        }

        NativeArray<ThreadInfo> m_ThreadInfo;
        NativeArray<NodeInfo> m_NodeInfo;

        public void GetData(out NativeArray<ThreadInfo> threadInfo, out NativeArray<NodeInfo> nodeInfo)
        {
            Dependency.Complete();
            threadInfo = m_ThreadInfo;
            nodeInfo = m_NodeInfo;
        }

        void Deallocate()
        {
            if (m_ThreadInfo.IsCreated)
                m_ThreadInfo.Dispose();
            if (m_NodeInfo.IsCreated)
                m_NodeInfo.Dispose();
        }

        protected override void OnCreate()
        {
            Enabled = false;
        }

        protected override void OnDestroy()
        {
            Deallocate();
            base.OnDestroy();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static int Percent(float value) { return (int)math.round(value * 100); }

        protected override void OnUpdate()
        {
            var nodeCount = m_nodeQuery.CalculateEntityCount();
            var storyThreadCount = m_storyThreadQuery.CalculateEntityCount();

            if (!m_ThreadInfo.IsCreated || m_ThreadInfo.Length != storyThreadCount || m_NodeInfo.Length != nodeCount)
            {
                Deallocate();
                m_ThreadInfo = new NativeArray<ThreadInfo>(storyThreadCount, Allocator.Persistent);
                m_NodeInfo = new NativeArray<NodeInfo>(nodeCount, Allocator.Persistent);
            }

            if (storyThreadCount == 0 && nodeCount == 0)
                return;

            var timeNow = ClientHooks.GetCurrentTime(World);
            var threads = m_ThreadInfo;

            Entities
                .WithName("CollectThreadsJob")
                .WithStoreEntityQueryInField(ref m_storyThreadQuery)
                .WithNativeDisableParallelForRestriction(threads)
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    DynamicBuffer<StoryLookaheadInfo> lookaheadData,
                    in StoryLookaheadWindow lookaheadWindow,
                    in StoryThreadState state) =>
                {
                    var info = new ThreadInfo { Entity = entity, IsLive = state.IsLive };
                    info.OffscreenTime.Append((float)(timeNow - state.TimeLastSeen));
                    info.UrgencyValue = Percent(state.Urgency);
                    info.Urgency.Append(info.UrgencyValue);

                    float movieTimeQuality = 0;
                    float gameTimeQuality = 0;
                    float avgQuality = 0;
                    long movieTimeStamp = 0;
                    long gameTimeStamp = 0;
                    if (!lookaheadWindow.IsEmpty())
                    {
                        movieTimeQuality = lookaheadWindow.MovieTimeValue(lookaheadData).Info.Value;
                        gameTimeQuality = lookaheadWindow.GameTimeValue(lookaheadData).Info.Value;
                        avgQuality = lookaheadWindow.GetAverageLookaheadValue();
                        movieTimeStamp = lookaheadWindow.MovieTimeFrame(lookaheadData);
                        gameTimeStamp = lookaheadWindow.GameTimeFrame(lookaheadData);
                    }

                    info.ReportedInterestValue = new int3(Percent(movieTimeQuality), Percent(gameTimeQuality), Percent(avgQuality));
                    info.ReportedInterest = FixedStringExtensions.FormatQuality(info.ReportedInterestValue);
                    info.LookaheadFrames = FixedStringExtensions.FormatFrameRange(
                        lookaheadWindow.LookheadWindowNumFrames, movieTimeStamp, gameTimeStamp);

                    threads[entityInQueryIndex] = info;
                }).Schedule();


            var nodes = m_NodeInfo;

            Entities
                .WithName("CollectNodesJob")
                .WithStoreEntityQueryInField(ref m_nodeQuery)
                .WithNativeDisableParallelForRestriction(nodes)
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    DynamicBuffer<StoryThreadTrackerSystemBase.VisibleTarget> visibleTargets, 
                    DynamicBuffer<StoryLookaheadInfo> lookaheadData,
                    in StoryLookaheadWindow lookaheadWindow,
                    in DirectorState directorState,
                    in NodeUpdateState updateState) =>
                {
                    var info = new NodeInfo { Entity = entity, IsLive = updateState.IsLive };
                    info.NumTargetsValue = visibleTargets.Length;
                    if (directorState.Code != 0)
                        info.DebugCode = FixedStringExtensions.ToHex32((int)directorState.Code);
                    info.NumTargets.Append(visibleTargets.Length);

                    float movieTimeQuality = 0;
                    float gameTimeQuality = 0;
                    float avgWindowQuality = 0;
                    long movieTimeStamp = 0;
                    long gameTimeStamp = 0;
                    if (!lookaheadWindow.IsEmpty())
                    {
                        movieTimeQuality = lookaheadWindow.MovieTimeValue(lookaheadData).Info.Value;
                        gameTimeQuality = lookaheadWindow.GameTimeValue(lookaheadData).Info.Value;
                        avgWindowQuality = lookaheadWindow.GetAverageLookaheadValue();
                        movieTimeStamp = lookaheadWindow.MovieTimeFrame(lookaheadData);
                        gameTimeStamp = lookaheadWindow.GameTimeFrame(lookaheadData);
                    }

                    info.QualityValue = new int3(Percent(movieTimeQuality), Percent(gameTimeQuality), Percent(avgWindowQuality));
                    info.FinalQualityValue = Percent(updateState.ShotQuality);
                    info.Quality = FixedStringExtensions.FormatQuality(info.QualityValue);
                    info.FinalQuality.Append(info.FinalQualityValue);
                    info.LookaheadFrames = FixedStringExtensions.FormatFrameRange(
                        lookaheadWindow.LookheadWindowNumFrames, movieTimeStamp, gameTimeStamp);

                    nodes[entityInQueryIndex] = info;

                }).Schedule();
        }
    }

    static class FixedStringExtensions
    {
        static readonly FixedString32Bytes s_hexLookup = "0123456789abcdef";

        public static FixedString32Bytes ToHex32(int v)
        {
            var str = new FixedString32Bytes();
            str.AppendRawByte(s_hexLookup[(v >> 12) & 0xf]);
            str.AppendRawByte(s_hexLookup[(v >> 8) & 0xf]);
            str.AppendRawByte(s_hexLookup[(v >> 4) & 0xf]);
            str.AppendRawByte(s_hexLookup[v & 0xf]);
            return str;
        }

        public static FixedString32Bytes FormatQuality(int3 v)
        {
            var str = new FixedString32Bytes();
            str.Append(v.x);
            str.Add((byte)' '); str.Add((byte)'/'); str.Add((byte)' ');
            str.Append(v.y);
            str.Add((byte)' '); str.Add((byte)'/'); str.Add((byte)' ');
            str.Append(v.z);
            return str;
        }

        public static FixedString32Bytes FormatFrameRange(long numSummed, long a, long b)
        {
            var str = new FixedString32Bytes();
            str.Append(numSummed);
            str.Add((byte)' '); str.Add((byte)'(');
            str.Append(a);
            str.Add((byte)'-');
            str.Append(b);
            str.Add((byte)')');
            return str;
        }
    }
}
