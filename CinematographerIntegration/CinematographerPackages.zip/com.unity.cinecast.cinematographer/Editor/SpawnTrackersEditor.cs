using UnityEngine;
using Unity.Cinemachine.Editor;
using Cinecast.CM.Hybrid;
using UnityEditor;

namespace Cinecast.CM.Editor
{
    [CustomEditor(typeof(SpawnTrackers))]
    class SpawnTrackersEditor : UnityEditor.Editor
    {
        [MenuItem("Cinecast/Cinemachine/Respawn Trackers")]
        private static void Respawn()
        {
            var spawners = FindObjectsOfType<SpawnTrackers>(false);
            foreach (var s in spawners)
                s.Respawn();
        }

        public override void OnInspectorGUI()
        {
            EditorGUI.BeginChangeCheck();
            DrawPropertiesExcluding(serializedObject, "m_Script");
            if (EditorGUI.EndChangeCheck())
                serializedObject.ApplyModifiedProperties();
        }
    }

    [CustomPropertyDrawer(typeof(SpawnTrackers.TemplateAssignment))]
    class SpawnTrackersTemplateAssignmentPropertyDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect rect, SerializedProperty property, GUIContent label)
        {
            var def = new SpawnTrackers.TemplateAssignment();
            var widthOverride = new InspectorUtility.LabelWidthOverride(1);
            InspectorUtility.MultiPropertyOnLine(
                rect, GUIContent.none,
                new [] { property.FindPropertyRelative(() => def.Type),
                        property.FindPropertyRelative(() => def.Hint),
                        property.FindPropertyRelative(() => def.Template) },
                new GUIContent[] {GUIContent.none, null, GUIContent.none} );
        }
    }
}
