using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Experimental.SceneManagement;
#endif

namespace Unity.Entities.Hybrid
{
    /// <summary>
    /// This component gives a GameObject a stable, non-replicable Globally Unique IDentifier.
    /// It can be used to reference a specific instance of an object no matter where it is.
    ///
    /// Prefabs do not have valid StableID values.  The instance IDs are generated when the prefab
    /// is instanced.  This is to ensure that duplicate IDs are never created.
    /// </summary>
    [ExecuteAlways, DisallowMultipleComponent]
    [AddComponentMenu("Stable ID")]
    public class StableID : EntityBehaviour
    {
        [SerializeField]
        [UnityEngine.Serialization.FormerlySerializedAs("m_BindingKey")]
        StableKey m_Value;

        /// <summary>
        /// Returns the StableKey value of this ID.
        /// </summary>
        /// <returns>Returns the StableKey value of this ID.</returns>
        public StableKey Value => m_Value;

        /// <summary>
        /// Returns if the StableKey is non-zero.
        /// </summary>
        /// <returns>Returns true, if valid. False, otherwise.</returns>
        public bool IsValid => m_Value.IsValid;

        // When de-serializing or creating this component, we want to either
        // restore our serialized GUID or create a new one
        void CreateGuid()
        {
            // If our serialized data is invalid, then we are a new object and need a new GUID
            if (!IsValid)
            {
    #if UNITY_EDITOR
                // if in editor, make sure we aren't a prefab of some kind
                if (IsAssetOnDisk())
                    return;
                Undo.RecordObject(this, "Added new StableKey value");
    #endif
                m_Value = StableKey.GenerateUnique();

    #if UNITY_EDITOR
                // If we are creating a new GUID for a prefab instance of a prefab,
                // but we have somehow lost our prefab connection
                // force a save of the modified prefab instance properties
                if (PrefabUtility.IsPartOfNonAssetPrefabInstance(this))
                    PrefabUtility.RecordPrefabInstancePropertyModifications(this);
    #endif
            }

            // Register with the GUID Manager so that other components can access
            // this If registration fails, we probably have a duplicate or
            // invalid GUID, get us a new one
            while (!StableIDGameObjectManager.Add(this))
                m_Value = StableKey.GenerateUnique();
        }

    #if UNITY_EDITOR
        bool IsEditingInPrefabMode()
        {
            // if the game object is stored on disk, it is a prefab of some kind,
            // despite not returning true for IsPartOfPrefabAsset =/
            if (EditorUtility.IsPersistent(this))
                return true;

            // If the GameObject is not persistent let's determine which stage we
            // are in first because getting Prefab info depends on it
            var mainStage = StageUtility.GetMainStageHandle();
            var currentStage = StageUtility.GetStageHandle(gameObject);
            if (currentStage != mainStage)
            {
                var prefabStage = PrefabStageUtility.GetPrefabStage(gameObject);
                if (prefabStage != null)
                    return true;
            }
            return false;
        }

        bool IsAssetOnDisk()
        {
            return PrefabUtility.IsPartOfPrefabAsset(this) || IsEditingInPrefabMode();
        }
    #endif

        /// <summary>
        /// Makes sure that if we are a prefab, then the GUID is not stored by us,
        /// because the GUID would then be duplicated when instanced. Prefabs have a default (0) GUID.
        /// </summary>
        public override void OnBeforeSerialize()
        {
            base.OnBeforeSerialize();
    #if UNITY_EDITOR
            // This lets us detect if we are a prefab instance or a prefab asset.
            // A prefab asset cannot contain a GUID since it would then be duplicated when instanced.
            if (IsAssetOnDisk())
                m_Value = StableKey.Default;
    #endif
        }

        void Reset()
        {
            CreateGuid();
        }

        void Awake()
        {
            CreateGuid();
        }

        protected override void OnValidate()
        {
    #if UNITY_EDITOR
            // similar to on Serialize, but gets called on Copying a Component or Applying a Prefab
            // at a time that lets us detect what we are
            if (IsAssetOnDisk())
                m_Value = StableKey.Default;
            else
    #endif
            {
                CreateGuid();
            }
            base.OnValidate();
        }

        /// <summary>
        /// Removes the StableKey from the StableIDGameObjectManager. This is important to let
        /// other objects looking for this StableKey know that we are gone.
        /// </summary>
        public void OnDestroy()
        {
            StableIDGameObjectManager.Remove(m_Value);
        }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            // If this is spawned from a prefab, then the Stable ID will be invalid.
            // We must generate a valid one before converting.
            if (!IsValid)
                CreateGuid();

            context.EntityManager.AddComponentData(entity, new StableKeyData { Value = m_Value });
        }

        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
        }
    }
}
