using System.Collections.Generic;
using UnityEngine;
using System;

namespace Unity.Entities.Hybrid
{
    /// <summary>
    /// StableIDGameObjectManager handles registering and accessing objects by StableID.
    /// All the public API is static so you need not worry about creating an instance.
    /// </summary>
    public class StableIDGameObjectManager
    {
        // for each GUID we need to know the Game Object it references
        // and an event to store all the callbacks that need to know when it is destroyed
        struct GuidInfo
        {
            public GameObject go;
            public event Action<GameObject> OnAdd;
            public event Action OnRemove;

            public GuidInfo(StableID comp)
            {
                go = comp.gameObject;
                OnRemove = null;
                OnAdd = null;
            }

            public void HandleAddCallback() { OnAdd?.Invoke(go); }
            public void HandleRemoveCallback() { OnRemove?.Invoke(); }
        }

        // Singleton interface
        static StableIDGameObjectManager s_Instance;

        /// <summary>
        /// Adds the Stable ID to the StableIDGameObjectManager dictionary.
        /// </summary>
        /// <param name="stableID">StableID to add.</param>
        /// <returns>Returns true upon successful addition. Returns false, if the stable ID is already in the list</returns>
        public static bool Add(StableID stableID)
        {
            if (s_Instance == null)
                s_Instance = new StableIDGameObjectManager();
            return s_Instance.InternalAdd(stableID);
        }

        /// <summary>
        /// Removes the Stable ID from the StableIDGameObjectManager dictionary.
        /// </summary>
        /// <param name="key">StableKey to remove.</param>
        public static void Remove(StableKey key)
        {
            s_Instance?.InternalRemove(key);
        }

        /// <summary>
        /// Gets the GameObject for the given StableKey and adds the specified onAddCallbacks and
        /// onDestroyCallback actions to it, if it is stored in the StableIDGameObjectManager.
        /// </summary>
        /// <param name="key">StableKey to find.</param>
        /// <param name="onAddCallback">OnAddCallback action to add to the stored GameObject holder.</param>
        /// <param name="onRemoveCallback">OnDestroyCallback action to add to the stored GameObject holder.</param>
        /// <returns>Returns the GameObject associated with the guid, if exists. Otherwise null.</returns>
        public static GameObject Resolve(
            StableKey key, Action<GameObject> onAddCallback, Action onRemoveCallback)
        {
            if (s_Instance == null)
                s_Instance = new StableIDGameObjectManager();
            return s_Instance.ResolveGuidInternal(key, onAddCallback, onRemoveCallback);
        }

        /// <summary>
        /// Gets the GameObject for the given StableKey and adds the specified onDestroyCallback action to it,
        /// if it is stored in the StableIDGameObjectManager.
        /// </summary>
        /// <param name="key">StableKey to find.</param>
        /// <param name="onRemoveCallback">OnDestroyCallback action to add to the stored GameObject holder.</param>
        /// <returns>Returns the GameObject associated with the guid, if exists. Otherwise null.</returns>
        public static GameObject Resolve(StableKey key, Action onDestroyCallback)
        {
            if (s_Instance == null)
                s_Instance = new StableIDGameObjectManager();
            return s_Instance.ResolveGuidInternal(key, null, onDestroyCallback);
        }

        /// <summary>
        /// Gets the GameObject for the given StableKey, if it is stored in the StableIDGameObjectManager.
        /// </summary>
        /// <param name="key">StableKey to find.</param>
        /// <returns>Returns the GameObject associated with the guid, if exists. Otherwise null. </returns>
        public static GameObject Resolve(StableKey key)
        {
            if (s_Instance != null)
                return s_Instance.ResolveGuidInternal(key);
            return null;
        }

        // instance data
        Dictionary<StableKey, GuidInfo> m_ObjectLookup;

        StableIDGameObjectManager()
        {
            m_ObjectLookup = new Dictionary<StableKey, GuidInfo>();
        }

        bool InternalAdd(StableID guidComponent)
        {
            var key = guidComponent.Value;
            var info = new GuidInfo(guidComponent);
            if (!m_ObjectLookup.ContainsKey(key))
            {
                m_ObjectLookup.Add(key, info);
                return true;
            }

            GuidInfo existingInfo = m_ObjectLookup[key];
            if (existingInfo.go != null && existingInfo.go != guidComponent.gameObject)
            {
                // normally, a duplicate GUID is a big problem, means you won't necessarily
                // be referencing what you expect
                if (Application.isPlaying)
                {
                    Debug.AssertFormat(false, guidComponent,
                        "Guid Collision Detected between {0} and {1}.\n"
                        + "Assigning new Guid. Consider tracking runtime instances using a "
                        + "direct reference or other method.",
                        (m_ObjectLookup[key].go != null ? m_ObjectLookup[key].go.name : "NULL"),
                        (guidComponent != null ? guidComponent.name : "NULL"));
                }
                else
                {
                    // however, at editor time, copying an object with a GUID will duplicate
                    // the GUID resulting in a collision and repair.
                    // we warn about this just for pedantry reasons, and so you can detect
                    // if you are unexpectedly copying these components
                    Debug.LogWarningFormat(guidComponent,
                        "Guid Collision Detected while creating {0}.\nAssigning new Guid.",
                        (guidComponent != null ? guidComponent.name : "NULL"));
                }
                return false;
            }

            // if we already tried to find this GUID, but haven't set the game object to
            // anything specific, copy any OnAdd callbacks then call them
            existingInfo.go = info.go;
            existingInfo.HandleAddCallback();
            m_ObjectLookup[key] = existingInfo;
            return true;
        }

        void InternalRemove(StableKey key)
        {
            // trigger all the destroy delegates that have registered
            if (m_ObjectLookup.TryGetValue(key, out GuidInfo info))
                info.HandleRemoveCallback();

            m_ObjectLookup.Remove(key);
        }

        GameObject ResolveGuidInternal(StableKey key)
        {
            return m_ObjectLookup.TryGetValue(key, out GuidInfo info) ? info.go : null;
        }

        // nice easy api to find a GUID, and if it works, register an on destroy callback
        // this should be used to register functions to cleanup any data you cache on finding
        // your target. Otherwise, you might keep components in memory by referencing them
        GameObject ResolveGuidInternal(
            StableKey key, Action<GameObject> onAddCallback, Action onRemoveCallback)
        {
            if (m_ObjectLookup.TryGetValue(key, out GuidInfo info))
            {
                if (onAddCallback != null)
                    info.OnAdd += onAddCallback;

                if (onRemoveCallback != null)
                    info.OnRemove += onRemoveCallback;

                m_ObjectLookup[key] = info;
                return info.go;
            }

            if (onAddCallback != null)
                info.OnAdd += onAddCallback;

            if (onRemoveCallback != null)
                info.OnRemove += onRemoveCallback;

            m_ObjectLookup.Add(key, info);
            return null;
        }
    }
}
