using UnityEngine;
using System;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Unity.Entities.Hybrid
{
    /// <summary>
    /// Use this class as a value field wherever a reference to an object with a StableKey is required.
    ///
    /// If the target object is loaded it will be returned, otherwise NULL will be returned.
    /// By default, the referenced object can be any GameObject with a StableKey.  To make a reference
    /// that accepts only GameObjects with a specific component, use StableReference<MyComponent>.
    /// </summary>
    [Serializable]
    public class StableReferenceBase : ISerializationCallbackReceiver
    {
        /// <summary>The Stable ID value of the thing being referred to</summary>
        public StableKey Referent;

    #if UNITY_EDITOR
        // Decorate with some extra info in Editor so we can inform a user of what that GUID means
        // These are internal for the propertyDrawer
        [SerializeField] internal string m_CachedName;
        [SerializeField] internal SceneAsset m_CachedScene;
    #endif

        // Component type that thie reference expects to refer to
        internal virtual Type TypeFilter => typeof(StableID);

        // cache the referenced Game Object if we find one for performance
        GameObject m_CachedReference;
        bool m_IsCacheSet;

        // create concrete delegates to avoid boxing. 
        // When called 10,000 times, boxing would allocate ~1MB of GC Memory
        Action<GameObject> m_AddDelegate;
        Action m_RemoveDelegate;
    
        // GML todo: implicit conversion to StableKey for easy assignment

        /// <summary>
        /// Checks whether this Stable ID's value is non-zero.
        /// </summary>
        /// <returns>True, if non-zero. False, otherwise.</returns>
        public bool IsValid => Referent.IsValid;

        /// <summary>
        /// GameObject accessor, ideally the only code you ever call on this class.
        /// </summary>
        /// <returns>Returns the GameObject associated with the stored StableKey, if exists.
        /// Returns null, otherwise.</returns>
        public GameObject GameObject
        {
            get
            {
                if (!m_IsCacheSet)
                {
                    m_CachedReference = StableIDGameObjectManager.Resolve(
                        Referent, m_AddDelegate, m_RemoveDelegate);
                    m_IsCacheSet = true;
                }
                return m_CachedReference;
            }
        }

        /// <summary>
        /// Clients can register events here for when referant is instanced
        /// </summary>
        public event Action<GameObject> OnReferentAdded = delegate (GameObject go) {};

        /// <summary>
        /// Clients can register events here for when referant is destroyed
        /// </summary>
        public event Action OnReferentRemoved = delegate() {};

        void ReferentAdded(GameObject go)
        {
            m_CachedReference = go;
            OnReferentAdded(go);
        }

        void ReferentRemoved()
        {
            m_CachedReference = null;
            m_IsCacheSet = false;
            OnReferentRemoved();
        }

        /// <summary>
        /// ISerializationCallbackReceiver implementation.  Does nothing.
        /// </summary>
        public void OnBeforeSerialize()
        {
        }

        /// <summary>
        /// ISerializationCallbackReceiver implementation.
        /// Resets the cached value and installs add/remove delegates.
        /// </summary>
        public void OnAfterDeserialize()
        {
            m_CachedReference = null;
            m_IsCacheSet = false;
            m_AddDelegate = OnReferentAdded;
            m_RemoveDelegate = ReferentRemoved;
        }
    }

    /// <summary>
    /// Use this class as a value field wherever a reference to an object with a StableKey is required.
    /// The property drawer in the editor will restrict objects to be of the appropriate type, as specified
    /// by the Generic param.
    ///
    /// If the target object is loaded it will be returned, otherwise NULL will be returned.
    /// </summary>
    [Serializable]
    public class StableReference<T> : StableReferenceBase where T : Component
    {
        internal override Type TypeFilter => typeof(T);
    }
}

