using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.StableID.Editor")]
