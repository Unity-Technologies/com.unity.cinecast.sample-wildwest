using System.Collections.Generic;
using Unity.Collections;
using Unity.Mathematics;
using UnityEngine;

namespace Unity.Entities.Hybrid
{
    /// <summary>
    /// This is a convenience wrapper for EntityBehaviour.  It adds some convenience
    /// methods and the ability to force immediate reconversion of an EntityBehaviour.
    /// </summary>
    public abstract class EntityBehaviourAuthoringBase : EntityBehaviour
    {
        /// <summary>
        /// Derived classes should call base.Reset() at the *end* of the local implementation.
        /// Base class implementation triggers a reconversion.
        /// </summary>
        protected virtual void Reset() { Reconvert(); }

        /// <summary>
        /// Get the entity associated with this behaviour, in a world other than SynchronizedWorld.
        /// This is only implemented in the editor, for debugging and inspector use.  At runtime
        /// it will return Entity.Null, or SynchronizedEntity if world is SynchronizedWorld.
        /// </summary>
        /// <param name="w">The world to query.  If this is SynchronizedWorld, then this method
        /// will return SynchronizedEntity.</param>
        /// <returns></returns>
        public Entity GetDefaultEntity(World w)
        {
            if (IsSynchronized && w == SynchronizedWorld)
                return SynchronizedEntity;
            Entity e = default;
#if UNITY_EDITOR
            // Only editor debug and inspector code should ever get here.
            // At runtime this behaviour is either synchronized or stripped away.
            if (w != null && w.IsCreated)
            {
                var debug = w.EntityManager.Debug;
                var list = new NativeList<Entity>(1, Allocator.TempJob);
                debug.GetEntitiesForAuthoringObject(gameObject, list);
                if (list.Length > 0)
                    e = list[0];
                list.Dispose();
            }
#endif
            return e;
        }

        /// <summary>
        /// Force immediate reconversion to Entity.  Use this as a fallback for classes that 
        /// don't implement Get/Set for all properties
        /// </summary>
        public void ReconvertNow() => Reconvert();
    }

    /// <summary>
    /// This is a convenience template for implementing authoring EntityBehaviours for
    /// an IComponentData.  It exposes the IComponentData as a single property, and implements
    /// the get/set boilerplate code.  If you want to expose more properties than this then
    /// you must implement the boilerplate code on your own.
    /// </summary>
    /// <typeparam name="T">The IComponentData to expose as a single property</typeparam>
    public abstract class ComponentAuthoringBase<T>
        : EntityBehaviourAuthoringBase where T : struct, IComponentData
    {
        /// <summary>
        /// The actual component value.  Access using the Value get/set methods to ensure that
        /// the entity world remains synchronized.  Accessing this field directly will bypass
        /// entity synchronization.  Use it for implementing such things as Reset and OnValidate.
        /// </summary>
        [HideFoldout]
        [SerializeField]
        protected T m_Value;

        /// <summary>
        /// Access the component value.  This forces a synchronization with the entities
        /// world, and may have a performance impact.
        /// </summary>
        public T Value
        {
            get
            {
                if (IsSynchronized && !TypeManager.GetTypeInfo<T>().IsZeroSized)
                    return SynchronizedWorld.EntityManager.GetComponentData<T>(SynchronizedEntity);
                return m_Value;
            }
            set
            {
                m_Value = value;
                if (IsSynchronized)
                    SynchronizedWorld.EntityManager.SetComponentData(SynchronizedEntity, m_Value);
            }
        }

        /// <summary>
        /// Pushes the appropriate components to the entities world.  Base class implementation
        /// pushes the template IConponentData.  Derived classes should call the base class
        /// implementation first.
        /// </summary>
        /// <param name="entity">The entity being converted to</param>
        /// <param name="context">The context for the conversion</param>
        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            context.EntityManager.AddComponentData(entity, m_Value);
        }

        /// <summary>
        /// Pulls the appropriate components from the entity and stores the values into this behaviour.
        /// Base class implementation pulls the template component.  Derived classes should call the base class
        /// implementation first. 
        /// </summary>
        /// <param name="entity">The entity being converted from</param>
        /// <param name="context">The context for the conversion</param>
        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            if (!TypeManager.GetTypeInfo<T>().IsZeroSized)
                m_Value = context.EntityManager.GetComponentData<T>(entity);
        }
    }

    /// <summary>
    /// This is a convenience template for implementing authoring EntityBehaviours for
    /// an ISharedComponentData.  It exposes the ISharedComponentData as a single property, and implements
    /// the get/set boilerplate code.  If you want to expose more properties than this then
    /// you must implement the boilerplate code on your own.
    /// </summary>
    /// <typeparam name="T">The ISharedComponentData to expose as a single property</typeparam>
    public abstract class SharedComponentAuthoringBase<T>
        : EntityBehaviourAuthoringBase where T : struct, ISharedComponentData
    {
        /// <summary>
        /// The actual component value.  Access using the Value get/set methods to ensure that
        /// the entity world remains synchronized.  Accessing this field directly will bypass
        /// entity synchronization. Use it for implementing such things as Reset and OnValidate.
        /// </summary>
        [HideFoldout]
        [SerializeField]
        protected T m_Value;

        /// <summary>
        /// Access the component value.  This forces a synchronization with the entities
        /// world, and may have a performance impact.
        /// </summary>
        public T Value
        {
            get
            {
                if (IsSynchronized)
                    return SynchronizedWorld.EntityManager.GetSharedComponentData<T>(SynchronizedEntity);
                return m_Value;
            }
            set
            {
                m_Value = value;
                if (IsSynchronized)
                    SynchronizedWorld.EntityManager.SetSharedComponentData(SynchronizedEntity, m_Value);
            }
        }

        /// <summary>
        /// Pushes the appropriate components to the entities world.  Base class implementation
        /// pushes the template IConponentData.  Derived classes should call the base class
        /// implementation first.
        /// </summary>
        /// <param name="entity">The entity being converted to</param>
        /// <param name="context">The context for the conversion</param>
        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            context.EntityManager.AddSharedComponentData(entity, m_Value);
        }

        /// <summary>
        /// Pulls the appropriate components from the entity and stores the values into this behaviour.
        /// Base class implementation pulls the template component.  Derived classes should call the base class
        /// implementation first. 
        /// </summary>
        /// <param name="entity">The entity being converted from</param>
        /// <param name="context">The context for the conversion</param>
        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            m_Value = context.EntityManager.GetSharedComponentData<T>(entity);
        }
    }

    /// <summary>
    /// This is a convenience template for implementing authoring EntityBehaviours for
    /// an IBufferElementData.  It exposes the IBufferElementData as a single property, and implements
    /// the get/set boilerplate code.  If you want to expose more properties than this then
    /// you must implement the boilerplate code on your own.
    /// </summary>
    /// <typeparam name="T">The IBufferElementData to expose as a single property array</typeparam>
    public abstract class DynamicBufferAuthoringBase<T>
        : EntityBehaviourAuthoringBase where T : unmanaged, IBufferElementData
    {
        /// <summary>
        /// The actual array of component values.  Access using the Values get/set methods to ensure that
        /// the entity world remains synchronized.  Accessing this field directly will bypass
        /// entity synchronization. Use it for implementing such things as Reset and OnValidate.
        /// </summary>
        [SerializeField]
        protected List<T> m_Values = new List<T>();

        List<T> m_ValuesCache = new List<T>();

        /// <summary>
        /// Access the component value array.  This forces a synchronization with the entities
        /// world, and may have a performance impact.
        /// </summary>
        public List<T> Values
        {
            get
            {
                if (IsSynchronized)
                {
                    var b = SynchronizedWorld.EntityManager.GetBuffer<T>(SynchronizedEntity);
                    m_ValuesCache.Clear();
                    for (int i = 0; i < b.Length; ++i)
                        m_ValuesCache.Add(b[i]);
                    return m_ValuesCache;
                }
                return m_Values;
            }
            set
            {
                m_Values = value;
                if (IsSynchronized)
                {
                    var buffer = SynchronizedWorld.EntityManager.GetBuffer<T>(SynchronizedEntity);
                    buffer.Clear();
                    buffer.Capacity = m_Values.Count;
                    foreach (var element in m_Values)
                        buffer.Add(element);
                }
            }
        }

        /// <summary>
        /// Pushes the appropriate components to the entities world.  Base class implementation
        /// pushes the template IConponentData.  Derived classes should call the base class
        /// implementation first.
        /// </summary>
        /// <param name="entity">The entity being converted to</param>
        /// <param name="context">The context for the conversion</param>
        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            var b = context.EntityManager.AddBuffer<T>(entity);
            b.Clear();
            b.Capacity = math.max(1, m_Values.Count);
            foreach (var element in m_Values)
                b.Add(element);
        }

        /// <summary>
        /// Pulls the appropriate components from the entity and stores the values into this behaviour.
        /// Base class implementation pulls the template component.  Derived classes should call the base class
        /// implementation first. 
        /// </summary>
        /// <param name="entity">The entity being converted from</param>
        /// <param name="context">The context for the conversion</param>
        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            var b = context.EntityManager.GetBuffer<T>(entity);
            m_Values.Clear();
            for (int i = 0; i < b.Length; ++i)
                m_Values.Add(b[i]);
        }
    }
}
