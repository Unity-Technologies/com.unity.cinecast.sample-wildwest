using System;
using System.Collections.Generic;
using System.Linq;
using Unity.Mathematics;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Transforms;
using UnityEngine;
using Unity.Jobs;
using Unity.Burst;
using UnityEngine.Jobs;

namespace Unity.Entities.Hybrid
{
    /// <summary>
    /// EntityBehaviour is a base class for DOTS authoring that behaves just like standard DOTS
    /// authoring behaviours, but with the additional ability to play nicely within an old-fashioned
    /// GameObject-based runtime, allowing clients to painlessly inject DOTS-implemented features
    /// into their non-DOTS projects.
    ///
    /// The intended user is a developer who wants to implement a DOTS feature that can be used in both
    /// DOTS and GameObject projects.  Clients of that new feature can use it in existing GameObject
    /// projects without even being aware that it's implemented in DOTS.
    /// 
    /// Features implemented using EntityBehaviour need to be implemented only once, and can then be used in
    /// pure-DOTS environments without performance penalties, and also in GameObject projects.  In the latter
    /// case, performance can be slower due to potential synchronization with GameObjects, but otherwise is
    /// identical to pure-DOTS performance, since it is the same implementation.
    ///
    /// EntityBehaviour works with or without the ExecuteAlways attribute.
    ///
    /// EntityBehaviour operates in two modes, depending on the context in which it finds itself:
    /// 
    /// 1. Non-synchronized mode:  In a pure-DOTS context (e.g. in a subscene or as part
    /// of a standard DOTS conversion hierarchy), the behaviour exists during authoring only, and is
    /// stripped away at runtime, abandoning the GameObject-based authoring wrapper.  Just like normal
    /// authoring behaviours, EntityBehaviour implements the IConvertGameObjectToEntity interface,
    /// and generates DOTS components for entities.  At authoring time, standard mechanisms
    /// (e.g. LiveLink) will function correctly, and it will behave as any other authoring behaviour.
    ///
    /// 2. Synchronized mode:  Outside of a conversion context, it has special behaviour.  It manages
    /// its own entity conversion and keeps track of associated entities.  In this mode, the GameObject
    /// is not stripped away, remaining at runtime just like ordinary MonoBehaviours.  Thus, it can
    /// expose DOTS-implemented state and functionality to other MonoBehaviours and to non-DOTS
    /// subsystems, via custom methods and get/set properties on the EntityBehaviour.
    ///
    /// In Synchronized mode, there is special logic to ensure consistency with other MonoBehaviours,
    /// so that the user of the feature need not even be aware that there is a DOTS backend:
    /// - ISerializationCallbackReceiver.OnBeforeSerialize() is implemented to ensure that the inspector
    /// always displays content that is synchronized with the current state of affairs in the DOTS world.
    /// - OnValidate() is implemented to push the inspector changes to the entity (client must not forget
    /// to call the base class implementation if this method is overridden).
    /// - OnDidApplyAnimationProperties() is implemented to push Animator changes to the entity (client
    /// must not forget to call the base class implementation if this method is overridden).
    /// - Transforms are automatically synchronized
    ///
    /// Where a standard authoring behaviour implements the Convert() method, the EntityBehaviour
    /// instead must implement 2 methods:
    /// - PushToEntity.  This converts from the Authoring representation to the entity representation.
    /// It is the same functionality as standard Convert (and takes the place of it), but with a
    /// slightly different API
    /// - PullFromEntity.  This is the reverse of PushToEntity, and updates the authoring data
    /// based on the entity data.  Only those fields that the client wishes to synchronize need
    /// be updated here.  This is at the discretion of the client.  Calling this will generate
    /// a sync point in the DOTS world, which can impact performance.
    /// </summary>
    ///
    /// <example>
    /// <code>
    /// struct MyComponent : IComponentData
    /// {
    ///     public int IntValue;
    ///     public float FloatValue;
    /// }
    /// 
    /// class MyEntityBehaviour : EntityBehaviour
    /// {
    ///     [SerializeField] private int _IntValue;
    ///     [SerializeField] private float _FloatValue;
    /// 
    ///     public int IntValue
    ///     {
    ///         get
    ///         {
    ///             if (IsSynchronized)
    ///                 return SynchronizedWorld.EntityManager.GetComponentData<MyComponent>(SynchronizedEntity).IntValue;
    ///             return _IntValue;
    ///         }
    ///         set
    ///         {
    ///             _IntValue = value;
    ///             if (IsSynchronized)
    ///             {
    ///                 // Retain other value (Only required if there are multiple properties on the IComponentData)
    ///                 var data = SynchronizedWorld.EntityManager.GetComponentData<MyComponent>(SynchronizedEntity);
    ///                 data.IntValue = value;
    ///                 SynchronizedWorld.EntityManager.SetComponentData(SynchronizedEntity, data);
    ///             }
    ///         }
    ///     }
    /// 
    ///     public float FloatValue
    ///     {
    ///         get
    ///         {
    ///             if (IsSynchronized)
    ///                 return SynchronizedWorld.EntityManager.GetComponentData<MyComponent>(SynchronizedEntity).FloatValue;
    ///             return _FloatValue;
    ///         }
    ///         set
    ///         {
    ///             _FloatValue = value;
    ///             if (IsSynchronized)
    ///             {
    ///                 // Retain other value (Only required if there are multiple properties on the IComponentData)
    ///                 var data = SynchronizedWorld.EntityManager.GetComponentData<MyComponent>(SynchronizedEntity);
    ///                 data.FloatValue = value;
    ///                 SynchronizedWorld.EntityManager.SetComponentData(SynchronizedEntity, data);
    ///             }
    ///         }
    ///     }
    /// 
    ///     override protected void PushToEntity(Entity entity, ConversionContext context)
    ///     {
    ///         context.EntityManager.AddComponentData(entity, new MyComponent
    ///         {
    ///             IntValue = _IntValue,
    ///             FloatValue = _FloatValue,
    ///         });
    ///     }
    /// 
    ///     override protected void PullFromEntity(Entity entity, ConversionContext context)
    ///     {
    ///         var data = context.EntityManager.GetComponentData<MyComponent>(entity);
    ///         _IntValue = data.IntValue;
    ///         _FloatValue = data.FloatValue;
    ///     }
    /// 
    ///     protected override void OnValidate()
    ///     {
    ///         _IntValue = Mathf.Clamp(_IntValue, 0, 100);
    ///         base.OnValidate(); // call the base class implementation at the end
    ///     }
    /// }
    /// </code>
    /// </example>
    abstract public class EntityBehaviour : MonoBehaviour, ISerializationCallbackReceiver, IConvertGameObjectToEntity
    {
        private World _World;
        private Entity _Entity;
        private EntityArchetype _BeforeConversionArchetype;
        private EntityArchetype _AfterConversionArchetype;
        private bool _IsSynchronized;

        /// <summary>
        /// This is passed as a parameter to PushToEntity and PullFromEntity, and provides
        /// an entity  conversion context.
        /// 
        /// It will be set up differently depending on whether the EntityBehaviour is Synchronized,
        /// and is meant to provide a uniform API to cover most conversion needs.
        /// </summary>
        public struct ConversionContext
        {
            GameObjectConversionSystem m_ConversionSystem;
            BidirectionalConversionSystem m_BidirectionalConversion;

            internal ConversionContext(BidirectionalConversionSystem system)
            {
                m_BidirectionalConversion = system;
                m_ConversionSystem = null;
            }

            internal ConversionContext(GameObjectConversionSystem system)
            {
                m_ConversionSystem = system;
                m_BidirectionalConversion = null;
            }

            /// <summary>
            /// Indicates the mode in which the EntityBehaviour is operating: synchronized or not.
            /// Synchronized means that the EntityBehaviour will remain in the runtime application,
            /// and will be synchronized with the underlying DOTS implementation.
            /// </summary>
            /// <value>True if EntityBehaviour is synchronized</value>
            public bool IsSynchronized => m_BidirectionalConversion != null;

            /// <summary>
            /// Get the destination entity manager for entity conversion
            /// </summary>
            /// <value>The entity manager to use for conversion</value>
            public EntityManager EntityManager
            {
                get
                {
                    if (IsSynchronized)
                        return m_BidirectionalConversion.EntityManager;
                    return m_ConversionSystem.DstEntityManager;
                }
            }

            /// <summary>
            /// Get the main entity generated by a game object during conversion, if the entity is not a prefab
            /// </summary>
            /// <param name="gameObject">The game object to look up</param>
            /// <returns>The promary entity created by that game object during conversion, if any</returns>
            public Entity GetPrimaryEntity(GameObject gameObject)
            {
                if (gameObject == null)
                    return Entity.Null;
                if (IsSynchronized)
                    return m_BidirectionalConversion.GetPrimaryEntity(gameObject, false);
                return m_ConversionSystem.GetPrimaryEntity(gameObject);
            }

            /// <summary>
            /// Get the main entity generated by a game object during conversion, if the entity is a prefab
            /// </summary>
            /// <param name="gameObject">The game object to look up</param>
            /// <returns>The promary entity created by that game object during conversion, if any</returns>
            public Entity GetPrimaryEntityForPrefab(GameObject gameObject)
            {
                if (gameObject == null)
                    return Entity.Null;
                if (IsSynchronized)
                    return m_BidirectionalConversion.GetPrimaryEntity(gameObject, true);
                return m_ConversionSystem.GetPrimaryEntity(gameObject);
            }

            /// <summary>
            /// Get the main entity generated by a game object during conversion
            /// </summary>
            /// <param name="component">A game object component</param>
            /// <returns>The promary entity created by that game object during conversion, if any</returns>
            public Entity GetPrimaryEntity(Component component)
            {
                if (component == null)
                    return Entity.Null;
                return GetPrimaryEntity(component.gameObject);
            }

            /// <summary>
            /// Get the authoring GameObject that generated an Entity.
            /// This can only be used in Synchronized mode, and only works if the object
            /// being looked up is also an EntityBehaviour in Synchronized mode.
            /// If not synchronized, an exception will be generated.
            /// </summary>
            /// <param name="entity">The entity to look up</param>
            /// <returns>The authoring component that generated the entity</returns>
            public GameObject GetGameObject(Entity entity)
            {
                if (IsSynchronized)
                    return m_BidirectionalConversion.GetGameObject(entity);
                throw new ArgumentException("GetGameObject may only be used when IsSynchronized is true");
            }

            /// <summary>
            /// Get the a component from an authoring behaviour that generated an Entity.
            /// This can only be used in Synchronized mode, and only works if the object
            /// being looked up is also an EntityBehaviour in Synchronized mode.
            /// </summary>
            /// <param name="entity">The entity to look up</param>
            /// <typeparam name="T">The component type to get</typeparam>
            /// <returns>The authoring component that generated the entity</returns>
            public T GetComponent<T>(Entity entity) where T : UnityEngine.Component
            {
                var go = GetGameObject(entity);
                if (go != null)
                {
                    go.TryGetComponent<T>(out var com);
                    return com;
                }
                return null;
            }

            /// <summary>
            /// Fallback to access standard conversion system methods.
            /// This can only be used if not in Synchronized mode.
            /// If not synchronized, an exception will be generated.
            /// </summary>
            public GameObjectConversionSystem ConversionSystem
            {
                get
                {
                    if (IsSynchronized)
                        throw new ArgumentException("ConversionSystem can't be used when IsSynchronized is true");
                    return m_ConversionSystem;
                }
            }
        }

        /// <summary>
        /// In Synchronized mode, this will return the entity that is associated
        /// with this EntityBehavior.  This can only be used in Synchronized mode.
        /// If not synchronized, an exception will be generated.
        /// </summary>
        /// <value>The associated entity</value>
        public Entity SynchronizedEntity
        {
            get
            {
                if (_IsSynchronized)
                    return _Entity;
                throw new System.ArgumentException("SynchronizedEntity may only be used when IsSynchronized is true.");
            }
        }

        /// <summary>
        /// In Synchronized mode, this will return the DOTS World that is associated
        /// with this EntityBehavior.  This can only be used in Synchronized mode.
        /// If not synchronized, an exception will be generated.
        /// </summary>
        /// <value>The associated DOTS World</value>
        public World SynchronizedWorld 
        {
            get
            {
                if (_IsSynchronized)
                    return _World;
                throw new System.ArgumentException("SynchronizedWorld may only be used when IsSynchronized is true.");
            }
        }

        /// <summary>
        /// Checks whether this behaviour is currently in Synchronized mode.
        /// It is in Synchronized mode when the entity has been created and
        /// when the EntityBehaviour is not otherwise in an entity conversion context.
        /// In an entity conversion context, the EntityBehaviour gets stripped away at runtime.
        /// </summary>
        /// <value>True if EntityBehaviour is currently in Synchronized mode</value>
        public bool IsSynchronized => _IsSynchronized && _World != null
            && _World.IsCreated && _World.EntityManager.Exists(_Entity);

        /// <summary>
        /// Create a Conversion Context to force immediate synchronization with associated entity.
        /// This can only be used in Synchronized mode.
        /// If not synchronized, an exception will be generated.
        /// </summary>
        /// <value>A ConversionContext suitable for synchronization</value>
        protected ConversionContext EntityConversionContext
        {
            get
            {
                if (_World != null)
                    return new ConversionContext(_World.GetExistingSystem<BidirectionalConversionSystem>());
                throw new System.ArgumentException("EntityConversionContext may only be used when IsSynchronized is true.");
            }
        }

        /// <summary>
        /// Force immediate reconversion: PushToEntity will be called.
        /// </summary>
        protected void Reconvert()
        {
            if (IsSynchronized)
            {
                RevertAddedComponentData();
                SynchronizedConvert(_Entity, _World, EntityConversionContext);
            }
        }

        /// <summary>
        /// Forces reconversion (PushToEntity will be called) after an editor change.
        /// Clients overriding this method must remember to call the base class implementation
        /// _at the end_ of their implementaion, to make sure to push the validated data.
        /// </summary>
        protected virtual void OnValidate()
        {
            Reconvert();
        }

        /// <summary>
        /// Forces reconversion (PushToEntity will be called) after an Animator change.
        /// Clients overriding this method must remember to call the base class implementation
        /// _at the end_ of their implementaion, to make sure to push the most up-to-date data.
        /// </summary>
        protected virtual void OnDidApplyAnimationProperties()
        {
            Reconvert();
        }

        /// <summary>
        /// Converts from authoring representation to runtime representation.  This does the same
        /// job as IConvertGameObjectToEntity.Convert() - and replaces that method - with the difference
        /// that the EntityBehaviour may be in Synchronized mode, in which case some extra support
        /// is available in the ConversionContext if required.
        /// </summary>
        /// <param name="entity">The primary entity created by this object</param>
        /// <param name="context">Context providing entity manager and conversion utilities</param>
        protected abstract void PushToEntity(Entity entity, ConversionContext context);

        /// <summary>
        /// Converts desired elements from runtime representation back to authoring representation to.
        /// Only those fields that the client wants to synchronize need be handled here.
        /// Generally speaking PullFromEntity is lossy, and not all data may be reverse-convertible.
        /// This will only be called if EntityBehaviour is in Synchronized mode.
        /// </summary>
        /// <param name="entity">The primary entity created by this object</param>
        /// <param name="context">Context providing entity manager and conversion utilities</param>
        protected abstract void PullFromEntity(Entity entity, ConversionContext context);


        /// <summary>
        /// Calls PushToEntity.  Clients should not override this method.
        /// Conversion should be fully implemented in PushToEntity.
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="dstManager"></param>
        /// <param name="conversionSystem"></param>
        public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
        {
    #if UNITY_EDITOR
            dstManager.SetName(entity, transform.name);
    #endif
            PushToEntity(entity, new ConversionContext(conversionSystem));
        }

        void OnEnableINTERNAL()
        {
            DefaultWorldInitialization.DefaultLazyEditModeInitialize();
            var defaultWorld = World.DefaultGameObjectInjectionWorld;
            if (defaultWorld != null)
            {
                var system = defaultWorld.GetOrCreateSystem<BidirectionalConversionSystem>();
                system.RegisterEntityBehaviour(this);
            }
/*
            else
            {
                Debug.LogWarning($"{gameObject.name}:RegisterEntityBehaviour failed because there "
                    + $"is no {nameof(World.DefaultGameObjectInjectionWorld)}", this);
            }
*/
        }

        void OnDisableINTERNAL()
        {
            if (_World != null && _World.IsCreated)
            {
                var system = _World.GetExistingSystem<BidirectionalConversionSystem>();
                system.UnregisterEntityBehaviour(this);
            }
/*
            else
            {
                Debug.LogWarning($"{gameObject.name}:UnregisterEntityBehaviour failed because there "
                    + $"is no {nameof(World.DefaultGameObjectInjectionWorld)}", this);
            }
*/
        }

        /// <summary>
        /// Implementation of ISerializationCallbackReceiver.OnBeforeSerialize().
        /// Derived classes must call the base class implementation
        /// </summary>
        public virtual void OnBeforeSerialize()
        {
            if (IsSynchronized)
                PullFromEntity(_Entity, EntityConversionContext);
        }

        /// <summary>
        /// Implementation of ISerializationCallbackReceiver.OnAfterDeserialize().
        /// Base class implementation is empty.
        /// </summary>
        public virtual void OnAfterDeserialize()
        {
        }

        internal void SynchronizedConvert(Entity entity, World world, ConversionContext context)
        {
            _BeforeConversionArchetype = world.EntityManager.GetChunk(entity).Archetype;
            PushToEntity(entity, context);
            _AfterConversionArchetype = world.EntityManager.GetChunk(entity).Archetype;
            _Entity = entity;
            _World = world;
            _IsSynchronized = true;
        }

        internal void ClearEntityReferences()
        {
            _BeforeConversionArchetype = default;
            _AfterConversionArchetype = default;
            _Entity = default;
            _World = null;
            _IsSynchronized = false;
        }

        unsafe internal void RevertAddedComponentData()
        {
            if (!_AfterConversionArchetype.Valid)
                return;
            var addedTypes = stackalloc int[_AfterConversionArchetype.TypesCount];
            var removedTypes = stackalloc int[_BeforeConversionArchetype.TypesCount];
            EntityArchetype.CalculateDifference(
                _BeforeConversionArchetype, _AfterConversionArchetype, addedTypes,
                out var addedTypesCount, removedTypes, out var removedTypesCount);

            for (int i = 0; i != addedTypesCount; i++)
                _World.EntityManager.RemoveComponent(_Entity, ComponentType.FromTypeIndex(addedTypes[i]));
            for (int i = 0; i != removedTypesCount; i++)
                _World.EntityManager.AddComponent(_Entity, ComponentType.FromTypeIndex(removedTypes[i]));

            _AfterConversionArchetype = default;
            _BeforeConversionArchetype = default;
        }

        /// <summary>
        /// Force an immediate conversion, to avoid waiting a frame for the entity to be created
        /// </summary>
        /// <param name="world">Current active world</param>
        public static void ForceImmediateConversion(World world)
        {
            world.GetOrCreateSystem<BidirectionalConversionSystem>().Update();
        }

        /// <summary>
        /// Do a manual update of the EntityBehaviour subsystem
        /// </summary>
        /// <param name="world">Current active world</param>
        public static void ManualUpdateSystems(World world)
        {
            world.GetOrCreateSystem<EntityBehaviourLocalToWorldToTransform>().Update();
            world.GetOrCreateSystem<BidirectionalConversionSystem>().Update();
        }
    }

    struct LastSyncedTransformState : IComponentData
    {
        public float3 Position;
        public quaternion Rotation;
    }

    class EntityOwnedByGameObject : IDisposable, IComponentData, ICloneable
    {
        public int RefCount;

        public void Dispose()
        {
            if (RefCount != 0)
            {
                // Debug.LogError("Entity was destroyed, but it is owned by a game object that is still alive");
            }
        }

        public object Clone()
        {
            Debug.LogError("It is not possible to Instantiate an entity that is owned by a game object");
            return null;
        }
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateBefore(typeof(TransformSystemGroup))]
    partial class EntityBehaviourLocalToWorldToTransform : SystemBase
    {
        EntityQuery m_ExistingQuery;

        protected override void OnCreate()
        {
            m_ExistingQuery = GetEntityQuery(
                new EntityQueryDesc
                {
                    All = new[]
                    {
                        ComponentType.ReadOnly<EntityOwnedByGameObject>(),
                        ComponentType.ReadOnly<Transform>(),
                        ComponentType.ReadOnly<LastSyncedTransformState>(),
                    }
                }
            );
        }

        protected override void OnUpdate()
        {
            //@TODO: Stop using Query.GetTransformAccessArray and incrementally add / remove from TransformAccessArray directly
            //       Transform should not be present on the Entity
            var transformAccessArray = m_ExistingQuery.GetTransformAccessArray();

            var job = new CopyTransformJob
            {
                Translation = GetComponentDataFromEntity<Translation>(),
                Rotation = GetComponentDataFromEntity<Rotation>(),
                LastKnownState = GetComponentDataFromEntity<LastSyncedTransformState>(),

                entities = m_ExistingQuery.ToEntityArrayAsync(Allocator.TempJob, out var dependendency)
            };

            Dependency = job.Schedule(transformAccessArray, JobHandle.CombineDependencies(dependendency, Dependency));
        }

        [BurstCompile]
        struct CopyTransformJob : IJobParallelForTransform
        {
            [NativeDisableParallelForRestriction]
            public ComponentDataFromEntity<Translation> Translation;
            [NativeDisableParallelForRestriction]
            public ComponentDataFromEntity<Rotation> Rotation;
            [NativeDisableParallelForRestriction]
            public ComponentDataFromEntity<LastSyncedTransformState> LastKnownState;


            [DeallocateOnJobCompletion] [ReadOnly] public NativeArray<Entity> entities;

            //@TODO: TransformAccessArray must be ordered hierarchy downwards since everything is in world space

            public void Execute(int index, TransformAccess transform)
            {
                var entity = entities[index];

                float3 enginePosition = transform.position;
                quaternion engineRotation = transform.rotation;
                
                var lastKnownState = LastKnownState[entity];
                bool didModify = false;

                // We combine positional changes from the entity and GameObject worlds, because we can
                var entityPosition = Translation[entity].Value;
                if (!lastKnownState.Position.Equals(enginePosition)
                    || !lastKnownState.Position.Equals(entityPosition))
                {
                    var engineDelta = enginePosition - lastKnownState.Position;
                    var entityDelta = entityPosition - lastKnownState.Position;

                    transform.position = lastKnownState.Position + engineDelta + entityDelta;

                    // floating point accuracy in a hierarchy means that the value you set isn't 
                    // necessarily the value you get back. 
                    // And we dont want to sync the opposite way next frame because of it...
                    lastKnownState.Position = transform.position;
                    Translation[entity] = new Translation { Value = lastKnownState.Position };
                    didModify = true;
                }

                // Rotational changes can't be combined, so any GameObject changes will crush Entity world changes
                if (!lastKnownState.Rotation.Equals(engineRotation))
                {
                    Rotation[entity] = new Rotation { Value = engineRotation };
                    lastKnownState.Rotation = engineRotation;
                    didModify = true;
                }
                else
                {
                    var entityRotation = Rotation[entity].Value;
                    if (!entityRotation.Equals(lastKnownState.Rotation))
                    {
                        transform.rotation = entityRotation;

                        // floating point accuracy in a hierarchy means that the value you set isn't
                        // necessarily the value you get back.
                        // And we dont want to sync the opposite way next frame because of it...
                        lastKnownState.Rotation = transform.rotation;
                        didModify = true;
                    }
                }
                if (didModify)
                {
                    LastKnownState[entity] = lastKnownState;
                }
            }
        }
    }

    [AlwaysUpdateSystem]
    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateInGroup(typeof(InitializationSystemGroup))]
    partial class BidirectionalConversionSystem : SystemBase
    {
        Dictionary<Entity, GameObject> _EntityToGameObject = new Dictionary<Entity, GameObject>();
        UnsafeHashMap<int, Entity>     _GameObjectToEntity = new UnsafeHashMap<int, Entity>(1024, Allocator.Persistent);
        HashSet<GameObject>            _ScheduledForConversion = new HashSet<GameObject>();
        HashSet<GameObject>            _ScheduledPrefabsForConversion = new HashSet<GameObject>();
        HashSet<EntityBehaviour>       _AllEntityBehaviours = new HashSet<EntityBehaviour>();
        private List<EntityBehaviour>  _EntityBehavioursCache = new List<EntityBehaviour>();
        private bool                   _HierarchyIsDirty;

        public void RegisterEntityBehaviour(EntityBehaviour behaviour)
        {
            _AllEntityBehaviours.Add(behaviour);

            if (!IsInConversionContext(behaviour.gameObject))
                _ScheduledForConversion.Add(behaviour.gameObject);
        }

        public void UnregisterEntityBehaviour(EntityBehaviour behaviour)
        {
            _AllEntityBehaviours.Remove(behaviour);

            if (behaviour.IsSynchronized)
                DisconnectFromEntityBehaviour(behaviour);
        }

        public void SetHierarchyIsDirty()
        {
            _HierarchyIsDirty = true;
        }

        void DisconnectFromEntityBehaviour(EntityBehaviour behaviour)
        {
            bool revert = true;
            var owner = EntityManager.GetComponentData<EntityOwnedByGameObject>(behaviour.SynchronizedEntity);
            if (owner != null)
            {
                owner.RefCount--;
                if (owner.RefCount <= 0)
                {
                    _GameObjectToEntity.Remove(behaviour.gameObject.GetInstanceID());
                    EntityManager.DestroyEntity(behaviour.SynchronizedEntity);
                    revert = false;
                }
            }

            if (revert)
                behaviour.RevertAddedComponentData();

            behaviour.ClearEntityReferences();
        }

        void CheckConversionContextForAllEntityBehaviours()
        {
            for (var it = _AllEntityBehaviours.GetEnumerator(); it.MoveNext(); )
            {
                var behaviour = it.Current;
                if (behaviour == null)
                    continue;
                if (behaviour.IsSynchronized)
                {
                    if (IsInConversionContext(behaviour.gameObject))
                        DisconnectFromEntityBehaviour(behaviour);
                }
                else if (!IsInConversionContext(behaviour.gameObject))
                    _ScheduledForConversion.Add(behaviour.gameObject);
            }
        }

        static bool IsInConversionContext(GameObject go)
        {
#if UNITY_EDITOR || UNITY_DOTSRUNTIME
            //@TODO: Support root scene conversion when it's a thing
            if (go.scene.isSubScene)
                return true;
#endif
            if (go.GetComponentInParent<ConvertToEntity>() != null
                && go.GetComponentInParent<StopConvertToEntity>() == null)
            {
                return true;
            }
            return false;
        }

        void DestroyEntitiesForDeletedGameObjects()
        {
            var destroyedList = new List<GameObject>();
            foreach (var i in _EntityToGameObject)
            {
                if (i.Value == null)
                    destroyedList.Add(i.Value);
            }

            foreach (var go in destroyedList)
            {
                OnDestroyGameObject(go);
            }
        }

        void OnDestroyGameObject(GameObject gameObject)
        {
            if (!_GameObjectToEntity.TryGetValue(gameObject.GetInstanceID(), out var entity))
                return;

            _GameObjectToEntity.Remove(gameObject.GetInstanceID());
            _EntityToGameObject.Remove(entity);

            EntityManager.DestroyEntity(entity);
        }

        void Convert(GameObject gameObject, bool isPrefab)
        {
            var entity = GetPrimaryEntityDontScheduleForConversion(gameObject);
            var context = new EntityBehaviour.ConversionContext(this);
            var transform = gameObject.transform;

            var pos = transform.position;
            var rot = transform.rotation;
            EntityManager.AddComponentData(entity, new Translation { Value = pos } );
            EntityManager.AddComponentData(entity, new Rotation { Value = rot } );
            EntityManager.AddComponentData(entity, new LocalToWorld { Value = transform.localToWorldMatrix } );

            if (!isPrefab)
            {
                EntityManager.AddComponentData(entity, new EntityGuid(gameObject.GetInstanceID(), 0, 0));

                EntityManager.AddComponentData(entity, new LastSyncedTransformState
                {
                    Position = pos,
                    Rotation = rot
                });
                //@TODO: Don't think Transform component existing on the entity is a good idea.
                //       Users might write game code accessing it directly, writing code that won't work in the conversion context.
                EntityManager.AddComponentObject(entity, transform);
            }

            // Only convert dedicated EntityBeahviours.
            // Don't convert other data that already has a game object runtime representation
            int count = 0;
            gameObject.GetComponents(_EntityBehavioursCache);

            foreach (var behaviour in _EntityBehavioursCache)
                behaviour.RevertAddedComponentData();

            foreach (var behaviour in _EntityBehavioursCache)
            {
    #if UNITY_EDITOR
                // Skip if Edit Mode and not ExecuteInEditMode
                if (!Application.isPlaying && !behaviour.runInEditMode)
                    continue;
    #endif
                ++count;
                behaviour.SynchronizedConvert(entity, World, context);
            }

            if (isPrefab)
                EntityManager.AddComponentData(entity, new Prefab());
            else
                EntityManager.AddComponentData(entity, new EntityOwnedByGameObject { RefCount = count });
        }

        Entity GetPrimaryEntityDontScheduleForConversion(GameObject gameObject)
        {
            if (_GameObjectToEntity.TryGetValue(gameObject.GetInstanceID(), out var entity))
                return entity;

            entity = EntityManager.CreateEntity();
    #if UNITY_EDITOR
            EntityManager.SetName(entity, gameObject.name);
    #endif
            _EntityToGameObject.Add(entity, gameObject);
            _GameObjectToEntity.Add(gameObject.GetInstanceID(), entity);
            return entity;
        }

        public Entity GetPrimaryEntity(GameObject gameObject, bool isPrefab)
        {
            if (_GameObjectToEntity.TryGetValue(gameObject.GetInstanceID(), out var entity))
                return entity;

            entity = EntityManager.CreateEntity();
    #if UNITY_EDITOR
            EntityManager.SetName(entity, gameObject.name);
    #endif
            _GameObjectToEntity.Add(gameObject.GetInstanceID(), entity);
            if (isPrefab)
                _ScheduledPrefabsForConversion.Add(gameObject);
            else
            {
                _EntityToGameObject.Add(entity, gameObject);
                _ScheduledForConversion.Add(gameObject);
            }
            return entity;
        }

        public GameObject GetGameObject(Entity entity)
        {
            _EntityToGameObject.TryGetValue(entity, out var gameObject);
            return gameObject;
        }

        protected override void OnUpdate()
        {
            //@TODO: Need test for defining the behaviour.
            // Fixup if objects were reparented into or out of conversion contexts
            if (_HierarchyIsDirty)
                CheckConversionContextForAllEntityBehaviours();
            _HierarchyIsDirty = false;

            while (_ScheduledForConversion.Count != 0)
            {
                var go = _ScheduledForConversion.First();
                if (go != null)
                    Convert(go, false);
                _ScheduledForConversion.Remove(go);
            }

            while (_ScheduledPrefabsForConversion.Count != 0)
            {
                var go = _ScheduledPrefabsForConversion.First();
                if (go != null)
                    Convert(go, true);
                _ScheduledPrefabsForConversion.Remove(go);
            }

            DestroyEntitiesForDeletedGameObjects();
        }
    }
}
