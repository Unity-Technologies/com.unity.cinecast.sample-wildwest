using System;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;
using Unity.Entities.Hybrid;

namespace Unity.Entities.Editor
{
    [CustomPropertyDrawer(typeof(StableReferenceBase), true)]
    class StableReferenceDrawer : PropertyDrawer
    {
        // Cache GUI content to avoid creating garbage every frame in editor
        GUIContent m_SceneLabelGUI = new GUIContent("in", "The target object is expected in this scene asset");
        GUIContent m_ClearButtonGUI = new GUIContent("Clear", "Remove Cross Scene Reference");

        GUIContent m_ExpandGUI = new GUIContent("", "Show the scene where the asset is expected to be found");
        GUIContent m_ShrinkGUI = new GUIContent("", "Hide the scene information");

        Color m_WarningColor = new Color(1, 193.0f/255.0f, 7.0f/255.0f); // the "warning" icon color

        // Optionally add an extra line to display source scene for targets
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            var h = base.GetPropertyHeight(property, label);
            if (property.isExpanded)
                h += EditorGUIUtility.singleLineHeight + EditorGUIUtility.standardVerticalSpacing;
            return h;
        }

        public override void OnGUI(Rect rect, SerializedProperty property, GUIContent label)
        {
            var key = StableKey.Default;

            // Unfortunately we cannot cache these because in lists the property drawer
            // gets recycled and used for multiple entries
            var editedObject = property.GetValueAsObject<StableReferenceBase>();
            var GUIDProp = property.FindPropertyRelative(() => editedObject.Referent)
                .FindPropertyRelative(() => key.Value)
                    .FindPropertyRelative(() => key.Value.Value);
            var nameProp = property.FindPropertyRelative(() => editedObject.m_CachedName);
            var sceneProp = property.FindPropertyRelative(() => editedObject.m_CachedScene);

            // Using BeginProperty / EndProperty on the parent property means that
            // prefab override logic works on the entire property.
            EditorGUI.BeginProperty(rect, label, property);
            EditorGUI.BeginChangeCheck();

            // Draw prefix label, returning the new rect we can draw in
            rect.height = EditorGUIUtility.singleLineHeight;
            var objectRect = EditorGUI.PrefixLabel(
                rect, GUIUtility.GetControlID(FocusType.Passive), label);
            var indentLevel = EditorGUI.indentLevel;
            EditorGUI.indentLevel = 0;
            key.Value.Value = GUIDProp.GetUint4Value();
            var currentGO = StableIDGameObjectManager.Resolve(key);
            var currentBoundObject = currentGO == null ? null : currentGO.GetComponent<StableID>();

            StableID newBoundObject = null;
            if (!key.IsValid || currentBoundObject != null)
            {
                // Show the bound object
                if (!key.IsValid)
                    property.isExpanded = false;
                else
                {
                    property.isExpanded =  EditorGUI.Foldout(
                        objectRect, property.isExpanded, property.isExpanded ? m_ShrinkGUI : m_ExpandGUI);
                }
                var newObj = EditorGUI.ObjectField(objectRect, currentBoundObject, editedObject.TypeFilter, true) as MonoBehaviour;
                if (newObj != null)
                    newObj.TryGetComponent(out newBoundObject);
            }
            else
            {
                // If our reference is set but the target isn't loaded, we display the
                // target and the scene it is in, and provide a way to clear the reference
                var clearButtonStyle = new GUIStyle(EditorStyles.miniButton);
                clearButtonStyle.fontSize -= 2;
                float clearWidth = clearButtonStyle.CalcSize(m_ClearButtonGUI).x;
                float dropSpotWidth = EditorGUIUtility.singleLineHeight;
                objectRect.xMax -= clearWidth + dropSpotWidth;

                property.isExpanded =  EditorGUI.Foldout(
                    objectRect, property.isExpanded, property.isExpanded ? m_ShrinkGUI : m_ExpandGUI);

                var guiEnabled = GUI.enabled;
                GUI.enabled = false;
                var oldColor = GUI.color;
                GUI.color = m_WarningColor;
                var r = objectRect;
                EditorGUI.LabelField(r,
                    new GUIContent(nameProp.stringValue, "Target GameObject is not currently loaded."),
                    EditorStyles.objectField);
                GUI.enabled = guiEnabled;
                GUI.color = oldColor;

                r.x += r.width; r.width = clearWidth;
                if (GUI.Button(r, m_ClearButtonGUI, clearButtonStyle))
                {
                    nameProp.stringValue = string.Empty;
                    sceneProp.objectReferenceValue = null;
                    GUIDProp.SetUint4Value(0);
                }

                r.x += r.width; r.width = dropSpotWidth;
                var newObj = EditorGUI.ObjectField(r, null, editedObject.TypeFilter, true) as MonoBehaviour;
                if (newObj != null)
                    newObj.TryGetComponent(out newBoundObject);
            }

            // Was binding deleted?
            if (currentBoundObject != null && newBoundObject == null)
            {
                nameProp.stringValue = string.Empty;
                sceneProp.objectReferenceValue = null;
                GUIDProp.SetUint4Value(0);
            }

            // if we have a valid reference, locate the scene it lives in so users can find it
            if (newBoundObject != null)
            {
                nameProp.stringValue = newBoundObject.name;
                string scenePath = newBoundObject.gameObject.scene.path;
                sceneProp.objectReferenceValue = AssetDatabase.LoadAssetAtPath<SceneAsset>(scenePath);

                // Only update the GUID Prop if something changed.
                // This fixes multi-edit on GUID References
                if (newBoundObject != currentBoundObject)
                    GUIDProp.SetUint4Value(newBoundObject.Value.Value.Value);
            }
            if (property.isExpanded)
            {
                // Show the target object's scene
                var oldWidth = EditorGUIUtility.labelWidth;
                EditorGUIUtility.labelWidth = GUI.skin.label.CalcSize(m_SceneLabelGUI).x;
                rect.x += oldWidth - EditorGUIUtility.labelWidth; rect.width -= oldWidth - EditorGUIUtility.labelWidth;
                rect.y += EditorGUIUtility.singleLineHeight + EditorGUIUtility.standardVerticalSpacing;
                bool cachedGUIState = GUI.enabled;
                GUI.enabled = false;
                EditorGUI.ObjectField(
                    rect, m_SceneLabelGUI, sceneProp.objectReferenceValue, typeof(SceneAsset), false);
                GUI.enabled = cachedGUIState;
                EditorGUIUtility.labelWidth = oldWidth;
            }
            EditorGUI.indentLevel = indentLevel;
            EditorGUI.EndProperty();
            if (EditorGUI.EndChangeCheck())
                property.serializedObject.ApplyModifiedProperties();
        }
    }
}
