using UnityEditor;
using Unity.Entities.Hybrid;

namespace Unity.Entities.Editor
{
    [CustomEditor(typeof(StableID))]
    class StableIDEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_Value"));
        }
    }
}
