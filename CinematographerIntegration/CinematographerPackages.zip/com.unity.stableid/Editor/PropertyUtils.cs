using System;
using System.Collections;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.RegularExpressions;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;

namespace Unity.Entities.Editor
{
    /// <summary>
    /// A collection of utilities for SerializedPropertys
    /// </summary>
    static class PropertyUtils
    {
        /// <summary>
        /// This is a way to get a field name string in such a manner that the compiler will
        /// generate errors for invalid fields.  Much better than directly using strings.
        /// Usage: instead of
        /// <code>
        /// "m_MyField";
        /// </code>
        /// do this:
        /// <code>
        /// MyClass myClass = null;
        /// SerializedPropertyHelper.PropertyName( () => myClass.m_MyField);
        /// </code>
        /// </summary>
        /// <param name="exp">Magic expression that resolves to a field: () => myClass.m_MyField</param>
        /// <returns></returns>
        public static string PropertyName(Expression<Func<object>> exp)
        {
            var body = exp.Body as MemberExpression;
            if (body == null)
            {
                var ubody = (UnaryExpression)exp.Body;
                body = ubody.Operand as MemberExpression;
            }

            Debug.Assert(body != null, nameof(body) + " != null"); // TODO: could it really be null, or is this unnecessary
            return body.Member.Name;
        }

        /// <summary>
        /// A compiler-assisted (non-string-based) way to call SerializedProperty.FindProperty
        /// </summary>
        /// <param name="obj">The serialized object to search</param>
        /// <param name="exp">Magic expression that resolves to a field: () => myClass.m_MyField</param>
        /// <returns>The resulting SerializedProperty, or null</returns>
        public static SerializedProperty FindProperty(this SerializedObject obj, Expression<Func<object>> exp)
        {
            return obj.FindProperty(PropertyName(exp));
        }

        /// <summary>
        /// A compiler-assisted (non-string-based) way to call SerializedProperty.FindPropertyRelative
        /// </summary>
        /// <param name="obj">The serialized object to search</param>
        /// <param name="exp">Magic expression that resolves to a field: () => myClass.m_MyField</param>
        /// <returns>The resulting SerializedProperty, or null</returns>
        public static SerializedProperty FindPropertyRelative(this SerializedProperty obj, Expression<Func<object>> exp)
        {
            return obj.FindPropertyRelative(PropertyName(exp));
        }

        /// <summary>
        /// Get a property value as a uint4
        /// </summary>
        /// <param name="p">the property</param>
        /// <returns>property value as uint4</returns>
        public static uint4 GetUint4Value(this SerializedProperty p)
        {
            return new uint4(
                (uint)p.FindPropertyRelative("x").intValue,
                (uint)p.FindPropertyRelative("y").intValue,
                (uint)p.FindPropertyRelative("z").intValue,
                (uint)p.FindPropertyRelative("w").intValue);
        }

        /// <summary>
        /// Set a property value as uint4
        /// </summary>
        /// <param name="p">the property</param>
        /// <param name="v">the uint4 value to set</param>
        public static void SetUint4Value(this SerializedProperty p, uint4 v)
        {
            p.FindPropertyRelative("x").longValue = v.x;
            p.FindPropertyRelative("y").longValue = v.y;
            p.FindPropertyRelative("z").longValue = v.z;
            p.FindPropertyRelative("w").longValue = v.w;
        }

        static readonly Regex k_MatchArrayElement = new Regex(@"^data\[(\d+)\]$");

        /// <summary>
        /// Get the SerializedProperty value as an object.
        /// </summary>
        /// <param name="property">The serialized property to process</param>
        /// <returns>The underlying object, or null</returns>
        public static T GetValueAsObject<T>(this SerializedProperty property) where T : class
        {
            var serializedObject = property.serializedObject;
            var path = property.propertyPath;
    
            object propertyObject = serializedObject == null || serializedObject.targetObject == null
                ? null : serializedObject.targetObject;
            if (!string.IsNullOrEmpty(path) && propertyObject != null)
            {
                var objectType = propertyObject.GetType();
                var splitPath = path.Split('.');
                Type fieldType = null;

                // work through the given property path, node by node
                for (int i = 0; i < splitPath.Length; i++)
                {
                    var pathNode = splitPath[i];

                    // both arrays and lists implement the IList interface
                    if (fieldType != null && typeof(IList).IsAssignableFrom(fieldType))
                    {
                        // IList items are serialized like this: Array.data[0]
                        Debug.AssertFormat(pathNode.Equals("Array", StringComparison.Ordinal),
                            serializedObject.targetObject,
                            "Expected path node 'Array', but found '{0}'", pathNode);

                        // just skip the Array part of the path
                        pathNode = splitPath[++i];

                        // match the data[0] part of the path and extract the IList item index
                        var elementMatch = k_MatchArrayElement.Match(pathNode);
                        if (elementMatch.Success && int.TryParse(elementMatch.Groups[1].Value, out var index))
                        {
                            var objectArray = (IList)propertyObject;
                            bool validArrayEntry = objectArray != null && index < objectArray.Count;
                            propertyObject = validArrayEntry ? objectArray[index] : null;
                            objectType = fieldType.IsArray
                                ? fieldType.GetElementType()          // only set for arrays
                                : fieldType.GenericTypeArguments[0];  // type of T in List<T>
                        }
                        else
                        {
                            Debug.LogErrorFormat(serializedObject.targetObject,
                                "Unexpected path format for array item: '{0}'", pathNode);
                        }
                        // reset fieldType, so we don't end up in the IList branch again next iteration
                        fieldType = null;
                    }
                    else
                    {
                        FieldInfo field;
                        var instanceType = objectType;
                        var fieldBindingFlags = BindingFlags.Instance | BindingFlags.Public
                            | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy;
                        do
                        {
                            field = instanceType.GetField(pathNode, fieldBindingFlags);

                            // because a private, serialized field of a subclass isn't directly retrievable,
                            fieldBindingFlags = BindingFlags.Instance | BindingFlags.NonPublic;
                            // if neccessary, work up the inheritance chain until we find it.
                            instanceType = instanceType.BaseType;
                        }
                        while (field == null && instanceType != typeof(object));

                        // store object info for next iteration or to return
                        propertyObject = field == null || propertyObject == null
                            ? null : field.GetValue(propertyObject);
                        fieldType = field?.FieldType;
                        objectType = fieldType;
                    }
                }
            }
            return propertyObject as T;
        }
    }
}
