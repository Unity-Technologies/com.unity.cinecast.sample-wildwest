using UnityEditor;
using UnityEngine;

namespace Unity.Entities.Editor
{
    [CustomPropertyDrawer(typeof(StableKey))]
    public class StableKeyPropertyDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect rect, SerializedProperty property, GUIContent label)
        {
            var key = StableKey.Default;
            key.Value.Value = property.FindPropertyRelative(() => key.Value)
                .FindPropertyRelative(() => key.Value.Value).GetUint4Value();

            GUI.enabled = false;
            EditorGUI.BeginProperty(rect, label, property);
            rect = EditorGUI.PrefixLabel(rect, GUIUtility.GetControlID(FocusType.Passive), label);
            EditorGUI.LabelField(rect, key.ToString());
            GUI.enabled = true;
        }
    }
}
