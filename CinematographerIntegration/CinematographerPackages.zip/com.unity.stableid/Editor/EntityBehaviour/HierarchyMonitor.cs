using UnityEditor;
using Unity.Entities.Hybrid;

namespace Unity.Entities.Editor
{
    [InitializeOnLoad]
    static class HierarchyMonitor
    {
    #if UNITY_2020_2_OR_NEWER
        static HierarchyMonitor()
        {
            ObjectChangeEvents.changesPublished += ObjectChangeEvent;
        }

        static void ObjectChangeEvent(ref ObjectChangeEventStream stream)
        {
            if (World.DefaultGameObjectInjectionWorld == null)
                return;
            for (int i = 0; i != stream.length; i++)
            {
                if (stream.GetEventType(i) == ObjectChangeKind.ChangeGameObjectParent)
                {
                    // Something may have moved into or out of a conversion context.  Trigger rescan
                    var system = World.DefaultGameObjectInjectionWorld.GetOrCreateSystem<BidirectionalConversionSystem>();
                    system.SetHierarchyIsDirty();
                    return;
                }
            }
        }

    #else
        static HierarchyMonitor()
        {
            EditorApplication.hierarchyChanged += OnHierarchyChanged;
        }
        static void OnHierarchyChanged()
        {
            if (World.DefaultGameObjectInjectionWorld != null)
            {
                // Something may have moved into or out of a conversion context.  Trigger rescan
                var system = World.DefaultGameObjectInjectionWorld.GetOrCreateSystem<BidirectionalConversionSystem>();
                system.SetHierarchyIsDirty();
            }
        }
    #endif
    }
}
