#if !UNITY_DOTSRUNTIME
    using UnityEngine;
#else
    // Define some stubs here - when in pure dots mode there is no UnityEngine
    public class PropertyAttribute : System.Attribute {}
#endif

namespace Unity.Entities
{
    /// <summary>
    /// Suppresses the top-level foldout on a complex property
    /// </summary>
    public sealed class HideFoldoutAttribute : PropertyAttribute {}
}
