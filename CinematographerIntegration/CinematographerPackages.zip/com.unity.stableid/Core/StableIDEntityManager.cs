using Unity.Collections;
using Unity.Jobs;
using System;
using Unity.Mathematics;

namespace Unity.Entities
{
    /// <summary>
    /// Instead of holding a StableKey field directly, components can hold a
    /// CachedStableEntityReference, which will reduce the total number of hash
    /// lookups by caching the last looked-up value.  This can be helpful in
    /// situations where there are a large number of StableKeys to be
    /// dereferenced every frame.
    /// </summary>
    public struct CachedStableEntityReference
    {
        /// <summary>
        /// The StableKey being referenced
        /// </summary>
        public StableKey StableKey;

        internal Hash128 CacheValidityStamp;
        internal Entity CachedEntity;
    }



    /// <summary>
    /// Holds the unique Stable ID value.  May be an invalid key
    /// only if StableKeyValidState is not present on the entity.
    /// </summary>
    [Serializable]
    public struct StableKeyData : IComponentData
    {
        public StableKey Value;
    }

    /// <summary>
    /// If this is present on the entity then this Stable ID is guaranteed to be valid,
    /// otherwise there is a risk, for newly-instantiated entities from prefabs, that
    /// no unique StableKey has been generated yet.
    /// </summary>
    public struct StableKeyValidState : ISystemStateComponentData {}

    /// <summary>
    /// Maintains the StableKey-Entity look up table.
    /// </summary>
    [AlwaysUpdateSystem]
    [UpdateInGroup(typeof(InitializationSystemGroup))]
    public partial class StableIDEntityManager : SystemBase
    {
        EntityQuery m_MissingStateQuery;
        EntityQuery m_LookupQuery;
        EntityQuery m_DanglingStateQuery;

        NativeHashMap<StableKey, Entity> m_EntityLookup;
        Hash128 m_LookupStateStamp;

        JobHandle m_EntityTableReadJobHandle = default;

        /// <summary>
        /// Get method for JobHandle for writing into the EntityTable.
        /// </summary>
        /// <returns>JobHandle for writing into the EntityTable</returns>
        public JobHandle EntityTableWriteHandle { get; private set; }

        protected override void OnCreate()
        {
            m_MissingStateQuery = GetEntityQuery(
                ComponentType.ReadWrite<StableKeyData>(),
                ComponentType.Exclude<StableKeyValidState>());
            m_LookupQuery = GetEntityQuery(
                ComponentType.ReadOnly<StableKeyData>(),
                ComponentType.ReadOnly<StableKeyValidState>());
            m_DanglingStateQuery = GetEntityQuery(
                ComponentType.Exclude<StableKeyData>(),
                ComponentType.ReadWrite<StableKeyValidState>());

            m_EntityLookup = new NativeHashMap<StableKey, Entity>(64, Allocator.Persistent);
        }

        protected override void OnDestroy()
        {
            m_EntityLookup.Dispose();
            base.OnDestroy();
        }

        protected override void OnUpdate()
        {
            // Make sure all readers have finished with the table
            m_EntityTableReadJobHandle.Complete();
            m_EntityTableReadJobHandle = default;

            // Have entities been added or removed?
            var changed = CleanupDanglingState() || m_MissingStateQuery.CalculateEntityCount() > 0;
            if (changed)
            {
                // Generate GUIDs for newly-instantiated entities
                Entities
                    .WithStoreEntityQueryInField(ref m_MissingStateQuery)
                    .WithoutBurst() // GML TODO: StableKey.GenerateUnique() is not burst-compatible
                    .ForEach((ref StableKeyData key) =>
                {
                    if (key.Value == StableKey.Default)
                        key.Value = StableKey.GenerateUnique();
                }).Schedule();

                EntityManager.AddComponent(
                    m_MissingStateQuery, ComponentType.ReadWrite<StableKeyValidState>());

                // Invalidate the lookup table to force a rebuild
                m_EntityLookup.Clear();
            }

            // Build the entity lookup table only if bindable entities were created or destroyed
            var numKeys = m_LookupQuery.CalculateEntityCount();
            if (m_EntityLookup.Count() != numKeys)
            {
                m_EntityLookup.Clear();
                m_EntityLookup.Capacity = math.max(m_EntityLookup.Capacity, numKeys);

                // New hash state stamp
                unsafe
                {
                    var guid = Guid.NewGuid();
                    m_LookupStateStamp = *(Hash128*) &guid;
                }

                // Rebuild the hashmap
                var hashMap = m_EntityLookup.AsParallelWriter();
                Entities.WithAll<StableKeyValidState>()
                    .ForEach((Entity entity, in StableKeyData key) =>
                {
                    hashMap.TryAdd(key.Value, entity);
                }).ScheduleParallel();

                EntityTableWriteHandle = Dependency;
            }
        }

        bool CleanupDanglingState()
        {
            if (m_DanglingStateQuery.CalculateEntityCount() == 0)
                return false;
            EntityManager.RemoveComponent<StableKeyValidState>(m_DanglingStateQuery);
            return true;
        }

        /// <summary>
        /// Get an Entity from a Stable ID.  Implies a sync point. This is not efficient.
        /// </summary>
        /// <param name="key">The key to lookup</param>
        /// <returns>The entity that owns the StableKey, or Entity.Null.</returns>
        public Entity LookupEntityNow(StableKey key)
        {
            EntityTableWriteHandle.Complete();
            m_EntityLookup.TryGetValue(key, out var e);
            return e;
        }

        /// <summary>
        /// This struct is used to dereference StableKeys.  It is job-friendly (when marked read-only)
        /// and provides several entry points for dereferencing a Stable ID.
        /// </summary>
        public struct StableReferenceResolver
        {
            readonly NativeHashMap<StableKey, Entity> m_Map;
            readonly Hash128 m_StateStamp;

            internal StableReferenceResolver(NativeHashMap<StableKey, Entity> map, Hash128 stateStamp)
            {
                m_Map = map;
                m_StateStamp = stateStamp;
            }

            /// <summary>
            /// True if there are registered objects with StableKey.
            /// </summary>
            public bool IsEmpty => m_Map.IsEmpty;

            /// <summary>
            /// Direct lookup of a StableKey.  A hash lookup will be performed.
            /// </summary>
            /// <param name="key">The key to look up</param>
            /// <param name="e">The entity holding that key</param>
            /// <returns>True if the StableKey lookup resulted in a valid entity</returns>
            public bool Resolve(StableKey key, out Entity e)
            {
                return m_Map.TryGetValue(key, out e);
            }

            /// <summary>
            /// Get an Entity from a CachedStableEntityReference.  A hash lookup will be performed
            /// if and only if the cached value from the previous lookup is invalid.
            /// If the lookup is valid, the result will be cached within the key, so that subsequent
            /// dereferencing will be maximally efficient.
            /// </summary>
            /// <param name="key">The key to look up</param>
            /// <param name="e">The entity holding that key</param>
            /// <returns>True if the StableKey lookup resulted in a valid entity</returns>
            public bool Resolve(ref CachedStableEntityReference key, out Entity e)
            {
                if (!key.CacheValidityStamp.Equals(m_StateStamp))
                {
                    if (!m_Map.TryGetValue(key.StableKey, out key.CachedEntity))
                    {
                        e = Entity.Null;
                        return false;
                    }
                    key.CacheValidityStamp = m_StateStamp;
                }
                e = key.CachedEntity;
                return true;
            }

            /// <summary>
            /// Get an Entity from a CachedStableEntityReference.  A hash lookup will be performed
            /// if and only if the cached value from the previous lookup is invalid.
            /// Because this call is for read-only references, it is not possible to cache the result of
            /// the lookup within the key.  Use the Dereference() method for that.
            /// </summary>
            /// <param name="key">The key to look up</param>
            /// <param name="e">The entity holding that key</param>
            /// <returns>True if the StableKey lookup resulted in a valid entity</returns>
            public bool ResolveReadOnly(in CachedStableEntityReference key, out Entity e)
            {
                if (!key.CacheValidityStamp.Equals(m_StateStamp))
                    return m_Map.TryGetValue(key.StableKey, out e);
                e = key.CachedEntity;
                return true;
            }
        }

        /// <summary>
        /// Get an entity dereferencer suitable for (read-only) use in jobs for 1 frame.
        /// The dereferencer becomes stale after end of current frame.
        /// This object converts a StableKey to Entity.
        /// Be sure to call RegisterDereferencerReadJobs() with the handles of any jobs that use this object.
        /// </summary>
        /// <param name="inputDependency">These will be combined with the dependency on the jobs
        /// that create the lookup data.</param>
        /// <param name="lookup">The returned dereferencer.  Read-only. Becomes stale after end of current frame.</param>
        /// <returns>inputDependency combined with the write dependencies on the lookup data, so that
        /// the job can be run after the lookup table is built.</returns>
        public JobHandle GetDereferencer(JobHandle inputDependency, out StableReferenceResolver lookup)
        {
            var h = JobHandle.CombineDependencies(inputDependency, EntityTableWriteHandle);
            lookup = new StableReferenceResolver(m_EntityLookup, m_LookupStateStamp);
            return h;
        }

        /// <summary>
        /// Register the jobs that are reading from the singleton entity lookup table,
        /// so that table will not be prematurely corrupted.
        /// </summary>
        /// <param name="h">Jobs that are reading from the table</param>
        /// <returns>the same h as passed in, for convenience</returns>
        public JobHandle RegisterDereferencerReadJobs(JobHandle h)
        {
            m_EntityTableReadJobHandle = JobHandle.CombineDependencies(m_EntityTableReadJobHandle, h);
            return h;
        }
    }
}

