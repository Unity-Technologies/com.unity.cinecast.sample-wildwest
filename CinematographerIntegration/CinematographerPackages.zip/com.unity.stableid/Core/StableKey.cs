using System;

namespace Unity.Entities
{
    /// <summary>
    /// A class for creating Globally Unique IDentifiers. Useful for creating weak references to objects.
    /// </summary>
    [Serializable]
    public struct StableKey : IEquatable<StableKey>, IComparable<StableKey>
    {
        /// <summary>
        /// Globally-unique value. To generate a unique value, call GenerateUnique().
        /// </summary>
        [UnityEngine.Serialization.FormerlySerializedAs("Guid")]
        public Hash128 Value;

        /// <summary>
        /// Default StableKey value indicating an empty (no Stable ID) state.
        /// </summary>
        public static StableKey Default => new StableKey { Value = new Hash128(0) };

        /// <summary>
        /// Generates a StableKey with a Globally Unique IDentifier (GUID).
        /// It relies on https://docs.microsoft.com/en-us/dotnet/api/system.guid?view=net-5.0
        /// </summary>
        /// <returns>A StableKey with a Globally Unique IDentifier</returns>
        public static unsafe StableKey GenerateUnique()
        {
            var guid = Guid.NewGuid();
            var hash = *(Hash128*) &guid;
            return new StableKey { Value = hash };
        }

        /// <summary>
        /// Get a string-representation of StableKey value
        /// </summary>
        /// <returns>StableKey value in 32 char string format.</returns>
        public override string ToString() { return Value.ToString(); }

        /// <summary>
        /// Construct a StableKey from a 32 character hex string.
        /// If the string has the incorrect length or non-hex characters the Value will be all 0
        /// </summary>
        /// <param name="value">String from which to generate StableKey</param>
        /// <returns>StableKey generated from string.
        /// If the string has the incorrect length or non-hex characters the Value will be all 0</returns>
        public static StableKey FromString(string value) { return new StableKey { Value = new Hash128(value) }; }

        /// <summary>
        /// Equality operator overload for comparing StableKeys.
        /// </summary>
        /// <param name="obj1">StableKey 1 to compare with 2</param>
        /// <param name="obj2">StableKey 2 to compare with 1</param>
        /// <returns>True, if obj1 and obj2 have the same value. False, otherwise.</returns>
        public static bool operator== (StableKey obj1, StableKey obj2) { return obj1.Value.Equals(obj2.Value); }

        /// <summary>
        /// Inequality operator overload for comparing StableKeys.
        /// </summary>
        /// <param name="obj1">StableKey 1 to compare with 2</param>
        /// <param name="obj2">StableKey 2 to compare with 1</param>
        /// <returns>True, if obj1 and obj2 have different value. False, otherwise.</returns>
        public static bool operator!= (StableKey obj1, StableKey obj2) { return !obj1.Value.Equals(obj2.Value); }

        /// <summary>
        /// Checks if input StableKey is equal to this.
        /// </summary>
        /// <param name="obj">StableKey to check</param>
        /// <returns>True, if obj has the same Value as this. False, otherwise.</returns>
        public bool Equals(StableKey obj) { return Value.Equals(obj.Value); }

        /// <summary>
        /// Checks if input object's guid is same as this.
        /// </summary>
        /// <param name="obj">Object to check</param>
        /// <returns>True, if obj's Value is equal to this. False, otherwise.</returns>
        public override bool Equals(object obj) { return Value.Equals(obj); }

        /// <summary>
        /// Smaller than operator overload for two StableKeys.
        /// </summary>
        /// <param name="a">StableKey left</param>
        /// <param name="b">StableKey right</param>
        /// <returns>Returns true, if a's Value is smaller than b's Value. False, otherwise.</returns>
        public static bool operator <(StableKey a, StableKey b) { return a.Value < b.Value; }

        /// <summary>
        /// Bigger than operator overload for two StableKeys.
        /// </summary>
        /// <param name="a">StableKey left</param>
        /// <param name="b">StableKey right</param>
        /// <returns>Returns true, if a's Value is bigger than b's Value. False, otherwise.</returns>
        public static bool operator >(StableKey a, StableKey b) { return a.Value > b.Value; }

        /// <summary>
        /// Compares input StableKey to this.
        /// </summary>
        /// <param name="other"></param>
        /// <returns>Returns -1 if this is smaller than other, 1 if this is bigger than other,
        /// and 0 is this is equal to other.</returns>
        public int CompareTo(StableKey other) { return Value.CompareTo(other.Value); }

        /// <summary>
        /// Gets hashcode.
        /// </summary>
        /// <returns>Hashcode</returns>
        // ReSharper disable once NonReadonlyMemberInGetHashCode (readonly fields will not get serialized by unity)
        public override int GetHashCode() => Value.GetHashCode();

        /// <summary>
        /// Checks whether this guid is valid.
        /// </summary>
        /// <returns>True, if non-zero value. False, otherwise.</returns>
        public bool IsValid => Value.IsValid;
    }
}
