using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using Unity.Entities.Hybrid;
using UnityEngine;
using UnityEngine.TestTools;

namespace Unity.Entities.UnitTests
{
    /// <summary>
    /// Unit tests for Stable ID package.
    /// </summary>
    [Category("Unit")]
    public sealed class StableIDGameObjectUnitTests
    {
        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        /// Tests adding to elements to the Lookup Table, finding these elements in the Lookup Table.
        /// Then tests, whether the Lookup table is updated correctly after the GameObjects are destroyed.
        /// </summary>
        /// <param name="lookupTableSize">The number of GameObjects with StableIDs in the lookup table</param>
        [UnityTest]
        [TestCase(100, TestName = "Find Stable IDs in Lookup table, then delete Stable IDs and check Lookup table again.", ExpectedResult = null)]
        public IEnumerator LookupTableAfterDestroyingGameObjects(int lookupTableSize)
        {
            // create GameObjects and add StableIDs to them
            var gos = CreateGameObjects(lookupTableSize);
            var stableIDs = AddStableIDs(gos);

            // check if stable id - gameobject links are correct
            for (int i = 0; i < stableIDs.Count; ++i)
            {
                var gameObject = StableIDGameObjectManager.Resolve(stableIDs[i].Value);
                Assert.IsTrue(gameObject == gos[i]);
            }

            // remove stable ids from lookup table
            for (int i = 0; i < stableIDs.Count; ++i)
            {
                StableIDGameObjectManager.Remove(stableIDs[i].Value);
            }
            // check if connection is no longer present
            for (int i = 0; i < stableIDs.Count; ++i)
            {
                var gameObject = StableIDGameObjectManager.Resolve(stableIDs[i].Value);
                Assert.IsTrue(gameObject == null);
            }

            // readd stable ids to the table
            for (int i = 0; i < stableIDs.Count; ++i)
            {
                StableIDGameObjectManager.Add(stableIDs[i]);
            }
            // check if stable id - gameobject links are correct, after readding them
            for (int i = 0; i < stableIDs.Count; ++i)
            {
                var gameObject = StableIDGameObjectManager.Resolve(stableIDs[i].Value);
                Assert.IsTrue(gameObject == gos[i]);
            }

            // destroy gameobjects
            for (int i = gos.Count - 1; i >= 0; --i)
            {
                Object.Destroy(gos[i]);
            }

            // Wait for destroy to happen.  Note: WaitForEndOfFrame() won't work in batch mode
            int waitFrameNumber = Time.frameCount + 1;
            yield return new WaitUntil(() => Time.frameCount >= waitFrameNumber);

            // check if lookup table was updated properly after the gameobjects were deleted.
            for (int i = 0; i < stableIDs.Count; ++i)
            {
                var gameObject = StableIDGameObjectManager.Resolve(stableIDs[i].Value);
                Assert.IsTrue(gameObject == null);
            }
        }

        [TearDown]
        public void TearDown()
        {
        }

        static List<GameObject> CreateGameObjects(int lookupTableSize)
        {
            var gos = new List<GameObject>();
            for (int i = 0; i < lookupTableSize; ++i)
            {
                var go = new GameObject();
                gos.Add(go);
            }
            return gos;
        }

        static List<StableID> AddStableIDs(List<GameObject> gos)
        {
            var stableIDs = new List<StableID>();
            for (int i = 0; i < gos.Count; ++i)
            {
                var stableId = gos[i].AddComponent<StableID>();
                StableIDGameObjectManager.Add(stableId);
                stableIDs.Add(stableId);
            }
            return stableIDs;
        }
    }
}
