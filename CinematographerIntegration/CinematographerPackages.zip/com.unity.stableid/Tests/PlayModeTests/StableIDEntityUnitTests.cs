using NUnit.Framework;
using Unity.Collections;
using Unity.Jobs;
using UnityEngine;

namespace Unity.Entities.UnitTests
{
    /// <summary>
    /// Unit tests for Stable ID package.
    /// </summary>
    [Category("Unit")]
    public sealed class StableIDEntityUnitTests
    {
        World m_World;
        EntityManager m_Manager;
        Entity m_SrcEntity;
        StableIDEntityManager m_StableIDManager;
        const int k_ThreadBatchCount = 32; // how many indices to handle per thread job

        [SetUp]
        public void Setup()
        {
            m_World = World.DefaultGameObjectInjectionWorld;
            m_Manager = m_World.EntityManager;
            m_StableIDManager = m_World.GetOrCreateSystem<StableIDEntityManager>();
            m_SrcEntity = m_Manager.CreateEntity();
        }

        [Test]
        [TestCase(100, TestName = "Find Stable IDs in Lookup table, then delete Stable IDs and check Lookup table again.")]
        public void LookupTableStateRefresh(int lookupTableSize)
        {
            Internal_LookupTableStateRefresh(lookupTableSize);
        }

        [TearDown]
        public void TearDown()
        {
            m_Manager.DestroyEntity(m_SrcEntity);
        }

        /// <summary>
        /// Tests adding to elements to the Lookup Table, finding these elements in the Lookup Table.
        /// Then tests, whether the Lookup table is updated correctly after the stableKeys are disposed.
        /// </summary>
        /// <param name="lookupTableSize">The number of entities with stableKey in the lookup table</param>
        void Internal_LookupTableStateRefresh(int lookupTableSize)
        {
            // create entities and add StableKeys to them
            var entities = CreateEntities(lookupTableSize, Allocator.Persistent);
            var stableKeys = AddStableKeyToEntities(entities);

            // build lookup table
            m_World.Update();
            m_Manager.CompleteAllJobs();

            var references = new NativeArray<CachedStableEntityReference>(stableKeys.Length, Allocator.Persistent);
            for (int i = 0; i < stableKeys.Length; ++i)
            {
                references[i] = new CachedStableEntityReference
                {
                    StableKey = stableKeys[i],
                };
            }

            // get dereferencer
            var dereferencerHandle = new JobHandle();
            dereferencerHandle =
                m_StableIDManager.GetDereferencer(dereferencerHandle, out var pathLookup);
            Assert.IsFalse(pathLookup.IsEmpty);

            // lookup with StableKey
            var findParallelJob = new FindParallel()
            {
                keys = stableKeys,
                lookup = pathLookup,
                entities = entities,
            }.Schedule(references.Length, k_ThreadBatchCount, dereferencerHandle);
            m_StableIDManager.RegisterDereferencerReadJobs(findParallelJob);
            findParallelJob.Complete();

            // lookup with CachedStableEntityReference
            var findParallelJobWithReferences = new FindParallelWithReferences()
            {
                references = references,
                lookup = pathLookup,
                entities = entities,
            }.Schedule(references.Length, k_ThreadBatchCount, dereferencerHandle);
            m_StableIDManager.RegisterDereferencerReadJobs(findParallelJobWithReferences);
            findParallelJobWithReferences.Complete();

            // lookup with CachedStableEntityReference ReadOnly
            var findParallelJobWithReferencesReadOnly = new FindParallelWithReferencesReadOnly()
            {
                references = references,
                lookup = pathLookup,
                entities = entities,
            }.Schedule(references.Length, k_ThreadBatchCount, dereferencerHandle);
            m_StableIDManager.RegisterDereferencerReadJobs(findParallelJobWithReferencesReadOnly);
            findParallelJobWithReferencesReadOnly.Complete();

            // lookup with StableKey now
            for (int i = 0; i < stableKeys.Length; ++i)
            {
                Assert.IsTrue(entities[i] == m_StableIDManager.LookupEntityNow(stableKeys[i]));
            }

            // destroy entities with stable keys
            m_Manager.DestroyEntity(entities);
            entities.Dispose();
            // update lookup table
            m_World.Update();
            m_Manager.CompleteAllJobs();

            // get valid pathLookup after update
            dereferencerHandle = new JobHandle();
            dereferencerHandle =
                m_StableIDManager.GetDereferencer(dereferencerHandle, out pathLookup);
            Assert.IsTrue(pathLookup.IsEmpty);

            // lookup with StableKey
            var dontFindParallelJob = new DontFindParallel()
            {
                keys = stableKeys,
                lookup = pathLookup,
            }.Schedule(references.Length, k_ThreadBatchCount, dereferencerHandle);
            m_StableIDManager.RegisterDereferencerReadJobs(dontFindParallelJob);
            dontFindParallelJob.Complete();

            // lookup with CachedStableEntityReference
            var dontFindParallelWithReferencesJob = new DontFindParallelWithReferences()
            {
                references = references,
                lookup = pathLookup,
            }.Schedule(references.Length, k_ThreadBatchCount, dereferencerHandle);
            m_StableIDManager.RegisterDereferencerReadJobs(dontFindParallelWithReferencesJob);
            dontFindParallelWithReferencesJob.Complete();

            // lookup with CachedStableEntityReference ReadOnly
            var dontFindParallelWithReferencesReadOnlyJob = new DontFindParallelWithReferencesReadOnly()
            {
                references = references,
                lookup = pathLookup,
            }.Schedule(references.Length, k_ThreadBatchCount, dereferencerHandle);
            m_StableIDManager.RegisterDereferencerReadJobs(dontFindParallelWithReferencesReadOnlyJob);
            dontFindParallelWithReferencesReadOnlyJob.Complete();

            // lookup with StableKey now
            for (int i = 0; i < stableKeys.Length; ++i)
            {
                Assert.IsTrue(m_StableIDManager.LookupEntityNow(stableKeys[i]) == Entity.Null);
            }

            references.Dispose();
            stableKeys.Dispose();
        }

        struct FindParallel : IJobParallelFor
        {
            [ReadOnly] public StableIDEntityManager.StableReferenceResolver lookup;
            [ReadOnly] public NativeArray<StableKey> keys;
            [ReadOnly] public NativeArray<Entity> entities;

            public void Execute(int index)
            {
                lookup.Resolve(keys[index], out var e);
                Assert.IsTrue(e == entities[index]);
            }
        }
        struct FindParallelWithReferences : IJobParallelFor
        {
            [ReadOnly] public StableIDEntityManager.StableReferenceResolver lookup;
            [ReadOnly] public NativeArray<CachedStableEntityReference> references;
            [ReadOnly] public NativeArray<Entity> entities;

            public void Execute(int index)
            {
                var cachedStableEntityReference = references[index];
                lookup.Resolve(ref cachedStableEntityReference, out var e);
                Assert.IsTrue(e == entities[index]);
            }
        }
        struct FindParallelWithReferencesReadOnly : IJobParallelFor
        {
            [ReadOnly] public StableIDEntityManager.StableReferenceResolver lookup;
            [ReadOnly] public NativeArray<CachedStableEntityReference> references;
            [ReadOnly] public NativeArray<Entity> entities;

            public void Execute(int index)
            {
                var cachedStableEntityReference = references[index];
                lookup.ResolveReadOnly(in cachedStableEntityReference, out var e);
                Assert.IsTrue(e == entities[index]);
            }
        }

        struct DontFindParallel : IJobParallelFor
        {
            [ReadOnly] public StableIDEntityManager.StableReferenceResolver lookup;
            [ReadOnly] public NativeArray<StableKey> keys;

            public void Execute(int index)
            {
                lookup.Resolve(keys[index], out var e);
                Assert.IsTrue(e == Entity.Null);
            }
        }
        struct DontFindParallelWithReferences : IJobParallelFor
        {
            [ReadOnly] public StableIDEntityManager.StableReferenceResolver lookup;
            [ReadOnly] public NativeArray<CachedStableEntityReference> references;

            public void Execute(int index)
            {
                var cachedStableEntityReference = references[index];
                lookup.Resolve(ref cachedStableEntityReference, out var e);
                Assert.IsTrue(e == Entity.Null);
            }
        }
        struct DontFindParallelWithReferencesReadOnly : IJobParallelFor
        {
            [ReadOnly] public StableIDEntityManager.StableReferenceResolver lookup;
            [ReadOnly] public NativeArray<CachedStableEntityReference> references;

            public void Execute(int index)
            {
                var cachedStableEntityReference = references[index];
                lookup.ResolveReadOnly(in cachedStableEntityReference, out var e);
                Assert.IsTrue(e == Entity.Null);
            }
        }

        NativeArray<Entity> CreateEntities(int entityCount, Allocator allocator)
        {
            return m_Manager.Instantiate(m_SrcEntity, entityCount, allocator);
        }

        NativeArray<StableKey> AddStableKeyToEntities(NativeArray<Entity> entities)
        {
            var stableKeys = new NativeArray<StableKey>(entities.Length, Allocator.Persistent);
            for (int i = 0; i < entities.Length; ++i)
            {
                var stableKey = StableKey.GenerateUnique();
                stableKeys[i] = stableKey;
                m_Manager.AddComponentData(entities[i], new StableKeyData
                {
                    Value = stableKey,
                });
            }

            return stableKeys;
        }
    }
}
