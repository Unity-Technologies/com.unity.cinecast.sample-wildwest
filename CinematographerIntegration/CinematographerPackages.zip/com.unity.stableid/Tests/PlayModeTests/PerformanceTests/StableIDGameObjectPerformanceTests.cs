using System.Collections.Generic;
using NUnit.Framework;
using Unity.Entities.Hybrid;
using Unity.PerformanceTesting;
using UnityEngine;

namespace Unity.Entities.PerformanceTests
{
    /// <summary>
    /// Performance tests for Stable ID package.
    ///
    /// General useful notes:
    /// > WarmupCount(int n) - number of times to to execute before measurements are collected. If unspecified,
    /// a default warmup is executed. This default warmup will wait for 100 ms. However, if less than 3 method
    /// executions have finished in that time, the warmup will wait until 3 method executions have completed.
    /// > MeasurementCount(int n) - number of measurements to capture. If not specified default value is 9.
    /// > IterationsPerMeasurement(int n) - number of method executions per measurement to use. If this value is not
    /// specified, the method will be executed as many times as possible until approximately 100 ms has elapsed.
    /// > SampleGroup(string name) - by default the measurement name will be "Time", this allows you to override it
    /// > GC() - if specified, will measure the total number of Garbage Collection allocation calls.
    /// > SetUp(Action action) - is called every iteration before executing the method. Setup time is not measured.
    /// > CleanUp(Action action) - is called every iteration after the execution of the method. Cleanup time is not
    /// measured.
    /// </summary>
    [TestFixture]
    [Category("Performance")]
    public sealed class StableIDGameObjectPerformanceTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test, Performance]
        [TestCase(1, TestName = "Adds 1 GameObject a StableID and adds them to lookup table")]
        [TestCase(10, TestName = "Adds 10 GameObjects StableIDs and adds them to lookup table")]
        [TestCase(100, TestName = "Adds 100 GameObjects StableIDs and adds them to lookup table")]
        [TestCase(1000, TestName = "Adds 1000 GameObjects StableIDs and adds them to lookup table")]
        public void AddStableIDs(int numOfAdds)
        {
            Internal_AddStableIDs(numOfAdds);
        }

        [Test, Performance]
        [TestCase(1, 1, TestName = "Removes 1 random StableID from lookup table size 1")]
        [TestCase(10, 1, TestName = "Removes 1 random StableID and adds them to lookup table size 10")]
        [TestCase(100, 1, TestName = "Removes 1 random StableID and adds them to lookup table size 100")]
        [TestCase(1000, 1, TestName = "Removes 1 random StableID and adds them to lookup table size 1000")]
        [TestCase(10, 10, TestName = "Removes 10 random StableID and adds them to lookup table size 10")]
        [TestCase(100, 10, TestName = "Removes 10 random StableID and adds them to lookup table size 100")]
        [TestCase(1000, 10, TestName = "Removes 10 random StableID and adds them to lookup table size 1000")]
        [TestCase(100, 100, TestName = "Removes 100 random StableID and adds them to lookup table size 100")]
        [TestCase(1000, 100, TestName = "Removes 100 random StableID and adds them to lookup table size 1000")]
        [TestCase(1000, 1000, TestName = "Removes 1000 random StableID and adds them to lookup table size 1000")]

        public void RemoveStableIDs(int tableSize, int numOfIDsToRemove)
        {
            Internal_RemoveStableIDs(tableSize, numOfIDsToRemove);
        }

        [Test, Performance]
        [TestCase(1, 1, false, TestName = "Lookup 1 random Stable ID in LookupTable size 1 (cold-start)")]
        [TestCase(10, 1, false, TestName = "Lookup 1 random Stable ID in LookupTable size 10 (cold-start)")]
        [TestCase(100, 1, false, TestName = "Lookup 1 random Stable ID in LookupTable size 100 (cold-start)")]
        [TestCase(1000, 1, false, TestName = "Lookup 1 random Stable ID in LookupTable size 1000 (cold-start)")]
        [TestCase(1, 1, true, TestName = "Lookup 1 random Stable ID in LookupTable size 1 (warm-start)")]
        [TestCase(10, 1, true, TestName = "Lookup 1 random Stable ID in LookupTable size 10 (warm-start)")]
        [TestCase(100, 1, true, TestName = "Lookup 1 random Stable ID in LookupTable size 100 (warm-start)")]
        [TestCase(1000, 1, true, TestName = "Lookup 1 random Stable ID in LookupTable size 1000 (warm-start)")]
        [TestCase(10, 5, false, TestName = "Lookup 5 random Stable ID in LookupTable size 10 (cold-start)")]
        [TestCase(100, 50, false, TestName = "Lookup 50 random Stable IDs in LookupTable size 100 (cold-start)")]
        [TestCase(1000, 500, false, TestName = "Lookup 500 random Stable IDs in LookupTable size 1000 (cold-start)")]
        [TestCase(10, 5, true, TestName = "Lookup 5 random Stable IDs in LookupTable size 10 (warm-start)")]
        [TestCase(100, 50, true, TestName = "Lookup 50 random Stable IDs in LookupTable size 100 (warm-start)")]
        [TestCase(1000, 500, true, TestName = "Lookup 500 random Stable IDs in LookupTable size 1000 (warm-start)")]
        public void RandomLookupStableIDs(int lookupTableSize, int numOfLookups, bool warmStart)
        {
            Internal_RandomLookupStableIDs(lookupTableSize, numOfLookups, warmStart);
        }

        [TearDown]
        public void TearDown()
        {
        }

        /// <summary>
        /// Creates 'numOfAdds' many Gameobjects and adds StableIds to them.
        /// Then measures, the time it takes:
        /// + to add them to the lookup table.
        /// </summary>
        /// <param name="numOfAdds">The number of adds to do.</param>
        void Internal_AddStableIDs(int numOfAdds)
        {
            var gos = new List<GameObject>();
            var stableIDs = new List<StableID>();

            Measure
                .Method(() =>
                {
                    for (int i = 0; i < stableIDs.Count; ++i)
                    {
                        StableIDGameObjectManager.Add(stableIDs[i]);
                    }
                })
                .SetUp(() =>
                {
                    // create GameObjects and add StableIDs to them
                    gos = CreateGameObjects(numOfAdds);
                    stableIDs = AddStableIDs(gos);
                })
                .CleanUp(() =>
                {
                    // is there a way to cleanup without keeping track of stableIDs?
                    for (int i = gos.Count - 1; i >= 0; --i)
                    {
                        Object.Destroy(gos[i]);
                    }
                    gos.Clear();
                })
                .WarmupCount(1)
                .MeasurementCount(10)
                // .IterationsPerMeasurement(8)
                .GC()
                .Run();
        }

        /// <summary>
        /// Creates 'lookupTableSize' many Gameobjects and adds StableIds to them. Builds look up table.
        /// Then measures, the time it takes:
        /// + to remove 'numOfRemoves' many StableIds from the lookup table.
        /// </summary>
        /// <param name="lookupTableSize">The number of gameObjects with stableIDs in the lookup table</param>
        /// <param name="numOfRemoves">The number of removes to do.</param>
        void Internal_RemoveStableIDs(int lookupTableSize, int numOfRemoves)
        {
            var gos = new List<GameObject>();
            var stableIDsToRemove = new List<StableID>();

            Measure
                .Method(() =>
                {
                    for (int i = 0; i < numOfRemoves; ++i)
                    {
                        StableIDGameObjectManager.Remove(stableIDsToRemove[i].Value);
                    }
                })
                .SetUp(() =>
                {
                    // create GameObjects and add StableIDs to them
                    gos = CreateGameObjects(lookupTableSize);
                    var stableIDs = AddStableIDs(gos);

                    for (int i = 0; i < numOfRemoves; ++i)
                    {
                        stableIDsToRemove.Add(stableIDs[Random.Range(0, stableIDs.Count)]);
                    }
                })
                .CleanUp(() =>
                {
                    // is there a way to cleanup without keeping track of stableIDs?
                    for (int i = gos.Count - 1; i >= 0; --i)
                    {
                        Object.Destroy(gos[i]);
                    }
                    gos.Clear();
                })
                .WarmupCount(1)
                .MeasurementCount(10)
                // .IterationsPerMeasurement(8)
                .GC()
                .Run();
        }

        /// <summary>
        /// Creates 'lookupTableSize' many gameobjects. Adds StableIds to them. Then selects 'numOfLookups'
        /// StableKeys randomly.
        /// Then measures, the time it takes:
        /// + to look up 'numOfLookups' gameobjects using the randomly selected StableKeys.
        /// </summary>
        /// <param name="lookupTableSize">The number of gameObjects with stableIDs in the lookup table</param>
        /// <param name="numOfLookups">The number of lookups to do.</param>
        /// <param name="warmStart">If true, then before measuring we'll do a lookup run to warm up cache.</param>
        void Internal_RandomLookupStableIDs(int lookupTableSize, int numOfLookups, bool warmStart)
        {
            var gos = new List<GameObject>();
            var randomStableKeys = new StableKey[numOfLookups];

            Measure
                .Method(() =>
                {
                    // random lookups
                    for (int i = 0; i < randomStableKeys.Length; ++i)
                    {
                        var go = StableIDGameObjectManager.Resolve(randomStableKeys[i]);
                    }
                })
                .SetUp(() =>
                {
                    // create GameObjects and add StableIDs to them
                    gos = CreateGameObjects(lookupTableSize);
                    var stableIDs = AddStableIDs(gos);

                    // prepare for random access
                    for (int i = 0; i < numOfLookups; ++i)
                    {
                        randomStableKeys[i] = stableIDs[Random.Range(0, stableIDs.Count)].Value;
                    }

                    // caching
                    if (warmStart)
                    {
                        for (int i = 0; i < randomStableKeys.Length; ++i)
                        {
                            StableIDGameObjectManager.Resolve(randomStableKeys[i]);
                        }
                    }
                })
                .CleanUp(() =>
                {
                    for (int i = gos.Count - 1; i >= 0; --i)
                    {
                        Object.Destroy(gos[i]);
                    }
                    gos.Clear();
                })
                .WarmupCount(1)
                .MeasurementCount(10)
                // .IterationsPerMeasurement(8)
                .GC()
                .Run();
        }

        static List<GameObject> CreateGameObjects(int lookupTableSize)
        {
            var gos = new List<GameObject>();
            for (int i = 0; i < lookupTableSize; ++i)
            {
                var go = new GameObject();
                gos.Add(go);
            }
            return gos;
        }

        static List<StableID> AddStableIDs(List<GameObject> gos)
        {
            var stableIDs = new List<StableID>();
            for (int i = 0; i < gos.Count; ++i)
            {
                var stableId = gos[i].AddComponent<StableID>();
                StableIDGameObjectManager.Add(stableId);
                stableIDs.Add(stableId);
            }
            return stableIDs;
        }
    }
}
