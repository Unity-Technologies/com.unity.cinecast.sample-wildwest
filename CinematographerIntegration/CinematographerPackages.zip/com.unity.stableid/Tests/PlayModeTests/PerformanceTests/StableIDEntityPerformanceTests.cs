using System.Collections.Generic;
using NUnit.Framework;
using Unity.Collections;
using Unity.Jobs;
using Unity.PerformanceTesting;
using UnityEngine;

namespace Unity.Entities.PerformanceTests
{
    /// <summary>
    /// Performance tests for Stable ID package.
    ///
    /// General useful notes:
    /// > WarmupCount(int n) - number of times to to execute before measurements are collected. If unspecified,
    /// a default warmup is executed. This default warmup will wait for 100 ms. However, if less than 3 method
    /// executions have finished in that time, the warmup will wait until 3 method executions have completed.
    /// > MeasurementCount(int n) - number of measurements to capture. If not specified default value is 9.
    /// > IterationsPerMeasurement(int n) - number of method executions per measurement to use. If this value is not
    /// specified, the method will be executed as many times as possible until approximately 100 ms has elapsed.
    /// > SampleGroup(string name) - by default the measurement name will be "Time", this allows you to override it
    /// > GC() - if specified, will measure the total number of Garbage Collection allocation calls.
    /// > SetUp(Action action) - is called every iteration before executing the method. Setup time is not measured.
    /// > CleanUp(Action action) - is called every iteration after the execution of the method. Cleanup time is not
    /// measured.
    /// </summary>
    [TestFixture]
    [Category("Performance")]
    public sealed class StableIDEntityPerformanceTests
    {
        World m_World;
        EntityManager m_Manager;
        Entity m_SrcEntity;
        StableIDEntityManager m_StableIDManager;
        const int k_ThreadBatchCount = 32; // how many indices to handle per thread job

        [SetUp]
        public void Setup()
        {
            m_World = World.DefaultGameObjectInjectionWorld;
            m_Manager = m_World.EntityManager;
            m_StableIDManager = m_World.GetOrCreateSystem<StableIDEntityManager>();
            m_SrcEntity = m_Manager.CreateEntity();
        }

        [Test, Performance]
        [TestCase(1, TestName = "Build LookupTable of 1 Stable ID")]
        [TestCase(10, TestName = "Build LookupTable of 10 Stable IDs")]
        [TestCase(100, TestName = "Build LookupTable of 100 Stable IDs")]
        [TestCase(1000, TestName = "Build LookupTable of 1000 Stable IDs")]
        [TestCase(10000, TestName = "Build LookupTable of 10 000 Stable IDs")]
        [TestCase(100000, TestName = "Build LookupTable of 100 000 Stable IDs")]
        public void BuildLookupTable(int lookupTableSize)
        {
            Internal_BuildLookupTable(lookupTableSize);
        }

        [Test, Performance]
        [TestCase(1, TestName = "Cleanup LookupTable of 1 Stable ID")]
        [TestCase(10, TestName = "Cleanup LookupTable of 10 Stable IDs")]
        [TestCase(100, TestName = "Cleanup LookupTable of 100 Stable IDs")]
        [TestCase(1000, TestName = "Cleanup LookupTable of 1000 Stable IDs")]
        [TestCase(10000, TestName = "Cleanup LookupTable of 10 000 Stable IDs")]
        [TestCase(100000, TestName = "Cleanup LookupTable of 100 000 Stable IDs")]
        public void CleanupLookupTable(int lookupTableSize)
        {
            Internal_CleanupLookupTable(lookupTableSize);
        }

        [Test, Performance]
        [TestCase(1, 1, TestName = "Add 1 Stable ID To LookupTable size 1")]
        [TestCase(10, 1, TestName = "Add 1 Stable ID To LookupTable size 10")]
        [TestCase(100, 1, TestName = "Add 1 Stable ID To LookupTable size 100")]
        [TestCase(1000, 1, TestName = "Add 1 Stable ID To LookupTable size 1000")]
        [TestCase(10000, 1, TestName = "Add 1 Stable ID To LookupTable size 10 000")]
        [TestCase(100000, 1, TestName = "Add 1 Stable ID To LookupTable size 100 000")]
        [TestCase(1, 10000, TestName = "Add 10 000 Stable IDs To LookupTable size 1")]
        [TestCase(10, 10000, TestName = "Add 10 000 Stable IDs To LookupTable size 10")]
        [TestCase(100, 10000, TestName = "Add 10 000 Stable IDs To LookupTable size 100")]
        [TestCase(1000, 10000, TestName = "Add 10 000 Stable IDs To LookupTable size 1000")]
        [TestCase(10000, 10000, TestName = "Add 10 000 Stable IDs To LookupTable size 10 000")]
        [TestCase(100000, 10000, TestName = "Add 10 000 Stable IDs To LookupTable size 100 000")]
        public void AddStableIDs(int lookupTableSize, int numOfStableIDsToAdd)
        {
            Internal_AddStableKeys(lookupTableSize, numOfStableIDsToAdd);
        }

        [Test, Performance]
        [TestCase(1, 1, TestName = "Remove 1 random Stable ID From LookupTable size 1")]
        [TestCase(10, 1, TestName = "Remove 1 random Stable ID From LookupTable size 10")]
        [TestCase(100, 1, TestName = "Remove 1 random Stable ID From LookupTable size 100")]
        [TestCase(1000, 1, TestName = "Remove 1 random Stable ID From LookupTable size 1000")]
        [TestCase(10000, 1, TestName = "Remove 1 random Stable ID From LookupTable size 10 000")]
        [TestCase(100000, 1, TestName = "Remove 1 random Stable ID From LookupTable size 100 000")]
        [TestCase(10, 5, TestName = "Remove 5 random Stable IDs From LookupTable size 10")]
        [TestCase(100, 50, TestName = "Remove 50 random Stable IDs From LookupTable size 100")]
        [TestCase(1000, 500, TestName = "Remove 500 random Stable IDs From LookupTable size 1000")]
        [TestCase(10000, 5000, TestName = "Remove 5000 random Stable IDs From LookupTable size 10 000")]
        [TestCase(100000, 50000, TestName = "Remove 50 000 random Stable IDs From LookupTable size 100 000")]
        public void RemoveStableIDs(int lookupTableSize, int numOfStableIDsToRemove)
        {
            Internal_RemoveStableKeys(lookupTableSize, numOfStableIDsToRemove);
        }

        [Test, Performance]
        [TestCase(1, 1, false, TestName = "Lookup 1 random Stable ID in LookupTable size 1 (cold-start)")]
        [TestCase(10, 1, false, TestName = "Lookup 1 random Stable ID in LookupTable size 10 (cold-start)")]
        [TestCase(100, 1, false, TestName = "Lookup 1 random Stable ID in LookupTable size 100 (cold-start)")]
        [TestCase(1000, 1, false, TestName = "Lookup 1 random Stable ID in LookupTable size 1000 (cold-start)")]
        [TestCase(10000, 1, false, TestName = "Lookup 1 random Stable ID in LookupTable size 10 000 (cold-start)")]
        [TestCase(100000, 1, false, TestName = "Lookup 1 random Stable ID in LookupTable size 100 000 (cold-start)")]
        [TestCase(1, 1, true, TestName = "Lookup 1 random Stable ID in LookupTable size 1 (warm-start)")]
        [TestCase(10, 1, true, TestName = "Lookup 1 random Stable ID in LookupTable size 10 (warm-start)")]
        [TestCase(100, 1, true, TestName = "Lookup 1 random Stable ID in LookupTable size 100 (warm-start)")]
        [TestCase(1000, 1, true, TestName = "Lookup 1 random Stable ID in LookupTable size 1000 (warm-start)")]
        [TestCase(10000, 1, true, TestName = "Lookup 1 random Stable ID in LookupTable size 10 000 (warm-start)")]
        [TestCase(100000, 1, true, TestName = "Lookup 1 random Stable ID in LookupTable size 100 000 (warm-start)")]
        [TestCase(10, 5, false, TestName = "Lookup 5 random Stable IDs in LookupTable size 10 (cold-start)")]
        [TestCase(100, 50, false, TestName = "Lookup 50 random Stable IDs in LookupTable size 100 (cold-start)")]
        [TestCase(1000, 500, false, TestName = "Lookup 500 random Stable IDs in LookupTable size 1000 (cold-start)")]
        [TestCase(10000, 5000, false, TestName = "Lookup 5000 random Stable IDs in LookupTable size 10 000 (cold-start)")]
        [TestCase(100000, 50000, false, TestName = "Lookup 50 000 random Stable IDs in LookupTable size 100 000 (cold-start)")]
        [TestCase(10, 5, true, TestName = "Lookup 5 random Stable IDs in LookupTable size 10 (warm-start)")]
        [TestCase(100, 50, true, TestName = "Lookup 50 random Stable IDs in LookupTable size 100 (warm-start)")]
        [TestCase(1000, 500, true, TestName = "Lookup 500 random Stable IDs in LookupTable size 1000 (warm-start)")]
        [TestCase(10000, 5000, true, TestName = "Lookup 5000 random Stable IDs in LookupTable size 10 000 (warm-start)")]
        [TestCase(100000, 50000, true, TestName = "Lookup 50 000 random Stable IDs in LookupTable size 100 000 (warm-start)")]
        public void RandomLookupStableIDs(int lookupTableSize, int numOfLookups, bool warmStart)
        {
            Internal_RandomLookupStableKeys(lookupTableSize, numOfLookups, warmStart);
        }

        [Test, Performance]
        [TestCase(1, 1, false, TestName = "Parallel Lookup 1 random Stable ID in LookupTable size 1 (cold-start)")]
        [TestCase(10, 1, false, TestName = "Parallel Lookup 1 random Stable ID in LookupTable size 10 (cold-start)")]
        [TestCase(100, 1, false, TestName = "Parallel Lookup 1 random Stable ID in LookupTable size 100 (cold-start)")]
        [TestCase(1000, 1, false, TestName = "Parallel Lookup 1 random Stable ID in LookupTable size 1000 (cold-start)")]
        [TestCase(10000, 1, false, TestName = "Parallel Lookup 1 random Stable ID in LookupTable size 10 000 (cold-start)")]
        [TestCase(100000, 1, false, TestName = "Parallel Lookup 1 random Stable ID in LookupTable size 100 000 (cold-start)")]
        [TestCase(1, 1, true, TestName = "Parallel Lookup 1 random Stable ID in LookupTable size 1 (warm-start)")]
        [TestCase(10, 1, true, TestName = "Parallel Lookup 1 random Stable ID in LookupTable size 10 (warm-start)")]
        [TestCase(100, 1, true, TestName = "Parallel Lookup 1 random Stable ID in LookupTable size 100 (warm-start)")]
        [TestCase(1000, 1, true, TestName = "Parallel Lookup 1 random Stable ID in LookupTable size 1000 (warm-start)")]
        [TestCase(10000, 1, true, TestName = "Parallel Lookup 1 random Stable ID in LookupTable size 10 000 (warm-start)")]
        [TestCase(100000, 1, true, TestName = "Parallel Lookup 1 random Stable ID in LookupTable size 100 000 (warm-start)")]
        [TestCase(10, 5, false, TestName = "Parallel Lookup 5 random Stable IDs in LookupTable size 10 (cold-start)")]
        [TestCase(100, 50, false, TestName = "Parallel Lookup 50 random Stable IDs in LookupTable size 100 (cold-start)")]
        [TestCase(1000, 500, false, TestName = "Parallel Lookup 500 random Stable IDs in LookupTable size 1000 (cold-start)")]
        [TestCase(10000, 5000, false, TestName = "Parallel Lookup 5000 random Stable IDs in LookupTable size 10 000 (cold-start)")]
        [TestCase(100000, 50000, false, TestName = "Parallel Lookup 50 000 random Stable IDs in LookupTable size 100 000 (cold-start)")]
        [TestCase(10, 5, true, TestName = "Parallel Lookup 5 random Stable IDs in LookupTable size 10 (warm-start)")]
        [TestCase(100, 50, true, TestName = "Parallel Lookup 50 random Stable IDs in LookupTable size 100 (warm-start)")]
        [TestCase(1000, 500, true, TestName = "Parallel Lookup 500 random Stable IDs in LookupTable size 1000 (warm-start)")]
        [TestCase(10000, 5000, true, TestName = "Parallel Lookup 5000 random Stable IDs in LookupTable size 10 000 (warm-start)")]
        [TestCase(100000, 50000, true, TestName = "Parallel Lookup 50 000 random Stable IDs in LookupTable size 100 000 (warm-start)")]
        public void RandomParallelLookupStableIDs(int lookupTableSize, int numOfLookups, bool warmStart)
        {
            Internal_RandomParallelLookupStableKeys(lookupTableSize, numOfLookups, warmStart);
        }

        [TearDown]
        public void TearDown()
        {
            m_Manager.DestroyEntity(m_SrcEntity);
        }

        /// <summary>
        /// Creates 'lookupTableSize' many entities. Adds stableKeyData to them.
        /// Then measures, the time it takes:
        /// + to build lookup table
        /// </summary>
        /// <param name="lookupTableSize">The number of entities with stableKey in the lookup table</param>
        void Internal_BuildLookupTable(int lookupTableSize)
        {
            var entities = new NativeArray<Entity>();

            Measure
                .Method(() =>
                {
                    // build look up table
                    m_World.Update();
                    m_Manager.CompleteAllJobs();
                })
                .SetUp(() =>
                {
                    // create entities and add StableKeys to them
                    entities = CreateEntities(lookupTableSize, Allocator.Temp);
                    AddStableKeyToEntities(entities);
                })
                .CleanUp(() =>
                {
                    CleanEntitiesAndFinishAllJobs(ref entities);
                })
                .WarmupCount(1)
                .MeasurementCount(10)
                // .IterationsPerMeasurement(20)
                .GC()
                .Run();
        }

        /// <summary>
        /// Creates 'lookupTableSize' many entities. Adds stableKeyData to them. Builds look up table.
        /// Removes all stableKeyDatas from entities.
        /// Then measures, the time it takes:
        /// + to cleanup table.
        /// </summary>
        /// <param name="lookupTableSize">The number of entities with stableKey in the lookup table</param>
        void Internal_CleanupLookupTable(int lookupTableSize)
        {
            var entities = new NativeArray<Entity>();

            Measure
                .Method(() =>
                {
                    // cleanup danglings references
                    m_World.Update();
                    m_Manager.CompleteAllJobs();
                })
                .SetUp(() =>
                {
                    // create entities and add StableKeys to them
                    entities = CreateEntities(lookupTableSize, Allocator.Temp);
                    AddStableKeyToEntities(entities);

                    // build look up table
                    m_World.Update();
                    m_Manager.CompleteAllJobs();

                    // remove StableKeyDatas -> making all references in lookup table dangling
                    m_Manager.RemoveComponent<StableKeyData>(entities);
                })
                .CleanUp(() =>
                {
                    CleanEntitiesAndFinishAllJobs(ref entities);
                })
                .WarmupCount(1)
                .MeasurementCount(10)
                // .IterationsPerMeasurement(20)
                .GC()
                .Run();
        }

        /// <summary>
        /// Adds 'numOfIDsToAdd'-many entities with stableKeys to
        /// a lookup table with 'lookupTableSize' many entites with stableKeys.
        ///
        /// The measurement measures the time it takes to build the lookup table after adding the
        /// 'numOfIDsToAdd'-many entites with stableKeys to it.
        /// </summary>
        /// <param name="lookupTableSize">The number of entities with stableKey in the lookup table</param>
        /// <param name="numOfIDsToAdd">The number of entities with stableKey to add.</param>
        void Internal_AddStableKeys(int lookupTableSize, int numOfIDsToAdd)
        {
            var entities = new NativeArray<Entity>(); // initialized in SetUp
            var entitiesToAdd = new NativeArray<Entity>();

            Measure
                .Method(() =>
                {
                    // build lookup table
                    m_World.Update();
                    m_Manager.CompleteAllJobs();
                })
                .SetUp(() =>
                {
                    // create entities and add StableKeys to them
                    entities = CreateEntities(lookupTableSize, Allocator.Temp);
                    AddStableKeyToEntities(entities);

                    // build lookup table
                    m_World.Update();
                    m_Manager.CompleteAllJobs();

                    // create entities and add StableKeys to them
                    entitiesToAdd = CreateEntities(numOfIDsToAdd, Allocator.Temp);
                    AddStableKeyToEntities(entitiesToAdd);
                })
                .CleanUp(() =>
                {
                    m_Manager.DestroyEntity(entitiesToAdd);
                    entitiesToAdd.Dispose();
                    CleanEntitiesAndFinishAllJobs(ref entities);
                })
                .WarmupCount(1)
                .MeasurementCount(20)
                // .IterationsPerMeasurement(10)
                .GC()
                .Run();
        }

         /// <summary>
        /// Creates 'lookupTableSize' many entities. Adds stableKeyData to them.
        /// Then measures, the time it takes:
        /// + to remove 'numOfIDsToRemove' stableKeys (chosen randomly) from the lookup table.
        ///
        /// Note: Does not measure time to initialize the 'lookupTableSize' many entities with stableKey.
        /// </summary>
        /// <param name="lookupTableSize">The number of entities with stableKey in the lookup table</param>
        /// <param name="numOfIDsToRemove">The number of stableKeys to remove</param>
        void Internal_RemoveStableKeys(int lookupTableSize, int numOfIDsToRemove)
        {
            var entities = new NativeArray<Entity>();
            var dereferencerHandle = new JobHandle();

            Measure
                .Method(() =>
                {
                    // cleanup dangling references created in SetUp
                    m_World.Update();
                    m_Manager.CompleteAllJobs();
                })
                .SetUp(() =>
                {
                    // create entities and add StableKeys to them
                    entities = CreateEntities(lookupTableSize, Allocator.Temp);
                    AddStableKeyToEntities(entities);

                    // build lookup table
                    m_World.Update();
                    m_Manager.CompleteAllJobs();

                    // get dereferencer
                    dereferencerHandle = m_StableIDManager.GetDereferencer(dereferencerHandle, out var pathLookup);
                    Assert.IsFalse(pathLookup.IsEmpty);

                    // randomly remove StableKeyData from entities to make them dangling
                    for (int i = 0; i < numOfIDsToRemove; ++i)
                    {
                        m_Manager.RemoveComponent<StableKeyData>(entities[Random.Range(0, entities.Length)]);
                    }
                })
                .CleanUp(() =>
                {
                    m_StableIDManager.RegisterDereferencerReadJobs(dereferencerHandle);
                    CleanEntitiesAndFinishAllJobs(ref entities);
                })
                .WarmupCount(1)
                .MeasurementCount(10)
                // .IterationsPerMeasurement(20)
                .GC()
                .Run();
        }

        /// <summary>
        /// Creates 'lookupTableSize' many entities. Adds stableKeyData to them. Then selects 'numOfLookups'
        /// StableKeyCachedReferences randomly to be used for look up.
        /// Then measures, the time it takes:
        /// + to look up 'numOfLookups' entities using the randomly selected StableKeyCachedReferences.
        /// </summary>
        /// <param name="lookupTableSize">The number of entities with stableKey in the lookup table</param>
        /// <param name="numOfLookups">The number of lookups to do.</param>
        /// <param name="warmStart">If true, then before measuring we'll do a lookup run to warm up cache.</param>
        void Internal_RandomLookupStableKeys(int lookupTableSize, int numOfLookups, bool warmStart)
        {
            var entities = new NativeArray<Entity>();
            var randomStableKeys = new CachedStableEntityReference[numOfLookups];
            var pathLookup = new StableIDEntityManager.StableReferenceResolver();
            var dereferencerHandle = new JobHandle();

            Measure
                .Method(() =>
                {
                    // random lookups
                    for (int i = 0; i < randomStableKeys.Length; ++i)
                    {
                        var randomStableKeyCachedReference = randomStableKeys[i];
                        pathLookup.ResolveReadOnly(in randomStableKeyCachedReference, out var e);
                    }
                })
                .SetUp(() =>
                {
                    // create entities and add StableKeys to them
                    entities = CreateEntities(lookupTableSize, Allocator.Temp);
                    var stableKeys = AddStableKeyToEntities(entities);

                    // build lookup table
                    m_World.Update();
                    m_Manager.CompleteAllJobs();

                    // prepare for random access
                    for (int i = 0; i < randomStableKeys.Length; ++i)
                    {
                        randomStableKeys[i] = new CachedStableEntityReference
                        {
                            StableKey = stableKeys[Random.Range(0, stableKeys.Count)],
                        };
                    }

                    // get dereferencer
                    dereferencerHandle = m_StableIDManager.GetDereferencer(dereferencerHandle, out pathLookup);
                    Assert.IsFalse(pathLookup.IsEmpty);

                    // caching
                    if (warmStart)
                    {
                        for (int i = 0; i < randomStableKeys.Length; ++i)
                        {
                            var randomStableKeyCachedReference = randomStableKeys[i];
                            pathLookup.Resolve(ref randomStableKeyCachedReference, out var e);
                            randomStableKeys[i] = randomStableKeyCachedReference;
                        }
                        m_StableIDManager.RegisterDereferencerReadJobs(dereferencerHandle);
                    }
                })
                .CleanUp(() =>
                {
                    m_StableIDManager.RegisterDereferencerReadJobs(dereferencerHandle);
                    CleanEntitiesAndFinishAllJobs(ref entities);
                })
                .WarmupCount(1)
                .MeasurementCount(10)
                // .IterationsPerMeasurement(8)
                .GC()
                .Run();
        }

        /// <summary>
        /// Creates 'lookupTableSize' many entities. Adds stableKeyData to them. Then selects 'numOfLookups'
        /// StableKeyCachedReferences randomly to be used for look up.
        /// Then measures, the time it takes:
        /// + to look up in parallel 'numOfLookups' entities using the randomly selected StableKeyCachedReferences.
        /// </summary>
        /// <param name="lookupTableSize">The number of entities with stableKey in the lookup table</param>
        /// <param name="numOfLookups">The number of lookups to do.</param>
        /// <param name="warmStart">If true, then before measuring we'll do a lookup run to warm up cache.</param>
        void Internal_RandomParallelLookupStableKeys(int lookupTableSize, int numOfLookups, bool warmStart)
        {
            var entities = new NativeArray<Entity>();
            var randomStableKeys = new NativeArray<CachedStableEntityReference>();
            var pathLookup = new StableIDEntityManager.StableReferenceResolver();
            var dereferencerHandle = new JobHandle();

            Measure
                .Method(() =>
                {
                    var randomLookupJob = new RandomLookupParallelJob()
                    {
                        references = randomStableKeys,
                        lookup = pathLookup,
                    }.Schedule(randomStableKeys.Length, k_ThreadBatchCount, dereferencerHandle);
                    m_StableIDManager.RegisterDereferencerReadJobs(randomLookupJob);
                    randomLookupJob.Complete();
                })
                .SetUp(() =>
                {
                    // create entities and add StableKeys to them
                    entities = CreateEntities(lookupTableSize, Allocator.Persistent);
                    var stableKeys = AddStableKeyToEntities(entities);

                    // build lookup table
                    m_World.Update();
                    m_Manager.CompleteAllJobs();

                    // prepare for random access
                    randomStableKeys =
                        new NativeArray<CachedStableEntityReference>(numOfLookups, Allocator.Persistent);
                    for (int i = 0; i < randomStableKeys.Length; ++i)
                    {
                        randomStableKeys[i] = new CachedStableEntityReference
                        {
                            StableKey = stableKeys[Random.Range(0, stableKeys.Count)],
                        };
                    }

                    // get dereferencer
                    dereferencerHandle = m_StableIDManager.GetDereferencer(dereferencerHandle, out pathLookup);
                    Assert.IsFalse(pathLookup.IsEmpty);

                    // caching
                    if (warmStart)
                    {
                        var randomLookUpJob = new RandomLookupParallelJobWithCaching()
                        {
                            references = randomStableKeys,
                            lookup = pathLookup,
                        }.Schedule(randomStableKeys.Length, k_ThreadBatchCount, dereferencerHandle);
                        randomLookUpJob.Complete();
                        m_StableIDManager.RegisterDereferencerReadJobs(randomLookUpJob);
                    }
                })
                .CleanUp(() =>
                {
                    m_StableIDManager.RegisterDereferencerReadJobs(dereferencerHandle);
                    randomStableKeys.Dispose();
                    CleanEntitiesAndFinishAllJobs(ref entities);
                })
                .WarmupCount(1)
                .MeasurementCount(10)
                // .IterationsPerMeasurement(8)
                .GC()
                .Run();
        }

        struct RandomLookupParallelJob : IJobParallelFor
        {
            [ReadOnly] public StableIDEntityManager.StableReferenceResolver lookup;
            [ReadOnly] public NativeArray<CachedStableEntityReference> references;

            public void Execute(int index)
            {
                var cachedStableEntityReference = references[index];
                lookup.ResolveReadOnly(in cachedStableEntityReference, out var e);
            }
        }
        struct RandomLookupParallelJobWithCaching : IJobParallelFor
        {
            [ReadOnly] public StableIDEntityManager.StableReferenceResolver lookup;
            public NativeArray<CachedStableEntityReference> references;

            public void Execute(int index)
            {
                var cachedStableEntityReference = references[index];
                lookup.Resolve(ref cachedStableEntityReference, out var e);
                references[index] = cachedStableEntityReference;
            }
        }

        NativeArray<Entity> CreateEntities(int entityCount, Allocator allocator)
        {
            return m_Manager.Instantiate(m_SrcEntity, entityCount, allocator);
        }

        List<StableKey> AddStableKeyToEntities(NativeArray<Entity> entities)
        {
            var stableKeys = new List<StableKey>();
            for (int i = 0; i < entities.Length; ++i)
            {
                var stableKey = StableKey.GenerateUnique();
                stableKeys.Add(stableKey);
                m_Manager.AddComponentData(entities[i], new StableKeyData
                {
                    Value = stableKey,
                });
            }

            return stableKeys;
        }

        void CleanEntitiesAndFinishAllJobs(ref NativeArray<Entity> entities)
        {
            m_Manager.DestroyEntity(entities);
            entities.Dispose();
            m_World.Update();
            m_Manager.CompleteAllJobs();
        }
    }
}
