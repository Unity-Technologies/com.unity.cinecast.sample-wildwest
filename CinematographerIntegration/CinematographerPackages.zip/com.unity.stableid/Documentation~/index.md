# Stable IDs for Cross-Scene Referencing
---------
This package makes it possible to reference objects across scene boundaries.  It is based on the **guid-based-reference** package originally developed by William Armstrong (williama@unity3d.com), and has been enhanced to work in DOTS as well as in GameObject-land.

The implementation is in DOTS, but StableIDs will work both for GameObjects that are converted to Entities, and GameObjects that are not.  Under the hood, StableID will generate entities for GameObjects that don't aldeady do so.

**Prefabs** will be assigned IDs when they are instanced, so every prefab instance is guaranteed to have a unique StableID.  The prefab _itself_ cannot be referred to using StableID.

## To Use:

### Authoring, and Hybrid:
Add a **StableID** component to any object you want to be able to reference.

In any code that needs to be able to reference objects by StableID, add a **StableReference\<MyComponent\>** field.  By specifying a component, the property drawer for the field will only accept GameObjects that hold an instance of _MyComponent_.  This is for convenience.  Use _StableID_ as the component filter if you don't want to filter on another component.

**StableReference.GameObject** will then return the GameObject if it is loaded, otherwise null.

### DOTS Runtime:
If the StableID is part of a game object within a conversion hierarchy, then a **StableKeyData** component will be added to the underlying entity, which will have a **StableKey** value.  

Components may hold **StableKey** fields as references to objects with Stable IDs.  These can be dereferenced via **StableIDEntityManager.StableReferenceResolver**, which accesses a hashmap StableKey -> Entity maintained by **StableIDEntityManager**.

Alternatively, components may hold a **CachedStableEntityReference** which caches the Entity from the last lookup, reducing the total number of hash lookups per frame.  The cached value is invalidated whenever any StableID-owning entities are created or destroyed.
