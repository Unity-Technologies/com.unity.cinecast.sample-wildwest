# Unity.Cinemachine.Dots

- Cinemachine.Dots is a DOTS implementation of Cinemachine.  
- It can be used in pure-DOTS projects, and also in classic non-DOTS projects.  
- Cinemachine.Dots objects may exist is DOTS subscenes, or in ordinary scenes.  
- Cinemachine.Dots supports cross-scene binding of targets.
- Cinemachine.Dots is compatible with classic Timeline, and also has some limited support for DOTS Timeline.

### Installation
- Repository is https://github.cds.internal.unity3d.com/unity/dots 
- Works eith current Unity 2020.2-dots partner edition
- Samples are included in the repository. They can be imported from the package manager.
- CinecastGreybox sample scene is also included - it is very WIP, and requires CM Classic to be installed.

### Sample Scenes
Many samples are set up with all CM content in a subscene, to illustrate pure-DOTS setup and cross-scene bindings.

- **SimpleFollow** - a simple tracker with damped follow and composer, following a player. WASD to move.
- **ClearShot** - simple test of ClearShot, showing camera switching based on occlusion
- **NewPath** - Dolly track with auto-follow. WASD to move.
- **GroupComposer** - composing on a group of moving objects, keeping constant screen size. Uses dolly tracks and paths.
- **BasicFreeLook** - Simple Orbital FreeLook wihout per-rig overrides. Mouse and WASD to move.
- **BlendHints** - Shows the effect of blending between nodes with different Blend Hints
- **Position Composer** - Simple target tracking with position composer. WASD to move.
- **Collider** - FreeLook following a character, with a Collision Resolution extension to resolve target occlusions. Mouse and WASD to move.
- **Impulse** - Tracker with Impulse Listener following a character, with an Impulse Emitter emitting periodic impulses.  Move the character away from the impulse source to see the decay in the camera's impulse response. WASD to move.
- **MultiNoise** - Showing additive effects of multiple noise channels on a tracker node
- **Sequencer** - Simple sequence of 2 trackers implementing a push-in when activated
- **Mixer** - Simple continuous mix of 2 trackers
- **ThirdPersonCamera** - An over-the-shoulder camera with dead-accurate aim. Mouse and WASD to move.
- **Timeline** - Integration with DOTS Timeline. Using timeline to switch between vcams, including a punch-in track and stacked blends. Not fully implemented, still some bugs.
- **CM_Boids** - A CM-enabled version of the Boids scene. Hybrid-mode trackers following shark and one red fish, and a ClearShot monitoring thousands of pure-DOTS (non-hybrid) trackers following individual fish, with shot quality evaluation. Pure-DOTS trackers are visualized as orange Unity logos following the fish, just so we know they’re there. Adjust the priorities on the trackers in the inspectors to trigger blending.

## Current Issues
- Workaround for cross-subscene target and channel references uses temporary GUID-based cross-scene binding. This will be upgraded to the Unity standard, when the latter becomes available.
- EntityBehaviour is an embedded class within the Cinemachine package.  This is a stopgap until EntityBehaviour becomes part of the Entities core (expected in Q2 2021).
- UX is minimal for almost everything. Using defaults; there is little or no custom UX. This will change.
- DOTS Timeline integration is nascent, still many rough edges and incomplete functionality (e.g. no way to animate vcam fields).
- Timeline animation of composer settings is temporarily disabled, as a workaround for DOTS.Timeline API change

### Not Implemented Yet
- CameraOffset extension
- Confiner
- Reactor
- PixelPerfect
- StateDrivenCamera
- Storyboard
- POV
- SmartUpdate
- PostProcessing integration
- Timeline animation of node fields (waiting for general DOTS timeline solution)

### Naming
Names in Cinemachine are being rethought, and are likely to change in the near future, along with new designs for UX.

## Cinemachine.Dots Overview

### Executive Summary: 
- Same functionality as CM Classic, but with added goodness
- Don’t lose any features of CM Classic, including client extensibility
- High performance, supports massive number of nodes
- Cinecast support
- Built from the ground up to support automated testing
- Able to function well in pure-DOTS (including Tiny) and also in classic non-DOTS projects

### DOTS core
- Core is 100% DOTS - no game objects
- New math library throughout
- All nodes update in parallel, burst-compiled

### Optional GameObject mode 
- Designed to allow the authoring components to remain in a classic project and provide seamless interface with the GameObject world.  This includes, inspector, animator, and scripts.
- Workflow remains similar to CM Classic for now
- Plays well with Presets and nested prefabs
- No weird hidden or secret game objects

## Design Overview
Cinemachine runs in the **LateSimulationGroup**, after scene objects have been positioned for the frame. The output is a new camera transform.

### Knowledge of Targets
Cameras look at and track targets, so we need to collect some information about the targets before the cameras can act intelligently. 
- Only entities with **CmTarget** or **CmTargetGroup** can be targeted.
- A CmTargetGroup is a collection of entities that have CmTarget but not CmTargetGroup (i.e. groups are non-nesting).
- **CmTargetSystem** Collects information about the targets and the groups, including location, orientation, and bounding shape. It also creates a lookup hash for this info, based on entity id. The hash is available for other systems to use.

### Basic Definitions
**CameraState** - a lerpable data packet that encapsulates the state of a Camera: 
- position, rotation, 
- Lens settings, 
- PostProcessing profiles and weights, 
- etc.
This can be applied to a Camera, or linearly blended with other CameraState objects. The CameraState of the current active Cm Node (or current active blend) is what is applied every frame to the Unity Camera.

**CM Node** - generic term for something that generates a CameraState.  Generally, nodes can be assigned procedural algorithms that compute CameraState dynamically.

**CM Channel** - generic term for something that manages input Nodes and blends, and outputs a CameraState.  It’s a kind of CM Node, so channels can in general be nested.

### Structure of a scene
**CM Listener** - There is no concept yet of a DOTS Camera, so Cinemachine must bridge between the "DOTS-land" and "GameObject-land". The CM Listener lives on the Camera GameObject, but it receives its input from a **CM Channel**.

**CM Tracker** - This is a CM Node that, in general, can track one or more CM targets.  Procedural algorithms (including the null algorithm for a _passive camera_) can be assigned to the tracker to control its manner of movement.

There is a top-level CM channel that the CM Listener monitors, and every frame the CameraState is pulled from this channel and applied to the camera.  Split-screen applications can implement multiple top-level channels, cameras, and listeners.

Each CM Tracker is assiged to a CM Channel. Channles may be nested, until ultimately parented to the top-level Channel.  The Channel assignment is implemented as a shared component on the node, which allows grouping of nodes by channel. 

Think of a channel as a mini-world of nodes. Each channel manages its collection of nodes, and sorts them every frame according to shot quality and priority. The channel handles CameraState blending, and manages its current active node and its current blend state. The output of a channel is a current **CameraState** for the channel, the output of which can be applied to a variety of cases, the most obvious of which is to feed the Camera back in GameObject-land.

Channels can be nested. In other words, it is possible to make a node which is itself a channel that owns other nodes. The output of this node is a CameraState (position, orientation, lens, etc) which can be applied to a Camera, and blended with other CameraStates. ClearShot is an example of this: a node that is really a channel that manages child node.

The **CmChannelSystem** and **NodeBlendStackSystem** manage the channels and their current states, sort the nodes, compute the blend states, and compute the final output CameraState.

### Tracker Pipeline
The Tracker Pipeline is a collection of systems that define the autonomous behaviour of the CM Tracker nodes.

The tracker pipeline consists of these systems, in this order:
- **TrackerPreBodySystem** (executes after TrackerTargetSystem): initializes the trackers for procedural positioning. Primes their state based on LocalToWorld values and target assignments.
- **TrackerPreAimSystem** - (empty placeholder for procedural ordering)
- **TrackerPreCorrectionSystem** - (empty placeholder for procedural ordering). Correction is applied after basic positioning, and can include obstacle avoidance, noise, etc.
- **TrackerPreFinalizeSystem** - (empty placeholder for procedural ordering).
- **TrackerFinalizeSystem** - updates vcam's LocalToWorld with the output of the procedural positioning.

Mostly, these systems are empty, and serve as placeholders for custom CM pipeline elements. For instance, a Position system (something that positions the Tracker in space, like the CM Soft Follow) will execute after TrackerPreBodySystem and before TrackerPreAimSystem. This permits the easy integration of internal and client-authored procedural Tracker systems.

### Shot Evaluation
Once the Tracker is positioned, a shot evaluator can be run, if desired. This calculates the quality of the shot, according to rules defined within the quality evaluator. Shot quality is distinct from Shot Transition Quality, which is a separate system that depends also on the current active shot.

Currently we have implemented three sample shot quality systems: 
- **LegacyShotQualitySystem** - does line-of-sight raycasts using the legacy physics API to determine target visibility. Degrades the shot quality if target is occluded.
- **SimpleShotQualitySystem** - does line-of-sight raycasts using the Unity.Physics API to determine target visibility. Degrades the shot quality if target is occluded.
- **ShotQualitySystem** - A more sphisticated shot suality system that requires knowledge of the importance of the targets for storytelling.  This is used in the context of Cinecast and the Story Manager.

### Subchannel Nodes
Nodes can themselves be channels with their own trackers and subnodes assigned to them
- **ClearShot** is a CMNode that is really a subchannel - it’s a node that manages its own channel and takes the state of its internal current active node (or blend). 
- **CmMixer**, **CmSequencer**, **StateDrivenCamera**, and other manager-style vcams behave in a manner analogous to ClearShot, but with different algorithms for choosing their internal current active vcams.
- By default, GameObject CmNode childen of the Subchannel Nodes will belong to the subchannel (but this can be managed differently if desired).

### EntityBehaviour
Cinemachine.Dots is built on top of the **EntityBehaviour** base class for DOTS authoring.  This is a 
MonoBehaviour authoring class that behaves just like standard DOTS authoring behaviours, but 
with the additional ability to play nicely within an old-fashioned GameObject-based runtime.

This means that Cinemachine.Dots can be used in pure-DOTS projects without performance penalty,
and also in GameObject-based classic projects, neatly wrapping the DOTS back-end.

EntityBehaviour operates in two modes, depending on the context in which it finds itself:

1. Non-synchronized mode:  **In a pure-DOTS context** (e.g. in a subscene or as part
of a standard DOTS conversion hierarchy), the behaviour exists during authoring only and is
stripped away at runtime, abandoning the GameObject-based authoring wrapper.  Just like normal
authoring behaviours, EntityBehaviour implements the IConvertGameObjectToEntity interface,
and generates DOTS components for entities.  At authoring time, standard mechanisms
(e.g. LiveLink) will function correctly, and it will behave as any other authoring behaviour.

2. Synchronized mode:  **Outside of a conversion context**, it has special behaviour.  It manages
its own entity conversion and keeps track of associated entities.  In this mode, the GameObject
is not stripped away, remaining at runtime just like ordinary MonoBehaviours.  Thus, it can
expose DOTS-implemented state and functionality to other MonoBehaviours and to non-DOTS
subsystems, via custom methods and get/set properties on the EntityBehaviour.

