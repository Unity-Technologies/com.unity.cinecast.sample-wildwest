using UnityEditor;
using UnityEngine;
using Unity.Entities;
using Unity.Mathematics;
using System.Collections.Generic;
using UnityEditorInternal;
using System.Linq;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CustomEditor(typeof(TCBSplinePathAuthoring))]
    internal class TCBSplinePathPathEditor : BaseEditor<TCBSplinePathAuthoring>
    {
        public override void OnInspectorGUI()
        {
            BeginInspector();

            float pathLength = Target.SynchronizedWorld.SafeGetComponentData<TCBSplinePathState>(
                Target.SynchronizedEntity).PathLength;
            EditorGUILayout.LabelField(
                new GUIContent("Path length"), new GUIContent(pathLength.ToString()));

            DrawRemainingPropertiesInInspector();
        }

        internal static void DrawPathGizmo(
            TCBSplinePathState pathState, DynamicBuffer<TCBSplinePathWaypointElement> waypoints,
            Color pathColor, float width, int resolution)
        {
            bool looped = pathState.Looped;

            // Draw the path
            Color colorOld = Gizmos.color;
            Gizmos.color = pathColor;
            float step = 1f / math.max(1, resolution);
            float3 right = new float3(1, 0, 0) * width / 2;
            float3 lastPos = TCBSplinePathSystem.EvaluatePosition(0, ref pathState, ref waypoints);
            float3 lastW = math.mul(TCBSplinePathSystem.EvaluateOrientation(
                0, ref pathState, ref waypoints), right);

            int count = waypoints.Length;
            float maxPos = math.select(0, math.select(count - 1, count, looped), count > 1);
            for (float t = step; t <= maxPos + step / 2; t += step)
            {
                float3 p = TCBSplinePathSystem.EvaluatePosition(t, ref pathState, ref waypoints);
                quaternion q = TCBSplinePathSystem.EvaluateOrientation(t, ref pathState, ref waypoints);

                float3 w = math.mul(q, right);
                float3 w2 = w * 1.2f;
                float3 p0 = p - w2;
                float3 p1 = p + w2;

                Gizmos.DrawLine(p0, p1);
                Gizmos.DrawLine(lastPos - lastW, p - w);
                Gizmos.DrawLine(lastPos + lastW, p + w);

#if false // visualize orientations
                Gizmos.color = Color.red;
                Gizmos.DrawLine(p, p + math.mul(q, new float3(width, 0, 0)));
                Gizmos.color = Color.green;
                Gizmos.DrawLine(p, p + math.mul(q, new float3(0, width, 0)));
                Gizmos.color = Color.blue;
                Gizmos.DrawLine(p, p + math.mul(q, new float3(0, 0, width)));
                Gizmos.color = pathColor;
#endif

                lastPos = p;
                lastW = w;
            }
            Gizmos.color = colorOld;
        }

        [DrawGizmo(GizmoType.Active | GizmoType.NotInSelectionHierarchy
            | GizmoType.InSelectionHierarchy | GizmoType.Pickable, typeof(TCBSplinePathAuthoring))]
        static void DrawGizmos(TCBSplinePathAuthoring path, GizmoType selectionType)
        {
            var w = ClientHooks.DefaultWorld;
            var e = path.SynchronizedEntity;
            if (!w.SafeHasComponent<TCBSplinePathState>(e)
                    || !w.SafeHasComponent<TCBSplinePathWaypointElement>(e))
                return;

            DrawPathGizmo(
                w.SafeGetComponentData<TCBSplinePathState>(e),
                w.SafeGetBuffer<TCBSplinePathWaypointElement>(e),
                (Selection.activeGameObject == path.gameObject)
                    ? path.Appearance.PathColor : path.Appearance.InactivePathColor,
                path.Appearance.Width, path.Value.Resolution);
        }
    }

    [CustomEditor(typeof(TCBSplinePathWaypointsAuthoring))]
    internal class TCBPathWaypointsEditor : BaseEditor<TCBSplinePathWaypointsAuthoring>
    {
        private ReorderableList m_WaypointList;

        GUIContent m_ResetLabel = new GUIContent("Reset", "Reset T/C/B");
        GUIContent m_PositionLabel = new GUIContent("Position");
        GUIContent m_NumberLabel = new GUIContent("999");

        const float hSpace = 3;

        protected override void GetExcludedPropertiesInInspector(List<string> excluded)
        {
            base.GetExcludedPropertiesInInspector(excluded);
            excluded.Add(FieldPath(x => x.Values));
        }

        void OnEnable()
        {
            m_WaypointList = null;
        }

        // ReSharper disable once UnusedMember.Global - magic method called when doing Frame Selected
        public bool HasFrameBounds()
        {
            return Target.Values.Count > 0;
        }

        // ReSharper disable once UnusedMember.Global - magic method called when doing Frame Selected
        public Bounds OnGetFrameBounds()
        {
            var values = Target.Values;
            List<Vector3> wp = new List<Vector3>();
            int selected = m_WaypointList == null ? -1 : m_WaypointList.index;
            if (selected >= 0 && selected < values.Count)
                wp.Add(values[selected].Position);
            else for (int i = 0; i < values.Count; ++i)
            {
                var p = values[i].Position;
                wp.Add(new Vector3(p.x, p.y, p.z));
            }
            return GeometryUtility.CalculateBounds(wp.ToArray(), Target.transform.localToWorldMatrix);
        }

        public override void OnInspectorGUI()
        {
            BeginInspector();

            if (m_WaypointList == null)
                SetupWaypointList();

            if (m_WaypointList.index >= m_WaypointList.count)
                m_WaypointList.index = m_WaypointList.count - 1;

            // Ordinary properties
            DrawRemainingPropertiesInInspector();

            // Waypoints
            EditorGUI.BeginChangeCheck();
            m_WaypointList.DoLayoutList();
            if (EditorGUI.EndChangeCheck())
                serializedObject.ApplyModifiedProperties();
        }

        void SetupWaypointList()
        {
            m_WaypointList = new ReorderableList(
                    serializedObject, serializedObject.FindProperty("m_Values"),
                    true, true, true, true);
            m_WaypointList.elementHeight
                = (EditorGUIUtility.standardVerticalSpacing + EditorGUIUtility.singleLineHeight) * 3;

            m_WaypointList.drawHeaderCallback = (Rect rect) =>
                { EditorGUI.LabelField(rect, "Waypoints"); };

            m_WaypointList.drawElementCallback
                = (Rect rect, int index, bool isActive, bool isFocused) =>
                { DrawWaypointEditor(rect, index); };

            m_WaypointList.onAddCallback = (ReorderableList l) =>
                { InsertWaypointAtIndex(l.index); };
        }

        void DrawWaypointEditor(Rect rect, int index)
        {
            rect.y += EditorGUIUtility.standardVerticalSpacing / 2;

            // Needed for accessing string names of fields
            TCBSplinePathWaypointElement def = new TCBSplinePathWaypointElement();
            SerializedProperty element = m_WaypointList.serializedProperty.GetArrayElementAtIndex(index);

            Vector2 resetLabelDimension = GUI.skin.button.CalcSize(m_ResetLabel);
            float positionLabelWidth = GUI.skin.label.CalcSize(m_PositionLabel).x;
            Vector2 numberDimension = GUI.skin.label.CalcSize(m_NumberLabel);
            float lineHeight = EditorGUIUtility.singleLineHeight + EditorGUIUtility.standardVerticalSpacing;

            // Divide into 3 columns
            Rect rA = new Rect(rect.x, rect.y, 
                numberDimension.x, EditorGUIUtility.singleLineHeight);
            Rect rB = new Rect(rA.x + rA.width + hSpace, rect.y, 
                rect.width - (rA.width + resetLabelDimension.x + 2 * hSpace), 
                EditorGUIUtility.singleLineHeight);
            Rect rC = new Rect(rB.x + rB.width + hSpace, rect.y,
                resetLabelDimension.x, EditorGUIUtility.singleLineHeight);

            // First column
            DrawGoToWaypointButton(rA, index);

            // Second column
            var oldWidth = new InspectorUtility.LabelWidthOverride(positionLabelWidth);
            EditorGUI.PropertyField(rB, element.FindPropertyRelative(() => def.Position));
            rB.y += lineHeight;

            var tcbProp = element.FindPropertyRelative(() => def.TCB);
            var tProp = tcbProp.FindPropertyRelative("x");
            var cProp = tcbProp.FindPropertyRelative("y");
            var bProp = tcbProp.FindPropertyRelative("z");
            InspectorUtility.MultiPropertyOnLine(
                rB, new GUIContent("Control"),
                new[] { tProp, cProp, bProp },
                new[] { new GUIContent("T"), new GUIContent("C"), new GUIContent("B") });

            rB.y += lineHeight;
            EditorGUIUtility.labelWidth += 12; // GML wtf
            EditorGUI.PropertyField(rB, element.FindPropertyRelative(() => def.Roll));

            // Third column
            DrawSetWaypointButton(rC, index);

            rC.y += lineHeight;
            GUI.enabled = tProp.floatValue != 0 || cProp.floatValue != 0 || bProp.floatValue != 0;
            if (GUI.Button(rC, m_ResetLabel))
            {
                tProp.floatValue = 0;
                cProp.floatValue = 0;
                bProp.floatValue = 0;
            }
            GUI.enabled = true;
        }

        void DrawGoToWaypointButton(Rect r, int index)
        {
            if (GUI.Button(r, new GUIContent(index.ToString(), "Go to the waypoint in the scene view")))
            {
                var s = SceneView.lastActiveSceneView;
                var e = Target.SynchronizedEntity;
                if (s != null && DefaultWorld.SafeHasComponent<TCBSplinePathState>(e))
                {
                    var pathState = DefaultWorld.SafeGetComponentData<TCBSplinePathState>(e);
                    var waypoints = DefaultWorld.SafeGetBuffer<TCBSplinePathWaypointElement>(e);

                    float3 pos = TCBSplinePathSystem.EvaluatePosition((float)index, ref pathState, ref waypoints);
                    s.LookAt(pos, s.camera.transform.rotation, 0); // zero size screws up navigation but I don't know how else to do this!
                    m_WaypointList.index = index;
                }
            }
        }

        void DrawSetWaypointButton(Rect r, int index)
        {
            GUIContent setButtonContent = EditorGUIUtility.IconContent("d_RectTransform Icon");
            setButtonContent.tooltip = "Match scene-view camera transform";
            if (GUI.Button(r, setButtonContent, GUI.skin.label) && SceneView.lastActiveSceneView != null)
            {
                Undo.RecordObject(Target, "Set waypoint");
                var values = Target.Values;
                m_WaypointList.index = index;
                var wp = values[index];
                Vector3 pos = SceneView.lastActiveSceneView.camera.transform.position;
                //var rot = SceneView.lastActiveSceneView.camera.transform.rotation;
                wp.Position = Target.transform.InverseTransformPoint(pos);
                values[index] = wp;
                Target.Values = values;
                InternalEditorUtility.RepaintAllViews();
            }
        }

        void InsertWaypointAtIndex(int indexA)
        {
            var path = Target.GetComponent<TCBSplinePathAuthoring>();
            bool looped = path == null ? false : path.Value.Looped;

            float3 pos = Vector3.right;
            float roll = 0;

            var e = Target.SynchronizedEntity;
            var pathState = DefaultWorld.SafeGetComponentData<TCBSplinePathState>(e);
            var waypoints = DefaultWorld.EntityManager.GetBuffer<TCBSplinePathWaypointElement>(e);

            // Get new values from the current indexA (if any)
            var values = Target.Values;
            int numWaypoints = waypoints.Length;
            if (indexA < 0)
                indexA = numWaypoints - 1;
            if (indexA >= 0)
            {
                int indexB = indexA + 1;
                if (looped && indexB >= numWaypoints)
                    indexB = 0;
                if (indexB >= numWaypoints)
                {
                    float3 delta = new float3(1, 0, 0);
                    if (indexA > 0)
                        delta = values[indexA].Position - Target.Values[indexA - 1].Position;
                    pos = values[indexA].Position + delta;
                    roll = values[indexA].Roll;
                }
                else
                {
                    // Interpolate
                    pos = Target.transform.InverseTransformPoint(
                        TCBSplinePathSystem.EvaluatePosition(0.5f + indexA, ref pathState, ref waypoints));
                    roll = values[indexA].Roll; // GML todo: intorpolate
                }
            }
            Undo.RecordObject(Target, "Add waypoint");
            var wp = new TCBSplinePathWaypointElement { Position = pos, Roll = roll };
            values.Insert(indexA + 1, wp);
            Target.Values = values;
            InternalEditorUtility.RepaintAllViews();
            m_WaypointList.index = indexA + 1; // select it
        }

        void OnSceneGUI()
        {
            if (m_WaypointList == null)
                SetupWaypointList();

            if (Tools.current == Tool.Move)
            {
                var values = Target.Values;
                Color colorOld = Handles.color;
                var localToWorld = Target.transform.localToWorldMatrix;
                for (int i = 0; i < values.Count; ++i)
                {
                    DrawSelectionHandle(values, i, localToWorld);
                    if (m_WaypointList.index == i)
                        DrawPositionControl(values, i, localToWorld, Target.transform.rotation); // Waypoint is selected
                }
                Handles.color = colorOld;
            }
        }

        void DrawSelectionHandle(List<TCBSplinePathWaypointElement> values, int index, Matrix4x4 localToWorld)
        {
            if (Event.current.button != 1)
            {
                var wp = values[index];
                Vector3 pos = localToWorld.MultiplyPoint(wp.Position);
                float size = HandleUtility.GetHandleSize(pos) * 0.2f;
                Handles.color = Color.white;
                if (Handles.Button(pos, Quaternion.identity, size, size, Handles.SphereHandleCap)
                    && m_WaypointList.index != index)
                {
                    m_WaypointList.index = index;
                    InternalEditorUtility.RepaintAllViews();
                }
                // Label it
                Handles.BeginGUI();
                Vector2 labelSize = new Vector2(
                        EditorGUIUtility.singleLineHeight * 2, EditorGUIUtility.singleLineHeight);
                Vector2 labelPos = HandleUtility.WorldToGUIPoint(pos);
                labelPos.y -= labelSize.y / 2;
                labelPos.x -= labelSize.x / 2;
                GUILayout.BeginArea(new Rect(labelPos, labelSize));
                GUIStyle style = new GUIStyle();
                style.normal.textColor = Color.black;
                style.alignment = TextAnchor.MiddleCenter;
                GUILayout.Label(new GUIContent(index.ToString(), "Waypoint " + index), style);
                GUILayout.EndArea();
                Handles.EndGUI();
            }
        }

        void DrawPositionControl(List<TCBSplinePathWaypointElement> values, int index, Matrix4x4 localToWorld, Quaternion localRotation)
        {
            var wp = values[index];
            Vector3 pos = localToWorld.MultiplyPoint(wp.Position);
            EditorGUI.BeginChangeCheck();
            Handles.color = Target.GetComponent<TCBSplinePathAuthoring>().Appearance.PathColor;
            Quaternion rotation = (Tools.pivotRotation == PivotRotation.Local)
                ? localRotation : Quaternion.identity;
            float size = HandleUtility.GetHandleSize(pos) * 0.1f;
            Handles.SphereHandleCap(0, pos, rotation, size, EventType.Repaint);
            pos = Handles.PositionHandle(pos, rotation);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(target, "Move Waypoint");
                wp.Position = Matrix4x4.Inverse(localToWorld).MultiplyPoint(pos);
                values[index] = wp;
                Target.Values = values;
                InternalEditorUtility.RepaintAllViews();
            }
        }

    }
}

