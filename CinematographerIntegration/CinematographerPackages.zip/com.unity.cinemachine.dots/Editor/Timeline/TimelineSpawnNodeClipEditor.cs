#if CINEMACHINE_TIMELINE
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using UnityEditor.Timeline;
using UnityEngine.Timeline;
using UnityEngine.Playables;
using Unity.Timeline.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CustomTimelineEditor(typeof(CmSpawnNodeClip))]
    public class DrawDebugGizmosForNode : ClipEditor
    {
        private static Texture2D GetTimelineIcon()
        {
            var o = ScriptableObject.CreateInstance<TimelineAsset>();
            var texture = AssetPreview.GetMiniThumbnail(o);
            Object.DestroyImmediate(o);
            return texture;
        }

        private static readonly Texture2D[] m_Icon = new[]
        {
           GetTimelineIcon()
        };
        private readonly Dictionary<CmSpawnNodeClip, PlayableDirector> m_DirectorCache 
            = new Dictionary<CmSpawnNodeClip, PlayableDirector>();

        public override ClipDrawOptions GetClipOptions(TimelineClip clip)
        {
            var shotClip = (CmSpawnNodeClip)clip.asset;
            var clipOptions = base.GetClipOptions(clip);
            if (shotClip != null)
            {
                if (shotClip.Prefab == null || shotClip.Prefab.GetComponent<CmCameraAuthoring>() == null)
                    clipOptions.errorText = "A CmNode must be assigned.";
                else
                    clipOptions.tooltip = shotClip.Prefab.name;
                if (shotClip.AnimationTimeline != null)
                    clipOptions.icons = m_Icon;
            }
            return clipOptions;
        }

        public override void OnClipChanged(TimelineClip clip)
        {
            var shotClip = (CmSpawnNodeClip) clip.asset;
            if (shotClip == null)
                return;
            if (shotClip.DisplayName != null && shotClip.DisplayName.Length != 0)
                clip.displayName = shotClip.DisplayName;
            else if (shotClip.Prefab != null)
                clip.displayName = shotClip.Prefab.name;
        }

        public override void GetSubTimelines(
            TimelineClip clip, PlayableDirector director, List<PlayableDirector> subTimelines)
        {
            var subTL = clip.asset as CmSpawnNodeClip;
            if (subTL.AnimationTimeline == null)
                return;

            m_DirectorCache.TryGetValue(subTL, out PlayableDirector subDirector);
            if (subDirector == null) // not found OR deleted
            {
                var go = new GameObject()
                {
                    hideFlags = HideFlags.HideAndDontSave | HideFlags.DontUnloadUnusedAsset,
                    name = subTL.AnimationTimeline.name
                };

                subDirector = go.AddComponent<PlayableDirector>();
                subDirector.hideFlags = HideFlags.HideAndDontSave | HideFlags.DontUnloadUnusedAsset;

                m_DirectorCache[subTL] = subDirector;

                var bindGO = new GameObject()
                {
                    hideFlags = HideFlags.HideAndDontSave | HideFlags.DontUnloadUnusedAsset,
                    name = " "
                };

                var binding = bindGO.AddComponent<AutoBinding>();
                binding.transform.parent = subDirector.transform;
            }

            var autoBind = subDirector.transform.GetChild(0).GetComponent<AutoBinding>();
            foreach (var t in subTL.AnimationTimeline.outputs)
            {
                if (typeof(TrackBaseBinding).IsAssignableFrom(t.outputTargetType))
                    subDirector.SetGenericBinding(t.sourceObject, autoBind);
            }

            subDirector.name = subTL.AnimationTimeline.name;
            subDirector.playableAsset = subTL.AnimationTimeline;
            subDirector.playOnAwake = false;

            subTimelines.Add(subDirector);
        }
    }

    [CustomEditor(typeof(CmSpawnNodeClip))]
    internal sealed class CmSpawnNodeClipEditor : BaseEditor<CmSpawnNodeClip>
    {
        protected override void GetExcludedPropertiesInInspector(List<string> excluded)
        {
            base.GetExcludedPropertiesInInspector(excluded);
            excluded.Add(FieldPath(x => x.Prefab));
            excluded.Add(FieldPath(x => x.AnimationTimeline));
            excluded.Add(FieldPath(x => x.WrapMode));
        }

        private void OnDisable()
        {
            DestroyComponentEditors();
        }

        private void OnDestroy()
        {
            DestroyComponentEditors();
        }

        public override void OnInspectorGUI()
        {
            BeginInspector();
            EditorGUI.indentLevel = 0; // otherwise subeditor layouts get screwed up

            SerializedProperty nodeProperty = FindProperty(x => x.Prefab);
            EditorGUI.BeginChangeCheck();
            {
                var rect = EditorGUILayout.GetControlRect(true);
                if (InspectorUtility.PrefabFieldWithCreateButton(
                    rect, nodeProperty, typeof(CmNodeAuthoringBase)))
                {
                    GameObject nodeGO = nodeProperty.objectReferenceValue as GameObject;
                    nodeGO = AssetHelper.CopyOrCreatePrefab(
                        nodeGO, "node", "CM Nodes", typeof(CmCameraAuthoring));
                    nodeProperty.objectReferenceValue = nodeGO;
                    if (SceneView.lastActiveSceneView != null)
                    {
                        var cam = SceneView.lastActiveSceneView.camera;
                        FindProperty(x => x.Position).SetFloat3Value(cam.transform.position);
                        FindProperty(x => x.Rotation).SetFloat3Value(cam.transform.rotation.eulerAngles);
                        var node = nodeGO.GetComponent<CmCameraAuthoring>();
                        if (node != null)
                            node.Lens = MainMenu.LensSettingsFromCamera(cam, false);
                    }
                }
            }
            if (EditorGUI.EndChangeCheck())
                serializedObject.ApplyModifiedProperties();

            DrawRemainingPropertiesInInspector();

            EditorGUI.BeginChangeCheck();
            {
                SerializedProperty property = FindProperty(x => x.AnimationTimeline);
                var rect = EditorGUILayout.GetControlRect(true);
                var asset = property.objectReferenceValue as TimelineAsset;
                if (asset != null)
                {
                    EditorGUI.PropertyField(rect, property);
                    EditorGUILayout.PropertyField(FindProperty(x => x.WrapMode));
                }
                else
                {
                    GUIContent createLabel = asset == null ? new GUIContent("Create") : GUIContent.none;
                    Vector2 createSize = GUI.skin.button.CalcSize(createLabel);
                    rect.width -= createSize.x;
                    EditorGUI.PropertyField(rect, property);
                    rect.x += rect.width; rect.width = createSize.x;
                    if (GUI.Button(rect, createLabel))
                    {
                        asset = AssetHelper.CreateSubTimelineFor(
                            nodeProperty.objectReferenceValue as GameObject);
                        if (asset != null)
                            property.objectReferenceValue = asset;
                    }
                }
            }
            if (EditorGUI.EndChangeCheck())
                serializedObject.ApplyModifiedProperties();

            EditorGUI.BeginChangeCheck();
            if (Target.Prefab)
                DrawSubeditors(Target.Prefab);

            // by default timeline rebuilds the entire graph when something changes,
            // but if a property of the CmNode changes, we only need to re-evaluate the timeline.
            // this prevents flicker on post processing updates
            if (EditorGUI.EndChangeCheck())
            {
                TimelineEditor.Refresh(RefreshReason.ContentsModified);
                GUI.changed = false;
            }
        }

        void DrawSubeditors(GameObject node)
        {
            // Create an editor for each of the cinemachine virtual cam and its components
            GUIStyle foldoutStyle = new GUIStyle(EditorStyles.foldout) { fontStyle = FontStyle.Bold };
            UpdateComponentEditors(node);
            for (int i = 0; m_editors != null && i < m_editors.Count; ++i)
            {
                var e = m_editors[i];
                if (e == null || e.target == null
                        || (e.target.hideFlags & HideFlags.HideInInspector) != 0)
                    continue;

                // Separator line - how do you make a thinner one?
                GUILayout.Box("", new GUILayoutOption[]
                    { GUILayout.ExpandWidth(true), GUILayout.Height(1) } );

                if (!s_EditorExpanded.TryGetValue(e.target.GetType(), out bool expanded))
                    expanded = true;
                expanded = EditorGUILayout.Foldout(
                    expanded, e.target.GetType().Name, true, foldoutStyle);
                if (expanded)
                    e.OnInspectorGUI();
                s_EditorExpanded[e.target.GetType()] = expanded;
            }
        }

        List<UnityEditor.Editor> m_editors = new List<UnityEditor.Editor>();
        List<MonoBehaviour> m_cachedTargets = new List<MonoBehaviour>();
        List<MonoBehaviour> m_scratchTargets = new List<MonoBehaviour>();
        static Dictionary<System.Type, bool> s_EditorExpanded = new Dictionary<System.Type, bool>();

        void UpdateComponentEditors(GameObject obj)
        {
            m_scratchTargets.Clear();
            if (obj != null)
                obj.GetComponents(m_scratchTargets);
            bool isSame = m_scratchTargets.Count == m_cachedTargets.Count;
            for (int i = 0; i < m_scratchTargets.Count && isSame; ++i)
                isSame = m_scratchTargets[i] == m_cachedTargets[i];
            if (!isSame)
            {
                DestroyComponentEditors();
                for (int i = 0; i < m_scratchTargets.Count; ++i)
                {
                    UnityEditor.Editor e = null;
                    CreateCachedEditor(m_scratchTargets[i], null, ref e);
                    m_editors.Add(e);
                    m_cachedTargets.Add(m_scratchTargets[i]);
                }
            }
        }

        void DestroyComponentEditors()
        {
            m_cachedTargets.Clear();
            for (int i = 0; i < m_editors.Count; ++i)
            {
                if (m_editors[i] != null)
                    UnityEngine.Object.DestroyImmediate(m_editors[i]);
                m_editors[i] = null;
            }
            m_editors.Clear();
        }
    }
}
#endif
