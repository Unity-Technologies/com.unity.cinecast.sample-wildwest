using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using System.Reflection;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    /// <summary>
    /// Editor for CmCameraAuthoring
    /// </summary>
    [CanEditMultipleObjects]
    [CustomEditor(typeof(CmCameraAuthoring), true)]
    internal class CmCameraEditor : CmNodeBaseEditor<CmCameraAuthoring>
    {
        readonly ComponentManagerDropdown m_PositionDropdown = new ComponentManagerDropdown();
        readonly ComponentManagerDropdown m_RotationDropdown = new ComponentManagerDropdown();
        readonly ComponentManagerDropdown m_NoiseDropdown = new ComponentManagerDropdown();
        readonly ExtensionManagerDropdown m_ExtensionsDropdown = new ExtensionManagerDropdown();
        GUIContent m_ProceduralHeader;

        protected override void OnEnable()
        {
            base.OnEnable();
            m_ProceduralHeader = new GUIContent("Procedural Motion");
            m_PositionDropdown.Initialize(
                new GUIContent("Position Control", "Procedural algorithm for positioning the camera"),
                "None",
                Target.gameObject, PipelineStage.Body);
            m_RotationDropdown.Initialize(
                new GUIContent("Rotation Control", "Procedural algorithm for orienting camera"),
                "None",
                Target.gameObject, PipelineStage.Aim);
            m_NoiseDropdown.Initialize(
                new GUIContent("Noise", "Procedural algorithm for adding position or rotation noise"),
                "None",
                Target.gameObject, PipelineStage.Noise);
            m_ExtensionsDropdown.Initialize(
                new GUIContent("Add Extension", "Add extra procedural components"),
                "(select)",
                Target.gameObject);
        }

        protected override void GetExcludedPropertiesInInspector(List<string> excluded)
        {
            base.GetExcludedPropertiesInInspector(excluded);
            excluded.Add(FieldPath(x => x.FollowTarget));
            excluded.Add(FieldPath(x => x.LookAtTarget));
        }

        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();

            EditorGUILayout.Space();
            EditorGUILayout.LabelField(m_ProceduralHeader, EditorStyles.boldLabel);

            Settings.CoreSettings.ShowInGameGuides
                = EditorGUILayout.Toggle(
                    new GUIContent(
                        "Game View Guides",
                        "Enable the display of overlays in the Game View.  You can adjust colours "
                            + "and opacity in Edit/Preferences/Cinemachine."),
                    Settings.CoreSettings.ShowInGameGuides);

            EditorGUILayout.PropertyField(FindProperty(x => x.FollowTarget));
            EditorGUILayout.PropertyField(FindProperty(x => x.LookAtTarget));

            m_PositionDropdown.DrawDropdownWidgetInInspector();
            m_RotationDropdown.DrawDropdownWidgetInInspector();
            m_NoiseDropdown.DrawDropdownWidgetInInspector();
            m_ExtensionsDropdown.DrawDropdownWidgetInInspector();
        }

        [MenuItem("CONTEXT/CmCameraAuthoring/Adopt Current Camera Settings")]
        static void AdoptCurrentCameraSettings(MenuCommand command)
        {
            var node = command.context as CmCameraAuthoring;
            var listener = CmListener.FindListener(node.Node.FindTopLevelChannel());
            if (listener != null)
            {
                node.Lens = listener.CameraState.Lens;
                node.transform.position = listener.transform.position;
                node.transform.rotation = listener.transform.rotation;
            }
        }

        [MenuItem("CONTEXT/CmCameraAuthoring/Adopt Scene View Camera Settings")]
        static void AdoptSceneViewCameraSettings(MenuCommand command)
        {
            var node = command.context as CmCameraAuthoring;
            MainMenu.SetCameraFromSceneView(node);
        }

        [DrawGizmo(GizmoType.Active | GizmoType.InSelectionHierarchy | GizmoType.Pickable, typeof(CmCameraAuthoring))]
        static void DrawCameraGizmos(CmCameraAuthoring node, GizmoType drawType)
        {
            DrawStandardCameraGizmos(node, drawType);
        }

        public class ComponentManagerDropdown
        {
            static Type[] sAllTypes;  // First entry is null
            static string[] sAllNames;

            Type[] myTypes;  // First entry is null
            string[] myNames;

            GameObject m_Target;
            GUIContent mLabel = GUIContent.none;
            string mEmptyLabel;
            PipelineStage mStageFilter;

            public void Initialize(
                GUIContent label, string emptyLabel,
                GameObject target,
                PipelineStage stageFilter)
            {
                mLabel = label;
                mEmptyLabel = emptyLabel;
                m_Target = target;
                mStageFilter = stageFilter;
                myTypes = null;
                myNames = null;
            }

            public void DrawDropdownWidgetInInspector()
            {
                RefreshLists();
                RefreshCurrent();
                Rect rect = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
                rect = EditorGUI.PrefixLabel(rect, mLabel);

                int selection = EditorGUI.Popup(rect, m_Current, myNames);
                if (selection != m_Current)
                {
                    Type type = myTypes[selection];
                    m_Current = selection;
                    foreach (var selectedGameobject in Selection.gameObjects)
                    {
                        if (selectedGameobject.GetType() != m_Target.GetType()) 
                            continue;
                        if (type != null && selectedGameobject.GetComponent(type) == null)
                            Undo.AddComponent(selectedGameobject, type);

                        for (int j = 1; j < myTypes.Length; ++j)
                        {
                            if (j == selection) 
                                continue;
                            var old = selectedGameobject.GetComponent(myTypes[j]);
                            if (old != null)
                            {
                                Undo.DestroyObjectImmediate(old);
                                break;
                            }
                        }
                    }
                    GUIUtility.ExitGUI();
                }
            }

            void RefreshLists()
            {
                if (sAllTypes == null)
                {
                    // Populate the master list
                    List<Type> types = new List<Type>();
                    List<string> names = new List<string>();
                    types.Add(null);
                    names.Add(string.Empty);
                    var allClasses
                        = ReflectionHelpers.GetTypesInAllDependentAssemblies(
                                (Type t) => t.GetCustomAttribute<CameraPipelineAttribute>() != null);
                    foreach (Type t in allClasses)
                    {
                        types.Add(t);
                        names.Add(NicifyClassName(t.Name));
                    }
                    sAllTypes = types.ToArray();
                    sAllNames = names.ToArray();
                }

                if (myTypes == null)
                {
                    List<Type> types = new List<Type>();
                    List<string> names = new List<string>();
                    types.Add(null);
                    names.Add(mEmptyLabel);
                    for (int i = 1; i < sAllTypes.Length; ++i)
                    {
                        var attr = sAllTypes[i].GetCustomAttribute<CameraPipelineAttribute>();
                        if (attr != null && attr.Stage == mStageFilter)
                        {
                            types.Add(sAllTypes[i]);
                            names.Add(sAllNames[i]);
                        }
                    }
                    myTypes = types.ToArray();
                    myNames = names.ToArray();
                }
            }

            List<MonoBehaviour> m_BehaviourList = new List<MonoBehaviour>(); // for recycling
            MonoBehaviour GetPipelineStageBehaviour(GameObject go)
            {
                go.GetComponents(m_BehaviourList);
                foreach (var behaviour in m_BehaviourList)
                {
                    if (behaviour == null || behaviour.GetType() == null) 
                        continue;
                    var attr = behaviour.GetType().GetCustomAttribute<CameraPipelineAttribute>();
                    if (attr != null && attr.Stage == mStageFilter) 
                        return behaviour;
                }
                return null;
            }

            int m_Current = 0;

            void RefreshCurrent()
            {
                m_Current = 0;
                var behaviour = GetPipelineStageBehaviour(m_Target);
                for (int j = 1; j < myTypes.Length && behaviour != null && m_Current == 0; ++j)
                {
                    if (behaviour.GetType() == myTypes[j])
                        m_Current = j;
                }
                if (IsHeterogeneous())
                    m_Current = myNames.Length; // dropdown will show blank
            }

            bool IsHeterogeneous()
            {
                foreach (var selectedGameObject in Selection.gameObjects)
                {
                    if (selectedGameObject.GetType() != m_Target.GetType() 
                            || selectedGameObject == m_Target) 
                        continue;

                    if (m_Current > 0)
                    {
                        if (selectedGameObject.GetComponent(myTypes[m_Current]) == null)
                            return true;
                    }
                    else
                    {
                        // Handle the "None" case
                        if (GetPipelineStageBehaviour(selectedGameObject) != null)
                            return true;
                    }
                }
                return false;
            }
        }

        public class ExtensionManagerDropdown
        {
            static Type[] sAllTypes;  // First entry is null
            static string[] sAllNames;

            Type[] myTypes;  // First entry is null
            string[] myNames;

            GameObject m_Target;
            GUIContent mLabel = GUIContent.none;
            string mEmptyLabel;

            public void Initialize(
                GUIContent label, string emptyLabel, GameObject target)
            {
                mLabel = label;
                mEmptyLabel = emptyLabel;
                m_Target = target;
                myTypes = null;
                myNames = null;
            }

            public void DrawDropdownWidgetInInspector()
            {
                RefreshLists();
                Rect rect = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
                rect = EditorGUI.PrefixLabel(rect, mLabel);

                int selection = EditorGUI.Popup(rect, 0, myNames);
                if (selection != 0)
                {
                    Type type = myTypes[selection];
                    foreach (var selectedGameobject in Selection.gameObjects)
                    {
                        if (selectedGameobject.GetType() != m_Target.GetType()) 
                            continue;
                        if (type != null && selectedGameobject.GetComponent(type) == null)
                            Undo.AddComponent(selectedGameobject, type);
                    }
                    
                }
            }

            void RefreshLists()
            {
                if (sAllTypes == null)
                {
                    // Populate the master list
                    List<Type> types = new List<Type>();
                    List<string> names = new List<string>();
                    types.Add(null);
                    names.Add(string.Empty);
                    var allClasses
                        = ReflectionHelpers.GetTypesInAllDependentAssemblies(
                                (Type t) => t.GetCustomAttribute<CameraExtensionAttribute>() != null);
                    foreach (Type t in allClasses)
                    {
                        types.Add(t);
                        names.Add(NicifyClassName(t.Name));
                    }
                    sAllTypes = types.ToArray();
                    sAllNames = names.ToArray();
                }

                if (myTypes == null)
                {
                    List<Type> types = new List<Type>();
                    List<string> names = new List<string>();
                    types.Add(null);
                    names.Add(mEmptyLabel);
                    for (int i = 1; i < sAllTypes.Length; ++i)
                    {
                        var attr = sAllTypes[i].GetCustomAttribute<CameraExtensionAttribute>();
                        if (attr != null)
                        {
                            types.Add(sAllTypes[i]);
                            names.Add(sAllNames[i]);
                        }
                    }
                    myTypes = types.ToArray();
                    myNames = names.ToArray();
                }
            }
        }

        static string NicifyClassName(string name)
        {
            if (name.StartsWith("Cm"))
                name = name.Substring(2); // Trim the prefix
            if (name.EndsWith("Authoring"))
                name = name.Substring(0, name.Length-9); // Trim the suffix
            return ObjectNames.NicifyVariableName(name);
        }
    }
}
