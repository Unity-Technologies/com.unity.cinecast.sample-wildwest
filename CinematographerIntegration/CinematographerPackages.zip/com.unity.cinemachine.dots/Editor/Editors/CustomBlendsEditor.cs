using UnityEngine;
using UnityEditor;
using UnityEditorInternal;
using System.Collections.Generic;
using Unity.Mathematics;
using Unity.Entities.Hybrid;
using Unity.Entities;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(CustomBlends))]
    internal sealed class CustomBlendsEditor : BaseEditor<CustomBlends>
    {
        private ReorderableList m_blendList;
        GUIContent m_FromLabel = new GUIContent("From");
        GUIContent m_ToLabel = new GUIContent("To");
        GUIContent m_BiLabel = new GUIContent("2-Way");
        GUIContent m_BlendLabel = new GUIContent("Blend");
        GUIContent m_AnyLabel = new GUIContent("Any");

        protected override void GetExcludedPropertiesInInspector(List<string> excluded)
        {
            base.GetExcludedPropertiesInInspector(excluded);
            excluded.Add(FieldPath(x => x.Blends));
        }

        public override void OnInspectorGUI()
        {
            BeginInspector();
            if (m_blendList == null)
                SetupBlendList();

            DrawRemainingPropertiesInInspector();

            m_blendList.DoLayoutList();
            serializedObject.ApplyModifiedProperties();
        }

        void SetupBlendList()
        {
            m_blendList = new ReorderableList(serializedObject,
                    serializedObject.FindProperty(() => Target.Blends),
                    true, true, true, true);

            // Needed for accessing string names of fields
            var def = new CustomBlends.Item();
            var checkboxWidth = EditorGUIUtility.singleLineHeight;

            m_blendList.drawHeaderCallback = (Rect r) =>
            {
                r.width = (r.width - EditorGUIUtility.singleLineHeight - checkboxWidth) / 3; 
                r.x += EditorGUIUtility.singleLineHeight;
                EditorGUI.LabelField(r, m_FromLabel);

                r.x += r.width;
                EditorGUI.LabelField(r, m_ToLabel);

                r.x += r.width; 
                EditorGUI.LabelField(r, m_BlendLabel);

                var biSize = GUI.skin.label.CalcSize(m_BiLabel).x;
                r.x += r.width + checkboxWidth - biSize; r.width = biSize;
                EditorGUI.LabelField(r, m_BiLabel);
            };

            m_blendList.elementHeightCallback = (int index) =>
            {
                SerializedProperty element = m_blendList.serializedProperty.GetArrayElementAtIndex(index);
                var h = EditorGUI.GetPropertyHeight(element.FindPropertyRelative(() => def.From));
                h = math.max(h, EditorGUI.GetPropertyHeight(element.FindPropertyRelative(() => def.To)));
                h = math.max(h, EditorGUI.GetPropertyHeight(element.FindPropertyRelative(() => def.Blend)));
                return h + 2 * EditorGUIUtility.standardVerticalSpacing;
            };

            m_blendList.drawElementCallback = (Rect rect, int index, bool isActive, bool isFocused) =>
            {
                var vSpace = EditorGUIUtility.standardVerticalSpacing;
                var oldLabelWidth = EditorGUIUtility.labelWidth;
                EditorGUIUtility.labelWidth = 1; // no labels

                SerializedProperty element = m_blendList.serializedProperty.GetArrayElementAtIndex(index);
                Rect r = rect; r.y += vSpace; 
                r.width = (r.width - checkboxWidth) / 3 - EditorGUIUtility.singleLineHeight;
                r.x += EditorGUIUtility.singleLineHeight;

                var p = element.FindPropertyRelative(() => def.From);
                r.height = EditorGUI.GetPropertyHeight(p);
                DrawNodeProperty(r, p);

                r.x += r.width + EditorGUIUtility.singleLineHeight;
                p = element.FindPropertyRelative(() => def.To);
                DrawNodeProperty(r, p);

                r.x += r.width + EditorGUIUtility.singleLineHeight;
                p = element.FindPropertyRelative(() => def.Blend);
                r.height = EditorGUI.GetPropertyHeight(p);
                EditorGUI.PropertyField(r, p);

                r.x += r.width;
                r.width = r.height = checkboxWidth;
                p = element.FindPropertyRelative(() => def.Bidirectional);
                EditorGUI.PropertyField(r, p);

                EditorGUIUtility.labelWidth = oldLabelWidth;
            };
        }

        void DrawNodeProperty(Rect rect, SerializedProperty p)
        {
            var def = new StableReferenceBase();
            StableKey key = StableKey.Default;
            var guidProp = p.FindPropertyRelative(() => def.Referent).FindPropertyRelative(
                () => key.Value).FindPropertyRelative(() => key.Value.Value);
            var guid = guidProp.GetUint4Value();
            key.Value = new Entities.Hash128(guid.x, guid.y, guid.z, guid.w);
            if (key.IsValid)
                EditorGUI.PropertyField(rect, p);
            else
            {
                p.isExpanded = false;
                var r = rect;
                r.x += EditorGUIUtility.labelWidth; r.width -= EditorGUIUtility.labelWidth;
                r.height = math.min(r.height, EditorGUIUtility.singleLineHeight);
                EditorGUI.LabelField(
                    new Rect(r.x + EditorGUIUtility.singleLineHeight, r.y, 
                     GUI.skin.button.CalcSize(m_AnyLabel).x, r.height), m_AnyLabel);
                r.x += r.width - EditorGUIUtility.singleLineHeight;
                r.width = EditorGUIUtility.singleLineHeight;
                var nowObj = EditorGUI.ObjectField(
                    r, null, typeof(CmNodeBindingKey), true) as CmNodeBindingKey;
                if (nowObj != null)
                    guidProp.SetUint4Value(nowObj.StableKey.Value.Value);
            }
        }
    }
}
