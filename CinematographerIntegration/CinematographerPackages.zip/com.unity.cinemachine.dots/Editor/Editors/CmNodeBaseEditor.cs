using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using Unity.Entities;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Editor
{
    /// <summary>
    /// Base class for CmNode editors.
    /// Handles drawing the header and the basic properties.
    /// </summary>
    [CustomEditor(typeof(CmNodeAuthoringBase), false)]
    [CanEditMultipleObjects]
    public class CmNodeBaseEditor<T> : BaseEditor<T>  where T : CmNodeAuthoringBase
    {
        GUIContent m_SoloButton;
        GUIContent m_UseDefault;

        protected StableKey TopLevelChannel { get; private set; }
        protected bool IsPrefab { get; private set; }

        protected virtual void OnEnable()
        {
            m_SoloButton = new GUIContent("Solo", "Make this camera become live for preview");
            m_UseDefault = new GUIContent("Using default", "This node will output to "
                + "the default top-level channel, or to its immediate channel parent.  "
                + "To change it, click on the object selector icon to the right.");

            TopLevelChannel = Target.Node.FindTopLevelChannel();
            IsPrefab = Target?.gameObject.scene.name == null;
        }

        protected virtual void OnDisable()
        {
            var ch = new ChannelHelper(TopLevelChannel, DefaultWorld);
            if (Target != null && ch.SoloCamera == Target.Node)
            {
                ch.SoloCamera = new CmNode(Entity.Null, null);
                // GML is this the right thing to do?
                InspectorUtility.RepaintGameView();
            }
        }

        protected override void GetExcludedPropertiesInInspector(List<string> excluded)
        {
            base.GetExcludedPropertiesInInspector(excluded);
            excluded.Add(FieldPath(x => x.OutputChannel));
            excluded.Add("m_Deactivated");
        }

        public override void OnInspectorGUI()
        {
            BeginInspector();
            DrawHeaderInInspector();
            DrawOutputChannelPropertyInInspector();
            DrawRemainingPropertiesInInspector();
        }

        protected void DrawHeaderInInspector()
        {
            if (!IsPropertyExcluded("Header"))
            {
                DrawGlobalControlsInInspector();
                DrawCameraStatusInInspector();
            }
            ExcludeProperty("Header");
        }

        protected void DrawOutputChannelPropertyInInspector()
        {
            Rect rect = EditorGUILayout.GetControlRect(true);
            var property = FindProperty(x => x.OutputChannel);

            EditorGUI.PropertyField(rect, property);

            // Show a friendly note if not set
            var key = StableKey.Default;
            var editedObject = property.GetValueAsObject<Entities.Hybrid.StableReferenceBase>();
            var GUIDProp = property.FindPropertyRelative(() => editedObject.Referent)
                .FindPropertyRelative(() => key.Value)
                    .FindPropertyRelative(() => key.Value.Value);
            key.Value.Value = GUIDProp.GetUint4Value();
            if (!key.IsValid)
            {
                rect.x += EditorGUIUtility.labelWidth;
                rect.width -= EditorGUIUtility.labelWidth + rect.height;

                EditorGUI.DrawRect(rect, InspectorUtility.DefaultBackgroundColor);
                var style = new GUIStyle(GUI.skin.label);
                style.fontStyle = FontStyle.Italic;
                EditorGUI.LabelField(rect, m_UseDefault, style);
            }
        }

        protected void DrawCameraStatusInInspector()
        {
            // Is the camera navel-gazing?
            CameraState state = Target.State;
            if (state.HasLookAt && (state.ReferenceLookAt - state.CorrectedPosition).AlmostZero())
                EditorGUILayout.HelpBox(
                    "The camera is positioned on the same point at which it is trying to look.",
                    MessageType.Warning);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Node", EditorStyles.boldLabel);
            if (!IsPrefab)
            {
                // Active status and Solo button
                Rect rect = EditorGUILayout.GetControlRect(true);
                Rect rectLabel = new Rect(rect.x, rect.y, EditorGUIUtility.labelWidth, rect.height);
                rect.width -= rectLabel.width;
                rect.x += rectLabel.width;

                var ch = new ChannelHelper(TopLevelChannel, DefaultWorld);
                Color color = GUI.color;
                var isSolo = ch.SoloCamera == Target.Node && !Target.Node.IsNull;
                if (isSolo)
                    GUI.color = CmChannelAuthoring.GetSoloGUIColor();

                bool isLive = Target.IsLive;
                GUI.enabled = isLive;
                GUI.Label(rectLabel, isLive ? "Status: Live"
                    : (Target.isActiveAndEnabled ? "Status: Standby" : "Status: Disabled"));
                GUI.enabled = true;

                //rect.width = Mathf.Max(GUI.skin.button.CalcSize(m_SoloButton).x, rect.width / 3);
                if (GUI.Button(rect, m_SoloButton))
                {
                    isSolo = !isSolo;
                    ch.SoloCamera = isSolo ? Target.Node : new CmNode(Entity.Null, null);
                    InspectorUtility.RepaintGameView();
                }
                GUI.color = color;

                if (isSolo && !Application.isPlaying)
                    InspectorUtility.RepaintGameView();
            }
        }

        static List<EntityBehaviourAuthoringBase> s_nodeComponentsBuffer;
        static readonly string kGizmoFileName = ScriptableObjectHelper.kPackageRoot + "/Gizmos/cm_logo.png";
        protected static void DrawStandardCameraGizmos(T node, GizmoType drawType)
        {
            var color = node.IsLive
                ? Settings.CoreSettings.ActiveGizmoColour
                : Settings.CoreSettings.InactiveGizmoColour;
            var state = node.State;
            CmChannelEditor.DrawCameraFrustumGizmo(state, color);
            Gizmos.DrawIcon(state.FinalPosition, kGizmoFileName, true);

            if (s_nodeComponentsBuffer == null)
                s_nodeComponentsBuffer = new List<EntityBehaviourAuthoringBase>();
            s_nodeComponentsBuffer.Clear();
            node.GetComponents(s_nodeComponentsBuffer);
            for (int i = 0; i < s_nodeComponentsBuffer.Count; ++i)
            {
                var drawer = s_nodeComponentsBuffer[i] as CmNodeDebugGizmoDrawer;
                if (drawer != null)
                    drawer.DrawDebugGizmosForNode();
            }
        }

/* GML todo: proper channel selection UX

        List<Entity> channelEntities = new List<Entity>();
        List<string> channelNames = new List<string>();
        List<StableKey> channelGuids = new List<StableKey>();
        void UpdateChannelEntities()
        {
            channelNames.Clear();
            channelGuids.Clear();
            channelNames.Add("Default"); channelGuids.Add(CmChannel.DefaultId);

            channelEntities.Clear();
            var chanelSystem = World?.GetOrCreateSystem<CmChannelSystem>();
            if (chanelSystem != null)
                chanelSystem.GetAllChannels(channelEntities);

            var targetChannel = new ChannelHelper(Target.CmNode.Entity);
            for (int i = 0; i < channelEntities.Count; ++i)
            {
                ChannelHelper c = new ChannelHelper(channelEntities[i]);
                var id = c.Channel(World).Id;
                if (id == CmChannel.DefaultId || !c.IsChannel(World) || targetChannel.IsOwnedChannel(id, World))
                    continue;
                channelNames.Add(c.Name(World));
                channelGuids.Add(id);
            }
        }
*/

        protected void DrawGlobalControlsInInspector()
        {
/*
            SaveDuringPlay.SaveDuringPlay.Enabled
                = EditorGUILayout.Toggle(
                    new GUIContent(
                        "Save During Play",
                        "If checked, CmNode settings changes made during Play Mode will "
                            + "be propagated back to the scene when Play Mode is exited."),
                    SaveDuringPlay.SaveDuringPlay.Enabled);

            if (Application.isPlaying && SaveDuringPlay.SaveDuringPlay.Enabled)
                EditorGUILayout.HelpBox(
                    " CmNode settings changes made during Play Mode will be propagated back to the scene when Play Mode is exited.",
                    MessageType.Info);
*/
        }
    }
}
