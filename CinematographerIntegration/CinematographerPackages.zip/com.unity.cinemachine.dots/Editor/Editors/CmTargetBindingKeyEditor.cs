using UnityEditor;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CustomEditor(typeof(CmTargetBindingKey))]
    internal class CmTargetBindingKeyEditor : BaseEditor<CmTargetBindingKey> {}
}
