using UnityEditor;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CustomEditor(typeof(CmNodeBindingKey))]
    internal class CmNodeBindingKeyEditor : BaseEditor<CmNodeBindingKey> {}
}
