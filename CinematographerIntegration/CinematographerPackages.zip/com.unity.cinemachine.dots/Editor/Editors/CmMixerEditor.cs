using System.Collections.Generic;
using Unity.Mathematics;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CustomEditor(typeof(CmMixerAuthoring))]
    [CanEditMultipleObjects]
    internal class CmMixerEditor : CmNodeBaseEditor<CmMixerAuthoring>
    {
        private ReorderableList m_List;

        protected override void GetExcludedPropertiesInInspector(List<string> excluded)
        {
            base.GetExcludedPropertiesInInspector(excluded);
            excluded.Add(FieldPath(x => x.m_InputNodes));
        }

        protected override void OnEnable()
        {
            base.OnEnable();
            m_List = null;
        }

        public override void OnInspectorGUI()
        {
            BeginInspector();
            DrawHeaderInInspector();
            DrawRemainingPropertiesInInspector();

            if (m_List == null)
                SetupTargetList();
            EditorGUI.BeginChangeCheck();
            m_List.DoLayoutList();
            if (EditorGUI.EndChangeCheck())
                serializedObject.ApplyModifiedProperties();

            DrawProportionIndicator();
        }

        void SetupTargetList()
        {
            float vSpace = EditorGUIUtility.standardVerticalSpacing;
            float floatFieldWidth = EditorGUIUtility.singleLineHeight * 3.5f;
            float hBigSpace = EditorGUIUtility.singleLineHeight * 2 / 3;

            m_List = new ReorderableList(
                    serializedObject, FindProperty(x => x.m_InputNodes),
                    true, true, true, true);

            // Needed for accessing field names as strings
            var def = new CmMixerAuthoring.InputNode();

            m_List.drawHeaderCallback = (Rect rect) =>
            {
                rect.width -= EditorGUIUtility.singleLineHeight + floatFieldWidth + hBigSpace;
                rect.x += EditorGUIUtility.singleLineHeight;
                EditorGUI.LabelField(rect, "Node");

                rect.x += rect.width + hBigSpace; rect.width = floatFieldWidth;
                EditorGUI.LabelField(rect, "Weight");
            };

            m_List.elementHeightCallback = (int index) =>
            {
                SerializedProperty element = m_List.serializedProperty.GetArrayElementAtIndex(index);
                var h = EditorGUI.GetPropertyHeight(element.FindPropertyRelative(() => def.Weight));
                h = math.max(h, EditorGUI.GetPropertyHeight(element.FindPropertyRelative(() => def.Node)));
                return h + 2 * EditorGUIUtility.standardVerticalSpacing;
            };

            m_List.drawElementCallback = (Rect rect, int index, bool isActive, bool isFocused) =>
            {
                SerializedProperty elemProp = m_List.serializedProperty.GetArrayElementAtIndex(index);

                var pushWidth = new InspectorUtility.LabelWidthOverride(1);
                rect.y += vSpace;
                rect.height = EditorGUIUtility.singleLineHeight;
                rect.width = ((rect.width - floatFieldWidth - hBigSpace));
                EditorGUI.PropertyField(
                    rect, elemProp.FindPropertyRelative(() => def.Node), GUIContent.none);

                EditorGUIUtility.labelWidth = hBigSpace;
                rect.x += rect.width; rect.width = floatFieldWidth + hBigSpace;
                EditorGUI.PropertyField(
                    rect, elemProp.FindPropertyRelative(() => def.Weight), new GUIContent(" "));
            };
        }

        void DrawProportionIndicator()
        {
            var list = Target.m_InputNodes;

            // Compute the weight sum
            var count = list.Count;
            float sum = 0;
            for (int i = 0; i < count; ++i)
            {
                var w = math.max(0, list[i].Weight);
                sum += w;
            }

            GUIStyle style = EditorStyles.centeredGreyMiniLabel;
            Color bkg = new Color(0.27f, 0.27f, 0.27f); // ack! no better way than this?
            Color fg = Color.Lerp(CmChannelAuthoring.GetSoloGUIColor(), bkg, 0.8f);
            float totalHeight = (style.lineHeight + style.margin.vertical) * count;
            Rect r = EditorGUILayout.GetControlRect(true, totalHeight);
            r.height /= count; r.height -= 1;
            float fullWidth = r.width;
            for (int i = 0; i < count; ++i)
            {
                string label = list[i].Node.IsValid ? list[i].Node.GameObject.name : "(none)";
                float p = sum > MathHelpers.Epsilon ? list[i].Weight / sum : 0;
                r.width = fullWidth * p;
                EditorGUI.DrawRect(r, fg);

                Rect r2 = r;
                r2.x += r.width;
                r2.width = fullWidth - r.width;
                EditorGUI.DrawRect(r2, bkg);

                r.width = fullWidth;
                EditorGUI.LabelField(r, label, style);

                r.y += r.height + 1;
            }
        }
    }
}
