using UnityEditor;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CustomEditor(typeof(CmChannelBindingKey))]
    internal class CmChannelBindingKeyEditor : BaseEditor<CmChannelBindingKey> {}
}
