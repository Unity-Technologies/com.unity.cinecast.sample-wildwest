using System.Collections.Generic;
using Unity.Mathematics;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CustomEditor(typeof(CmSequencerAuthoring))]
    [CanEditMultipleObjects]
    internal class CmSequencerEditor : CmNodeBaseEditor<CmSequencerAuthoring>
    {
        private ReorderableList m_TargetList;

        protected override void GetExcludedPropertiesInInspector(List<string> excluded)
        {
            base.GetExcludedPropertiesInInspector(excluded);
            excluded.Add(FieldPath(x => x.Channel));
            excluded.Add(FieldPath(x => x.Instructions));
        }

        protected override void OnEnable()
        {
            base.OnEnable();
            m_TargetList = null;
        }

        public override void OnInspectorGUI()
        {
            BeginInspector();
            DrawHeaderInInspector();
            DrawRemainingPropertiesInInspector();

            EditorGUILayout.LabelField("Instructions");
            if (m_TargetList == null)
                SetupTargetList();
            EditorGUI.BeginChangeCheck();
            m_TargetList.DoLayoutList();
            if (EditorGUI.EndChangeCheck())
                serializedObject.ApplyModifiedProperties();
        }

        void SetupTargetList()
        {
            float vSpace = EditorGUIUtility.standardVerticalSpacing;
            float floatFieldWidth = EditorGUIUtility.singleLineHeight * 3.5f;
            float hBigSpace = EditorGUIUtility.singleLineHeight * 2 / 3;

            m_TargetList = new ReorderableList(
                    serializedObject, FindProperty(x => x.Instructions),
                    true, true, true, true);

            // Needed for accessing field names as strings
            var def = new CmSequencerAuthoring.Instruction();

            m_TargetList.drawHeaderCallback = (Rect rect) =>
            {
                rect.width -= EditorGUIUtility.singleLineHeight + floatFieldWidth + hBigSpace;
                rect.width *= 0.5f;
                rect.x += EditorGUIUtility.singleLineHeight;
                EditorGUI.LabelField(rect, "Blend");

                rect.x += rect.width;
                EditorGUI.LabelField(rect, "Node");

                rect.x += rect.width + hBigSpace; rect.width = floatFieldWidth;
                EditorGUI.LabelField(rect, "Hold");
            };

            m_TargetList.elementHeightCallback = (int index) =>
            {
                SerializedProperty element = m_TargetList.serializedProperty.GetArrayElementAtIndex(index);
                var h = EditorGUI.GetPropertyHeight(element.FindPropertyRelative(() => def.Blend));
                h = math.max(h, EditorGUI.GetPropertyHeight(element.FindPropertyRelative(() => def.Node)));
                return h + 2 * EditorGUIUtility.standardVerticalSpacing;
            };

            m_TargetList.drawElementCallback = (Rect rect, int index, bool isActive, bool isFocused) =>
            {
                bool repeating = Target.RepeatMode != CmSequencer.RepeatMode.None;
                SerializedProperty elemProp = m_TargetList.serializedProperty.GetArrayElementAtIndex(index);
                const float hSpace = 2;

                var pushWidth = new InspectorUtility.LabelWidthOverride(1);
                rect.y += vSpace;
                rect.height = EditorGUIUtility.singleLineHeight;
                rect.width = ((rect.width - floatFieldWidth - hBigSpace) * 0.5f) - hSpace;
                if (repeating || index != 0)
                    EditorGUI.PropertyField(
                        rect, elemProp.FindPropertyRelative(() => def.Blend), GUIContent.none);

                rect.width += hSpace;
                rect.x += rect.width + hSpace; 
                EditorGUI.PropertyField(
                    rect, elemProp.FindPropertyRelative(() => def.Node), GUIContent.none);

                EditorGUIUtility.labelWidth = hBigSpace;
                rect.x += rect.width; rect.width = floatFieldWidth + hBigSpace;
                if (repeating || index != Target.Instructions.Count-1)
                    EditorGUI.PropertyField(
                        rect, elemProp.FindPropertyRelative(() => def.Hold), new GUIContent(" "));
            };
        }
    }
}
