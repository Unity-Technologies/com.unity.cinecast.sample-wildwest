using UnityEditor;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CustomEditor(typeof(CmListener))]
    [CanEditMultipleObjects]
    internal class CmListenerEditor : BaseEditor<CmListener> {}
}
