using UnityEditor;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CustomEditor(typeof(CmClearShotAuthoring))]
    [CanEditMultipleObjects]
    internal class CmClearShotEditor : CmNodeBaseEditor<CmClearShotAuthoring>
    {
    }
}
