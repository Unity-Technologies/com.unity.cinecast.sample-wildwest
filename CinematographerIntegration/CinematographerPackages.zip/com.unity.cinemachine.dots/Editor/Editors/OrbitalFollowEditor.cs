using UnityEngine;
using UnityEditor;
using Unity.Mathematics;
using Unity.Entities;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(OrbitalFollowAuthoring))]
    internal class OrbitalFollowEditor : BaseEditor<OrbitalFollowAuthoring>
    {
        [DrawGizmo(GizmoType.Active | GizmoType.NotInSelectionHierarchy
            | GizmoType.InSelectionHierarchy | GizmoType.Pickable, typeof(OrbitalFollowAuthoring))]
        static void DrawGizmos(OrbitalFollowAuthoring orbitalProxy, GizmoType selectionType)
        {
            var w = orbitalProxy.SynchronizedWorld;
            var e = orbitalProxy.SynchronizedEntity;
            if (w == null || e == Entity.Null
                    || !w.EntityManager.HasComponent<OrbitalFollowState>(e) || !orbitalProxy.enabled)
                return;

            var state = w.EntityManager.GetComponentData<OrbitalFollowState>(e);
            var orbital = w.EntityManager.GetComponentData<OrbitalFollow>(e);
            var inputBuffer = w.EntityManager.GetBuffer<InputAxisXYZ>(e);
            var input = inputBuffer[state.InputAxisIndex];
            float scale = input.Z.Value.GetClampedValue();
            var pos = state.PreviousTargetPosition;
            var orient = math.normalizesafe(state.PreviousTargetRotation, quaternion.identity);
            var up = math.mul(orient, math.up());

            Color originalGizmoColour = Gizmos.color;
            Gizmos.color = CmNode.FromEntity(e, w).IsLive()
                ? Settings.CoreSettings.ActiveGizmoColour
                : Settings.CoreSettings.InactiveGizmoColour;

            DrawCircleAtPointWithRadius(
                pos + up * orbital.Top.Height * scale,
                orient, orbital.Top.Radius * scale);
            DrawCircleAtPointWithRadius(
                pos + up * orbital.Middle.Height * scale,
                orient, orbital.Middle.Radius * scale);
            DrawCircleAtPointWithRadius(
                pos + up * orbital.Bottom.Height * scale,
                orient, orbital.Bottom.Radius * scale);

            DrawCameraPath(pos, orient, scale, ref orbital);

            Gizmos.color = originalGizmoColour;
        }

        static void DrawCircleAtPointWithRadius(float3 point, quaternion orient, float radius)
        {
            Matrix4x4 prevMatrix = Gizmos.matrix;
            Gizmos.matrix = Matrix4x4.TRS(point, orient, radius * Vector3.one);

            const int kNumPoints = 25;
            Vector3 currPoint = Vector3.forward;
            Quaternion rot = Quaternion.AngleAxis(360f / (float)kNumPoints, Vector3.up);
            for (int i = 0; i < kNumPoints + 1; ++i)
            {
                Vector3 nextPoint = rot * currPoint;
                Gizmos.DrawLine(currPoint, nextPoint);
                currPoint = nextPoint;
            }
            Gizmos.matrix = prevMatrix;
        }

        static void DrawCameraPath(
            float3 atPos, quaternion orient, float scale, ref OrbitalFollow state)
        {
            Matrix4x4 prevMatrix = Gizmos.matrix;
            Gizmos.matrix = Matrix4x4.TRS(atPos, orient, Vector3.one * scale);

            const int kNumSteps = 20;
            Vector3 currPos = state.SplineValueAt(-1f);
            for (int i = 1; i < kNumSteps + 1; ++i)
            {
                float t = ((float)i * 2 / (float)kNumSteps) - 1;
                Vector3 nextPos = state.SplineValueAt(t);
                Gizmos.DrawLine(currPos, nextPos);
                currPos = nextPos;
            }
            Gizmos.matrix = prevMatrix;
        }
    }
}
