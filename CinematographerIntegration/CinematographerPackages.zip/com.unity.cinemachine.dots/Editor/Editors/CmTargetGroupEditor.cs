using UnityEngine;
using UnityEditor;
using UnityEditorInternal;
using System.Collections.Generic;
using Unity.Mathematics;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CustomEditor(typeof(CmTargetGroupAuthoring))]
    [CanEditMultipleObjects]
    internal sealed class CmTargetGroupEditor : BaseEditor<CmTargetGroupAuthoring>
    {
        private ReorderableList m_TargetList;

        protected override void GetExcludedPropertiesInInspector(List<string> excluded)
        {
            base.GetExcludedPropertiesInInspector(excluded);
            excluded.Add(FieldPath(x => x.m_Targets));
        }

        void OnEnable()
        {
            m_TargetList = null;
        }

        public override void OnInspectorGUI()
        {
            BeginInspector();
            DrawRemainingPropertiesInInspector();

            if (m_TargetList == null)
                SetupTargetList();
            EditorGUI.BeginChangeCheck();
            m_TargetList.DoLayoutList();
            if (EditorGUI.EndChangeCheck())
                serializedObject.ApplyModifiedProperties();
        }

        void SetupTargetList()
        {
            float vSpace = EditorGUIUtility.standardVerticalSpacing;
            float floatFieldWidth = EditorGUIUtility.singleLineHeight * 3.5f;
            float hBigSpace = EditorGUIUtility.singleLineHeight * 2 / 3;

            m_TargetList = new ReorderableList(
                    serializedObject, FindProperty(x => x.m_Targets),
                    true, true, true, true);

            // Needed for accessing field names as strings
            CmTargetGroupAuthoring.Target def = new CmTargetGroupAuthoring.Target();

            m_TargetList.drawHeaderCallback = (Rect rect) =>
            {
                rect.width -= EditorGUIUtility.singleLineHeight + floatFieldWidth + hBigSpace;
                rect.x += EditorGUIUtility.singleLineHeight;
                EditorGUI.LabelField(rect, "Target");

                rect.x += rect.width + hBigSpace; rect.width = floatFieldWidth + hBigSpace;
                EditorGUI.LabelField(rect, "Weight");
            };

            m_TargetList.elementHeightCallback = (int index) =>
            {
                SerializedProperty element = m_TargetList.serializedProperty.GetArrayElementAtIndex(index);
                var h = EditorGUI.GetPropertyHeight(element.FindPropertyRelative(() => def.TargetObject));
                h = math.max(h, EditorGUI.GetPropertyHeight(element.FindPropertyRelative(() => def.Weight)));
                return h + 2 * EditorGUIUtility.standardVerticalSpacing;
            };

            m_TargetList.drawElementCallback = (Rect rect, int index, bool isActive, bool isFocused) =>
            {
                SerializedProperty elemProp = m_TargetList.serializedProperty.GetArrayElementAtIndex(index);

                var pushWidth = new InspectorUtility.LabelWidthOverride(1);
                rect.y += vSpace;
                rect.height = EditorGUIUtility.singleLineHeight;
                rect.width -= floatFieldWidth + hBigSpace;
                EditorGUI.PropertyField(
                    rect, elemProp.FindPropertyRelative(() => def.TargetObject), GUIContent.none);

                EditorGUIUtility.labelWidth = hBigSpace;
                rect.x += rect.width; rect.width = floatFieldWidth + hBigSpace;
                EditorGUI.PropertyField(
                    rect, elemProp.FindPropertyRelative(() => def.Weight), new GUIContent(" "));
            };

            m_TargetList.onAddCallback = (ReorderableList l) =>
            {
                var index = l.serializedProperty.arraySize;
                ++l.serializedProperty.arraySize;
                SerializedProperty elemProp = m_TargetList.serializedProperty.GetArrayElementAtIndex(index);
                elemProp.FindPropertyRelative(() => def.Weight).floatValue = 1;
            };
        }
    }
}
