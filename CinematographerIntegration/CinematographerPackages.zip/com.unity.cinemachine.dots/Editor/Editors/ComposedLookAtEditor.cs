using UnityEngine;
using UnityEditor;
using static Unity.Cinemachine.Core.MathHelpers;
using Unity.Mathematics;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(ComposedLookAtAuthoring))]
    internal class ComposedLookAtEditor : BaseEditor<ComposedLookAtAuthoring>
    {
        ScreenComposerGuides mScreenGuideEditor;
        GameViewEventCatcher mGameViewEventCatcher;

        protected virtual void OnEnable()
        {
            mScreenGuideEditor = new ScreenComposerGuides();
            mScreenGuideEditor.GetHardGuide = () => { return ToRect(Target.ComposerZones.GetHardGuideRect()); };
            mScreenGuideEditor.GetSoftGuide = () => { return ToRect(Target.ComposerZones.GetSoftGuideRect()); };
            mScreenGuideEditor.SetHardGuide = (Rect r) => { Target.ComposerZones.SetHardGuideRect(FromRect(r)); };
            mScreenGuideEditor.SetSoftGuide = (Rect r) => { Target.ComposerZones.SetSoftGuideRect(FromRect(r)); };
            mScreenGuideEditor.Target = () => { return serializedObject; };

            mGameViewEventCatcher = new GameViewEventCatcher();
            mGameViewEventCatcher.OnEnable();

            DebugHelpers.OnGUIHandlers -= OnGUI;
            DebugHelpers.OnGUIHandlers += OnGUI;
            InspectorUtility.RepaintGameView();
        }

        static Rect ToRect(rect2d r) { return new Rect(r.Min + new float2(0.5f, 0.5f), r.Size); }
        static rect2d FromRect(Rect r) { return new rect2d { Center = r.position - new Vector2(0.5f, 0.5f) + r.size * 0.5f, HalfSize = r.size * 0.5f }; }

        protected virtual void OnDisable()
        {
            mGameViewEventCatcher.OnDisable();
            DebugHelpers.OnGUIHandlers -= OnGUI;
            InspectorUtility.RepaintGameView();
        }

        public override void OnInspectorGUI()
        {
            BeginInspector();
#if false
            // GML this not working - LookAtTarget is created at runtime
            if (Target.SafeGetComponentData<LookAtTarget>().target == Entity.Null)
                EditorGUILayout.HelpBox(
                    "A LookAt target is required.  Behaviour will be undefined.  Remove this component you don't want a LookAt target.",
                    MessageType.Error);
#endif
            // First snapshot some settings
            Rect oldHard = ToRect(Target.ComposerZones.GetHardGuideRect());
            Rect oldSoft = ToRect(Target.ComposerZones.GetSoftGuideRect());

            // Draw the properties
            DrawRemainingPropertiesInInspector();
            mScreenGuideEditor.SetNewBounds(
                oldHard, oldSoft,
                ToRect(Target.ComposerZones.GetHardGuideRect()),
                ToRect(Target.ComposerZones.GetSoftGuideRect()));
        }

        // Oh gawd there has to be a nicer way to do this!
        Texture2D targetMarkerTex = null;
        Texture2D GetTargetMarkerTex()
        {
            if (targetMarkerTex == null)
            {
                const int size = 128;
                const float th = 1f;
                Color[] pix = new Color[size * size];
                Color c = Settings.ComposerSettings.TargetColour;
                float radius = size / 2 - th;
                Vector2 center = new Vector2(size-1, size-1) / 2;
                for (int y = 0; y < size; ++y)
                {
                    for (int x = 0; x < size; ++x)
                    {
                        float d = Vector2.Distance(new Vector2(x, y), center);
                        d = Mathf.Abs((d - radius) / th);
                        var a = Mathf.Clamp01(1 - d);
                        pix[y * size + x] = new Color(1, 1, 1, a);
                    }
                }
                targetMarkerTex = new Texture2D(size, size);
                targetMarkerTex.SetPixels(pix);
                targetMarkerTex.Apply();
            }
            return targetMarkerTex;
        }

        protected virtual void OnGUI()
        {
            if (Target == null || !Target.enabled || !Settings.CoreSettings.ShowInGameGuides)
                return;

            // Draw the camera guides
            var node = CmNode.FromEntity(Target.SynchronizedEntity, Target.SynchronizedWorld);
            var TopLevelChannel = node.FindTopLevelChannel();
            var listener = CmListener.FindListener(TopLevelChannel);
            var camera = listener == null ? null : listener.OutputCamera;
            if (camera == null)
                return;

            var state = node.GetState();
            bool isLive = node.IsLive();
            mScreenGuideEditor.OnGUI_DrawGuides(isLive, camera, state.Lens, true);

            // Draw an on-screen gizmo for the target
            if (state.HasLookAt && isLive)
            {
                var lookAt = DefaultWorld.SafeGetComponentData<ComposedLookAtState>(
                    node.Entity).Predictor.PredictedPosition;
                Vector3 c = camera.WorldToScreenPoint(lookAt);
                if (c.z > 0)
                {
                    float lookAtRadius = state.ReferenceLookAtRadius;
                    c.y = Screen.height - c.y;
                    var p2 = lookAt + math.mul(state.FinalOrientation, new float3(lookAtRadius, 0, 0));
                    p2 = camera.WorldToScreenPoint(p2);
                    float radius = Mathf.Abs(p2.x - c.x);
                    Rect r = new Rect(c, Vector3.zero);
                    float minSize = ScreenComposerGuides.kGuideBarWidthPx;

                    var oldColor = GUI.color;
                    GUI.color = Color.black;
                    GUI.DrawTexture(InspectorUtility.InflateRect(r, new Vector2(minSize, minSize)),
                        Texture2D.whiteTexture, ScaleMode.StretchToFill);
                    var color = Settings.ComposerSettings.TargetColour;
                    GUI.color = color;
                    GUI.DrawTexture(InspectorUtility.InflateRect(r, new Vector2(minSize * 0.66f, minSize * 0.66f)),
                        Texture2D.whiteTexture, ScaleMode.StretchToFill);
                    if (radius > minSize)
                    {
                        color.a = Mathf.Lerp(1f, Settings.ComposerSettings.OverlayOpacity, (radius - 10f) / 50f);
                        GUI.color = color;
                        GUI.DrawTexture(InspectorUtility.InflateRect(r, new Vector2(radius, radius)),
                            GetTargetMarkerTex(), ScaleMode.StretchToFill);
                    }
                    GUI.color = oldColor;
                }
            }
        }
    }
}
