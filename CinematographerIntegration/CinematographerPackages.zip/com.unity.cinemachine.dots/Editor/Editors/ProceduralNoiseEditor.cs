using System.Collections.Generic;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(ProceduralNoiseAuthoring))]
    internal class GeneratedWaveEditor : BaseEditor<ProceduralNoiseAuthoring>
    {
        private ReorderableList m_List;

        protected override void GetExcludedPropertiesInInspector(List<string> excluded)
        {
            base.GetExcludedPropertiesInInspector(excluded);
            excluded.Add(FieldPath(x => x.SignalDefinition));
        }

        void OnEnable()
        {
            m_List = null;
        }

        public override void OnInspectorGUI()
        {
            BeginInspector();
            DrawRemainingPropertiesInInspector();

            if (m_List == null)
                SetupList();
            EditorGUI.BeginChangeCheck();
            m_List.DoLayoutList();
            if (EditorGUI.EndChangeCheck())
                serializedObject.ApplyModifiedProperties();
        }

        void SetupList()
        {
            float vSpace = EditorGUIUtility.standardVerticalSpacing;
            float floatFieldWidth = EditorGUIUtility.singleLineHeight * 3.5f;
            float hBigSpace = EditorGUIUtility.singleLineHeight * 2 / 3;

            m_List = new ReorderableList(
                    serializedObject, FindProperty(x => x.SignalDefinition),
                    true, true, true, true);

            // Needed for accessing field names as strings
            ProceduralNoiseAuthoring.Channel def = new ProceduralNoiseAuthoring.Channel();

            m_List.drawHeaderCallback = (Rect rect) =>
            {
                EditorGUI.LabelField(rect, m_List.serializedProperty.displayName);
            };

            m_List.elementHeightCallback = (int index) =>
            {
                return 3 * (EditorGUIUtility.singleLineHeight + EditorGUIUtility.standardVerticalSpacing);
            };

            m_List.drawElementCallback = (Rect rect, int index, bool isActive, bool isFocused) =>
            {
                SerializedProperty elemProp = m_List.serializedProperty.GetArrayElementAtIndex(index);
                rect.height = EditorGUIUtility.singleLineHeight;
                EditorGUI.PropertyField(rect, elemProp.FindPropertyRelative(() => def.NoiseProfile));
                rect.y += EditorGUIUtility.singleLineHeight + EditorGUIUtility.standardVerticalSpacing;
                EditorGUI.PropertyField(rect, elemProp.FindPropertyRelative(() => def.AmplitudeGain));
                rect.y += EditorGUIUtility.singleLineHeight + EditorGUIUtility.standardVerticalSpacing;
                EditorGUI.PropertyField(rect, elemProp.FindPropertyRelative(() => def.FrequencyGain));
            };
        }
     }
}
