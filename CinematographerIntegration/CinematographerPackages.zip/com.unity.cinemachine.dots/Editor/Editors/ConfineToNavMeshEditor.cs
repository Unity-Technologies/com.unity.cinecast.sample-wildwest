using UnityEditor;
using UnityEditor.AI;
using UnityEngine;
using UnityEngine.AI;
using Unity.Cinemachine.Hybrid;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Editor
{
    [CustomEditor(typeof(ConfineToNavMeshAuthoring))]
    [CanEditMultipleObjects]
    internal class ConfineToNavMeshEditor : BaseEditor<ConfineToNavMeshAuthoring>
    {
    }

    [CustomPropertyDrawer(typeof(NavMeshAreaPropertyAttribute))]
    internal sealed class NavMeshAreaPropertyDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect rect, SerializedProperty property, GUIContent label)
        {
            var areaIndex = -1;
            var areaNames = GameObjectUtility.GetNavMeshAreaNames();
            for (var i = 0; i < areaNames.Length; i++)
            {
                var areaValue = GameObjectUtility.GetNavMeshAreaFromName(areaNames[i]);
                if (areaValue == property.intValue)
                    areaIndex = i;
            }
            EditorGUI.BeginProperty(rect, label, property);
            {
                EditorGUI.BeginChangeCheck();
                areaIndex = EditorGUI.MaskField(rect, label.text, areaIndex, areaNames);
                if (EditorGUI.EndChangeCheck())
                    property.intValue = areaIndex;
            }
            EditorGUI.EndProperty();
        }
    }

    [CustomPropertyDrawer(typeof(NavMeshAgentTypePropertyAttribute))]
    internal sealed class NavMeshAgentTypePropertyDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect rect, SerializedProperty property, GUIContent label)
        {
            var index = -1;
            var count = NavMesh.GetSettingsCount();
            var agentTypeNames = new string[count + 2];
            for (var i = 0; i < count; i++)
            {
                var id = NavMesh.GetSettingsByIndex(i).agentTypeID;
                var name = NavMesh.GetSettingsNameFromID(id);
                agentTypeNames[i] = name;
                if (id == property.intValue)
                    index = i;
            }
            agentTypeNames[count] = "";
            agentTypeNames[count + 1] = "Open Agent Settings...";

            bool validAgentType = index != -1;
            if (!validAgentType)
                EditorGUILayout.HelpBox("Agent Type invalid.", MessageType.Warning);

            EditorGUI.BeginProperty(rect, label, property);
            {
                EditorGUI.BeginChangeCheck();
                index = EditorGUI.Popup(rect, label.text, index, agentTypeNames);
                if (EditorGUI.EndChangeCheck())
                {
                    if (index >= 0 && index < count)
                    {
                        var id = NavMesh.GetSettingsByIndex(index).agentTypeID;
                        property.intValue = id;
                    }
                    else if (index == count + 1)
                        NavMeshEditorHelpers.OpenAgentSettings(-1);
                }
            }
            EditorGUI.EndProperty();
        }
    }
}

