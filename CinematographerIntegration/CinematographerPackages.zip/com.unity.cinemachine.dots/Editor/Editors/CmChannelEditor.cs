using UnityEditor;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CustomEditor(typeof(CmChannelAuthoring))]
    [CanEditMultipleObjects]
    internal class CmChannelEditor : BaseEditor<CmChannelAuthoring>
    {
        internal static void DrawCameraFrustumGizmo(CameraState state, Color color)
        {
            var lens = state.Lens;
            Matrix4x4 originalMatrix = Gizmos.matrix;
            Color originalGizmoColour = Gizmos.color;
            Gizmos.color = color;
            Gizmos.matrix = Matrix4x4.TRS(state.FinalPosition, state.FinalOrientation, Vector3.one);
            if (lens.Orthographic)
            {
                Vector3 size = new Vector3(
                        lens.Aspect * lens.OrthographicSize * 2,
                        lens.OrthographicSize * 2,
                        lens.NearClipPlane + lens.FarClipPlane);
                Gizmos.DrawWireCube(
                    new Vector3(0, 0, (size.z / 2) + lens.NearClipPlane), size);
            }
            else
            {
                Gizmos.DrawFrustum(
                        Vector3.zero, lens.FieldOfView,
                        lens.FarClipPlane, lens.NearClipPlane, lens.Aspect);
            }
            Gizmos.matrix = originalMatrix;
            Gizmos.color = originalGizmoColour;
        }

        [DrawGizmo(GizmoType.Selected | GizmoType.NonSelected, typeof(CmChannelAuthoring))]
        private static void DrawChannelGizmos(CmChannelAuthoring channel, GizmoType drawType)
        {
            if (channel.ShowCameraFrustum)
                DrawCameraFrustumGizmo(channel.CameraState, Color.white); // GML why is this color hardcoded?
        }
    }
}
