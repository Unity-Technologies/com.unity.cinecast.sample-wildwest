using UnityEditor;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CustomEditor(typeof(CmPathBindingKey))]
    internal class CmPathBindingKeyEditor : BaseEditor<CmPathBindingKey> {}
}
