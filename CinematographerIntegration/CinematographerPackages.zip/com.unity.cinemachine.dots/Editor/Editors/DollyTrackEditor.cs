using UnityEditor;
using UnityEngine;
using Unity.Entities;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(DollyTrackAuthoring))]
    internal class DollyTrackEditor : BaseEditor<DollyTrackAuthoring>
    {
        public override void OnInspectorGUI()
        {
            BeginInspector();
            DrawPropertyInInspector(FindProperty(x => x.Path));

            float pathLength = 0;
            if (DefaultWorld != null)
            {
                var pathEntity = DefaultWorld.GetOrCreateSystem<StableIDEntityManager>().LookupEntityNow(
                    Target.Path.Referent);
                if (DefaultWorld.EntityManager.HasComponent<TCBSplinePathState>(pathEntity))
                    pathLength = DefaultWorld.EntityManager.GetComponentData<TCBSplinePathState>(pathEntity).PathLength;
            }
            EditorGUILayout.LabelField(new GUIContent("Path length"), new GUIContent(pathLength.ToString()));

            DrawRemainingPropertiesInInspector();
        }
    }
}
