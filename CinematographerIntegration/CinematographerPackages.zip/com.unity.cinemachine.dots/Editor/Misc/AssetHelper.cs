using System;
using UnityEditor;
using UnityEngine;
#if CINEMACHINE_TIMELINE
using UnityEngine.Timeline;
using Unity.Timeline.ECS;
#endif

namespace Unity.Cinemachine.Editor
{
    /// <summary>
    /// Helpers for the editor
    /// </summary>
    public static class AssetHelper
    {
        // GML todo: add dialog for pathname
        public static GameObject CopyOrCreatePrefab(
            GameObject source, string defaultName, 
            string optionalAssetSubdirectory, 
            params Type[] components)
        {
            string newPath;
            if (source != null)
            {
                var oldPath = AssetDatabase.GetAssetPath(source);
                newPath = AssetDatabase.GenerateUniqueAssetPath(oldPath);
                AssetDatabase.CopyAsset(oldPath, newPath);
                return AssetDatabase.LoadAssetAtPath<GameObject>(newPath);
            }

            if (defaultName == null || defaultName.Length == 0)
                defaultName = "Item";

            newPath = "Assets";
            if (AssetDatabase.IsValidFolder(newPath))
            {
                var suffix = "Prefabs";
                if (!AssetDatabase.IsValidFolder(newPath + suffix))
                    AssetDatabase.CreateFolder(newPath, suffix);
                newPath += "/" + suffix;
                if (optionalAssetSubdirectory == null || optionalAssetSubdirectory.Length == 0)
                {
                    suffix = optionalAssetSubdirectory;
                    if (!AssetDatabase.IsValidFolder(newPath + suffix))
                        AssetDatabase.CreateFolder(newPath, suffix);
                    newPath += "/" + suffix;
                }
            }
            newPath += "/" + defaultName + ".prefab";
            newPath = AssetDatabase.GenerateUniqueAssetPath(newPath);
            GameObject go = ObjectFactory.CreateGameObject(defaultName, components);
            PrefabUtility.SaveAsPrefabAsset(go, newPath, out bool success);
            UnityEngine.Object.DestroyImmediate(go);
            return AssetDatabase.LoadAssetAtPath<GameObject>(newPath);
        }

#if CINEMACHINE_TIMELINE
            // GML todo: make the default path more sensible: take from prefab
        public static TimelineAsset CreateSubTimelineFor(GameObject prefab)
        {
            var name = "SubTimeline";
            if (prefab != null)
                name = prefab.name + "_SubTimeline";
            var path = EditorUtility.SaveFilePanel(
                "Create Timeline",
                Application.dataPath,
                name,
                "playable");
            if (path.Length == 0)
                return null;
            if (!path.StartsWith(Application.dataPath))
            {
                Debug.LogError("File must be located within the assets folder");
                return null;
            }

            path = path.Replace(Application.dataPath, "Assets/");
            var timelineAsset = ScriptableObject.CreateInstance<TimelineAsset>();
            AssetDatabase.DeleteAsset(path);
            AssetDatabase.CreateAsset(timelineAsset, path);
            var baseTrack = timelineAsset.CreateTrack<ComponentTrack>();
            if (prefab != null)
                baseTrack.name = prefab.name;

            return timelineAsset;
        }
#endif
    }
}
