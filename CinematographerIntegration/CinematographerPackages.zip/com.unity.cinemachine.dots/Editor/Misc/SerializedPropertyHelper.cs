using System;
using System.Collections;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.RegularExpressions;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;

namespace Unity.Cinemachine.Editor
{
    /// <summary>
    /// Helpers for the editor
    /// </summary>
    public static class SerializedPropertyHelper
    {
        /// This is a way to get a field name string in such a manner that the compiler will
        /// generate errors for invalid fields.  Much better than directly using strings.
        /// Usage: instead of
        /// <example>
        /// "m_MyField";
        /// </example>
        /// do this:
        /// <example>
        /// MyClass myclass = null;
        /// SerializedPropertyHelper.PropertyName( () => myClass.m_MyField);
        /// </example>
        public static string PropertyName(Expression<Func<object>> exp)
        {
            var body = exp.Body as MemberExpression;
            if (body == null)
            {
                var ubody = (UnaryExpression)exp.Body;
                body = ubody.Operand as MemberExpression;
            }
            return body.Member.Name;
        }

        /// Usage: instead of
        /// <example>
        /// mySerializedObject.FindProperty("m_MyField");
        /// </example>
        /// do this:
        /// <example>
        /// MyClass myclass = null;
        /// mySerializedObject.FindProperty( () => myClass.m_MyField);
        /// </example>
        public static SerializedProperty FindProperty(
            this SerializedObject obj, Expression<Func<object>> exp)
        {
            return obj.FindProperty(PropertyName(exp));
        }

        /// Usage: instead of
        /// <example>
        /// mySerializedProperty.FindPropertyRelative("m_MyField");
        /// </example>
        /// do this:
        /// <example>
        /// MyClass myclass = null;
        /// mySerializedProperty.FindPropertyRelative( () => myClass.m_MyField);
        /// </example>
        public static SerializedProperty FindPropertyRelative(
            this SerializedProperty obj, Expression<Func<object>> exp)
        {
            return obj.FindPropertyRelative(PropertyName(exp));
        }

        /// <summary>Get the value of a proprty, as an object</summary>
        public static object GetPropertyValue(SerializedProperty property)
        {
            var targetObject = property.serializedObject.targetObject;
            var targetObjectClassType = targetObject.GetType();
            var field = targetObjectClassType.GetField(property.propertyPath);
            if (field != null)
                return field.GetValue(targetObject);
            return null;
        }

        public static float3 GetFloat3Value(this SerializedProperty p)
        {
            return new float3(
                p.FindPropertyRelative("x").floatValue,
                p.FindPropertyRelative("y").floatValue,
                p.FindPropertyRelative("z").floatValue);
        }

        public static void SetFloat3Value(this SerializedProperty p, float3 v)
        {
            p.FindPropertyRelative("x").floatValue = v.x;
            p.FindPropertyRelative("y").floatValue = v.y;
            p.FindPropertyRelative("z").floatValue = v.z;
        }

        public static float4 GetFloat4Value(this SerializedProperty p)
        {
            return new float4(
                p.FindPropertyRelative("x").floatValue,
                p.FindPropertyRelative("y").floatValue,
                p.FindPropertyRelative("z").floatValue,
                p.FindPropertyRelative("w").floatValue);
        }

        public static void SetFloat4Value(this SerializedProperty p, float4 v)
        {
            p.FindPropertyRelative("x").floatValue = v.x;
            p.FindPropertyRelative("y").floatValue = v.y;
            p.FindPropertyRelative("z").floatValue = v.z;
            p.FindPropertyRelative("w").floatValue = v.w;
        }

        public static uint4 GetUint4Value(this SerializedProperty p)
        {
            return new uint4(
                (uint)p.FindPropertyRelative("x").intValue,
                (uint)p.FindPropertyRelative("y").intValue,
                (uint)p.FindPropertyRelative("z").intValue,
                (uint)p.FindPropertyRelative("w").intValue);
        }

        public static void SetUint4Value(this SerializedProperty p, uint4 v)
        {
            p.FindPropertyRelative("x").longValue = v.x;
            p.FindPropertyRelative("y").longValue = v.y;
            p.FindPropertyRelative("z").longValue = v.z;
            p.FindPropertyRelative("w").longValue = v.w;
        }

        static readonly Regex k_MatchArrayElement = new Regex(@"^data\[(\d+)\]$");

        /// <summary>
        /// Get the SerializedProperty value as an object.
        /// </summary>
        /// <param name="property">The serialized property to process</param>
        /// <returns>The underlying object, or null</returns>
        public static T GetValueAsObject<T>(this SerializedProperty property) where T : class
        {
            var serializedObject = property.serializedObject;
            var path = property.propertyPath;
    
            object propertyObject = serializedObject == null || serializedObject.targetObject == null
                ? null : serializedObject.targetObject;
            if (!string.IsNullOrEmpty(path) && propertyObject != null)
            {
                var objectType = propertyObject.GetType();
                var splitPath = path.Split('.');
                Type fieldType = null;

                // work through the given property path, node by node
                for (int i = 0; i < splitPath.Length; i++)
                {
                    var pathNode = splitPath[i];

                    // both arrays and lists implement the IList interface
                    if (fieldType != null && typeof(IList).IsAssignableFrom(fieldType))
                    {
                        // IList items are serialized like this: Array.data[0]
                        Debug.AssertFormat(pathNode.Equals("Array", StringComparison.Ordinal),
                            serializedObject.targetObject,
                            "Expected path node 'Array', but found '{0}'", pathNode);

                        // just skip the Array part of the path
                        pathNode = splitPath[++i];

                        // match the data[0] part of the path and extract the IList item index
                        var elementMatch = k_MatchArrayElement.Match(pathNode);
                        if (elementMatch.Success && int.TryParse(elementMatch.Groups[1].Value, out var index))
                        {
                            var objectArray = (IList)propertyObject;
                            bool validArrayEntry = objectArray != null && index < objectArray.Count;
                            propertyObject = validArrayEntry ? objectArray[index] : null;
                            objectType = fieldType.IsArray
                                ? fieldType.GetElementType()          // only set for arrays
                                : fieldType.GenericTypeArguments[0];  // type of T in List<T>
                        }
                        else
                        {
                            Debug.LogErrorFormat(serializedObject.targetObject,
                                "Unexpected path format for array item: '{0}'", pathNode);
                        }
                        // reset fieldType, so we don't end up in the IList branch again next iteration
                        fieldType = null;
                    }
                    else
                    {
                        FieldInfo field;
                        var instanceType = objectType;
                        var fieldBindingFlags = BindingFlags.Instance | BindingFlags.Public
                            | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy;
                        do
                        {
                            field = instanceType.GetField(pathNode, fieldBindingFlags);

                            // because a private, serialized field of a subclass isn't directly retrievable,
                            fieldBindingFlags = BindingFlags.Instance | BindingFlags.NonPublic;
                            // if neccessary, work up the inheritance chain until we find it.
                            instanceType = instanceType.BaseType;
                        }
                        while (field == null && instanceType != typeof(object));

                        // store object info for next iteration or to return
                        propertyObject = field == null || propertyObject == null
                            ? null : field.GetValue(propertyObject);
                        fieldType = field?.FieldType;
                        objectType = fieldType;
                    }
                }
            }
            return propertyObject as T;
        }
    }
}
