using System;
using Unity.Entities;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    [WorldSystemFilter(WorldSystemFilterFlags.DotsRuntimeGameObjectConversion)]
    [ConverterVersion("vladv", 3)]
    public class ConvertCmListenerForTiny : GameObjectConversionSystem
    {
        public override bool ShouldRunConversionSystem()
        {
            if (!base.ShouldRunConversionSystem())
                return false;

            var tinyCameraType = Type.GetType("Unity.Tiny.Rendering.Camera, Unity.Tiny.Rendering");
            if (tinyCameraType != null)
            {
                return BuildHasType(tinyCameraType);
            }

            return false;
        }

        protected override void OnUpdate()
        {
            Entities.ForEach((CmListener listener) =>
            {
                DstEntityManager.AddComponentData(GetPrimaryEntity(listener), new CmListenerTiny
                {
                    OutputCamera = GetPrimaryEntity(listener.OutputCamera),
                    ChannelOverride = listener.ChannelOverride.Referent
                });
            });
        }
    }
}
