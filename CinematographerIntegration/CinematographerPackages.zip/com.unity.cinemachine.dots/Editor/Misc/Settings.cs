using UnityEngine;
using UnityEditor;
using System;

namespace Unity.Cinemachine.Editor
{
    [InitializeOnLoad]
    internal sealed class Settings
    {
        public static class CoreSettings
        {
            private static readonly string hShowInGameGuidesKey = "CM3_ShowInGameGuides";
            public static bool ShowInGameGuides
            {
                get { return EditorPrefs.GetBool(hShowInGameGuidesKey, true); }
                set
                {
                    if (ShowInGameGuides != value)
                    {
                        EditorPrefs.SetBool(hShowInGameGuidesKey, value);
                        InspectorUtility.RepaintGameView();
                    }
                }
            }

            private static readonly string kCoreActiveGizmoColourKey = "CM3_Active_Gizmo_Colour";
            public static readonly Color kDefaultActiveColour = new Color32(255, 0, 0, 100);
            public static Color ActiveGizmoColour
            {
                get
                {
                    string packedColour = EditorPrefs.GetString(kCoreActiveGizmoColourKey, PackColor(kDefaultActiveColour));
                    return UnpackColour(packedColour);
                }

                set
                {
                    if (ActiveGizmoColour != value)
                    {
                        string packedColour = PackColor(value);
                        EditorPrefs.SetString(kCoreActiveGizmoColourKey, packedColour);
                    }
                }
            }

            private static readonly string kCoreInactiveGizmoColourKey = "CM3_Inactive_Gizmo_Colour";
            public static readonly Color kDefaultInactiveColour = new Color32(9, 54, 87, 100);
            public static Color InactiveGizmoColour
            {
                get
                {
                    string packedColour = EditorPrefs.GetString(kCoreInactiveGizmoColourKey, PackColor(kDefaultInactiveColour));
                    return UnpackColour(packedColour);
                }

                set
                {
                    if (InactiveGizmoColour != value)
                    {
                        string packedColour = PackColor(value);
                        EditorPrefs.SetString(kCoreInactiveGizmoColourKey, packedColour);
                    }
                }
            }
        }

        public static class ComposerSettings
        {
            private static readonly string kOverlayOpacityKey           = "CM3_Overlay_Opacity";
            private static readonly string kComposerHardBoundsColourKey = "CM3_Composer_HardBounds_Colour";
            private static readonly string kComposerSoftBoundsColourKey = "CM3_Composer_SoftBounds_Colour";
            private static readonly string kComposerTargetColourKey     = "CM3_Composer_Target_Colour";

            public const float kDefaultOverlayOpacity = 0.15f;
            public static readonly Color kDefaultHardBoundsColour = new Color32(255, 0, 72, 255);
            public static readonly Color kDefaultSoftBoundsColour = new Color32(0, 194, 255, 255);
            public static readonly Color kDefaultTargetColour = new Color32(255, 254, 25, 255);

            public static float OverlayOpacity
            {
                get { return EditorPrefs.GetFloat(kOverlayOpacityKey, kDefaultOverlayOpacity); }
                set
                {
                    if (value != OverlayOpacity)
                    {
                        EditorPrefs.SetFloat(kOverlayOpacityKey, value);
                    }
                }
            }

            public static Color HardBoundsOverlayColour
            {
                get
                {
                    string packedColour = EditorPrefs.GetString(kComposerHardBoundsColourKey, PackColor(kDefaultHardBoundsColour));
                    return UnpackColour(packedColour);
                }

                set
                {
                    if (HardBoundsOverlayColour != value)
                    {
                        string packedColour = PackColor(value);
                        EditorPrefs.SetString(kComposerHardBoundsColourKey, packedColour);
                    }
                }
            }

            public static Color SoftBoundsOverlayColour
            {
                get
                {
                    string packedColour = EditorPrefs.GetString(kComposerSoftBoundsColourKey, PackColor(kDefaultSoftBoundsColour));
                    return UnpackColour(packedColour);
                }

                set
                {
                    if (SoftBoundsOverlayColour != value)
                    {
                        string packedColour = PackColor(value);
                        EditorPrefs.SetString(kComposerSoftBoundsColourKey, packedColour);
                    }
                }
            }

            public static Color TargetColour
            {
                get
                {
                    string packedColour = EditorPrefs.GetString(kComposerTargetColourKey, PackColor(kDefaultTargetColour));
                    return UnpackColour(packedColour);
                }

                set
                {
                    if (TargetColour != value)
                    {
                        string packedColour = PackColor(value);
                        EditorPrefs.SetString(kComposerTargetColourKey, packedColour);
                    }
                }
            }
        }

        private static bool ShowCoreSettings
        {
            get { return EditorPrefs.GetBool(kCoreSettingsFoldKey, false); }
            set
            {
                if (value != ShowCoreSettings)
                {
                    EditorPrefs.SetBool(kCoreSettingsFoldKey, value);
                }
            }
        }

        private static bool ShowComposerSettings
        {
            get { return EditorPrefs.GetBool(kComposerSettingsFoldKey, false); }
            set
            {
                if (value != ShowComposerSettings)
                {
                    EditorPrefs.SetBool(kComposerSettingsFoldKey, value);
                }
            }
        }

        private static Texture2D sCinemachineHeader = null;
        internal static Texture2D CinemachineHeader
        {
            get
            {
                if (sCinemachineHeader == null)
                    sCinemachineHeader = Resources.Load<Texture2D>("CM3_header");
                ;
                if (sCinemachineHeader != null)
                    sCinemachineHeader.hideFlags = HideFlags.DontSaveInEditor;
                return sCinemachineHeader;
            }
        }

        private static readonly string kCoreSettingsFoldKey     = "CM3_Folded";
        private static readonly string kComposerSettingsFoldKey = "CM3_Composer_Folded";

        internal static event Action AdditionalCategories = null;

        class Styles {
            public static readonly GUIContent sCoreActiveGizmosColour = new GUIContent("Active CmNode", "The colour for the active node's gizmos");
            public static readonly GUIContent sCoreInactiveGizmosColour = new GUIContent("Inactive CmNode", "The colour for all inactive node gizmos");
            public static readonly GUIContent sComposerOverlayOpacity = new GUIContent("Overlay Opacity", "The alpha of the composer's overlay when a node is selected with composer module enabled");
            public static readonly GUIContent sComposerHardBoundsOverlay = new GUIContent("Hard Bounds Overlay", "The colour of the composer overlay's hard bounds region");
            public static readonly GUIContent sComposerSoftBoundsOverlay = new GUIContent("Soft Bounds Overlay", "The colour of the composer overlay's soft bounds region");
            public static readonly GUIContent sComposerTargetOverlay = new GUIContent("Composer Target", "The colour of the composer overlay's target");
        }

        private const string kCinemachineHeaderPath = "CM3_header.tif";
//        private const string kCinemachineDocURL = @"http://www.cinemachineimagery.com/documentation/";

        private static Vector2 sScrollPosition = Vector2.zero;

        [SettingsProvider]
        static SettingsProvider CreateProjectSettingsProvider()
        {
            var provider = new SettingsProvider("Preferences/Cinemachine", SettingsScope.User, SettingsProvider.GetSearchKeywordsFromGUIContentProperties<Styles>());
            provider.guiHandler = (sarchContext) => OnGUI();
            return provider;
        }

        private static void OnGUI()
        {
            if (CinemachineHeader != null)
            {
                const float kWidth = 350f;
                float aspectRatio = (float)CinemachineHeader.height / (float)CinemachineHeader.width;
                GUILayout.BeginScrollView(Vector2.zero, false, false, GUILayout.Width(kWidth), GUILayout.Height(kWidth * aspectRatio));
                Rect texRect = new Rect(0f, 0f, kWidth, kWidth * aspectRatio);

                GUILayout.BeginArea(texRect);
                GUI.DrawTexture(texRect, CinemachineHeader, ScaleMode.ScaleToFit);
                GUILayout.EndArea();

                GUILayout.EndScrollView();
            }

            sScrollPosition = GUILayout.BeginScrollView(sScrollPosition);

            ShowCoreSettings = EditorGUILayout.Foldout(ShowCoreSettings, "Runtime Settings");
            if (ShowCoreSettings)
            {
                EditorGUI.indentLevel++;
                EditorGUI.BeginChangeCheck();
                EditorGUILayout.BeginHorizontal();
                EditorGUI.BeginChangeCheck();
                Color newActiveGizmoColour = EditorGUILayout.ColorField(Styles.sCoreActiveGizmosColour, CoreSettings.ActiveGizmoColour);

                if (EditorGUI.EndChangeCheck())
                {
                    CoreSettings.ActiveGizmoColour = newActiveGizmoColour;
                    InspectorUtility.RepaintGameView();
                }

                if (GUILayout.Button("Reset"))
                {
                    CoreSettings.ActiveGizmoColour = CoreSettings.kDefaultActiveColour;
                }
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                EditorGUI.BeginChangeCheck();
                Color newInactiveGizmoColour = EditorGUILayout.ColorField(Styles.sCoreInactiveGizmosColour, CoreSettings.InactiveGizmoColour);

                if (EditorGUI.EndChangeCheck())
                {
                    CoreSettings.InactiveGizmoColour = newInactiveGizmoColour;
                    UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
                }

                if (GUILayout.Button("Reset"))
                {
                    CoreSettings.InactiveGizmoColour = CoreSettings.kDefaultInactiveColour;
                }
                EditorGUILayout.EndHorizontal();
                EditorGUI.indentLevel--;
            }

            ShowComposerSettings = EditorGUILayout.Foldout(ShowComposerSettings, "Composer Settings");
            if (ShowComposerSettings)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.BeginHorizontal();
                EditorGUI.BeginChangeCheck();

                float overlayOpacity = EditorGUILayout.Slider(Styles.sComposerOverlayOpacity, ComposerSettings.OverlayOpacity, 0f, 1f);

                if (EditorGUI.EndChangeCheck())
                {
                    ComposerSettings.OverlayOpacity = overlayOpacity;
                }

                if (GUILayout.Button("Reset"))
                {
                    ComposerSettings.OverlayOpacity = ComposerSettings.kDefaultOverlayOpacity;
                }
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                EditorGUI.BeginChangeCheck();
                Color newHardEdgeColor = EditorGUILayout.ColorField(Styles.sComposerHardBoundsOverlay, ComposerSettings.HardBoundsOverlayColour);

                if (EditorGUI.EndChangeCheck())
                {
                    ComposerSettings.HardBoundsOverlayColour = newHardEdgeColor;
                }

                if (GUILayout.Button("Reset"))
                {
                    ComposerSettings.HardBoundsOverlayColour = ComposerSettings.kDefaultHardBoundsColour;
                }
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                EditorGUI.BeginChangeCheck();
                Color newSoftEdgeColor = EditorGUILayout.ColorField(Styles.sComposerSoftBoundsOverlay, ComposerSettings.SoftBoundsOverlayColour);

                if (EditorGUI.EndChangeCheck())
                {
                    ComposerSettings.SoftBoundsOverlayColour = newSoftEdgeColor;
                }

                if (GUILayout.Button("Reset"))
                {
                    ComposerSettings.SoftBoundsOverlayColour = ComposerSettings.kDefaultSoftBoundsColour;
                }
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                EditorGUI.BeginChangeCheck();
                Color newTargetColour = EditorGUILayout.ColorField(Styles.sComposerTargetOverlay, ComposerSettings.TargetColour);

                if (EditorGUI.EndChangeCheck())
                {
                    ComposerSettings.TargetColour = newTargetColour;
                }

                if (GUILayout.Button("Reset"))
                {
                    ComposerSettings.TargetColour = ComposerSettings.kDefaultTargetColour;
                }
                EditorGUILayout.EndHorizontal();

                EditorGUI.indentLevel--;
            }

            if (AdditionalCategories != null)
            {
                AdditionalCategories();
            }

            GUILayout.EndScrollView();
        }

        internal static Color UnpackColour(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                byte[] bytes = Base64Decode(str);

                if ((bytes != null) && bytes.Length == 16)
                {
                    float r = BitConverter.ToSingle(bytes, 0);
                    float g = BitConverter.ToSingle(bytes, 4);
                    float b = BitConverter.ToSingle(bytes, 8);
                    float a = BitConverter.ToSingle(bytes, 12);

                    return new Color(r, g, b, a);
                }
            }

            return Color.white;
        }

        internal static string PackColor(Color col)
        {
            byte[] bytes = new byte[16];

            byte[] rBytes = BitConverter.GetBytes(col.r);
            byte[] gBytes = BitConverter.GetBytes(col.g);
            byte[] bBytes = BitConverter.GetBytes(col.b);
            byte[] aBytes = BitConverter.GetBytes(col.a);

            Buffer.BlockCopy(rBytes, 0, bytes, 0, 4);
            Buffer.BlockCopy(gBytes, 0, bytes, 4, 4);
            Buffer.BlockCopy(bBytes, 0, bytes, 8, 4);
            Buffer.BlockCopy(aBytes, 0, bytes, 12, 4);

            return Base64Encode(bytes);
        }

        private static string Base64Encode(byte[] data)
        {
            return Convert.ToBase64String(data);
        }

        private static byte[] Base64Decode(string base64EncodedData)
        {
            return Convert.FromBase64String(base64EncodedData);
        }
    }
}
