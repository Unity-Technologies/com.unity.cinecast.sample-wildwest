using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace Unity.Cinemachine.Editor
{
    public class InspectorUtility
    {
        /// <summary>Put multiple properties on a single inspector line, with
        /// optional label overrides.  Passing null as a label (or sublabel) override will
        /// cause the property's displayName to be used as a label.  For no label at all,
        /// pass GUIContent.none.</summary>
        public static void MultiPropertyOnLine(
            Rect rect,
            GUIContent label,
            SerializedProperty[] props, GUIContent[] subLabels)
        {
            if (props == null || props.Length == 0)
                return;

            const int hSpace = 2;
            int indentLevel = EditorGUI.indentLevel;
            float labelWidth = Mathf.Max(1, EditorGUIUtility.labelWidth - indentLevel * 15);

            float totalSubLabelWidth = 0;
            int numBoolColumns = 0;
            if (sActualLabels == null)
                sActualLabels = new List<GUIContent>();
            sActualLabels.Clear();
            if (sActualLabelWidths == null)
                sActualLabelWidths = new List<float>();
            sActualLabelWidths.Clear();
            for (int i = 0; i < props.Length; ++i)
            {
                GUIContent sublabel = new GUIContent(props[i].displayName, props[i].tooltip);
                if (subLabels != null && subLabels.Length > i && subLabels[i] != null)
                    sublabel = subLabels[i];
                sActualLabels.Add(sublabel);
                var w = GUI.skin.label.CalcSize(sublabel).x - 2;
                sActualLabelWidths.Add(w);
                totalSubLabelWidth += w;
                if (i > 0)
                    totalSubLabelWidth += hSpace;
                // Special handling for toggles, or it looks stupid
                if (props[i].propertyType == SerializedPropertyType.Boolean)
                {
                    totalSubLabelWidth += rect.height;
                    ++numBoolColumns;
                }
            }

            float subFieldWidth = rect.width - labelWidth - totalSubLabelWidth - hSpace;
            float numCols = props.Length - numBoolColumns;
            float colWidth = numCols == 0 ? 0 : subFieldWidth / numCols;

            // Main label.  If no first sublabel, then main label must take on that
            // role, for mouse dragging value-scrolling support
            int subfieldStartIndex = 0;
            if (label == null)
                label = new GUIContent(props[0].displayName, props[0].tooltip);
            if (sActualLabels[0] != GUIContent.none)
                rect = EditorGUI.PrefixLabel(rect, label);
            else
            {
                rect.width = labelWidth + colWidth - hSpace;
                EditorGUI.PropertyField(rect, props[0], label);
                rect.x += rect.width + hSpace;
                subfieldStartIndex = 1;
            }

            for (int i = subfieldStartIndex; i < props.Length; ++i)
            {
                EditorGUI.indentLevel = 0;
                EditorGUIUtility.labelWidth = sActualLabelWidths[i];
                if (props[i].propertyType == SerializedPropertyType.Boolean)
                {
                    rect.width = EditorGUIUtility.labelWidth + rect.height;
                    props[i].boolValue = EditorGUI.ToggleLeft(rect, sActualLabels[i], props[i].boolValue);
                }
                else
                {
                    rect.width = EditorGUIUtility.labelWidth + colWidth;
                    EditorGUI.PropertyField(rect, props[i], sActualLabels[i]);
                }
                rect.x += rect.width + hSpace;
            }

            EditorGUIUtility.labelWidth = labelWidth;
            EditorGUI.indentLevel = indentLevel;
        }
        static List<GUIContent> sActualLabels; // scratch list - recycle for efficiency
        static List<float> sActualLabelWidths; // scratch list - recycle for efficiency

/*
        public static string NicifyClassName(string name)
        {
            if (name.StartsWith("Cinemachine"))
                name = name.Substring(11); // Trim the prefix
            return ObjectNames.NicifyVariableName(name);
        }
*/
        public static void AddAssetsFromPackageSubDirectory(
            Type type, List<ScriptableObject> assets, string path)
        {
            try
            {
                path = "/" + path;
                var info = new DirectoryInfo(ScriptableObjectHelper.CinemachineInstallPath + path);
                path = ScriptableObjectHelper.kPackageRoot + path + "/";
                var fileInfo = info.GetFiles();
                foreach (var file in fileInfo)
                {
                    if (file.Extension != ".asset")
                        continue;
                    string name = path + file.Name;
                    ScriptableObject a = AssetDatabase.LoadAssetAtPath(name, type) as ScriptableObject;
                    if (a != null)
                        assets.Add(a);
                }
            }
            catch (Exception e)
            {
                Debug.Log(e.Message);
            }
        }
/*
        // Temporarily here
        public static GameObject CreateGameObject(string name, params Type[] types)
        {
            return ObjectFactory.CreateGameObject(name, types);
        }
*/

        public static Rect InflateRect(Rect r, Vector2 delta)
        {
            return new Rect(
                r.xMin - delta.x, r.yMin - delta.y,
                r.width + delta.x * 2, r.height + delta.y * 2);
        }

        public static void RepaintGameView()
        {
            EditorApplication.QueuePlayerLoopUpdate();
            UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
        }

        /// <summary>
        /// Returns true if Create/Clone was invoked
        /// </summary>
        /// <param name="property"></param>
        /// <param name="prefabComponentFilter"></param>
        /// <returns></returns>
        public static bool PrefabFieldWithCreateButton(
            Rect rect,
            SerializedProperty property,
            Type prefabComponentFilter)
        {
            GameObject go = property.objectReferenceValue as GameObject;
            bool isValid = go != null 
                && (prefabComponentFilter == null 
                    || go.GetComponent(prefabComponentFilter) != null);

            GUIContent icon = GUIContent.none;
            if (!isValid)
            {
                if (go == null)
                    icon = new GUIContent(
                        EditorGUIUtility.IconContent("console.warnicon.sml").image,
                        $"Choose a {prefabComponentFilter.Name} prefab");
                else
                    icon = new GUIContent(
                        EditorGUIUtility.IconContent("console.erroricon.sml").image,
                        $"Prefab must be of type {prefabComponentFilter.Name}");
            }
            Vector2 iconSize = GUI.skin.label.CalcSize(icon);

            GUIContent createLabel = new GUIContent(isValid ? "Clone" : "Create");
            Vector2 createSize = GUI.skin.button.CalcSize(createLabel);

            rect.width -= createSize.x + iconSize.x;
            EditorGUI.PropertyField(rect, property);

            rect.x += rect.width; rect.width = iconSize.x;
            EditorGUI.LabelField(rect, icon);

            rect.x += rect.width; rect.width = createSize.x;
            return GUI.Button(rect, createLabel);
        }

        /// <summary>
        /// Restores the old value on destruction
        /// </summary>
        public class IndentOverride
        {
            int m_saved;
            public IndentOverride(int indent) 
            { 
                m_saved = EditorGUI.indentLevel;
                EditorGUI.indentLevel = indent; 
            }
            ~IndentOverride() { EditorGUI.indentLevel = m_saved; }
        }

        /// <summary>
        /// Restores the old value on destruction
        /// </summary>
        public class LabelWidthOverride
        {
            float m_saved;
            public LabelWidthOverride(float w)
            {
                m_saved = EditorGUIUtility.labelWidth;
                EditorGUIUtility.labelWidth = w;
            }
            ~LabelWidthOverride() { EditorGUIUtility.labelWidth = m_saved; }
        }

        /// <summary>
        /// Restores the old value on destruction
        /// </summary>
        public class GUIColorOverride
        {
            Color m_saved;
            public GUIColorOverride(Color c)
            {
                m_saved = GUI.color;
                GUI.color = c;
            }
            ~GUIColorOverride() { GUI.color = m_saved; }
        }

        /// <summary>
        /// Restores the old value on destruction
        /// </summary>
        public class GUIEnabledOverride
        {
            bool m_saved;
            public GUIEnabledOverride(bool enabled)
            {
                m_saved = GUI.enabled;
                GUI.enabled = enabled;
            }
            ~GUIEnabledOverride() { GUI.enabled = m_saved; }
        }

        private static Color _DefaultBackgroundColor;
        public static Color DefaultBackgroundColor
        {
            get
            {
                if (_DefaultBackgroundColor.a == 0)
                {
                    var method = typeof(EditorGUIUtility)
                        .GetMethod("GetDefaultBackgroundColor", BindingFlags.NonPublic | BindingFlags.Static);
                    _DefaultBackgroundColor = (Color)method.Invoke(null, null);
                }
                return _DefaultBackgroundColor;
            }
        }
    }
}
