using UnityEditor;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using Unity.Entities;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Editor
{
    /// <summary>
    /// A convenience base class for making inspector editors.
    /// </summary>
    /// <typeparam name="T">The class we're editing</typeparam>
    public class BaseEditor<T> : UnityEditor.Editor where T : class
    {
        protected T Target { get { return target as T; } }
        protected World DefaultWorld { get { return ClientHooks.DefaultWorld; } }

        protected SerializedProperty FindAndExcludeProperty<TValue>(Expression<Func<T, TValue>> expr)
        {
            SerializedProperty p = FindProperty(expr);
            ExcludeProperty(p.name);
            return p;
        }

        protected SerializedProperty FindProperty<TValue>(Expression<Func<T, TValue>> expr)
        {
            return serializedObject.FindProperty(FieldPath(expr));
        }

        protected string FieldPath<TValue>(Expression<Func<T, TValue>> expr)
        {
            return ReflectionHelpers.GetFieldPath(expr);
        }

        protected virtual void GetExcludedPropertiesInInspector(List<string> excluded)
        {
            excluded.Add("m_Script");
        }

        List<string> m_Excluded = new List<string>();
        List<string> m_AdditionalExcluded = new List<string>();

        protected void ExcludeProperty(string propertyName)
        {
            m_AdditionalExcluded.Add(propertyName);
        }

        protected bool IsPropertyExcluded(string propertyName)
        {
            return m_Excluded.Contains(propertyName) || m_AdditionalExcluded.Contains(propertyName);
        }

        public override void OnInspectorGUI()
        {
            BeginInspector();
            DrawRemainingPropertiesInInspector();
        }

        protected virtual void BeginInspector()
        {
            m_AdditionalExcluded.Clear();
            m_Excluded.Clear();
            GetExcludedPropertiesInInspector(m_Excluded);
            serializedObject.Update();
        }

        protected virtual void DrawPropertyInInspector(SerializedProperty p)
        {
            if (!IsPropertyExcluded(p.name))
            {
                EditorGUI.BeginChangeCheck();
                EditorGUILayout.PropertyField(p);
                if (EditorGUI.EndChangeCheck())
                    serializedObject.ApplyModifiedProperties();
                ExcludeProperty(p.name);
            }
        }

        protected void DrawRemainingPropertiesInInspector()
        {
            m_Excluded.AddRange(m_AdditionalExcluded);
            EditorGUI.BeginChangeCheck();
            DrawPropertiesExcluding(serializedObject, m_Excluded.ToArray());
            if (EditorGUI.EndChangeCheck())
                serializedObject.ApplyModifiedProperties();
        }
    }
}
