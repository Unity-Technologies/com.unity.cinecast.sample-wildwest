using UnityEngine;
using UnityEditor;
using Unity.Mathematics;
using System.Collections.Generic;
using Unity.Entities.Hybrid;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Editor
{
    internal static class MainMenu
    {
        const string s_CinemachineAssetsRootMenu = "Assets/Create/Cinemachine/";
        const string s_CinemachineGameObjectRootMenu = "GameObject/Cinemachine/";
        const int GameObjectMenuPriority = 11; // Right after Camera

        // Assets Menu

        [MenuItem(s_CinemachineAssetsRootMenu + "BlenderSettings")]
        static void CreateBlenderSettingAsset()
        {
            ScriptableObjectHelper.Create<CustomBlends>();
        }

        [MenuItem(s_CinemachineAssetsRootMenu + "NoiseSettings")]
        static void CreateNoiseSettingAsset()
        {
            ScriptableObjectHelper.Create<GeneratedWaveProfile>();
        }

        // GameObject Menu

        [MenuItem(s_CinemachineGameObjectRootMenu + "Cm Camera", false, GameObjectMenuPriority)]
        static void CreatePassiveCamera(MenuCommand command)
        {
            //CinemachineEditorAnalytics.SendCreateEvent("Virtual Camera");
            CreateDefaultCamera(parentObject: command.context as GameObject, select: true);
        }

        [MenuItem(s_CinemachineGameObjectRootMenu + "Cm Follow Camera", false, GameObjectMenuPriority)]
        static void CreateFollowCamera(MenuCommand command)
        {
            //CinemachineEditorAnalytics.SendCreateEvent("Virtual Camera");
            var cam = CreateDefaultCamera(parentObject: command.context as GameObject, select: true);
            Undo.AddComponent<FollowAuthoring>(cam.gameObject);
            Undo.AddComponent<ComposedLookAtAuthoring>(cam.gameObject);
        }

        [MenuItem(s_CinemachineGameObjectRootMenu + "Cm Nonrotating Follow Camera", false, GameObjectMenuPriority)]
        static void Create2DCamera(MenuCommand command)
        {
            //CinemachineEditorAnalytics.SendCreateEvent("2D Camera");
            var cam = CreateDefaultCamera(parentObject: command.context as GameObject, select: true);
            Undo.AddComponent<ComposedFollowAuthoring>(cam.gameObject);
        }

        [MenuItem(s_CinemachineGameObjectRootMenu + "Cm FreeLook Camera", false, GameObjectMenuPriority)]
        static void CreateFreeLookCamera(MenuCommand command)
        {
            //CinemachineEditorAnalytics.SendCreateEvent("FreeLook Camera");
            var cam = CreateDefaultCamera("Cm FreeLook Camera", command.context as GameObject, true);
            Undo.AddComponent<OrbitalFollowAuthoring>(cam.gameObject);
            Undo.AddComponent<ComposedLookAtAuthoring>(cam.gameObject);
        }

        [MenuItem(s_CinemachineGameObjectRootMenu + "Cm ClearShot Camera", false, GameObjectMenuPriority)]
        static void CreateClearShotVirtualCamera(MenuCommand command)
        {
            //CinemachineEditorAnalytics.SendCreateEvent("ClearShot Camera");
            var cam = CreateCinemachineObject<CmClearShotAuthoring>(
                "ClearShot Camera", command.context as GameObject, true);

            // We give the camera a child as an example setup
            var child = CreateDefaultCamera(parentObject: cam.gameObject);
#if CINEMACHINE_PHYSICS
            Undo.AddComponent<CollisionResolutionAuthoring>(child.gameObject);
#elif CINEMACHINE_LEGACY_PHYSICS
            Undo.AddComponent<LegacyCollisionResolutionAuthoring>(child.gameObject);
#endif
        }

        [MenuItem(s_CinemachineGameObjectRootMenu + "Cm Sequencer", false, GameObjectMenuPriority)]
        static void CreateBlendListCamera(MenuCommand command)
        {
            //CinemachineEditorAnalytics.SendCreateEvent("Blend List Camera");
            var cam = CreateCinemachineObject<CmSequencerAuthoring>(
                "Cm Sequencer", command.context as GameObject, true);

            // We give the camera a couple of children as an example of setup
            var child1 = CreateDefaultCamera(parentObject: cam.gameObject);
            var child2 = CreateDefaultCamera(parentObject: cam.gameObject);
            var lens = child2.Lens;
            lens.FieldOfView = 10;
            child2.Lens = lens;

            // Set up initial instruction set
            cam.Instructions = new List<CmSequencerAuthoring.Instruction>(2);
            cam.Instructions.Add(new CmSequencerAuthoring.Instruction
            {
                Node = new StableReference<CmNodeBindingKey> { Referent = child1.StableKey },
                Hold = 1f
            });
            cam.Instructions.Add(new CmSequencerAuthoring.Instruction
            {
                Node = new StableReference<CmNodeBindingKey> { Referent = child2.StableKey },
                Blend = new TransitionDefinition { Length = 2f }
            });
        }

        [MenuItem(s_CinemachineGameObjectRootMenu + "Cm Mixer", false, GameObjectMenuPriority)]
        static void CreateMixingCamera(MenuCommand command)
        {
            //CinemachineEditorAnalytics.SendCreateEvent("Mixing Camera");
            var cam = CreateCinemachineObject<CmMixerAuthoring>(
                "Cm Mixer", command.context as GameObject, true);

            // We give the camera a couple of children as an example of setup
            var child1 = CreateDefaultCamera(parentObject: cam.gameObject);
            var child2 = CreateDefaultCamera(parentObject: cam.gameObject);

            cam.InputNodes = new List<CmMixerAuthoring.InputNode> 
            { 
                new CmMixerAuthoring.InputNode 
                {
                    Node = new StableReference<CmNodeBindingKey> { Referent = child1.StableKey },
                    Weight = 0.5f
                },
                new CmMixerAuthoring.InputNode 
                {
                    Node = new StableReference<CmNodeBindingKey> { Referent = child2.StableKey },
                    Weight = 0.5f
                }
            };
        }

        [MenuItem(s_CinemachineGameObjectRootMenu + "Dolly Camera with Track", false, GameObjectMenuPriority)]
        static void CreateDollyCameraWithPath(MenuCommand command)
        {
            //CinemachineEditorAnalytics.SendCreateEvent("Dolly Camera with Track");
            var cam = CreateDefaultCamera("Cm Dolly Camera", command.context as GameObject, true);
            var dolly = Undo.AddComponent<DollyTrackAuthoring>(cam.gameObject);
            var path = CreateCinemachineObject<TCBSplinePathAuthoring>(
                "Dolly Track", command.context as GameObject, false);
            dolly.Path.Referent = path.StableKey;
        }

        [MenuItem(s_CinemachineGameObjectRootMenu + "Dolly Cart with Track", false, GameObjectMenuPriority)]
        static void CreateDollyTrackWithCart(MenuCommand command)
        {
            //CinemachineEditorAnalytics.SendCreateEvent("Dolly Track with Cart");
            var path = CreateCinemachineObject<TCBSplinePathAuthoring>(
                "Dolly Track", command.context as GameObject, false);
            CreateCinemachineObject<DollyCartAuthoring>(
                "Dolly Cart", command.context as GameObject, true).Path.Referent = path.StableKey;
        }

        [MenuItem(s_CinemachineGameObjectRootMenu + "Target Group Camera", false, GameObjectMenuPriority)]
        static void CreateTargetGroupCamera(MenuCommand command)
        {
            //CinemachineEditorAnalytics.SendCreateEvent("Target Group Camera");
            var cam = CreateDefaultCamera("Cm Camera", command.context as GameObject, true);
            Undo.AddComponent<ComposedLookAtAuthoring>(cam.gameObject);
            Undo.AddComponent<SizeFramingAuthoring>(cam.gameObject);

            var targetGroup = CreateCinemachineObject<CmTargetGroupAuthoring>(
                "Target Group", command.context as GameObject, false);
            var id = targetGroup.GetComponent<StableID>().Value;
            cam.LookAtTarget.Referent = id;
            cam.FollowTarget.Referent = id;
        }

        /// <summary>
        /// Sets the specified <see cref="Transform"/> to match the position and 
        /// rotation of the <see cref="SceneView"/> camera, and returns the scene view 
        /// camera's lens settings.
        /// </summary>
        /// <param name="sceneObject">The <see cref="Transform"/> to match with the 
        /// <see cref="SceneView"/> camera.</param>
        /// <returns>A <see cref="LensSettings"/> representing the scene view camera's lens</returns>
        public static LensSettings MatchSceneViewCamera(Transform sceneObject)
        {
            var lens = LensSettings.Default;

            // Take initial settings from the GameView camera, because we don't want to override 
            // things like ortho vs perspective - we just want position and FOV
            var listener = CreateListenerOnCameraIfAbsent();
            if (listener != null && listener.OutputCamera != null)
                lens = LensSettingsFromCamera(listener.OutputCamera, false);

            if (SceneView.lastActiveSceneView != null)
            {
                var src = SceneView.lastActiveSceneView.camera;
                sceneObject.SetPositionAndRotation(src.transform.position, src.transform.rotation);
                if (lens.Orthographic == src.orthographic)
                {
                    if (src.orthographic)
                        lens.OrthographicSize = src.orthographicSize;
                    else
                        lens.FieldOfView = src.fieldOfView;
                }
            }
            return lens;
        }

        /// <summary>
        /// Create a CmNode, with dots components
        /// </summary>
        public static void SetCameraFromSceneView(CmCameraAuthoring node)
        {
            if (SceneView.lastActiveSceneView != null)
            {
                node.transform.position = SceneView.lastActiveSceneView.camera.transform.position;
                node.transform.rotation = SceneView.lastActiveSceneView.camera.transform.rotation;
                node.Lens = LensSettingsFromCamera(SceneView.lastActiveSceneView.camera, false);
                if (Camera.main != null)
                    node.Lens.SnapshotCameraReadOnlyProperties(Camera.main);
            }
        }

        /// <summary>
        /// Creates a new LensSettings, copying the values from the
        /// supplied Camera
        /// </summary>
        /// <param name="fromCamera">The Camera from which the FoV, near
        /// and far clip planes will be copied.</param>
        public static LensSettings LensSettingsFromCamera(
            Camera fromCamera, bool includeClipPlanes)
        {
            LensSettings lens = LensSettings.Default;
            if (fromCamera != null)
            {
                lens.FieldOfView = fromCamera.fieldOfView;
                lens.OrthographicSize = fromCamera.orthographicSize;
                if (includeClipPlanes)
                {
                    lens.NearClipPlane = fromCamera.nearClipPlane;
                    lens.FarClipPlane = fromCamera.farClipPlane;
                }
                lens.LensShift = fromCamera.lensShift;
                lens.SnapshotCameraReadOnlyProperties(fromCamera);
            }
            return lens;
        }


        /// <summary>
        /// Snapshot the properties that are read-only in the Camera
        /// </summary>
        /// <param name="camera">The Camera from which we will take the info</param>
        static void SnapshotCameraReadOnlyProperties(this LensSettings lens, Camera camera)
        {
            if (camera != null)
            {
                lens.Orthographic = camera.orthographic;
                lens.SensorSize = new float2(camera.aspect, 1f);
                lens.IsPhysicalCamera = camera.usePhysicalProperties;
                if (lens.IsPhysicalCamera)
                    lens.SensorSize = camera.sensorSize;
                else
                    lens.LensShift = float2.zero;
            }
        }

        /// <summary>
        /// Creates a <see cref="CinemachineVirtualCamera"/> with standard procedural components.
        /// </summary>
        public static CmCameraAuthoring CreateDefaultCamera(
            string name = "Cm Camera", GameObject parentObject = null, bool select = false)
        {
            var vcam = CreateCinemachineObject<CmCameraAuthoring>(name, parentObject, select);
            vcam.Lens = MatchSceneViewCamera(vcam.transform);
            return vcam;
        }

        /// <summary>
        /// Creates a Cinemachine <see cref="GameObject"/> in the scene with a specified component.
        /// </summary>
        /// <typeparam name="T">The type of <see cref="Component"/> to add to the new <see cref="GameObject"/>.</typeparam>
        /// <param name="name">The name of the new <see cref="GameObject"/>.</param>
        /// <param name="parentObject">The <see cref="GameObject"/> to parent the new <see cref="GameObject"/> to.</param>
        /// <param name="select">Whether the new <see cref="GameObject"/> should be selected.</param>
        /// <returns>The instance of the component that is added to the new <see cref="GameObject"/>.</returns>
        static T CreateCinemachineObject<T>(string name, GameObject parentObject, bool select) where T : Component
        {
            // We always enforce the existence of the CmListener and default CmChannel
            CreateListenerOnCameraIfAbsent();
            CreateDefaultChannelIfAbsent();

            // We use ObjectFactory to create a new GameObject as it automatically supports undo/redo
            var go = ObjectFactory.CreateGameObject(name);
            T component = go.AddComponent<T>();

            if (parentObject != null)
                Undo.SetTransformParent(go.transform, parentObject.transform, "Set parent of " + name);

            // We ensure that the new object has a unique name, for example "Camera (1)".
            // This must be done after setting the parent in order to get an accurate unique name
            GameObjectUtility.EnsureUniqueNameForSibling(go);

            // We set the new object to be at the current pivot of the scene.
            // GML TODO: Support the "Place Objects At World Origin" preference option in 2020.3+, see GOCreationCommands.cs
            if (SceneView.lastActiveSceneView != null)
                go.transform.position = SceneView.lastActiveSceneView.pivot;

            if (select)
                Selection.activeGameObject = go;

            return component;
        }

        /// <summary>
        /// If there is no CmListener in the scene, try to create one on the main camera
        /// </summary>
        static CmListener CreateListenerOnCameraIfAbsent()
        {
            var listeners = UnityEngine.Object.FindObjectsOfType(
                typeof(CmListener)) as CmListener[];
            if (listeners != null && listeners.Length > 0)
                return listeners[0];
            Camera cam = Camera.main;
            if (cam == null)
            {
                Camera[] cams = UnityEngine.Object.FindObjectsOfType(
                        typeof(Camera)) as Camera[];
                if (cams != null && cams.Length > 0)
                    cam = cams[0];
            }
            if (cam != null)
                return Undo.AddComponent<CmListener>(cam.gameObject);
            return null;
        }

        /// <summary>
        /// If there is no CmChannel in the scene, try to create one on the main camera
        /// </summary>
        static void CreateDefaultChannelIfAbsent()
        {
            var type = typeof(CmChannelAuthoring);
            var channels = UnityEngine.Object.FindObjectsOfType(type) as CmChannelAuthoring[];
            if (channels == null || channels.Length == 0)
            {
                var go = ObjectFactory.CreateGameObject("Default CmChannel", type);
                GameObjectUtility.EnsureUniqueNameForSibling(go);
            }
        }
    }
}
