using UnityEngine;
using UnityEditor;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Editor
{
    [CustomPropertyDrawer(typeof(TransitionCurve))]
    public class TransitionCurvePropertyDrawer : PropertyDrawer
    {
        Implementation m_implementation = new Implementation();

        public override bool CanCacheInspectorGUI(SerializedProperty property)
        {
            return false;
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return m_implementation.GetPropertyHeight();
        }

        public override void OnGUI(Rect rect, SerializedProperty property, GUIContent label)
        {
            m_implementation.DrawProperty(rect, property, label, false);
        }

        public class Implementation
        {
            TransitionCurve myClass = new TransitionCurve(); // to access name strings
            const float kPreviewHeight = 128;

            public float GetPropertyHeight()
            {
                float height = EditorGUIUtility.singleLineHeight + EditorGUIUtility.standardVerticalSpacing;
                height += height * 3 + kPreviewHeight + EditorGUIUtility.standardVerticalSpacing;
                return height;
            }

            public void DrawProperty(
                Rect rect, SerializedProperty property, GUIContent label, bool invertGraph)
            {
                // Using BeginProperty / EndProperty on the parent property means that
                // prefab override logic works on the entire property.
                EditorGUI.BeginProperty(rect, label, property);

                Rect r = rect;
                var propA = property.FindPropertyRelative(() => myClass.A);
                var propB = property.FindPropertyRelative(() => myClass.B);
                var propBias = property.FindPropertyRelative(() => myClass.Bias);

                r = rect; r.height = EditorGUIUtility.singleLineHeight;
                EditorGUI.PropertyField(r, propA); r.y += r.height + EditorGUIUtility.standardVerticalSpacing;
                EditorGUI.PropertyField(r, propB); r.y += r.height + EditorGUIUtility.standardVerticalSpacing;
                EditorGUI.PropertyField(r, propBias); r.y += r.height + EditorGUIUtility.standardVerticalSpacing;

                rect.height -= (r.y - rect.y) + EditorGUIUtility.standardVerticalSpacing;
                rect.y += r.y - rect.y;
                if (rect.width > 8 && rect.height > 8)
                    DrawSample(rect, invertGraph, new TransitionCurve
                    {
                        A = propA.floatValue,
                        B = propB.floatValue,
                        Bias = propBias.floatValue
                    });

                EditorGUI.EndProperty();
            }

            Vector3[] mSamples;
            void DrawSample(Rect r, bool invert, TransitionCurve curve)
            {
                // Resample
                int numSamples = (int)(r.width / 2) + 1;
                if (mSamples == null || mSamples.Length != numSamples)
                    mSamples = new Vector3[numSamples];
                for (int i = 0; i < numSamples; ++i)
                {
                    float x = (float)i / (float)(numSamples - 1);
                    float y = curve.Evaluate(x);
                    if (!invert)
                        y = 1 - y;
                    mSamples[i] = new Vector3(r.position.x + x * r.width, r.position.y + y * r.height, 0);
                }

                // Draw
                EditorGUI.DrawRect(r, Color.black);
                Handles.color = GUI.enabled ? new Color(0, 1, 0, 1) : new Color(0.2f, 0.2f, 0.2f, 1);
                Handles.DrawPolyLine(mSamples);
            }
        }
    }
}
