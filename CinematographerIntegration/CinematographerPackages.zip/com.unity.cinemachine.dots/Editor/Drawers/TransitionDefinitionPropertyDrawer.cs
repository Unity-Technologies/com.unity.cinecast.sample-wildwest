using UnityEngine;
using UnityEditor;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Editor
{
    [CustomPropertyDrawer(typeof(TransitionDefinitionUnitsLabelAttribute))]
    internal sealed class TransitionDefinitionUnitsPropertyDrawer : TransitionDefinitionPropertyDrawer
    {
        public override void OnGUI(Rect rect, SerializedProperty property, GUIContent label)
        {
            var a = attribute as TransitionDefinitionUnitsLabelAttribute;
            if (a != null)
            {
                m_LengthLabel = a.Label;
                m_LengthTooltip = a.Tooltip;
            }
            base.OnGUI(rect, property, label);
        }
    }

    [CustomPropertyDrawer(typeof(TransitionDefinition))]
    internal class TransitionDefinitionPropertyDrawer : PropertyDrawer
    {
        TransitionDefinition myClass = new TransitionDefinition(); // to access name strings

        protected string m_LengthLabel;
        protected string m_LengthTooltip;

        GUIContent m_LengthGUI;
        GUIContent m_CurveGUI;
        Vector2 m_LengthTextSize;

        TransitionCurvePropertyDrawer.Implementation curveDrawer = new TransitionCurvePropertyDrawer.Implementation();

        public override bool CanCacheInspectorGUI(SerializedProperty property)
        {
            return false;
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            float height = EditorGUIUtility.singleLineHeight;
            if (property.isExpanded)
                height += curveDrawer.GetPropertyHeight() + EditorGUIUtility.standardVerticalSpacing;
            return height;
        }

        /// <summary>Supported predefined shapes for the blend curve.</summary>
        public enum Style
        {
            /// <summary>Zero-length transition</summary>
            None,
            /// <summary>S-shaped curve, giving a gentle and smooth transition</summary>
            EaseInOut,
            /// <summary>Linear out of the outgoing, and easy into the incoming</summary>
            LinearThenEasy,
            /// <summary>Easy out of the outgoing, and linear into the incoming</summary>
            EasyThenLinear,
            /// <summary>Easy out of the outgoing, and hard into the incoming</summary>
            EasyThenHard,
            /// <summary>Hard out of the outgoing, and easy into the incoming</summary>
            HardThenEasy,
            /// <summary>Linear transition.  Mechanical-looking.</summary>
            Linear,
            /// <summary>Custom transition curve.</summary>
            Custom
        };

        static Style ToStyle(TransitionDefinition d)
        {
            if (d.Length == 0)
                return Style.None;
            if (d.Curve.Bias == 0)
            {
                if (d.Curve.A == 0 && d.Curve.B == 0) return Style.EaseInOut;
                if (d.Curve.A == 0.5f && d.Curve.B == 0) return Style.LinearThenEasy;
                if (d.Curve.A == 0 && d.Curve.B == 0.5f) return Style.EasyThenLinear;
                if (d.Curve.A == 0 && d.Curve.B == 1) return Style.EasyThenHard;
                if (d.Curve.A == 1 && d.Curve.B == 0) return Style.HardThenEasy;
                if (d.Curve.A == d.Curve.B && d.Curve.B == TransitionCurve.Linear.A) return Style.Linear;
            }
            return Style.Custom;
        }

        static TransitionDefinition FromStyle(Style s, TransitionDefinition d)
        {
            if (s != Style.None && d.Length == 0)
                d.Length = 1;
            switch (s)
            {
                default: break;
                case Style.None: d.Length = 0; break;
                case Style.EaseInOut: d.Curve = TransitionCurve.Default; break;
                case Style.LinearThenEasy: d.Curve = new TransitionCurve { A = 0.5f, B = 0, Bias = 0 }; break;
                case Style.EasyThenLinear: d.Curve = new TransitionCurve { A = 0, B = 0.5f, Bias = 0 }; break;
                case Style.EasyThenHard: d.Curve = new TransitionCurve { A = 0, B = 1, Bias = 0 }; break;
                case Style.HardThenEasy: d.Curve = new TransitionCurve { A = 1, B = 0, Bias = 0 }; break;
                case Style.Linear: d.Curve = TransitionCurve.Linear; break;
            }
            return d;
        }

        public override void OnGUI(Rect rect, SerializedProperty property, GUIContent label)
        {
            float floatFieldWidth = EditorGUIUtility.fieldWidth + 2;

            // Using BeginProperty / EndProperty on the parent property means that
            // prefab override logic works on the entire property.
            EditorGUI.BeginProperty(rect, label, property);

            var curveProp = property.FindPropertyRelative(() => myClass.Curve);
            var aProp = curveProp.FindPropertyRelative(() => myClass.Curve.A);
            var bProp = curveProp.FindPropertyRelative(() => myClass.Curve.B);
            var biasProp = curveProp.FindPropertyRelative(() => myClass.Curve.Bias);
            var lengthProp = property.FindPropertyRelative(() => myClass.Length);

            if (m_LengthGUI == null)
            {
                m_LengthGUI = new GUIContent(
                    string.IsNullOrEmpty(m_LengthLabel) ? " s" : " " + m_LengthLabel, 
                    string.IsNullOrEmpty(m_LengthTooltip) ? lengthProp.tooltip : m_LengthTooltip);
                m_LengthTextSize = GUI.skin.label.CalcSize(m_LengthGUI);
                m_CurveGUI = new GUIContent("", "Defines the shape of the transition (expand for details)");
            }

            Rect r = rect; r.width = r.height = EditorGUIUtility.singleLineHeight;
            r = EditorGUI.PrefixLabel(rect, GUIUtility.GetControlID(FocusType.Passive), label);
            r.height = EditorGUIUtility.singleLineHeight;
            r.width -= floatFieldWidth + m_LengthTextSize.x;

            var indentLevel = new InspectorUtility.IndentOverride(0);
            property.isExpanded = EditorGUI.Foldout(r, property.isExpanded, m_CurveGUI);

            // Style dropdown
            myClass.Curve = new TransitionCurve 
                { A = aProp.floatValue, B = bProp.floatValue, Bias = biasProp.floatValue };
            myClass.Length = lengthProp.floatValue;
            Style style = ToStyle(myClass);
            EditorGUI.BeginChangeCheck();
            style = (Style)EditorGUI.EnumPopup(r, GUIContent.none, style);
            if (EditorGUI.EndChangeCheck())
            {
                myClass = FromStyle(style, myClass);
                if (style == Style.Custom && ToStyle(myClass) != Style.Custom)
                {
                    // Just perturb it a bit
                    myClass.Curve.A += 0.01f;
                    myClass.Curve.B += 0.01f;
                }
                aProp.floatValue = myClass.Curve.A;
                bProp.floatValue = myClass.Curve.B;
                biasProp.floatValue = myClass.Curve.Bias;
                lengthProp.floatValue = myClass.Length;
            }

            // Duration
            float oldWidth = EditorGUIUtility.labelWidth;
            EditorGUIUtility.labelWidth = m_LengthTextSize.x;
            r.x += r.width; r.width = floatFieldWidth + EditorGUIUtility.labelWidth;
            EditorGUI.BeginChangeCheck();
            EditorGUI.PropertyField(r, lengthProp, m_LengthGUI);
            if (EditorGUI.EndChangeCheck())
                lengthProp.floatValue = Mathf.Max(lengthProp.floatValue, 0);
            EditorGUIUtility.labelWidth = oldWidth;

            // Curve if expanded
            if (property.isExpanded)
            {
                bool wasEnabled = GUI.enabled;
                GUI.enabled = style != Style.None;
                ++EditorGUI.indentLevel;
                r.height += EditorGUIUtility.standardVerticalSpacing;
                r = new Rect(rect.x, rect.y + r.height, rect.width, rect.height - r.height);
                curveDrawer.DrawProperty(r, curveProp, GUIContent.none, IsInverted());
                --EditorGUI.indentLevel;
                GUI.enabled = wasEnabled;
            }
            EditorGUI.EndProperty();
        }

        bool IsInverted()
        {
            var attrs = fieldInfo.GetCustomAttributes(typeof(InvertedTransitionGraphAttribute), false);
            return (attrs != null && attrs.Length > 0);
        }
    }
}
