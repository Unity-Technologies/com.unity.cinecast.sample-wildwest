#if CINEMACHINE_UNITY_PHYSICS

using UnityEngine;
using UnityEditor;
using Unity.Physics.Authoring;
using System.Linq;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Editor
{
    static class Styles
    {
        public const float CreateAssetButtonWidth = 24;

        public static readonly string CompatibilityWarning = L10n.Tr("Not compatible with {0}.");
        public static readonly string CreateAssetButtonTooltip =
            L10n.Tr("Click to create a {0} asset and define category names.");
        public static readonly string MultipleAssetsTooltip =
            L10n.Tr("Multiple {0} assets found. UI will display labels defined in {1}.");

        public static readonly GUIContent CreateAssetLabel = new GUIContent { text = "+" };
        public static readonly GUIContent MultipleAssetsWarning =
            new GUIContent { image = EditorGUIUtility.Load("console.warnicon") as Texture };
    }

    [CustomPropertyDrawer(typeof(UnityPhysicsLayerMaskAttribute))]
    internal sealed class PhysicsLayerMaskPropertyDrawer : PropertyDrawer
    {
        static readonly string DefaultCategoryFormatString = L10n.Tr("(Undefined Category {0})");
        public static readonly string[] DefaultCategoriesOptions =
            Enumerable.Range(0, 32).Select(i => string.Format(DefaultCategoryFormatString, i)).ToArray();

        string[] m_CategoriesOptionNames;
        PhysicsCategoryNames[] m_CategoriesAssets;

        void GetOptionsAndNameAssets()
        {
            if (m_CategoriesOptionNames != null)
                return;
            var defaultOptions = DefaultCategoriesOptions;
            var guids = AssetDatabase.FindAssets($"t:{typeof(PhysicsCategoryNames).Name}");
            m_CategoriesAssets = guids
                .Select(AssetDatabase.GUIDToAssetPath)
                .Select(AssetDatabase.LoadAssetAtPath<PhysicsCategoryNames>)
                .Where(c => c != null)
                .ToArray();
            m_CategoriesOptionNames = m_CategoriesAssets.FirstOrDefault()?.CategoryNames.ToArray() ?? defaultOptions;
            for (var i = 0; i < m_CategoriesOptionNames.Length; ++i)
                m_CategoriesOptionNames[i] = string.IsNullOrEmpty(m_CategoriesOptionNames[i])
                    ? defaultOptions[i] : m_CategoriesOptionNames[i];
        }

        public override void OnGUI(Rect rect, SerializedProperty property, GUIContent label)
        {
            GetOptionsAndNameAssets();

            if (m_CategoriesAssets?.Length == 0)
                rect.xMax -= Styles.CreateAssetButtonWidth + EditorGUIUtility.standardVerticalSpacing;
            else if (m_CategoriesAssets?.Length > 1)
                rect.xMax -= EditorGUIUtility.singleLineHeight + EditorGUIUtility.standardVerticalSpacing;

            var savedMixed = EditorGUI.showMixedValue;

            EditorGUI.BeginProperty(rect, label, property);
            var controlPosition = EditorGUI.PrefixLabel(rect, label);
            EditorGUI.showMixedValue = property.hasMultipleDifferentValues;
            property.intValue = EditorGUI.MaskField(
                controlPosition, GUIContent.none, property.intValue, m_CategoriesOptionNames);
            EditorGUI.EndProperty();

            EditorGUI.showMixedValue = savedMixed;

            if (m_CategoriesAssets?.Length == 0)
            {
                rect.width = Styles.CreateAssetButtonWidth;
                rect.x = controlPosition.xMax + EditorGUIUtility.standardVerticalSpacing;
                Styles.CreateAssetLabel.tooltip =
                    string.Format(Styles.CreateAssetButtonTooltip, ObjectNames.NicifyVariableName(typeof(PhysicsCategoryNames).Name));
                if (GUI.Button(rect, Styles.CreateAssetLabel, EditorStyles.miniButton))
                {
                    var assetPath =
                        AssetDatabase.GenerateUniqueAssetPath($"Assets/{typeof(PhysicsCategoryNames).Name}.asset");
                    AssetDatabase.CreateAsset(ScriptableObject.CreateInstance<PhysicsCategoryNames>(), assetPath);
                    Selection.activeObject = AssetDatabase.LoadAssetAtPath<PhysicsCategoryNames>(assetPath);
                    m_CategoriesOptionNames = null;
                }
            }
            else if (m_CategoriesAssets.Length > 1)
            {
                var id = GUIUtility.GetControlID(FocusType.Passive);
                if (Event.current.type == EventType.Repaint)
                {
                    rect.width = EditorGUIUtility.singleLineHeight;
                    rect.x = controlPosition.xMax + EditorGUIUtility.standardVerticalSpacing;
                    Styles.MultipleAssetsWarning.tooltip = string.Format(
                        Styles.MultipleAssetsTooltip,
                        ObjectNames.NicifyVariableName(typeof(PhysicsCategoryNames).Name),
                        m_CategoriesAssets.FirstOrDefault(n => n != null)?.name
                    );
                    GUIStyle.none.Draw(rect, Styles.MultipleAssetsWarning, id);
                }
            }
        }
    }
}
#endif
