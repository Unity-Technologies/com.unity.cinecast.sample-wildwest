using UnityEngine;
using UnityEditor;
using System;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Editor
{
    [CustomPropertyDrawer(typeof(InputAxisWithName))]
    internal sealed class InputAxisWithNamePropertyDrawer : PropertyDrawer
    {
        InputAxisWithName def = new InputAxisWithName(); // to access name strings

        public override void OnGUI(Rect rect, SerializedProperty property, GUIContent label)
        {
            float height = EditorGUIUtility.singleLineHeight;
            rect.height = height;

            int oldIndent = EditorGUI.indentLevel;
            float oldLabelWidth = EditorGUIUtility.labelWidth;
            float indentOffset = oldIndent * 15f;
            float w = indentOffset + oldLabelWidth;
            property.isExpanded = EditorGUI.Foldout(
                new Rect(rect.x, rect.y, w, rect.height),
                property.isExpanded, label, true);

            // Is the axis name valid?
            var nameProp = property.FindPropertyRelative(() => def.InputName);
            string nameError = string.Empty;
            var nameValue = nameProp.stringValue;
            if (nameValue.Length > 0)
                try { ClientHooks.GetInputAxis(nameValue); }
                catch (ArgumentException e) { nameError = e.Message; }

            // Draw the input name on the same line as the foldout
            var nameLabel = new GUIContent(nameProp.displayName, nameProp.tooltip);
            EditorGUI.indentLevel = 0;
            EditorGUIUtility.labelWidth = GUI.skin.label.CalcSize(nameLabel).x;
            Rect r = new Rect(rect.x + w, rect.y, rect.width - w, rect.height);
            EditorGUI.PropertyField(r, nameProp, nameLabel);

            // Show an error icon if there's a problem
            if (nameError.Length > 0)
            {
                r.x += r.width - (height + EditorGUIUtility.standardVerticalSpacing);
                EditorGUI.LabelField(r, new GUIContent(
                    EditorGUIUtility.IconContent("console.erroricon.sml").image,
                    nameError));
            }

            EditorGUI.indentLevel = oldIndent;
            EditorGUIUtility.labelWidth = oldLabelWidth;

            if (property.isExpanded)
            {
                ++EditorGUI.indentLevel;
                rect.y += height + EditorGUIUtility.standardVerticalSpacing;
                EditorGUI.PropertyField(rect, property.FindPropertyRelative(() => def.Axis));
                --EditorGUI.indentLevel;
            }
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            if (property == null || !property.isExpanded)
                return EditorGUIUtility.singleLineHeight + EditorGUIUtility.standardVerticalSpacing;
            float height = 0;
            var childProperty = property.Copy();
            var endProperty = childProperty.GetEndProperty();
            childProperty.NextVisible(true);
            while (!SerializedProperty.EqualContents(childProperty, endProperty))
            {
                height += EditorGUI.GetPropertyHeight(childProperty)
                    + EditorGUIUtility.standardVerticalSpacing;
                childProperty.NextVisible(false);
            }
            return height - EditorGUIUtility.standardVerticalSpacing;
        }
    }
}
