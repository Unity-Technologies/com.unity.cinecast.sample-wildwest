using UnityEngine;
using UnityEditor;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Editor
{
    [CustomPropertyDrawer(typeof(OrbitalFollow.Orbit))]
    internal sealed class OrbitPropertyDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect rect, SerializedProperty property, GUIContent label)
        {
            var def = new OrbitalFollow.Orbit();
            InspectorUtility.MultiPropertyOnLine(
                rect, label,
                new [] { property.FindPropertyRelative(() => def.Height),
                        property.FindPropertyRelative(() => def.Radius) },
                null);
        }
    }
}
