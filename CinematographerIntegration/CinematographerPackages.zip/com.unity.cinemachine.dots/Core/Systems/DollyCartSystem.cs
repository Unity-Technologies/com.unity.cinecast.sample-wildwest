using UnityEngine;
using Unity.Entities;
using System;
using Unity.Transforms;
using Unity.Jobs;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct DollyCart : IComponentData
    {
        /// <summary>The path to follow</summary>
        [Tooltip("The path to follow")]
        [HideInInspector]
        public CachedStableEntityReference PathKey;

        /// <summary>How to interpret the Path Position</summary>
        [Tooltip("How to interpret the Path Position.  If set to Path Units, values are as follows: "
            + "0 represents the first waypoint on the path, 1 is the second, and so on.  "
            + "Values in-between are points on the path in between the waypoints.  "
            + "If set to Distance, then Path Position represents distance along the path.")]
        public TCBSplinePathSystem.PositionUnits PositionUnits;

        /// <summary>The cart's current position on the path, in distance units</summary>
        [Tooltip("The position along the path at which the cart will be placed.  "
            + "This can be animated directly or, if the velocity is non-zero, will be updated "
            + "automatically.  The value is interpreted according to the Position Units setting.")]
        public float Position;

        /// <summary>Move the cart with this speed</summary>
        [Tooltip("Move the cart with this speed along the path.  The value is interpreted according "
            + "to the Position Units setting.")]
        public float Speed;
    }

    /// <summary>
    /// This is a very simple behaviour that constrains its transform to a Path.
    /// It can be used to animate any objects along a path, or as a Follow target for
    /// Cinemachine cameras.
    /// </summary>
    [UpdateAfter(typeof(TCBSplinePathSystem))]
    public partial class DollyCartSystem : SystemBase
    {
        StableIDEntityManager m_bindingKeySystem;

        protected override void OnCreate()
        {
            m_bindingKeySystem = World.GetOrCreateSystem<StableIDEntityManager>();
        }

        protected override void OnUpdate()
        {
            Dependency = m_bindingKeySystem.GetDereferencer(Dependency, out var pathLookup);

            var deltaTime = ClientHooks.GetDeltaTime(World);
            var paths = GetComponentDataFromEntity<TCBSplinePathState>(isReadOnly: true);
            var waypoints = GetBufferFromEntity<TCBSplinePathWaypointElement>(isReadOnly: true);

            Entities
                .WithName("DollyCartJob")
                .WithReadOnly(pathLookup)
                .WithReadOnly(waypoints)
                .WithReadOnly(paths)
                .ForEach((
                    ref DollyCart dolly,
                    ref Translation posState,
                    ref Rotation rotState) =>
                {
                    if (!pathLookup.Resolve(ref dolly.PathKey, out Entity pathEntity))
                        return;

                    if (!waypoints.HasComponent(pathEntity) || !paths.HasComponent(pathEntity))
                        return; // no path

                    DynamicBuffer<TCBSplinePathWaypointElement> wp = waypoints[pathEntity];
                    TCBSplinePathState pathState = paths[pathEntity];

                    dolly.Position = dolly.Position + dolly.Speed * deltaTime;
                    dolly.Position = TCBSplinePathSystem.ClampUnit(
                        ref wp, ref pathState, dolly.Position, dolly.PositionUnits);

                    float p = TCBSplinePathSystem.ToNativePathUnits(
                        ref wp, ref pathState, dolly.Position, dolly.PositionUnits);
                    posState.Value = TCBSplinePathSystem.EvaluatePosition(p, ref pathState, ref wp);
                    rotState.Value = TCBSplinePathSystem.EvaluateOrientation(p, ref pathState, ref wp);
                })
                .ScheduleParallel();

            m_bindingKeySystem.RegisterDereferencerReadJobs(Dependency);
        }
    }
}
