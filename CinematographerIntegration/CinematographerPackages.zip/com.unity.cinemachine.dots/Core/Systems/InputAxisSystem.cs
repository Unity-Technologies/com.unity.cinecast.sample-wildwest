using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Burst;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct InputAxisControl
    {
        /// <summary>The value of the input control.  A value of 0 means no input
        /// You can drive this directly from a
        /// custom input system, or you can set the Axis Name and have the value
        /// driven by the internal Input Manager</summary>
        [Tooltip("The value of the input control.  A value of 0 means no input.  You can drive "
            + "this directly from a custom input system, or you can set the Axis Name and "
            + "have the value driven by the internal Input Manager")]
        public float InputValue;

        /// <summary>Multiply the input by this amount prior to processing.
        /// Controls the input power</summary>
        [Tooltip("Multiply the input by this amount prior to processing.  Controls the input power.")]
        public float Multiplier;

        /// <summary>The amount of time in seconds it takes to accelerate to
        /// MaxSpeed with the supplied Axis at its maximum value</summary>
        [Tooltip("The amount of time in seconds it takes to accelerate to MaxSpeed with the "
            + "supplied Axis at its maximum value")]
        public float AccelTime;

        /// <summary>The amount of time in seconds it takes to decelerate
        /// the axis to zero if the supplied axis is in a neutral position</summary>
        [Tooltip("The amount of time in seconds it takes to decelerate the axis to zero if "
            + "the supplied axis is in a neutral position")]
        public float DecelTime;

        // Cheating: storing state info here
        internal FixedString32Bytes NativeName;
        internal float CurrentSpeed;
        internal double InputTime;

        /// <summary>Call from OnValidate: Make sure the fields are sensible</summary>
        public void Validate()
        {
            AccelTime = math.max(0, AccelTime);
            DecelTime = math.max(0, DecelTime);
        }

        public void Reset()
        {
            InputValue = 0;
            CurrentSpeed = 0;
            InputTime = 0;
        }
    }

    [Serializable]
    public struct InputAxisValue
    {
        /// <summary>The current value of the axis.  You can drive this directly from a custom
        /// input system, or you can have it driven automatically by providing a valid input name
        /// and have the value driven by the internal Input Manager</summary>
        [Tooltip("The current value of the axis.  You can drive this directly from a custom"
            + "input system, or you can have it driven automatically by providing a valid input name"
            + "and have the value driven by the internal Input Manager")]
        public float Value;

        /// <summary>The valid range for the axis value</summary>
        [Tooltip("The valid range for the axis value")]
        [Float2AsRangeProperty]
        public float2 Range;

        /// <summary>If set, then the axis will wrap around at the min/max values, forming a loop</summary>
        [Tooltip("If set, then the axis will wrap around at the min/max values, forming a loop")]
        public bool Wrap;

        /// <summary>Clamp the value to range, taking wrap into account</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float ClampValue(float v)
        {
            float r = Range.y - Range.x;
            var v1 = (v - Range.x) % r;
            v1 += math.select(0, r, v1 < 0);
            v1 += Range.x;
            v1 = math.select(v, v1, Wrap && r > MathHelpers.Epsilon);
            return math.clamp(v1, Range.x, Range.y);
        }

        /// <summary>Clamp and scale the value to range 0...1, taking wrap into account</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetNormalizedValue()
        {
            float v = ClampValue(Value);
            float r = Range.y - Range.x;
            return (v - Range.x) / math.select(1, r, r > MathHelpers.Epsilon);
        }

        /// <summary>Return clamped value</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetClampedValue()
        {
            return ClampValue(Value);
        }
    }

    [Serializable]
    public struct InputAxisRecentering
    {
        /// <summary>If set, will enable automatic Recentering of the axis</summary>
        [Tooltip("If set, will enable automatic Recentering of the axis")]
        public bool Enabled;

        /// <summary>The value to which recentring will bring the axis</summary>
        [Tooltip("The value to which recentring will bring the axis.")]
        public float Center;

        /// <summary>If no input has been detected, the camera will wait
        /// this long in seconds before moving its heading to the default heading.</summary>
        [Tooltip("If no user input has been detected on the axis, the axis will wait this "
            + "long in seconds before Recenter.")]
        public float Wait;

        /// <summary>How long it takes to reach destination once Recenter. has started</summary>
        [Tooltip("How long it takes to reach destination once Recenter. has started.")]
        public float Time;
    }

    [Serializable]
    public struct InputAxis
    {
        [HideFoldout]
        public InputAxisValue Value;
        public InputAxisControl InputControl;
        public InputAxisRecentering Recentering;

        public static InputAxis WithInputName(InputAxis axis, string name)
        {
            axis.InputControl.NativeName = name;
            return axis;
        }

        public void Validate()
        {
            InputControl.Validate();
            Value.Range.y = math.max(Value.Range.x, Value.Range.y);
            Recentering.Wait = math.max(0, Recentering.Wait);
            Recentering.Time = math.max(0, Recentering.Time);
            Recentering.Center = math.clamp(Recentering.Center, Value.Range.x, Value.Range.y);
        }

        public void Reset()
        {
            InputControl.Reset();
            if (Recentering.Enabled)
                Value.Value = Recentering.Center;
        }

        public void RecenterNow() { InputControl.InputTime = 0; }
        public void CancelRecentering (double timeNow) { InputControl.InputTime = timeNow; }
    }

    /// <summary>
    /// This is used for authoring
    /// </summary>
    [Serializable]
    public struct InputAxisWithName
    {
        /// <summary>Legacy Input System axis name that will drive this axis.
        /// Leave blank if driving manually</summary>
        [Tooltip("Legacy Input System axis name that will drive this axis.  "
            + "Leave blank if driving manually")]
        public string InputName;

        /// <summary>The input axis that will be driven by the named input channel</summary>
        [Tooltip("The input axis that will be driven by the named input channel")]
        [HideFoldout]
        public InputAxis Axis;
    }

    [Serializable]
    public struct InputAxisXYZ : IBufferElementData
    {
        public InputAxis X;
        public InputAxis Y;
        public InputAxis Z;
        public bool DecoupledRecentering;

        /// <summary>
        /// Add an InputAxisXYZ buffer element to an entity.  Call this at conversion time.
        /// </summary>
        /// <param name="m">The entity manager for this world</param>
        /// <param name="entity">The entitiy to which to asdd the InputAxisXYZ element</param>
        /// <param name="xyz"></param>
        /// <returns>Returns the index within DynamicBuffer<InputAxisXYZ> corresponding to this input.
        /// Use the index when reading this input buffer.</returns>
        public static int AddInputToEntity(EntityManager m, Entity entity, in InputAxisXYZ xyz)
        {
            var buffer = m.AddBuffer<InputAxisXYZ>(entity);
            var index = buffer.Length;
            buffer.Add(xyz);
            return index;
        }
    }

    public partial class LegacyInputSystem : SystemBase
    {
        NativeHashMap<FixedString32Bytes, float> m_InputValues;

        EntityQuery m_inputQuery;

        protected override void OnCreate()
        {
            m_inputQuery = GetEntityQuery(ComponentType.ReadWrite<InputAxisXYZ>());
            m_InputValues = new NativeHashMap<FixedString32Bytes, float>();
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            if (m_InputValues.IsCreated)
                m_InputValues.Dispose();
        }

        float ReadInputAxis(string name)
        {
            float value = 0;
            if (name.Length != 0)
            {
                try { value = ClientHooks.GetInputAxis(name); }
                catch (ArgumentException) {}
            }
            return value;
        }

        protected override void OnUpdate()
        {
            // Read the legacy input values
            // GML todo: this is terrible.  The whole treatment of user input needs to be rethought
            var inputs = GetBufferFromEntity<InputAxisXYZ>(true);
            var entities = m_inputQuery.ToEntityArray(Allocator.TempJob);
            int numInputs = 0;
            for (int i = 0; i < entities.Length; ++i)
                numInputs += inputs[entities[i]].Length * 3;
            if (numInputs == 0)
                return;

            if (!m_InputValues.IsCreated || m_InputValues.Capacity < numInputs)
            {
                if (m_InputValues.IsCreated)
                    m_InputValues.Dispose();
                m_InputValues = new NativeHashMap<FixedString32Bytes, float>(numInputs, Allocator.Persistent);
            }

            // Read the legacy input system
            m_InputValues.Clear();
            for (int i = 0; i < entities.Length; ++i)
            {
                var buffer = inputs[entities[i]];
                for (int j = 0; j < buffer.Length; ++j)
                {
                    var n = buffer[j].X.InputControl.NativeName;
                    if (n.Length > 0 && !m_InputValues.ContainsKey(n))
                        m_InputValues[n] = ReadInputAxis(n.ToString());
                    n = buffer[j].Y.InputControl.NativeName;
                    if (n.Length > 0 && !m_InputValues.ContainsKey(n))
                        m_InputValues[n] = ReadInputAxis(n.ToString());
                    n = buffer[j].Z.InputControl.NativeName;
                    if (n.Length > 0 && !m_InputValues.ContainsKey(n))
                        m_InputValues[n] = ReadInputAxis(n.ToString());
                }
            }
            entities.Dispose();

            // Push the values to the interested parties
            var job = new LegacyInputDriverJob()
            {
                InputAxisXYZAccessor = GetBufferTypeHandle<InputAxisXYZ>(),
                
                InputValues = m_InputValues,
                DeltaTime = Time.DeltaTime,
                TimeNow = DateTime.UtcNow.ToFileTimeUtc() * 1e-7
            };
            Dependency = job.Schedule(m_inputQuery, Dependency);
        }

        [BurstCompile]
        struct LegacyInputDriverJob : IJobEntityBatch
        {
            public BufferTypeHandle<InputAxisXYZ> InputAxisXYZAccessor;
            
            [ReadOnly] public NativeHashMap<FixedString32Bytes, float> InputValues;
            public float DeltaTime;
            public double TimeNow;

            public void Execute(ArchetypeChunk batch, int batchIndex)
            {
                var inputXYZs = batch.GetBufferAccessor(InputAxisXYZAccessor);

                for (int i = 0; i < batch.Count; ++i)
                {
                    var inputXYZbuffer = inputXYZs[i];
                    for (int j = 0; j < inputXYZbuffer.Length; ++j)
                    {
                        var inputXYZ = inputXYZbuffer[j];

                        var changedTime = new double3(
                            UpdateAxis(ref inputXYZ.X), UpdateAxis(ref inputXYZ.Y), UpdateAxis(ref inputXYZ.Z));
                        var mostRecent = math.max(math.max(changedTime.x, changedTime.y), changedTime.z);

                        // If coupled, input on any axis cancels recentering on all axes
                        inputXYZ.X.InputControl.InputTime = math.select(mostRecent, changedTime.x, inputXYZ.DecoupledRecentering);
                        inputXYZ.Y.InputControl.InputTime = math.select(mostRecent, changedTime.y, inputXYZ.DecoupledRecentering);
                        inputXYZ.Z.InputControl.InputTime = math.select(mostRecent, changedTime.z, inputXYZ.DecoupledRecentering);

                        // Do recentering
                        DoRecentering(ref inputXYZ.X);
                        DoRecentering(ref inputXYZ.Y);
                        DoRecentering(ref inputXYZ.Z);

                        inputXYZbuffer[j] = inputXYZ;
                    }
                }
            }

            double UpdateAxis(ref InputAxis axis)
            {
                if (InputValues.TryGetValue(axis.InputControl.NativeName, out float input))
                    axis.InputControl.InputValue = input;
                else
                    input = axis.InputControl.InputValue;

                axis.InputControl.InputTime = math.select(
                    axis.InputControl.InputTime, TimeNow, math.abs(input) > MathHelpers.Epsilon);
                input *= axis.InputControl.Multiplier;
                if (DeltaTime < MathHelpers.Epsilon)
                    axis.InputControl.CurrentSpeed = 0;
                else
                {
                    float speed = input / DeltaTime;
                    float dampTime = math.select(
                        axis.InputControl.AccelTime, axis.InputControl.DecelTime,
                        math.abs(speed) < math.abs(axis.InputControl.CurrentSpeed));
                    speed = axis.InputControl.CurrentSpeed + MathHelpers.Damp(
                        speed - axis.InputControl.CurrentSpeed, dampTime, DeltaTime);
                    axis.InputControl.CurrentSpeed = speed;

                    // Decelerate to the end points of the range if not wrapping
                    float range = axis.Value.Range.y - axis.Value.Range.x;
                    if (!axis.Value.Wrap && axis.InputControl.DecelTime > MathHelpers.Epsilon
                        && range > MathHelpers.Epsilon)
                    {
                        float v0 = axis.Value.GetClampedValue();
                        float v = axis.Value.ClampValue(v0 + speed * DeltaTime);
                        float d = math.select(v - axis.Value.Range.x, axis.Value.Range.y - v, speed > 0);
                        if (d < (0.1f * range) && math.abs(speed) > MathHelpers.Epsilon)
                            speed = MathHelpers.Damp(v - v0, axis.InputControl.DecelTime, DeltaTime) / DeltaTime;
                    }
                    input = speed * DeltaTime;
                }
                axis.Value.Value = axis.Value.ClampValue(axis.Value.Value + input);
                return axis.InputControl.InputTime;
            }

            void DoRecentering(ref InputAxis axis)
            {
                float v = axis.Value.GetClampedValue();
                float delta = axis.Recentering.Center - v;
                if (axis.Recentering.Enabled && delta != 0
                    && TimeNow > (axis.InputControl.InputTime + axis.Recentering.Wait))
                {
                    // Determine the direction
                    float target = axis.Recentering.Center;
                    float r = axis.Value.Range.y - axis.Value.Range.x;
                    v += math.select(
                        0, math.select(r, -r, v > target),
                        axis.Value.Wrap && math.abs(delta) > r * 0.5f);

                    // Damp our way there
                    v += MathHelpers.Damp(target - v, axis.Recentering.Time, DeltaTime);
                    axis.Value.Value = v;
                }
            }
        }
    }
}
