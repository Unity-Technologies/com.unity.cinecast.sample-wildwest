using System;
using System.Collections.Generic;
using System.Threading;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// Each node is associated with a specific channel.  Channels each do their
    /// own blending and prioritization.
    /// </summary>
    [Serializable]
    public struct CmChannel : IComponentData
    {
        [Serializable]
        public struct ChannelSettings
        {
            /// <summary>
            /// Because cameras need to know which way up is, it's possible to override that
            /// GML todo: this should be an object reference, so value can mutate in state data
            /// </summary>
            public float3 WorldPosition;
            public quaternion WorldOrientation;

            public float Aspect;

            public enum ProjectionType
            {
                Perspective,
                Orthographic
            }
            public ProjectionType Projection;

            public bool IsOrthographic { get { return Projection == ProjectionType.Orthographic; } }
        }
        [HideInInspector]
        public ChannelSettings Settings;

        public enum SortMode
        {
            PriorityThenQuality,
            QualityThenPriority,
            Custom
        };
        public SortMode Sorting;

        /// <summary>Wait this many seconds before activating a new node</summary>
        public float ActivateAfter;

        /// <summary>An active node must be active for at least this many seconds</summary>
        public float MinDuration;

        /// <summary>
        /// The blend that is used if you don't explicitly define a blend between two nodes.
        /// </summary>
        [TransitionDefinitionUnitsLabel("s", "The duration (in seconds) of the blend")]
        public TransitionDefinition DefaultBlend;

        public static CmChannel Default
        {
            get
            {
                return new CmChannel
                {
                    Settings = new ChannelSettings
                    {
                        WorldOrientation = quaternion.identity,
                        Aspect = 1
                    }
                };
            }
        }

        public void Validate()
        {
            Settings.WorldOrientation = math.normalizesafe(
                Settings.WorldOrientation, quaternion.identity);
            ActivateAfter = math.max(0, ActivateAfter);
            MinDuration = math.max(0, MinDuration);
        }
    }

    public struct CmChannelState : IComponentData
    {
        public float DeltaTime;
        public double ActivationTime;
        public Entity ActiveNode;
        public bool PreviousStateIsValid;

        public Entity DesiredActiveNode;
        public double CurrentTime;
        public Entity PendingNode;
        public double PendingActivationTime;
        public Entity PreviousActiveNode;
        public bool IsCut;

        internal int CacheIndex;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraFinalizeSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CmChannelSystem : CinemachineSystemBase
    {
        ChannelCache m_ChannelCache;
        NativeHashMap<StableKey, Entity> m_ChannelLookup = new NativeHashMap<StableKey, Entity>();
        uint m_RandomSeed = 0x9F6ABC1;


        List<ChannelCache.Item> GetChannelCache(bool recalculate)
        {
            ActiveChannelStateJobs.Complete(); // GML is this necessary?
            if (recalculate || m_ChannelCache.Cache == null)
            {
                var channels = m_channelsQuery.ToEntityArray(Allocator.TempJob);
                m_ChannelCache.RecreateCache(channels, World);
                channels.Dispose();
            }
            return m_ChannelCache.Cache;
        }

        public struct ChannelIterationInfo
        {
            public NodeChannelAssignment Filter;
            public CmChannel.ChannelSettings Settings;
            public CmChannelState State;
            public Entity ChannelEntity;
            public int NestLevel;
        }
        List<ChannelIterationInfo> m_channelIterationInfoList = new List<ChannelIterationInfo>();
        public List<ChannelIterationInfo> GetChannelsForFiltering() { return m_channelIterationInfoList; }

        public NativeHashMap<StableKey, Entity> GetChannelLookup()
        {
            // GML todo cache this properly
            ActiveChannelStateJobs.Complete();
            var cache = GetChannelCache(false);
            if (m_ChannelLookup.IsCreated && m_ChannelLookup.Capacity != cache.Count + 1)
                m_ChannelLookup.Dispose();
            if (!m_ChannelLookup.IsCreated)
                m_ChannelLookup = new NativeHashMap<StableKey, Entity>(
                    cache.Count + 1, Allocator.Persistent);
            m_ChannelLookup.Clear();
            for (int i = 0; i < cache.Count; ++i)
            {
                m_ChannelLookup[cache[i].k] = cache[i].e;
                if (cache[i].IsDefaultChannel)
                    m_ChannelLookup[default] = cache[i].e;
            }
            return m_ChannelLookup;
        }

        public void RegisterChannelLookupReadDependencies(JobHandle deps)
        {
            ActiveChannelStateJobs = JobHandle.CombineDependencies(ActiveChannelStateJobs, deps);
        }

        public Entity GetChannelEntity(StableKey channelId)
        {
            var cache = GetChannelCache(false);
            for (int i = 0; i < cache.Count; ++i)
            {
                var e = cache[i];
                if (e.k == channelId || (channelId == default && e.IsDefaultChannel))
                    return e.e;
            }
            return Entity.Null;
        }

        /// <summary>
        /// Get all the nodes that are currently live
        /// </summary>
        /// <param name="channel">Which top-level channel to examine</param>
        /// <param name="nodes">Output the live nodes here</param>
        /// <param name="deep">If true, recurse into the live channels</param>
        public void GetLiveNodes(StableKey channelId, List<CmNode> nodes, bool deep)
        {
            ActiveChannelStateJobs.Complete();
            var e = GetChannelEntity(channelId);
            nodes.Clear();
            if (World == null || !World.SafeHasComponent<CurrentNodeBlendElement>(e))
                return;
            World.EntityManager.GetBuffer<CurrentNodeBlendElement>(e).GetLiveNodes(nodes, World);
            if (deep)
            {
                int start = 0;
                int end = nodes.Count;
                while (end > start)
                {
                    for (int i = start; i < end; ++i)
                    {
                        if (EntityManager.HasComponent<CurrentNodeBlendElement>(nodes[i].Entity))
                        {
                            // Don't add twice
                            bool alreadyAdded = false;
                            for (int j = i - 1; j >= 0 && !alreadyAdded; --j)
                                alreadyAdded = (nodes[j] == nodes[i]);
                            if (alreadyAdded)
                            {
                                nodes.RemoveAt(i--);
                                --end;
                            }
                            else
                            {
                                EntityManager.GetBuffer<CurrentNodeBlendElement>(
                                    nodes[i].Entity).GetLiveNodes(nodes, World);
                            }
                        }
                    }
                    start = end;
                    end = nodes.Count;
                }
            }
        }

        /// <summary>
        /// Initialize the Channel system at the start of the CM pipeline
        /// </summary>
        internal JobHandle InitChannelStates(JobHandle dependency)
        {
            CreateMissingStateComponents();
            var cache = GetChannelCache(true);

            // Get the default channel Settings
            CmChannel.ChannelSettings defaultChannel = new CmChannel.ChannelSettings();
            for (int i = 0; i < cache.Count; ++i)
            {
                if (cache[i].IsDefaultChannel)
                {
                    defaultChannel = cache[i].c.Settings;
                    break;
                }
            }

            // Iterate in leaf-first order
            for (int i = 0; i < cache.Count; ++i)
            {
                var item = cache[m_ChannelCache.LeafFirstCacheSort[i]];
                var e = item.e;

                if (item.TopLevelParentIndex >= 0)
                {
                    var c = item.c;
                    var cTop = cache[item.TopLevelParentIndex].c;
                    var p = cTop.Settings.Projection;
                    if (c.Settings.Aspect != cTop.Settings.Aspect || c.Settings.Projection != p)
                    {
                        c.Settings.Aspect = cTop.Settings.Aspect;
                        c.Settings.Projection = p;
                        item.c = c;
                        EntityManager.SetComponentData(e, item.c);
                    }
                }

                bool isCut = false;
                if (World.SafeHasComponent<NativeNodeBlendElement>(e))
                {
                    var b = World.EntityManager.GetBuffer<NativeNodeBlendElement>(e);
                    if (!b.IsEmpty)
                    {
                        // Resolve any undefined blends
                        var activated = b.GetNewlyActivatedNode(World);
                        b.ResolveUndefinedBlends(item.c.DefaultBlend, World, e);

                        // Detect camera cuts
                        if (!activated.IsNull)
                        {
                            // Take this opportunity to randomize the sequence numbers of channel nodes
                            dependency = RandomizeSequenceNumbers(cache[i].k, dependency, activated.Entity);
                            isCut = b[0].IsCut;
                        }
                        // This works because we're evaluating leaf-most channels first:
                        // Check for a cut inside an active channel node
                        if (!isCut)
                        {
                            var activeChannel = new ChannelHelper(b[0].Blend.Node, World);
                            if (activeChannel.IsChannel)
                                isCut = activeChannel.ChannelState.IsCut;
                        }
                    }
                }

                bool isSolo = false;
                if (World.SafeHasComponent<OverrideNodeBlendElement>(e))
                {
                    var b = World.EntityManager.GetBuffer<OverrideNodeBlendElement>(e);
                    if (b.Length > 0 && b[0].Id == OverrideNodeBlendElement.SoloId
                            && b[0].NodeB != Entity.Null)
                        isSolo = true;
                }
                double timeNow = ClientHooks.GetCurrentTime(World);
#if UNITY_EDITOR
                if (!Application.isPlaying)
                    timeNow = (double)DateTime.UtcNow.ToFileTimeUtc() * 1e-7;
#endif
                if (Application.isPlaying || isSolo)
                    item.state.DeltaTime = ClientHooks.GetDeltaTime(World);
                else
                    item.state.PreviousStateIsValid = false; // not playing, time has no meaning

                if (item.state.CurrentTime == 0 || item.state.CurrentTime > timeNow)
                    item.state.PreviousStateIsValid = false;
                item.state.CurrentTime = timeNow;
                item.state.ActivationTime = math.min(item.state.ActivationTime, timeNow); // In case time was scrubbed back
                item.state.IsCut = isCut;
                EntityManager.SetComponentData(e, item.state);
                cache[m_ChannelCache.LeafFirstCacheSort[i]] = item;
            }

            // Now rebuild the iteration info list - leaf-first sort order
            BuildChannelIterationList(cache, m_ChannelCache.LeafFirstCacheSort);

            return dependency;
        }

        JobHandle RandomizeSequenceNumbers(StableKey channelId, JobHandle dependency, Entity newlyActivated)
        {
            var filter = new NodeChannelAssignment { ChannelId = channelId };
            m_RandomizeSequenceQuery.SetSharedComponentFilter(filter);
            var nodeCount = m_RandomizeSequenceQuery.CalculateEntityCount();
            if (nodeCount > 1)
            {
                var maxSequence = Interlocked.Add(ref m_nodeSequence, nodeCount--);
                var sequences = new NativeList<int>(nodeCount, Allocator.TempJob);
                var random = new Mathematics.Random(m_RandomSeed++);

                dependency = Entities
                    .WithName("RandomizeSequenceNumbers")
                    .WithSharedComponentFilter(filter)
                    .WithDisposeOnCompletion(sequences)
                    .WithStoreEntityQueryInField(ref m_RandomizeSequenceQuery)
                    .ForEach((Entity entity, ref NodeUpdateState updateState) =>
                    {
                        if (sequences.Length == 0)
                        {
                            // Init sequence table
                            var max = maxSequence - 1;
                            for (int i = 0; i < nodeCount; ++i)
                                sequences.Add(max - i);
                        }
                        updateState.Sequence = maxSequence;
                        if (entity != newlyActivated) // newly activated gets highest sequence
                        {
                            var index = random.NextInt(0, sequences.Length);
                            updateState.Sequence = sequences[index];
                            sequences.RemoveAtSwapBack(index);
                        }
                    })
                    .Schedule(dependency);
            }
            return dependency;
        }

        void BuildChannelIterationList(
            List<ChannelCache.Item> cache, NativeArray<int> leafFirstCacheSort)
        {
            m_channelIterationInfoList.Clear();
            bool haveDefault = false;
            for (int i = 0; i < cache.Count; ++i)
            {
                var item = cache[leafFirstCacheSort[i]];
                m_channelIterationInfoList.Add(new ChannelIterationInfo
                {
                    Filter = new NodeChannelAssignment { ChannelId = item.k },
                    Settings = item.c.Settings,
                    State = item.state,
                    ChannelEntity = item.e,
                    NestLevel = item.NestLevel
                });

                // Handle default channel assignment
                if (!haveDefault && item.IsDefaultChannel)
                {
                    m_channelIterationInfoList.Add(new ChannelIterationInfo
                    {
                        Filter = new NodeChannelAssignment { ChannelId = StableKey.Default },
                        Settings = item.c.Settings,
                        State = item.state,
                        ChannelEntity = item.e
                    });
                    haveDefault = true;
                }
            }
        }

        EntityQuery m_channelsQuery;
        EntityQuery m_RandomizeSequenceQuery;
        EntityQuery m_missingChannelStateGroup;

        JobHandle ActiveChannelStateJobs { get; set; }

        static int m_nodeSequence = 1;
        public static int NextNodeSequence { get => Interlocked.Increment(ref m_nodeSequence); }

        protected override void OnCreate()
        {
            m_channelsQuery = GetEntityQuery(
                ComponentType.ReadOnly<NodeChannelAssignment>(),
                ComponentType.ReadOnly<StableKeyData>(),
                ComponentType.ReadOnly<CmChannel>(),
                ComponentType.ReadWrite<CmChannelState>());

            m_missingChannelStateGroup = GetEntityQuery(
                ComponentType.ReadOnly<CmChannel>(),
                ComponentType.Exclude<CmChannelState>());

            m_nodeSequence = 1;
        }

        protected override void OnDestroy()
        {
            ActiveChannelStateJobs.Complete();
            m_ChannelCache.Dispose();
            if (m_ChannelLookup.IsCreated)
                m_ChannelLookup.Dispose();
            base.OnDestroy();
        }

        void CreateMissingStateComponents()
        {
            EntityManager.AddComponent(m_missingChannelStateGroup,
                ComponentType.ReadWrite<CmChannelState>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();
            ActiveChannelStateJobs.Complete();
            var cache = GetChannelCache(false);
            if (cache.Count == 0)
                return;

            var qualities = GetComponentDataFromEntity<NodeUpdateState>();

            Entities
                .WithName("ComputeChannelShotQualityJob")
                .WithAll<NodeChannelAssignment, CmChannelState, NodeUpdateState>()
                .ForEach((
                    Entity entity, 
                    DynamicBuffer<CurrentNodeBlendElement> b) =>
                {
                    // GML TODO C#9 [MethodImpl(MethodImplOptions.AggressiveInlining)]
                    float SafeGetQuality(Entity e)
                    {
                        return qualities.HasComponent(e) ? qualities[e].ShotQuality : 0;
                    }

                    float q = 0;
                    if (b.Length > 0)
                    {
                        q = SafeGetQuality(b[b.Length - 1].Blend.Node);
                        for (int i = b.Length - 2; i >= 0; --i)
                            q = math.lerp(q, SafeGetQuality(b[i].Blend.Node),
                                b[i].Blend.BlendWeight());
                    }
                    var updateState = qualities[entity];
                    updateState.ShotQuality = q;
                    qualities[entity]= updateState;
                })
                .Schedule();

            // Choose the best candidate node on each channel
            bool defaultDone = false;
            for (int i = 0; i < cache.Count; ++i)
            {
                var item = cache[i];
                if (item.c.Sorting == CmChannel.SortMode.Custom)
                    continue; // nothing to do here

                var qualityFirst = item.c.Sorting == CmChannel.SortMode.QualityThenPriority;

                ScheduleFindBestCandidateJob(item.k, qualityFirst, m_ChannelCache.BestCandidateNode, i);

                // If this is the default channel then create the default queue
                if (!defaultDone && item.IsDefaultChannel)
                {
                    ScheduleFindBestCandidateJob(
                        StableKey.Default, qualityFirst, m_ChannelCache.DefaultBestCandidateNode, i);
                    defaultDone = true;
                }
                cache[i] = item;
            }

            var TopCandidate = m_ChannelCache.BestCandidateNode;
            var DefaultTopCandidate = m_ChannelCache.DefaultBestCandidateNode;

            Entities
                .WithName("ApplyBestCandidateJob")
                .WithAll<NodeChannelAssignment, StableKeyData>()
                .ForEach((
                    ref CmChannelState state,
                    in CmChannel c) =>
                {
                    var a = TopCandidate[state.CacheIndex];
                    var b = DefaultTopCandidate[state.CacheIndex];
                    state.DesiredActiveNode = CompareCandidates(
                        a, b, c.Sorting == CmChannel.SortMode.QualityThenPriority) > 0 ? b.Entity : a.Entity;
                })
                .Schedule();

            ActiveChannelStateJobs = Dependency;
        }

        void ScheduleFindBestCandidateJob(
            StableKey key, bool qualityFirst,
            NativeArray<ChannelCache.CandidateInfo> topCandidate, int arrayIndex)
        {
            Entities
                .WithName("FindBestCandidateJob")
                .WithSharedComponentFilter(new NodeChannelAssignment() { ChannelId = key })
                .WithoutBurst()
                .ForEach((
                    Entity entity,
                    in NodePriority priority,
                    in NodeUpdateState updateState) =>
                {
                    var info = new ChannelCache.CandidateInfo
                    {
                        Entity = entity,
                        NodePriority = priority,
                        ShotQuality = updateState.ShotQuality,
                        Sequence = updateState.Sequence
                    };
                    if (!updateState.ForceDisable && CompareCandidates(topCandidate[arrayIndex], info, qualityFirst) > 0)
                        topCandidate[arrayIndex] = info;
                })
                .Schedule();
        }

        static int CompareCandidates(
            in ChannelCache.CandidateInfo x, in ChannelCache.CandidateInfo y, bool qualityFirst)
        {
            int p = y.NodePriority.Priority - x.NodePriority.Priority; // high-to-low
            float qf = y.ShotQuality - x.ShotQuality; // high-to-low
            int q = math.select(math.select(-1, 1, qf >= 0), 0, qf == 0);

            int s = y.Sequence - x.Sequence; // high-to-low
            int e = y.Entity.Index - x.Entity.Index; // high-to-low
            int v = y.Entity.Version - x.Entity.Version; // high-to-low
            var otherStuff = math.select(s, math.select(e, v, e == 0), s == 0);

            return math.select(
                math.select(p, math.select(q, otherStuff, q == 0), p == 0),
                math.select(q, math.select(p, otherStuff, p == 0), q == 0),
                qualityFirst);
        }

    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CmChannelSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CmChannelFinalizeSystem : CinemachineSystemBase
    {
        CmChannelSystem m_channelSystem;

        protected override void OnCreate()
        {
            m_channelSystem = World.GetOrCreateSystem<CmChannelSystem>();
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            Entities
                .WithName("UpdateChannelJob")
                .ForEach((ref CmChannelState state, in CmChannel c) =>
                {
                    float ActivateAfter = c.ActivateAfter;
                    float MinDuration = c.MinDuration;

                    Entity currentNode = state.ActiveNode;
                    Entity desiredNode = state.DesiredActiveNode;
                    if (state.PreviousStateIsValid && state.ActivationTime != 0)
                    {
                        // Is it active now?
                        if (currentNode == desiredNode)
                        {
                            // Yes, cancel any pending
                            state.PendingActivationTime = 0;
                            state.PendingNode = Entity.Null;
                        }

                        // Is it pending?
                        if (state.PendingActivationTime != 0
                            && state.PendingNode == desiredNode)
                        {
                            // Has it not been pending long enough, or are we not allowed to switch away
                            // from the active action?
                            if ((state.CurrentTime - state.PendingActivationTime) < ActivateAfter
                                || (state.CurrentTime - state.ActivationTime) < MinDuration)
                            {
                                desiredNode = currentNode; // sorry, not yet
                            }
                        }

                        if (currentNode != desiredNode
                            && state.PendingNode != desiredNode
                            && (ActivateAfter > 0 || (state.CurrentTime - state.ActivationTime) < MinDuration))
                        {
                            // Too early - make it pending
                            state.PendingNode = desiredNode;
                            state.PendingActivationTime = state.CurrentTime;
                            desiredNode = currentNode;
                        }
                    }

                    if (!state.PreviousStateIsValid || currentNode != desiredNode)
                    {
                        // Change cameras
                        state.ActivationTime = state.CurrentTime;
                        state.PendingActivationTime = 0;
                        state.PendingNode = Entity.Null;
                        state.PreviousActiveNode = currentNode;
                    }

                    state.ActiveNode = desiredNode;
                    state.PreviousStateIsValid = true;
                })
                .ScheduleParallel();

            m_channelSystem.RegisterChannelLookupReadDependencies(Dependency);
        }
    }
}
