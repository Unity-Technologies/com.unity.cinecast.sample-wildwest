using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System;
using UnityEngine;
using System.Runtime.CompilerServices;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct SizeFraming : IComponentData
    {
        public const float kMinScreenFitSize = 0.001f;

        /// <summary>How much of the screen to fill with the bounding box of the targets.</summary>
        [Tooltip("The bounding box of the targets should occupy this amount of the screen space.  "
            + "1 means fill the whole screen.  0.5 means fill half the screen, etc.")]
        [Float2AsRangeProperty]
        public float2 ScreenFit;

        /// <summary>What screen dimensions to consider when framing</summary>
        public enum FramingMode
        {
            /// <summary>Consider only the horizontal dimension.  Vertical framing is ignored.</summary>
            Horizontal,
            /// <summary>Consider only the vertical dimension.  Horizontal framing is ignored.</summary>
            Vertical,
            /// <summary>The larger of the horizontal and vertical dimensions will dominate, to get the best fit.</summary>
            HorizontalAndVertical
        };

        /// <summary>What screen dimensions to consider when framing</summary>
        [Tooltip("What screen dimensions to consider when framing.  "
            + "Can be Horizontal, Vertical, or both")]
        public FramingMode Framing;

        /// <summary>How long it takes to adjust the framing to the desired layout</summary>
        [Tooltip("How long it takes to adjust the framing to the desired layout.")]
        public float Damping;

        /// <summary>How to adjust the camera to get the desired framing</summary>
        public enum AdjustmentMode
        {
            /// <summary>Do not move the camera, only adjust the FOV.</summary>
            ZoomOnly,
            /// <summary>Just move the camera, don't change the FOV.</summary>
            DollyOnly,
            /// <summary>Move the camera as much as permitted by the ranges, then
            /// adjust the FOV if necessary to make the shot.</summary>
            DollyThenZoom
        };

        /// <summary>How to adjust the camera to get the desired framing</summary>
        [Tooltip("How to adjust the camera to get the desired framing.  "
            + "You can zoom, dolly in/out, or do both.")]
        public AdjustmentMode Adjustment;

        /// <summary>The maximum distance that this behaviour is allowed to move the camera>
        [Tooltip("The maximum distance that this behaviour is allowed to move the camera.")]
        [Float2AsRangeProperty]
        public float2 DollyRange;

        /// <summary>Set this to limit how close to the target the camera can get</summary>
        [Tooltip("Set this to limit how close to the target the camera can get.")]
        [Float2AsRangeProperty]
        public float2 TargetDistance;

        /// <summary>If adjusting FOV, will not set the FOV outside of this range</summary>
        [Tooltip("If adjusting FOV, will not set the FOV outside of this range.")]
        [Float2AsRangeProperty]
        public float2 FovRange;

        /// <summary>If adjusting Orthographic Size, will not set it outside of this range</summary>
        [Tooltip("If adjusting Orthographic Size, will not set it outside of this range.")]
        [Float2AsRangeProperty]
        public float2 OrthoSizeRange;
    }

    // Internal use only
    struct SizeFramingState : IComponentData
    {
        public float prevFramingDistance;
        public float prevFOV;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPostAimSystem))]
    [UpdateBefore(typeof(CameraPreNoiseSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class SizeFramingSystem : CinemachineSystemBase
    {
        EntityQuery m_missingStateQuery;

        protected override void OnCreate()
        {
            m_missingStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<SizeFraming>(),
                ComponentType.Exclude<SizeFramingState>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing composer state components
            EntityManager.AddComponent(m_missingStateQuery,
                ComponentType.ReadWrite<SizeFramingState>());

            Entities
                .WithName("SizeFramingJob")
                .ForEach((
                    ref SizeFramingState framingState,
                    ref PositionState posState,
                    in LookAtTargetState lookAt,
                    in SizeFraming framing,
                    in NodeUpdateState updateState) =>
                {
                    if (lookAt.Value.Entity == Entity.Null)
                        return;

                    // GML todo: handle ForcePositionAndRotation

                    bool previousValid = updateState.PreviousFrameDataIsValid
                        && (framingState.prevFOV != 0);

                    if (updateState.Orthographic)
                    {
                        if (lookAt.Value.Radius < SizeFraming.kMinScreenFitSize)
                            return;

                        float h = GetTargetHeight(lookAt.Value.Radius, framing.Framing, updateState.Aspect);
                        float2 height2 = h / math.max(0.01f, framing.ScreenFit);

                        float current = posState.Lens.FOV * 2;
                        float targetHeight = math.select(
                            height2.y,
                            math.select(height2.x, current, current < height2.x),
                            posState.Lens.FOV > height2.y);

                        var limit = framing.OrthoSizeRange * 2;
                        targetHeight = math.clamp(targetHeight, limit.x, limit.y);

                        // Apply damping
                        targetHeight *= 0.5f;
                        targetHeight = math.select(
                            targetHeight,
                            framingState.prevFOV + MathHelpers.Damp(
                                targetHeight - framingState.prevFOV, framing.Damping,
                                updateState.DeltaTime),
                            previousValid);

                        posState.Lens.FOV = framingState.prevFOV = targetHeight;
                    }
                    else
                    {
                        var cameraPos = posState.GetCorrectedPosition();
                        var fwd = lookAt.Value.Position - cameraPos;
                        float d = math.length(fwd);
                        if (d < MathHelpers.Epsilon)
                        {
                            fwd = math.mul(posState.RawRotation, new float3(0, 0, 1));
                            d = 0.01f;
                        }

                        fwd /= d;
                        float h = GetTargetHeight(
                            math.max(SizeFraming.kMinScreenFitSize, lookAt.Value.Radius), framing.Framing, updateState.Aspect);
                        float2 height2 = h / math.max(SizeFraming.kMinScreenFitSize, framing.ScreenFit);

                        // Move the camera
                        if (framing.Adjustment != SizeFraming.AdjustmentMode.ZoomOnly)
                        {
                            // What distance would be needed to get the target height, at the current FOV
                            float2 targetDistance2 = height2 / (2f * math.tan(math.radians(posState.Lens.FOV) * 0.5f));
                            float targetDistance = math.select(
                                targetDistance2.y,
                                math.select(targetDistance2.x, d, d < targetDistance2.x),
                                d > targetDistance2.y);

                            // Clamp to respect min/max distance settings
                            targetDistance = math.clamp(
                                targetDistance, framing.TargetDistance.x, framing.TargetDistance.y);

                            // Clamp to respect min/max camera movement
                            float targetDelta = math.clamp(
                                targetDistance - d, framing.DollyRange.x, framing.DollyRange.y);

                            // Apply damping
                            targetDelta = framingState.prevFramingDistance + MathHelpers.Damp(
                                targetDelta - framingState.prevFramingDistance,
                                math.select(0, framing.Damping, previousValid), updateState.DeltaTime);

                            framingState.prevFramingDistance = targetDelta;
                            posState.RawPosition -= fwd * targetDelta;
                            d += targetDelta;
                        }

                        // Apply zoom
                        if (framing.Adjustment != SizeFraming.AdjustmentMode.DollyOnly)
                        {
                            float current = posState.Lens.FOV;
                            float2 targetFOV2 = 2f * math.degrees(math.atan(height2 / (2 * d)));
                            float targetFOV = math.select(
                                targetFOV2.y,
                                math.select(targetFOV2.x, current, current < targetFOV2.x),
                                current > targetFOV2.y);
                            targetFOV = math.clamp(targetFOV, framing.FovRange.x, framing.FovRange.y);

                            // Apply damping
                            targetFOV = math.select(
                                targetFOV,
                                framingState.prevFOV + MathHelpers.Damp(
                                    targetFOV - framingState.prevFOV, framing.Damping,
                                    updateState.DeltaTime),
                                previousValid);
                            posState.Lens.FOV = targetFOV;
                            posState.MaxFOV = framing.FovRange.y;
                        }

                        framingState.prevFOV = posState.Lens.FOV;
                    }
                })
                .ScheduleParallel();
        }

        // Helper for jobs
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float GetTargetHeight(float radius, SizeFraming.FramingMode mode, float aspect)
        {
            float v = math.max(MathHelpers.Epsilon, radius * 2);
            float h = v / aspect;
            return math.select(
                math.select(h, v, mode == SizeFraming.FramingMode.Vertical),
                math.max(h, v),
                mode == SizeFraming.FramingMode.HorizontalAndVertical);
        }
    }
}
