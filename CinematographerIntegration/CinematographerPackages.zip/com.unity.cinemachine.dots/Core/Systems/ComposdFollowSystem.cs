using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System.Runtime.CompilerServices;
using System;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// Component that contains the settings for the Cinemachine Composed Follow behaviour
    /// </summary>
    [Serializable]
    public struct ComposedFollow : IComponentData
    {
        /// <summary>Target position prediction controls</summary>
        public TargetPositionPredictor Lookahead;

        /// <summary>How long it takes to bring the camera to the desired screen position</summary>
        [UnityEngine.Tooltip("How long it takes to bring the camera to the desired screen position.")]
        public float3 Damping;

        /// <summary>Set this to limit how close to the target the camera can get</summary>
        [UnityEngine.Tooltip("Set this to limit how close to the target the camera can get.")]
        [Float2AsRangeProperty]
        public float2 CameraDistance;

        /// <summary>Force target to center of screen when this camera activates.  If false,
        /// will clamp target to the edges of the dead zone</summary>
        [UnityEngine.Tooltip("Force target to center of screen when this camera activates.  If false, "
            + "will clamp target to the edges of the dead zone")]
        public bool CenterOnActivate;

        /// <summary>If checked, then then soft zone will be unlimited in size</summary>
        [UnityEngine.Tooltip("If set, then then soft zone will be unlimited in size.")]
        public bool UnlimitedSoftZone;
    }

    [Serializable]
    public struct ComposedFollowState : IComponentData
    {
        /// State information used for damping
        public float3 PrevCameraPos;
        public quaternion PrevCameraRot;

        public TargetPositionPredictor.StateData Predictor;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPostAimSystem))]
    [UpdateBefore(typeof(CameraPreNoiseSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class ComposedFollowSystem : CinemachineSystemBase
    {
        EntityQuery m_missingStateGroup;

        const float kMinimumCameraDistance = 0.01f;

        protected override void OnCreate()
        {
            m_missingStateGroup = GetEntityQuery(
                ComponentType.Exclude<ComposedFollowState>(),
                ComponentType.ReadOnly<ComposedFollow>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing composer state components
            EntityManager.AddComponent(m_missingStateGroup,
                ComponentType.ReadWrite<ComposedFollowState>());

            Entities
                .WithName("ComposedFollowJob")
                .ForEach((
                    ref PositionState posState,
                    ref ComposedFollowState composerState,
                    in ComposedFollow composer,
                    in ScreenComposerZones composerZones,
                    in FollowTargetState follow,
                    in NodeUpdateState updateState) =>
                {
                    if (follow.Value.Entity == Entity.Null)
                        return;

                    var previousIsValid = updateState.PreviousFrameDataIsValid
                        && !math.all(composerState.PrevCameraRot.value == 0);

                    composerState.Predictor.Update(
                        follow.Value.Position, posState.Up, composer.Lookahead,
                        math.select(-1, updateState.DeltaTime, previousIsValid));

                    composerState.PrevCameraPos = math.select(
                        posState.RawPosition, composerState.PrevCameraPos,
                        previousIsValid);
                    composerState.PrevCameraRot = math.select(
                        posState.RawRotation.value, composerState.PrevCameraRot.value,
                        previousIsValid);

                    if (updateState.ForcePositionAndRotation)
                        return; // posState already contains desired position

                    // Only target movement is damped
                    quaternion localToWorld = posState.RawRotation;
                    composerState.PrevCameraPos = composerState.Predictor.PredictedPosition
                        + math.mul(math.mul(localToWorld, math.inverse(composerState.PrevCameraRot)),
                            composerState.PrevCameraPos - composerState.Predictor.PredictedPosition);

                    // Work in camera-local space
                    float3 camPosWorld = composerState.PrevCameraPos;
                    quaternion worldToLocal = math.inverse(localToWorld);
                    float3 cameraPos = math.mul(worldToLocal, camPosWorld);
                    float3 targetPos = math.mul(
                        worldToLocal, composerState.Predictor.PredictedPosition) - cameraPos;

                    // Move along camera z
                    float3 cameraOffset = float3.zero;
                    float minZ = math.max(kMinimumCameraDistance, composer.CameraDistance.x);
                    float maxZ = math.max(minZ, composer.CameraDistance.y);
                    float targetDistance = math.clamp(targetPos.z, minZ, maxZ);
                    cameraOffset.z = targetPos.z - targetDistance;

                    // Move along the XY plane
                    float screenHalfSize = math.select(
                        math.tan(0.5f * math.radians(posState.Lens.FOV)) * targetDistance,
                        posState.Lens.FOV, updateState.Orthographic);
                    var softGuide = ScreenToOrtho(
                        composerZones.GetSoftGuideRect(), updateState.Aspect, screenHalfSize, follow.Value.Radius);
                    if (!previousIsValid)
                    {
                        // No damping or hard bounds, just snap to central bounds, skipping the soft zone
                        softGuide.HalfSize = math.select(
                            softGuide.HalfSize, float2.zero, composer.CenterOnActivate);
                        cameraOffset += OrthoOffsetToScreenBounds(targetPos, softGuide);
                    }
                    else
                    {
                        // Move it through the soft zone, with damping
                        cameraOffset += OrthoOffsetToScreenBounds(targetPos, softGuide);
                        cameraOffset = MathHelpers.Damp(cameraOffset, composer.Damping, updateState.DeltaTime);

                        // Make sure the real target (not the lookahead one) is still in the frame
                        if (!composer.UnlimitedSoftZone)
                        {
                            var hardGuideOrtho = ScreenToOrtho(
                                composerZones.GetHardGuideRect(), updateState.Aspect, screenHalfSize, follow.Value.Radius);
                            var realTargetPos = math.mul(worldToLocal, follow.Value.Position) - cameraPos;
                            cameraOffset += OrthoOffsetToScreenBounds(realTargetPos - cameraOffset, hardGuideOrtho);
                        }
                    }

                    posState.RawPosition = math.mul(localToWorld, (cameraPos + cameraOffset));
                    composerState.PrevCameraPos = posState.RawPosition;
                    composerState.PrevCameraRot = posState.RawRotation;
                })
                .ScheduleParallel();
        }

        // Convert from normalized screen coords to orthographic distance coords
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static MathHelpers.rect2d ScreenToOrtho(
            MathHelpers.rect2d rScreen, float aspect, float screenHalfSize, float targetRadius)
        {
            var s = new float2(screenHalfSize * aspect, screenHalfSize) * 2;
            var r = new MathHelpers.rect2d { Center = rScreen.Center * s, HalfSize = rScreen.HalfSize * s };
            return r.Inflate(-targetRadius);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static float3 OrthoOffsetToScreenBounds(float3 targetPos, MathHelpers.rect2d screenRect)
        {
            // Bring it to the edge of screenRect, if outside.  Leave it alone if inside.
            var p2d = new float2(targetPos.x, targetPos.y);
            p2d = math.clamp(p2d, screenRect.Min, screenRect.Max);
            return targetPos - new float3(p2d.x, p2d.y, targetPos.z);
        }
    }
}
