#if CINEMACHINE_LEGACY_PHYSICS

using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Burst;
using System;
using UnityEngine;
using Unity.Mathematics;
using System.Runtime.CompilerServices;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct LegacyCollisionResolution : IComponentData
    {
        /// <summary>Objects on these layers will be detected.</summary>
        [Tooltip("Objects on these layers will be detected")]
        public LayerMask CollideAgainst;

        /// <summary>Obstacles closer to the target than this will be ignored</summary>
        [Tooltip("Obstacles closer to the target than this will be ignored")]
        public float MinimumDistanceFromTarget;

        /// <summary>
        /// Don't take action unless occlusion has lasted at least this long.
        /// </summary>
        [Tooltip("Don't take action unless occlusion has lasted at least this long.")]
        public float MinimumOcclusionTime;

        /// <summary>
        /// Camera will try to maintain this distance from any obstacle.
        /// Increase this value if you are seeing inside obstacles due to a large
        /// FOV on the camera.
        /// </summary>
        [Tooltip("Camera will try to maintain this distance from any obstacle.  "
            + "Try to keep this value small.  Increase it if you are seeing inside obstacles "
            + "due to a large FOV on the camera.")]
        public float CameraRadius;

        /// <summary>
        /// Smoothing to apply to obstruction resolution.  Nearest camera point is held for
        /// at least this long.
        /// </summary>
        [Range(0, 2)]
        [Tooltip("Smoothing to apply to obstruction resolution.  Nearest camera point is "
            + "held for at least this long")]
        public float SmoothingTime;

        /// <summary>
        /// How gradually the camera returns to its normal position after having been corrected.
        /// Higher numbers will move the camera more gradually back to normal.
        /// </summary>
        [Range(0, 10)]
        [Tooltip("How gradually the camera returns to its normal position after having been "
            + "corrected.  Higher numbers will move the camera more gradually back to normal.")]
        public float Damping;

        /// <summary>
        /// How gradually the camera moves to resolve an occlusion.
        /// Higher numbers will move the camera more gradually.
        /// </summary>
        [Range(0, 10)]
        [Tooltip("How gradually the camera moves to resolve an occlusion.  Higher numbers "
            + "will move the camera more gradually.")]
        public float DampingWhenOccluded;

        /// <summary>
        /// How shot quality degrades as the camera is displaced.  If the camera is moved farther 
        /// than the specified distance, quiality will be 0.  A setting of 0 will disable 
        /// this feature and leave shot quality unaffected.
        /// </summary>
        [Tooltip("How shot quality degrades as the camera is displaced.  "
            + "If the camera is moved farther than the specified distance, quiality will be 0.  "
            + "A setting of 0 will this disable feature and leave shot quality unaffected.")]
        [TransitionDefinitionUnitsLabel("m", "The distance (in metres) at which quality becomes 0.  "
            + "Set this to 0 to disable quality degradation")]
        [InvertedTransitionGraph]
        public TransitionDefinition QualityDegradation;
    }

    [BurstCompile]
    struct LegacyCollisionResolutionState : IComponentData
    {
        public float3 previousDisplacement;
        public float3 previousDisplacementCorrection;
        public float colliderDisplacement;
        public double occlusionStartTime;

        internal float smoothedDistance;
        internal double smoothedTime;
    }

    static class LegacyCollisionResolutionStateUtility
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float ApplyDistanceSmoothing(
            this LegacyCollisionResolutionState state,
            float distance, float smoothingTime, double timeNow)
        {
            if (state.smoothedTime != 0 && smoothingTime > MathHelpers.Epsilon)
            {
                if ((float)(timeNow - state.smoothedTime) < smoothingTime)
                    return math.min(distance, state.smoothedDistance);
            }
            return distance;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void UpdateDistanceSmoothing(
            this LegacyCollisionResolutionState state,
            float distance, float smoothingTime, double timeNow)
        {
            if (state.smoothedDistance == 0 || distance <= state.smoothedDistance)
            {
                state.smoothedDistance = distance;
                state.smoothedTime = timeNow;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void ResetDistanceSmoothing(
            this LegacyCollisionResolutionState state,
            float smoothingTime, double timeNow)
        {
            if ((float)(timeNow - state.smoothedTime) >= smoothingTime)
            {
                state.smoothedDistance = 0;
                state.smoothedTime = 0;
            }
        }
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPostBodySystem))]
    [UpdateBefore(typeof(CameraPreAimSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class LegacyCollisionResolutionSystem : CinemachineSystemBase
    {
        EntityQuery m_nodeQuery;
        EntityQuery m_missingStateQuery;

        protected override void OnCreate()
        {
            m_nodeQuery = GetEntityQuery(
                ComponentType.ReadOnly<NodeChannelAssignment>(),
                ComponentType.ReadOnly<LegacyCollisionResolution>(),
                ComponentType.ReadWrite<LegacyCollisionResolutionState>(),
                ComponentType.ReadWrite<PositionState>(),
                ComponentType.ReadOnly<LookAtTargetState>());

            m_missingStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<LegacyCollisionResolution>(),
                ComponentType.Exclude<LegacyCollisionResolutionState>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing composer state components
            EntityManager.AddComponent(m_missingStateQuery,
                ComponentType.ReadWrite<LegacyCollisionResolutionState>());

            var objectCount = m_nodeQuery.CalculateEntityCount();

            // These will be deallocated by the final job
            var raycasts = new NativeArray<RaycastCommand>(objectCount, Allocator.TempJob);
            var hits = new NativeArray<RaycastHit>(objectCount, Allocator.TempJob);

            Entities
                .WithName("SetupRaycastsJob")
                .WithAll<LegacyCollisionResolutionState>()
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    in LegacyCollisionResolution settings,
                    in LookAtTargetState lookAt,
                    in PositionState posState) =>
                {
                    // Look from the target to the camera to get the objet closest to target
                    float3 dir = posState.GetCorrectedPosition() - lookAt.Value.Position;
                    float distance = math.length(dir);
                    dir /= distance;
                    distance = math.max(0, distance - settings.MinimumDistanceFromTarget);
                    raycasts[entityInQueryIndex] = new RaycastCommand(
                        lookAt.Value.Position + dir * settings.MinimumDistanceFromTarget, dir,
                        distance, settings.CollideAgainst);
                }).ScheduleParallel();

            Dependency = RaycastCommand.ScheduleBatch(raycasts, hits, 32, Dependency);

            const float Epsilon = MathHelpers.Epsilon;

            Entities
                .WithName("CollisionResolutionJob")
                .WithDisposeOnCompletion(hits)
                .WithDisposeOnCompletion(raycasts)
                .WithAll<LegacyCollisionResolutionState>()
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    ref LegacyCollisionResolutionState colliderState,
                    ref PositionState posState,
                    ref NodeUpdateState updateState,
                    in LegacyCollisionResolution collider,
                    in LookAtTargetState lookAt) =>
                {
                    if (lookAt.Value.Entity == Entity.Null)
                        return;

                    float3 cameraPos = posState.GetCorrectedPosition();
                    var targetPos = lookAt.Value.Position;
#if false
                    // A prior strategy involved updating this system after Aim, while
                    // preserving the LookAt point on the screen.  This is not great,
                    // because framing is often incorrect.  Instead, updating before Aim.

                    // Save the target screen position
                    float3 dirToTarget = math.normalizesafe(
                        lookAt.Value.Position - cameraPos, new float3(0, 0, 1));
                    float2 screenRot = MathHelpers.GetCameraRotationToTarget(
                        posState.RawRotation, dirToTarget, posState.Up);
#endif
                    float3 displacement = PreserveLignOfSight(
                        ref hits, entityInQueryIndex, cameraPos, targetPos,
                        raycasts[entityInQueryIndex].direction, collider);
                    if (collider.MinimumOcclusionTime > Epsilon)
                    {
                        if (math.lengthsq(displacement) < Epsilon)
                            colliderState.occlusionStartTime = 0;
                        else
                        {
                            if (colliderState.occlusionStartTime <= 0)
                                colliderState.occlusionStartTime = updateState.UpdateTime;
                            if ((float)(updateState.UpdateTime - colliderState.occlusionStartTime) < collider.MinimumOcclusionTime)
                                displacement = colliderState.previousDisplacement;
                        }
                    }

                    // Apply distance smoothing
                    if (collider.SmoothingTime > Epsilon)
                    {
                        float3 pos = cameraPos + displacement;
                        float3 dir = pos - lookAt.Value.Position;
                        float distance = math.length(dir);
                        if (distance > Epsilon)
                        {
                            dir /= distance;
                            if (!displacement.AlmostZero())
                                colliderState.UpdateDistanceSmoothing(distance, collider.SmoothingTime, updateState.UpdateTime);
                            distance = colliderState.ApplyDistanceSmoothing(distance, collider.SmoothingTime, updateState.UpdateTime);
                            displacement += (lookAt.Value.Position + dir * distance) - pos;
                        }
                    }

                    float damping = collider.Damping;
                    if (displacement.AlmostZero())
                        colliderState.ResetDistanceSmoothing(collider.SmoothingTime, updateState.UpdateTime);
                    else
                        damping = collider.DampingWhenOccluded;
                    if (damping > 0 && updateState.PreviousFrameDataIsValid)
                    {
                        float3 delta = displacement - colliderState.previousDisplacement;
                        delta = MathHelpers.Damp(delta, damping, updateState.DeltaTime);
                        displacement = colliderState.previousDisplacement + delta;
                    }
                    colliderState.previousDisplacement = displacement;

                    float3 correction = RespectMinimumDistanceFromTarget(
                        cameraPos + displacement, targetPos,
                        raycasts[entityInQueryIndex].direction, collider.MinimumDistanceFromTarget);
                    if (damping > 0 && updateState.PreviousFrameDataIsValid)
                    {
                        float3 delta = correction - colliderState.previousDisplacementCorrection;
                        delta = MathHelpers.Damp(delta, damping, updateState.DeltaTime);
                        correction = colliderState.previousDisplacementCorrection + delta;
                    }
                    displacement += correction;
                    colliderState.previousDisplacementCorrection = correction;
                    colliderState.colliderDisplacement = math.length(displacement);
                    posState.RawPosition += displacement;

                    updateState.ShotQuality *= collider.QualityDegradation.Evaluate(colliderState.colliderDisplacement, 1);
#if false
                    // See note in commented out section above

                    // Restore the target screen position
                    dirToTarget = math.normalizesafe(lookAt.Value.Position - (cameraPos + displacement), new float3(0, 0, 1));
                    posState.RawRotation = MathHelpers.ApplyCameraRotation(
                        quaternion.LookRotation(dirToTarget, posState.Up), screenRot, posState.Up);
#endif
                }).ScheduleParallel();
        }

        static float3 PreserveLignOfSight(
            [ReadOnly] ref NativeArray<RaycastHit> hits,
            int index, float3 cameraPos, float3 lookAtPoint, float3 raycastDirection,
            in LegacyCollisionResolution collider)
        {
            // Pull camera in front of nearest obstacle
            float3 displacement = float3.zero;
            if (hits[index].normal != Vector3.zero)
            {
                float3 hitPoint = hits[index].point;
                var newPos = hitPoint - raycastDirection * collider.CameraRadius;
                var d = math.distance(lookAtPoint, newPos);
                if (d < collider.MinimumDistanceFromTarget)
                    newPos = lookAtPoint + raycastDirection * collider.MinimumDistanceFromTarget;
                displacement = newPos - cameraPos;
            }
            return displacement;
        }

        static float3 RespectMinimumDistanceFromTarget(
            float3 cameraPos, float3 lookAtPoint, float3 raycastDirection,
            float minimumDistanceFromTarget)
        {
            // Respect the minimum distance from target - push camera back if we have to
            float3 result = float3.zero;
            var d = math.distance(lookAtPoint, cameraPos);
            if (d < minimumDistanceFromTarget)
            {
                result = lookAtPoint + raycastDirection * minimumDistanceFromTarget - cameraPos;
            }
            return result;
        }
    }
}
#endif
