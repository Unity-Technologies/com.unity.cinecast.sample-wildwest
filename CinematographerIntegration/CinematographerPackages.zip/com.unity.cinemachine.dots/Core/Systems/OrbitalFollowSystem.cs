using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;
using System;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct OrbitalFollow : IComponentData
    {
        /// <summary>The coordinate space to use when interpreting the offset from the target</summary>
        public FollowControlSystem.BindingMode Binding;

        /// <summary>How long it takes to respond to changes in the target's position</summary>
        [Tooltip("How long it takes to respond to changes in the target's position")]
        public float3 Damping;

        /// <summary>How long it takes to respond to changes in the target's rotation</summary>
        [Tooltip("How long it takes to respond to changes in the target's rotation")]
        public float AngularDamping;

        /// <summary>Defines the height and radius for an orbit</summary>
        [Serializable]
        public struct Orbit
        {
            /// <summary>Height relative to target</summary>
            public float Height;

            /// <summary>Radius of orbit</summary>
            public float Radius;
        }

        public Orbit Top;
        public Orbit Middle;
        public Orbit Bottom;

        /// <summary></summary>
        [Tooltip("Controls how taut is the line that connects the rigs' orbits, which determines "
            + "final placement on the Y axis")]
        [Range(0f, 1f)]
        public float SplineCurvature;

        // t ranges from -1 to 1
        public float3 SplineValueAt(float t)
        {
            var p0 = math.select(new float3(0, Bottom.Height, -Bottom.Radius), float3.zero, t < 0);
            var p1 = math.select(new float3(0, Middle.Height, -Middle.Radius), new float3(0, Bottom.Height, -Bottom.Radius), t < 0);
            var p2 = math.select(new float3(0, Top.Height, -Top.Radius), new float3(0, Middle.Height, -Middle.Radius), t < 0);
            var p3 = math.select(float3.zero, new float3(0, Top.Height, -Top.Radius), t < 0);

            float t0 = 1 - math.select(0, -SplineCurvature, t < 0);
            float t1 = 1 - math.select(-SplineCurvature, 0, t < 0);
            var d0 = p1 + ((t0 * (p1 - p0)) + (t0 * (p2 - p1))) * 0.1666666666f;
            var d1 = p2 - ((t1 * (p2 - p1)) + (t1 * (p3 - p2))) * 0.1666666666f;

            return MathHelpers.Bezier(math.select(t, t + 1, t < 0), p1, d0, d1, p2);
        }
    }

    /// <summary>
    /// Internal use only.  Public for authoring code that draws gizmnos
    /// </summary>
    [Serializable]
    internal struct OrbitalFollowState : IComponentData
    {
        /// State information used for damping
        public float3 PreviousTargetPosition;
        public quaternion PreviousTargetRotation;
        public float3 PreviousTargetOffset;
        public float PreviousHeading;
        public int InputAxisIndex;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPreBodySystem))]
    [UpdateBefore(typeof(CameraPostBodySystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class OrbitalFollowSystem : CinemachineSystemBase
    {
        EntityQuery m_missingStateQuery;

        protected override void OnCreate()
        {
            m_missingStateQuery = GetEntityQuery(
                ComponentType.Exclude<OrbitalFollowState>(),
                ComponentType.ReadOnly<OrbitalFollow>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing orbital state components
            EntityManager.AddComponent(m_missingStateQuery,
                ComponentType.ReadWrite<OrbitalFollowState>());

            Entities
                .WithName("OrbitalFollowJob")
                .ForEach((
                    DynamicBuffer<InputAxisXYZ> inputXYZbuffer,
                    ref PositionState posState,
                    ref OrbitalFollowState orbitalState,
                    ref OrbitalFollow orbital,
                    in FollowTargetState follow,
                    in NodeUpdateState updateState) =>
                    {
                        if (follow.Value.Entity == Entity.Null)
                            return;

                        var targetPos = follow.Value.Position;
                        var targetRot = follow.Value.Rotation;

                        if (updateState.ForcePositionAndRotation)
                        {
#if false // GML todo: infer X/Y/Z axis values from camera/target relationship
                            var dirToTarget = targetPos - posState.RawPosition;
                            targetRot = FollowControlSystem.GetRotationForBindingMode(
                                targetRot, orbital.Binding,
                                dirToTarget, updateState.WorldUp);

                            orbitalState.PreviousTargetRotationXX = follow.Value.Rotation;
                            orbitalState.PreviousTargetPositionXX = FollowControlSystem.InferTargetPosFromCameraPos(
                                orbital.Binding, orbital.FollowOffset, posState.Up,
                                posState.RawPosition, posState.RawRotation, follow.Value.Rotation);
#endif
                            return;
                        }

                        bool previousValid = updateState.PreviousFrameDataIsValid
                            && !math.all(orbitalState.PreviousTargetRotation.value == 0);

                        bool isSimpleFollow = orbital.Binding == FollowControlSystem.BindingMode.CameraAxesWithWorldUp;
                        var prevPos = math.select(
                            follow.Value.Position, orbitalState.PreviousTargetPosition, previousValid);
                        var prevRot = math.select(
                            follow.Value.Rotation.value, orbitalState.PreviousTargetRotation.value, previousValid);

                        targetPos = FollowControlSystem.ApplyPositionDamping(
                            updateState.DeltaTime, 
                            math.select(float3.zero, orbital.Damping, previousValid),
                            prevPos, targetPos, prevRot);
                        targetRot = FollowControlSystem.GetRotationForBindingMode(
                            targetRot, orbital.Binding,
                            targetPos - posState.RawPosition, updateState.WorldUp);
                        targetRot = FollowControlSystem.ApplyRotationDamping(
                            updateState.DeltaTime, 
                            math.select(0, orbital.AngularDamping, previousValid && !isSimpleFollow),
                            prevRot, targetRot);

                        // Compute the new heading and follow offset
                        var inputXYZ = inputXYZbuffer[orbitalState.InputAxisIndex];
                        var followOffset = ComputeFollowOffset(
                            ref inputXYZ, ref orbital, targetRot, out float heading);
                        if (isSimpleFollow)
                        {
                            inputXYZ.X.Value.Value = 0; // reset after read
                            inputXYZbuffer[orbitalState.InputAxisIndex] = inputXYZ;
                        }

                        // Naive version
                        posState.Up = math.normalize(math.mul(targetRot, math.up()));
                        posState.RawPosition = targetPos + followOffset;

                        // Respect minimum target distance on XZ plane
                        targetPos += FollowControlSystem.GetOffsetForMinimumTargetDistance(
                            posState.RawPosition, posState.RawRotation, posState.Up,
                            math.length(followOffset.ProjectOntoPlane(posState.Up)) * 0.2f,
                            targetPos, follow.Value.Position);

                        // Assuming that the axes didn't change, where would we be?
                        var prevOffset = math.select(followOffset, orbitalState.PreviousTargetOffset, previousValid);
                        var basePosition = targetPos + prevOffset;

                        // Handle the axis change - we rotate the damped target pos along with the heading change
                        var deltaHeading = heading - math.select(heading, orbitalState.PreviousHeading, previousValid);
                        targetPos = follow.Value.Position + math.mul(
                            quaternion.AxisAngle(posState.Up, deltaHeading),
                            targetPos - follow.Value.Position);
                        posState.RawPosition = targetPos + followOffset;

                        posState.DampingBypass = FollowControlSystem.ComputeDampingBypass(
                            basePosition - follow.Value.Position,
                            posState.RawPosition - follow.Value.Position, posState.Up);

                        orbitalState.PreviousTargetOffset = followOffset;
                        orbitalState.PreviousTargetPosition = targetPos;
                        orbitalState.PreviousTargetRotation = targetRot;
                        orbitalState.PreviousHeading = math.select(heading, 0, isSimpleFollow);
                    }
                )
                .ScheduleParallel();  // GML TODO should be inputDeps and then combined for output?
        }

        // Compute the heading and follow offset
        static float3 ComputeFollowOffset(
            ref InputAxisXYZ inputXYZ, ref OrbitalFollow orbital,
            quaternion targetRot, out float heading)
        {
            heading = math.radians(inputXYZ.X.Value.GetClampedValue());

            var followOffset = orbital.SplineValueAt(inputXYZ.Y.Value.GetNormalizedValue() * 2 - 1);
            followOffset *= inputXYZ.Z.Value.GetClampedValue();
            quaternion q = quaternion.Euler(0, heading, 0);
            followOffset = math.mul(q, followOffset);
            followOffset = math.mul(targetRot, followOffset);

            return followOffset;
        }

#if false // GML todo: infer X/Y/Z axis values from camera/target relationship
        /// <summary>
        /// What axis value would we need to get as close as possible to the desired cameraPos?
        /// </summary>
        /// <param name="cameraPos">camera position we would like to approximate</param>
        /// <param name="up">world up</param>
        /// <returns>The best value to put into the X axis, to approximate the desired camera pos</returns>
        public float GetAxisClosestValue(
            float3 cameraPos, float3 up, float3 targetPos, quaternion targetRot)
        {
            var fwd = math.mul(targetRot, new float3(0, 0, 1)).ProjectOntoPlane(up);
            if (!fwd.AlmostZero())
            {
                // Get the base camera placement
                var pos = targetPos + orient * EffectiveOffset;

                var a = math.normalizesafe((pos - targetPos).ProjectOntoPlane(up));
                var b = math.normalizesafe((cameraPos - targetPos).ProjectOntoPlane(up));
                return MathHelpers.SignedAngleUnit(a, b, up);
            }
            return m_LastHeading; // Can't calculate, stay conservative
        }

        float GetYAxisClosestValue(Vector3 cameraPos, Vector3 up)
        {
            if (Follow != null)
            {
                // Rotate the camera pos to the back
                Quaternion q = Quaternion.FromToRotation(up, Vector3.up);
                Vector3 dir = q * (cameraPos - Follow.position);
                Vector3 flatDir = dir; flatDir.y = 0;
                if (!flatDir.AlmostZero())
                {
                    float angle = Vector3.SignedAngle(flatDir, Vector3.back, Vector3.up);
                    dir = Quaternion.AngleAxis(angle, Vector3.up) * dir;
                }
                dir.x = 0;

                // Sample the spline in a few places, find the 2 closest, and lerp
                int i0 = 0, i1 = 0;
                float a0 = 0, a1 = 0;
                const int NumSamples = 13;
                float step = 1f / (NumSamples-1);
                for (int i = 0; i < NumSamples; ++i)
                {
                    float a = Vector3.SignedAngle(
                        dir, GetLocalPositionForCameraFromInput(i * step), Vector3.right);
                    if (i == 0)
                        a0 = a1 = a;
                    else
                    {
                        if (Mathf.Abs(a) < Mathf.Abs(a0))
                        {
                            a1 = a0;
                            i1 = i0;
                            a0 = a;
                            i0 = i;
                        }
                        else if (Mathf.Abs(a) < Mathf.Abs(a1))
                        {
                            a1 = a;
                            i1 = i;
                        }
                    }
                }
                if (Mathf.Sign(a0) == Mathf.Sign(a1))
                    return i0 * step;
                float t = Mathf.Abs(a0) / (Mathf.Abs(a0) + Mathf.Abs(a1));
                return Mathf.Lerp(i0 * step, i1 * step, t);
            }
            return m_YAxis.Value; // stay conservative
        }
#endif
        }
}
