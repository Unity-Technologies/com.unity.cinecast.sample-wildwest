using Unity.Entities;
using Unity.Jobs;
using Unity.Transforms;
using Unity.Mathematics;
using UnityEngine;
using System;
using System.Runtime.CompilerServices;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// StableKey of the camera Follow target
    /// </summary>
    [Serializable]
    public struct FollowTarget : IComponentData
    {
        public StableKey Target;
    }

    /// <summary>
    /// StableKey of the camera LookAt target
    /// </summary>
    [Serializable]
    public struct LookAtTarget : IComponentData
    {
        public StableKey Target;
    }

    /// <summary>
    /// Describes the FOV and clip planes for a camera.  This generally mirrors the Unity Camera's
    /// lens settings, and will be used to drive the Unity camera when the node is active.
    /// </summary>
    [Serializable]
    public struct LensData : IComponentData
    {
        /// <summary>
        /// This is the camera view in vertical degrees. For cinematic people, a 50mm lens
        /// on a super-35mm sensor would equal a 19.6 degree FOV.
        /// When using an orthographic camera, this defines the height, in world
        /// co-ordinates, of the camera view.
        /// </summary>
        public float FOV;

        /// <summary> The near clip plane for this LensSettings </summary>
        public float NearClip;

        /// <summary> The far clip plane for this LensSettings </summary>
        public float FarClip;

        /// <summary> The dutch (tilt) to be applied to the camera. In degrees </summary>
        public float Dutch;

        /// <summary> For physical cameras only: position of the gate relative to the film back </summary>
        public float2 LensShift;

        /// <summary>A default lens</summary>
        public static LensData Default
        {
            get { return new LensData { FOV = 40, NearClip = 0.1f, FarClip = 5000 }; }
        }
    }

    [Serializable]
    public struct PositionState : IComponentData
    {
        /// <summary>Lens state</summary>
        public LensData Lens;

        /// <summary>
        /// This should be set to the maximum FOV that this lens can assume,
        /// which is not necessarily the same as the current FOV
        /// </summary>
        public float MaxFOV;

        /// <summary> Raw (un-corrected) world space position of this camera </summary>
        public float3 RawPosition;

        /// <summary>
        /// Position correction.  This will be added to the raw position.
        /// This value doesn't get fed back into the system when calculating the next frame.
        /// Can be noise, or smoothing, or both, or something else.
        /// </summary>
        public float3 PositionCorrection;

        /// <summary>This is a way bypass damping in.  The rotation will be applied to cached
        /// previous state prior to computing the damping.  This is useful, for example,
        /// when the body needs to rotate its point of view due to user input, but does not
        /// want interference from the aim damping</summary>
        public quaternion DampingBypass;

        /// <summary> Which way is up for this node (independent of its orientation).
        /// World space unit vector. </summary>
        /// GML todo: remove (already in NodeUpdateState)
        public float3 Up;

        /// <summary> Raw (un-corrected) world space orientation of this camera </summary>
        public quaternion RawRotation;

        /// <summary>
        /// Rotation correction.  This will be added to the raw orientation.
        /// This value doesn't get fed back into the system when calculating the next frame.
        /// Can be noise, or smoothing, or both, or something else.
        /// </summary>
        public quaternion RotationCorrection;

        /// <summary>
        /// This can be used for calculating camera velocity
        /// </summary>
        public float3 PreviousPosition;
    }

    /// <summary>
    /// Convenience methods for PositionState
    /// </summary>
    public static class PositionStateExtensions
    {
        /// <summary>
        /// Compute the final position, which takes into account raw and corrected position.
        /// </summary>
        /// <param name="posState"></param>
        /// <returns>The final position</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float3 GetCorrectedPosition(this PositionState posState)
        {
            return posState.RawPosition + posState.PositionCorrection;
        }

        /// <summary>
        /// Compute the final rotation, which takes into account raw and corrected rotation.
        /// </summary>
        /// <param name="posState"></param>
        /// <returns>The final rotation</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static quaternion GetCorrectedRotation(this PositionState posState)
        {
            return math.normalize(math.mul(posState.RawRotation, posState.RotationCorrection));
        }
    }

    /// <summary>
    /// Current relevant info about a camera target.
    /// This is gathered every frame at the start of the pipeline.
    /// </summary>
    public struct CmTargetInfo
    {
        public Entity Entity;
        public float3 Position;
        public float Radius;
        public quaternion Rotation;

        public static CmTargetInfo Default
            { get { return new CmTargetInfo { Rotation = quaternion.identity }; } }
    }

    /// <summary>
    /// Current relevant info about the Follow target.
    /// This is gathered every frame at the start of the pipeline.
    /// </summary>
    public struct FollowTargetState : IComponentData
    {
        public CmTargetInfo Value;
    }

    /// <summary>
    /// Current relevant info about the LookAt target.
    /// This is gathered every frame at the start of the pipeline.
    /// </summary>
    public struct LookAtTargetState : IComponentData
    {
        public CmTargetInfo Value;
    }


    // These systems define the CmCamera pipeline, in this order.
    // Use them to ensure correct ordering of CM pipeline systems

    /// <summary>
    /// Initializes the CmCamera pipeline.
    /// </summary>
    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(NodeInitSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CameraInitSystem : CinemachineSystemBase
    {
        CmTargetSystem m_targetSystem;

        EntityQuery m_missingPosStateQuery;
        EntityQuery m_missingFollowStateQuery;
        EntityQuery m_missingLookAtStateQuery;

        protected override void OnCreate()
        {
            m_targetSystem = World.GetOrCreateSystem<CmTargetSystem>();

            m_missingPosStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<NodeChannelAssignment>(),
                ComponentType.Exclude<PositionState>());
            m_missingFollowStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<NodeChannelAssignment>(),
                ComponentType.ReadOnly<FollowTarget>(),
                ComponentType.Exclude<FollowTargetState>());
            m_missingLookAtStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<NodeChannelAssignment>(),
                ComponentType.ReadOnly<LookAtTarget>(),
                ComponentType.Exclude<LookAtTargetState>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing state components
            EntityManager.AddComponent(m_missingPosStateQuery,
                ComponentType.ReadWrite<PositionState>());
            EntityManager.AddComponent(m_missingFollowStateQuery,
                ComponentType.ReadWrite<FollowTargetState>());
            EntityManager.AddComponent(m_missingLookAtStateQuery,
                ComponentType.ReadWrite<LookAtTargetState>());

            Entities
                .WithName("InitCameraJob")
                .ForEach((
                    ref PositionState posState,
                    in LensData lens,
                    in LocalToWorld l2w,
                    in NodeUpdateState updateState) =>
                {
                    posState.Lens = lens;
                    posState.MaxFOV = lens.FOV;

                    posState.DampingBypass = quaternion.identity;
                    posState.Up = updateState.WorldUp;
                    posState.PositionCorrection = float3.zero;
                    posState.RotationCorrection = quaternion.identity;
                    if (!updateState.ForcePositionAndRotation)
                    {
                        posState.RawPosition = l2w.Value.GetTranslationFromTRS();
                        posState.RawRotation = l2w.Value.GetRotationFromTRS();
                    }
                })
                .ScheduleParallel();

            // GML todo: should we keep this?
            Entities
                .WithName("InitCameraNoL2WJob")
                .WithNone<LocalToWorld>()
                .ForEach((
                    ref PositionState posState,
                    in LensData lens,
                    in NodeUpdateState updateState) =>
                {
                    posState.Lens = lens;
                    posState.MaxFOV = lens.FOV;

                    posState.DampingBypass = quaternion.identity;
                    posState.Up = updateState.WorldUp;
                    posState.PositionCorrection = float3.zero;
                    posState.RotationCorrection = quaternion.identity;
                })
                .ScheduleParallel();

            Dependency = m_targetSystem.GetTargetLookupForJobs(Dependency, out var targetLookup);
            if (targetLookup.IsCreated)
            {
                Entities
                    .WithName("SetFollowTargetStateJob")
                    .WithAll<NodeChannelAssignment>()
                    .WithReadOnly(targetLookup)
                    .ForEach((ref FollowTargetState state, in FollowTarget follow) =>
                    {
                        if (!targetLookup.TryGetValue(follow.Target, out state.Value))
                            state.Value = CmTargetInfo.Default;
                    })
                    .ScheduleParallel();

                Entities
                    .WithName("SetLookAtTargetStateJob")
                    .WithAll<NodeChannelAssignment>()
                    .WithReadOnly(targetLookup)
                    .ForEach((ref LookAtTargetState state, in LookAtTarget lookAt) =>
                    {
                        if (!targetLookup.TryGetValue(lookAt.Target, out state.Value))
                            state.Value = CmTargetInfo.Default;
                    })
                    .ScheduleParallel();

                m_targetSystem.RegisterTargetLookupReadJobs(Dependency);
            }
        }
    }

    /// <summary>
    /// This is a placeholder system for system ordering of camera pipeline functionality.
    /// It does nothing.  To implement systems that position the camera,
    /// execute after this system and before CameraPostBodySystem.
    /// </summary>
    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraInitSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CameraPreBodySystem : SystemBase
    {
        protected override void OnUpdate() {} // Do nothing
    }

    /// <summary>
    /// This is a placeholder system for system ordering of camera pipeline functionality.
    /// It does nothing.  
    /// </summary>
    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPreBodySystem))]
    [UpdateBefore(typeof(CameraPreAimSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CameraPostBodySystem : SystemBase
    {
        protected override void OnUpdate() {} // Do nothing
    }

    /// <summary>
    /// This is a placeholder system for system ordering of camera pipeline functionality.
    /// It does nothing.  To implement camera aiming, execute after this system and before
    /// CameraPostAimSystem.
    /// </summary>
    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPostBodySystem))]
    [UpdateBefore(typeof(CameraPostAimSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CameraPreAimSystem : SystemBase
    {
        protected override void OnUpdate() {} // Do nothing
    }

    /// <summary>
    /// This is a placeholder system for system ordering of camera pipeline functionality.
    /// It does nothing.  To implement camera post-aim functionality, execute after
    /// this system and before CameraPreNoiseSystem.
    /// </summary>
    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPreAimSystem))]
    [UpdateBefore(typeof(CameraPreNoiseSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CameraPostAimSystem : SystemBase
    {
        protected override void OnUpdate() {} // Do nothing
    }

    /// <summary>
    /// This is a placeholder system for system ordering of camera pipeline functionality.
    /// It does nothing.  To implement camera noise or other perturbation, execute after this system
    /// and before CameraPostNoiseSystem.
    /// </summary>
    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPostAimSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CameraPreNoiseSystem : SystemBase
    {
        protected override void OnUpdate() {} // Do nothing
    }

    /// <summary>
    /// This is a placeholder system for system ordering of camera pipeline functionality.
    /// It does nothing.  To implement camera finalization after the camera has been fully
    /// positioned and aimed, execute after this system and before CameraFinalizeSystem.
    /// </summary>
    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPreNoiseSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CameraPostNoiseSystem : SystemBase
    {
        protected override void OnUpdate() {} // Do nothing
    }

    /// <summary>
    /// This system pushes the camera position and rotation to LocalToWorld.
    /// It is the final stage of the camera pipeline.
    /// </summary>
    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPostNoiseSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CameraFinalizeSystem : CinemachineSystemBase
    {
        protected override void OnUpdate()
        {
            base.OnUpdate();

            Entities
                .WithName("FinalizePosJob")
                .WithAll<NodeChannelAssignment>()
                .WithNone<CmChannel>()
                .ForEach((
                    ref LocalToWorld l2w,
                    ref PositionState posState) =>
                {
                    // Push pos/rot to LocalToWorld.  Preserve the scale
                    l2w.Value = float4x4.TRS(
                        posState.RawPosition, posState.RawRotation, l2w.Value.GetScaleFromTRS());
                    posState.PreviousPosition = posState.RawPosition;
                })
                .ScheduleParallel();
        }
    }
}
