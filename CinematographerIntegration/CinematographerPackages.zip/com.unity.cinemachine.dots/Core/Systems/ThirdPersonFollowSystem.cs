using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;
#if CINEMACHINE_UNITY_PHYSICS
using Unity.Physics;
using Unity.Physics.Systems;
#endif
using System;
using System.Runtime.CompilerServices;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// Component that contains the settings for the Cinemachine Third Person Follow behaviour.
    /// </summary>
    [Serializable]
    public struct ThirdPersonFollow : IComponentData
    {
        /// <summary>How responsively the camera tracks the target.  Each axis (camera-local)
        /// can have its own setting.  Value is the approximate time it takes the camera
        /// to catch up to the target's new position.  Smaller values give a more rigid
        /// effect, larger values give a squishier one.</summary>
        [Tooltip("How responsively the camera tracks the target.  Each axis (camera-local) "
           + "can have its own setting.  Value is the approximate time it takes the camera "
           + "to catch up to the target's new position.  Smaller values give a more "
           + "rigid effect, larger values give a squishier one")]
        public float3 Damping;

        /// <summary>Position of the shoulder pivot relative to the Follow target origin.
        /// This offset is in target-local space.</summary>
        [Header("Rig")]
        [Tooltip("Position of the shoulder pivot relative to the Follow target origin.  "
            + "This offset is in target-local space")]
        public float3 ShoulderOffset;

        /// <summary>Vertical offset of the hand in relation to the shoulder.
        /// Arm length will affect the follow target's screen position
        /// when the camera rotates vertically.</summary>
        [Tooltip("Vertical offset of the hand in relation to the shoulder.  "
            + "Arm length will affect the follow target's screen position when "
            + "the camera rotates vertically")]
        public float VerticalArmLength;

        [Tooltip("Moves camera from one shoulder to the other.")] [Range(-1.0f, 1.0f)]
        [UnityEngine.Serialization.FormerlySerializedAs("BlendBetweenShoulders")]
        public float CameraSide;

        [Tooltip("Desired camera distance from HandOffset")]
        public float CameraDistance;

#if CINEMACHINE_UNITY_PHYSICS
        [Header("Camera Collider")]
        [Range(0.0f, 10.0f)]
        [Tooltip("Camera will try to maintain this distance from any obstacle.  "
                 + "Try to keep this value small.  Increase it if you are seeing inside obstacles.")]
        public float CameraRadius;

        [Tooltip("Objects on these layers will be considered for collision with the camera.")]
        [UnityPhysicsLayerMask]
        public int CameraCollideAgainst;

#if false // GML TODO
        /// <summary>
        /// Obstacles with this tag will be ignored.  It is a good idea
        /// to set this field to the target's tag
        /// </summary>
        [TagField]
        [Tooltip("Obstacles with this tag will be ignored.  "
            + "It is a good idea to set this field to the target's tag")]
        public string IgnoreTag = string.Empty;
#endif

        /// <summary>
        /// How gradually the camera moves to correct for collisions.
        /// Higher numbers will move the camera more gradually.
        /// </summary>
        [Range(0, 10)]
        [Tooltip("How gradually the camera moves to correct for collisions.  " +
            "Higher numbers will move the camera more gradually.")]
        public float DampingIntoCollision;

        /// <summary>
        /// How gradually the camera returns to its normal position after having been corrected by the built-in
        /// collision resolution. Higher numbers will move the camera more gradually back to normal.
        /// </summary>
        [Range(0, 10)]
        [Tooltip("How gradually the camera returns to its normal position after having been corrected by the built-in " +
            "collision resolution.  Higher numbers will move the camera more gradually back to normal.")]
        public float DampingFromCollision;
#endif
    }

    // Internal use only
    struct ThirdPersonFollowState : IComponentData
    {
        public float3 PreviousFollowTargetPosition;
        public float3 DampingCorrection;
        public float CamPosCollisionCorrection;
        public bool IsValid;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPreBodySystem))]
    [UpdateBefore(typeof(CameraPostBodySystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class ThirdPersonFollowSystem : CinemachineSystemBase
    {
#if CINEMACHINE_UNITY_PHYSICS
        private BuildPhysicsWorld m_physicsWorldSystem;
#endif

        private EntityQuery m_missingStateQuery;

        protected override void OnCreate()
        {
#if CINEMACHINE_UNITY_PHYSICS
            m_physicsWorldSystem = World.GetOrCreateSystem<Physics.Systems.BuildPhysicsWorld>();
#endif

            m_missingStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<ThirdPersonFollow>(),
                ComponentType.Exclude<ThirdPersonFollowState>());
        }

        protected override void OnStartRunning()
        {
            base.OnStartRunning();
#if CINEMACHINE_UNITY_PHYSICS
            PhysicsRuntimeExtensions.RegisterPhysicsRuntimeSystemReadOnly(this);
#endif
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing state components
            EntityManager.AddComponent(m_missingStateQuery,
                ComponentType.ReadWrite<ThirdPersonFollowState>());

#if CINEMACHINE_UNITY_PHYSICS
            var collisionWorld = m_physicsWorldSystem.PhysicsWorld.CollisionWorld;
#endif

            Entities
                .WithName("CameraPositionJob")
#if CINEMACHINE_UNITY_PHYSICS
                .WithReadOnly(collisionWorld)
#endif
                .ForEach((
                    ref ThirdPersonFollowState thirdPersonState,
                    ref PositionState posState,
                    in FollowTargetState follow,
                    in ThirdPersonFollow thirdPerson,
                    in NodeUpdateState updateState) =>
                {
                    if (follow.Value.Entity == Entity.Null)
                        return;

                    // GML todo: handle ForcePositionAndRotation

                    bool previousValid = updateState.PreviousFrameDataIsValid
                        && thirdPersonState.IsValid;

                    var up = posState.Up;
                    var targetPos = follow.Value.Position;
                    var targetRot = follow.Value.Rotation;
                    var targetForward = math.mul(targetRot, new float3(0, 0, 1));
                    var heading = GetHeading(targetForward, up);

                    if (!previousValid)
                    {
                        // No damping - reset damping state info
                        thirdPersonState.DampingCorrection = float3.zero;
                        thirdPersonState.CamPosCollisionCorrection = 0;
                    }
                    else
                    {
                        // Damping correction is applied to the shoulder offset - stretching the rig
                        thirdPersonState.DampingCorrection
                            += math.mul(math.inverse(heading),
                                thirdPersonState.PreviousFollowTargetPosition - targetPos);
                        thirdPersonState.DampingCorrection
                            -= MathHelpers.Damp(thirdPersonState.DampingCorrection,
                                thirdPerson.Damping, updateState.DeltaTime);
                    }

                    thirdPersonState.PreviousFollowTargetPosition = targetPos;
                    thirdPersonState.IsValid = true;
                    var root = targetPos;
                    GetRawRigPositions(
                        thirdPerson, ref thirdPersonState,
                        root, targetRot, heading, out _, out var hand);

                    // Place the camera at the correct distance from the hand
                    var camPos = hand - (targetForward * (thirdPerson.CameraDistance - thirdPersonState.DampingCorrection.z));

#if CINEMACHINE_UNITY_PHYSICS
                    // Check if hand is colliding with something, if yes, then move the hand
                    // closer to the player. The radius is slightly enlarged, to avoid problems
                    // next to walls
                    float dummy = 0;
                    var collidedHand = ResolveCollisions(
                        in collisionWorld, in thirdPerson, root, hand, 0, false,
                        thirdPerson.CameraRadius * 1.05f, ref dummy);
                    camPos = ResolveCollisions(
                        in collisionWorld, in thirdPerson, collidedHand, camPos, updateState.DeltaTime,
                        updateState.PreviousFrameDataIsValid,
                        thirdPerson.CameraRadius, ref thirdPersonState.CamPosCollisionCorrection);
#endif
                    // Set state
                    posState.RawPosition = camPos;
                    posState.RawRotation = targetRot; // not necessary, but left in to avoid breaking scenes that depend on this
                })
                .ScheduleParallel();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static quaternion GetHeading(float3 targetForward, float3 up)
        {
            var planeForward = targetForward.ProjectOntoPlane(up);
            planeForward = math.cross(up, math.cross(planeForward, up));
            return quaternion.LookRotation(planeForward, up);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static void GetRawRigPositions(
            in ThirdPersonFollow thirdPerson,
            ref ThirdPersonFollowState thirdPersonState,
            float3 root, quaternion targetRot, quaternion heading,
            out float3 shoulder, out float3 hand)
        {
            var shoulderOffset = thirdPerson.ShoulderOffset;
            shoulderOffset.x = Mathf.Lerp(-shoulderOffset.x, shoulderOffset.x, thirdPerson.CameraSide);
            shoulderOffset.x += thirdPersonState.DampingCorrection.x;
            shoulderOffset.y += thirdPersonState.DampingCorrection.y;
            shoulder = root + math.mul(heading, shoulderOffset);
            hand = shoulder + math.mul(targetRot, new float3(0, thirdPerson.VerticalArmLength, 0));
        }

#if CINEMACHINE_UNITY_PHYSICS
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static unsafe float3 ResolveCollisions(
            in CollisionWorld collisionWorld,
            in ThirdPersonFollow thirdPerson,
            float3 root, float3 tip, float deltaTime, bool previousStateIsValid,
            float cameraRadius, ref float collisionCorrection)
        {
            var filter = StandardFilter(thirdPerson.CameraCollideAgainst);
            if (filter.IsEmpty)
                return tip;

            var dir = tip - root;
            var len = math.length(dir);
            dir /= len;

            var result = tip;
            float desiredCorrection = 0;

            var sphereCast = new ColliderCastInput
            {
                Collider = (Physics.Collider*) Physics.SphereCollider.Create(new SphereGeometry
                {
                    Center = float3.zero,
                    Radius = cameraRadius
                }, filter).GetUnsafePtr(),
                Orientation = quaternion.identity,
                Start = root,
                End = tip
            };
            if (collisionWorld.CastCollider(sphereCast, out ColliderCastHit colliderHit))
            {
                // Note: we want to lerp, because colliderHit.Position will be the collision point,
                // however the lerped position will give the center of the sphere touching the collision point.
                var hitPoint = math.lerp(sphereCast.Start, sphereCast.End, colliderHit.Fraction);
                desiredCorrection = math.length(hitPoint - tip);
            }

            collisionCorrection += math.select(
                desiredCorrection - collisionCorrection,
                MathHelpers.Damp(
                    desiredCorrection - collisionCorrection,
                    math.select(thirdPerson.DampingFromCollision,
                        thirdPerson.DampingIntoCollision, desiredCorrection > collisionCorrection),
                    deltaTime),
                previousStateIsValid);

            // Apply the correction
            if (collisionCorrection > MathHelpers.Epsilon)
                result -= dir * collisionCorrection;

            return result;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static CollisionFilter StandardFilter(int colliderLayer)
        {
            return new CollisionFilter()
            {
                BelongsTo = 0xffffffff,
                CollidesWith = unchecked((uint) colliderLayer),
                GroupIndex = 0
            };
        }
#endif
    }
}
