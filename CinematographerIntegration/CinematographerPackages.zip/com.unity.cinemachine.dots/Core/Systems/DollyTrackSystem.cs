using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System.Runtime.CompilerServices;
using UnityEngine;
using System;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct DollyTrack : IComponentData
    {
        /// <summary>The path to which the camera will be constrained.</summary>
        [Tooltip("The path to which the camera will be constrained.")]
        [HideInInspector]
        public CachedStableEntityReference PathKey;

        /// <summary>The position along the path at which the camera will be placed.
        /// This can be animated directly, or set automatically by the Auto-Dolly feature
        /// to get as close as possible to the Follow target.</summary>
        [Tooltip("The position along the path at which the camera will be placed.  "
            + "This can be animated directly, or set automatically by the Auto-Dolly feature "
            + "to get as close as possible to the Follow target.  The value is interpreted "
            + "according to the Position Units setting.")]
        public float PathPosition;

        /// <summary>How to interpret the Path Position</summary>
        [Tooltip("How to interpret Path Position.  If set to Path Units, values are as follows: "
            + "0 represents the first waypoint on the path, 1 is the second, and so on.  "
            + "Values in-between are points on the path in between the waypoints.  "
            + "If set to Distance, then Path Position represents distance along the path.")]
        public TCBSplinePathSystem.PositionUnits PositionUnits;

        /// <summary>Where to put the camera relative to the path postion.
        /// X is perpendicular to the path, Y is up, and Z is parallel to the path.</summary>
        [Tooltip("Where to put the camera relative to the path position.  "
        + " X is perpendicular to the path, Y is up, and Z is parallel to the path.  "
        + "This allows the camera to be offset from the path itself (as if on a tripod, for example).")]
        public float3 PathOffset;

        /// <summary>How long it takes to position the camera at the desired spot on the track</summary>
        [Tooltip("How long it takes to position the camera at the desired spot on the track")]
        public float3 Damping;

        /// <summary>"How long it takes to respond to changes in the target's rotation</summary>
        [Tooltip("How long it takes to respond to changes in the target's rotation")]
        public float AngularDamping;

        /// <summary>Different ways to set the camera's up vector</summary>
        public enum CameraUpMode
        {
            /// <summary>Leave the camera's up vector alone.  It will be set according to the Channels's WorldUp.</summary>
            Default,
            /// <summary>Take the up vector from the path's up vector at the current point</summary>
            Path,
            /// <summary>Take the up vector from the path's up vector at the current point, but with the roll zeroed out</summary>
            PathNoRoll,
            /// <summary>Take the up vector from the Follow target's up vector</summary>
            FollowTarget,
            /// <summary>Take the up vector from the Follow target's up vector, but with the roll zero'ed out</summary>
            FollowTargetNoRoll,
        };

        /// <summary>How to set the CmNode's Up vector.  This will affect the screen composition.</summary>
        [Tooltip("How to set the CmNode's Up vector.  This will affect the screen composition, "
            + "because the camera Aim behaviours will always try to respect the Up direction.")]
        public CameraUpMode CameraUp;

        /// <summary>Controls how automatic dollying occurs</summary>
        [Serializable]
        public struct AutoDollySettings
        {
            /// <summary>If checked, will enable automatic dolly, which chooses a path position
            /// that is as close as possible to the Follow target.</summary>
            [Tooltip("If checked, will enable automatic dolly, which chooses a path position "
                + "that is as close as possible to the Follow target")]
            public bool Enabled;

            /// <summary>Offset, in current position units, from the closest point on the path to the follow target.</summary>
            [Tooltip("Offset, in current position units, from the closest point on the path to the follow target")]
            public float PositionOffset;

            /// <summary>Search up to how many waypoints on either side of the current position.  Use 0 for Entire path</summary>
            [Tooltip("Search up to how many waypoints on either side of the current position.  "
               + "Use 0 for Entire path.")]
            public int SearchRadius;

            /// <summary>We search between waypoints by dividing the segment into this many straight pieces.
            /// The higher the number, the more accurate the result, but performance is
            /// proportionally slower for higher numbers</summary>
            [Tooltip("We search between waypoints by dividing the segment into this many straight pieces.  "
                + "The higher the number, the more accurate the result, but performance is proportionally "
                + "slower for higher numbers")]
            public int SearchResolution;
        };

        /// <summary>Controls how automatic dollying occurs</summary>
        [Tooltip("Controls how automatic dollying occurs.  A Follow target is necessary to use this feature.")]
        public AutoDollySettings AutoDolly;
    }

    [Serializable]
    public struct DollyTrackState : IComponentData
    {
        public quaternion PreviousCameraRotation;
        public float3 PreviousCameraPosition;
        public float PreviousPathPosition;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPreBodySystem))]
    [UpdateBefore(typeof(CameraPostBodySystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class DollyTrackSystem : CinemachineSystemBase
    {
        StableIDEntityManager m_bindingKeySystem;

        EntityQuery m_missingStateQuery;
        EntityQuery m_missingTargetQuery;

        protected override void OnCreate()
        {
            m_bindingKeySystem = World.GetOrCreateSystem<StableIDEntityManager>();

            m_missingStateQuery = GetEntityQuery(
                ComponentType.Exclude<DollyTrackState>(),
                ComponentType.ReadOnly<DollyTrack>());

            m_missingTargetQuery = GetEntityQuery(
                ComponentType.Exclude<FollowTarget>(),
                ComponentType.ReadOnly<DollyTrack>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing transposer state components
            EntityManager.AddComponent(m_missingStateQuery,
                ComponentType.ReadWrite<DollyTrackState>());
            EntityManager.AddComponent(m_missingTargetQuery,
                ComponentType.ReadWrite<FollowTarget>());

            Dependency = m_bindingKeySystem.GetDereferencer(Dependency, out var pathLookup);

            var paths = GetComponentDataFromEntity<TCBSplinePathState>(true);
            var waypoints = GetBufferFromEntity<TCBSplinePathWaypointElement>(true);

            Entities
                .WithName("AutoDollyJob")
                .WithReadOnly(pathLookup)
                .WithReadOnly(waypoints)
                .WithReadOnly(paths)
                .ForEach((
                    ref DollyTrack dolly,
                    in PositionState posState,
                    in DollyTrackState dollyState,
                    in FollowTargetState follow,
                    in NodeUpdateState updateState) =>
                {
                    if (!pathLookup.Resolve(ref dolly.PathKey, out Entity pathEntity))
                        return;

                    if (!waypoints.HasComponent(pathEntity) || !paths.HasComponent(pathEntity) || !dolly.AutoDolly.Enabled)
                        return; // no path or no auto-dolly

                    if (follow.Value.Entity == Entity.Null)
                        return;

                    DynamicBuffer<TCBSplinePathWaypointElement> wp = waypoints[pathEntity];
                    TCBSplinePathState pathState = paths[pathEntity];

                    bool previousValid = updateState.PreviousFrameDataIsValid
                        && !math.all(dollyState.PreviousCameraRotation.value == 0);

                    // Auto-dolly: get the new ideal path base position if valid follow target.
                    // This works in path units
                    float prevPos = TCBSplinePathSystem.ToNativePathUnits(
                        ref wp, ref pathState, dollyState.PreviousPathPosition, dolly.PositionUnits);
                    var radius = dolly.AutoDolly.SearchRadius;
                    dolly.PathPosition = TCBSplinePathSystem.FindClosestPoint(
                        follow.Value.Position,
                        (int) math.floor(prevPos),
                        math.select(-1, radius, previousValid && radius > 0),
                        dolly.AutoDolly.SearchResolution,
                        ref pathState, ref wp);

                    dolly.PathPosition = TCBSplinePathSystem.FromPathNativeUnits(
                        ref wp, ref pathState, dolly.PathPosition, dolly.PositionUnits);

                    // Apply the path position offset
                    dolly.PathPosition += dolly.AutoDolly.PositionOffset;
                })
                .ScheduleParallel();

            Entities
                .WithName("DollyJob")
                .WithReadOnly(pathLookup)
                .WithReadOnly(waypoints)
                .WithReadOnly(paths)
                .ForEach((
                    ref PositionState posState,
                    ref DollyTrackState dollyState,
                    in DollyTrack dolly,
                    in NodeUpdateState updateState) =>
                {
                    if (!pathLookup.ResolveReadOnly(dolly.PathKey, out Entity pathEntity))
                        return;
                    if (!waypoints.HasComponent(pathEntity) || !paths.HasComponent(pathEntity))
                        return; // no path

                    if (updateState.ForcePositionAndRotation)
                    {
                        // posState already contains desired pos and rot
                        dollyState.PreviousCameraPosition = posState.RawPosition;
                        dollyState.PreviousCameraRotation = posState.RawRotation;
                        return;
                    }

                    DynamicBuffer<TCBSplinePathWaypointElement> wp = waypoints[pathEntity];
                    TCBSplinePathState pathState = paths[pathEntity];

                    // Where to go on the path
                    float newPathPosition = dolly.PathPosition;
                    bool previousValid = updateState.PreviousFrameDataIsValid
                        && !math.all(dollyState.PreviousCameraRotation.value == 0);
                    if (previousValid)
                    {
                        // Normalize previous position to find the shortest path
                        float maxUnit = TCBSplinePathSystem.MaxUnit(ref wp, ref pathState, dolly.PositionUnits);
                        float next = TCBSplinePathSystem.ClampUnit(
                            ref wp, ref pathState, newPathPosition, dolly.PositionUnits);
                        float prev = TCBSplinePathSystem.ClampUnit(
                            ref wp, ref pathState, dollyState.PreviousPathPosition, dolly.PositionUnits);
                        prev = math.select(
                            prev, math.select(prev - maxUnit, prev + maxUnit, next > prev),
                            pathState.Looped && math.abs(next - prev) > maxUnit / 2);

                        dollyState.PreviousPathPosition = prev;
                        newPathPosition = next;

                        // Apply damping along the path direction
                        float delta = newPathPosition - dollyState.PreviousPathPosition;
                        delta = MathHelpers.Damp(delta, dolly.Damping.z, updateState.DeltaTime);
                        newPathPosition = dollyState.PreviousPathPosition + delta;
                    }

                    dollyState.PreviousPathPosition = newPathPosition;

                    // Get the path info at the new position
                    float nativePathPos = TCBSplinePathSystem.ToNativePathUnits(
                        ref wp, ref pathState, newPathPosition, dolly.PositionUnits);
                    float3 newCameraPos
                        = TCBSplinePathSystem.EvaluatePosition(nativePathPos, ref pathState, ref wp);
                    var newPathOrientation
                        = TCBSplinePathSystem.EvaluateOrientation(nativePathPos, ref pathState, ref wp);

                    // Apply the offset to get the new camera position
                    newCameraPos += math.mul(newPathOrientation, dolly.PathOffset);

                    // Apply damping to the remaining directions
                    if (previousValid)
                    {
                        var delta = newCameraPos - dollyState.PreviousCameraPosition;
                        delta = math.mul(newPathOrientation, delta);
                        delta.xy = MathHelpers.Damp(delta.xy, dolly.Damping.xy, updateState.DeltaTime);
                        delta = math.mul(math.inverse(newPathOrientation), delta);
                        newCameraPos = dollyState.PreviousCameraPosition + delta;
                    }

                    posState.RawPosition = dollyState.PreviousCameraPosition = newCameraPos;

                    // Set the orientation and up
                    var newOrientation = GetCameraOrientationAtPathPoint(
                        newPathOrientation, updateState.WorldUp, dolly.CameraUp, newPathOrientation, posState.RawRotation);
                    float t = MathHelpers.Damp(1, dolly.AngularDamping,
                        math.select(dolly.AngularDamping, updateState.DeltaTime, previousValid));
                    newOrientation = math.slerp(dollyState.PreviousCameraRotation, newOrientation, t);
                    posState.RawRotation = dollyState.PreviousCameraRotation= newOrientation;
                    posState.Up = math.select(
                        math.normalize(math.mul(newOrientation, math.up())), updateState.WorldUp,
                        dolly.CameraUp == DollyTrack.CameraUpMode.Default);

                })
                .ScheduleParallel();

            m_bindingKeySystem.RegisterDereferencerReadJobs(Dependency);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static quaternion GetCameraOrientationAtPathPoint(
            quaternion pathOrientation, float3 up,
            DollyTrack.CameraUpMode upMode,
            quaternion followTargetRotation, quaternion cameraOrientation)
        {
            switch (upMode)
            {
                default: break;
                case DollyTrack.CameraUpMode.Path:
                    return pathOrientation;
                case DollyTrack.CameraUpMode.PathNoRoll:
                    return quaternion.LookRotation(math.mul(pathOrientation, new float3(0, 0, 1)), up);
                case DollyTrack.CameraUpMode.FollowTarget:
                    return followTargetRotation;
                case DollyTrack.CameraUpMode.FollowTargetNoRoll:
                    return quaternion.LookRotation(math.mul(followTargetRotation, new float3(0, 0, 1)), up);
            }

            return quaternion.LookRotation(math.mul(cameraOrientation, new float3(0, 0, 1)), up);
        }

    }
}
