using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct HardLockToTarget : IComponentData
    {
        [Tooltip("Offset is in Target Space")]
        public float3 Offset;

        public bool LockRotation;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPreBodySystem))]
    [UpdateBefore(typeof(CameraPostBodySystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class HardLockToTargetSystem : CinemachineSystemBase
    {
        protected override void OnUpdate()
        {
            base.OnUpdate();

            Entities
                .WithName("HardLockToTargetJob")
                .ForEach((
                    ref PositionState posState,
                    in HardLockToTarget hardLock,
                    in FollowTargetState follow) =>
                {
                    if (follow.Value.Entity == Entity.Null)
                        return;
                    var rot = follow.Value.Rotation.value;
                    posState.RawPosition = follow.Value.Position + math.mul(rot, hardLock.Offset);
                    posState.RawRotation = math.select(posState.RawRotation.value, rot, hardLock.LockRotation);
                })
                .ScheduleParallel();
        }
    }
}
