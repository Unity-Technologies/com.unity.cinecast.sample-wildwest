using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct CmSequencer : IComponentData
    {
        /// <summary>
        /// This enum controls what happens after the last camera is
        /// activated in the sequence
        /// </summary>
        public enum RepeatMode
        {
            /// <summary>Last camera is held indefinitely</summary>
            None,
            /// <summary>First camera gets activated after the last camera is finished</summary>
            Loop,
            /// <summary>Sequence reverses after the last camera in the list, in ping-pong fashion</summary>
            PingPong
        }
        /// <summary>
        /// This enum controls what happens after the last camera is
        /// activated in the sequence
        /// </summary>
        [Tooltip("This setting controls what happens after the last camera is activated in the sequence")]
        public RepeatMode Repeat;
    }

    [Serializable]
    struct CmSequencerState : IComponentData
    {
        public int CurrentInstruction;
        public bool Reverse;
    }

    /// <summary>
    /// This is a single entry in the sequencer's list of cameras
    /// </summary>
    [Serializable]
    public struct CmSequencerInstruction : IBufferElementData
    {
        /// <summary>How to blend to this node in the list</summary>
        [Tooltip("How to blend to this node in the list")]
        [TransitionDefinitionUnitsLabel("s", "The duration (in seconds) of the blend")]
        public TransitionDefinition Blend;

        /// <summary>The node to activate when this instruction becomes active</summary>
        [Tooltip("The node to activate when this instruction becomes active")]
        public Entity Node;

        /// <summary>How long to wait (in seconds) before activating the next node in the list (if any)</summary>
        [Tooltip("How long to wait (in seconds) before activating the next node in the list (if any)")]
        public float Hold;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CmChannelSystem))]
    [UpdateBefore(typeof(CmChannelFinalizeSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CmSequencerSystem : CinemachineSystemBase
    {
        const float MinHoldTime = 0.1f; // GML hack: should be a little over 1 frame

        EntityQuery m_missingStateQuery;

        protected override void OnCreate()
        {
            m_missingStateQuery = GetEntityQuery(
                ComponentType.Exclude<CmSequencerState>(),
                ComponentType.ReadOnly<CmSequencer>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing state components
            EntityManager.AddComponent(m_missingStateQuery,
                ComponentType.ReadWrite<CmSequencerState>());

            Entities
                .WithName("SequencerJob")
                .ForEach((
                    ref CmSequencerState sequencerState,
                    ref CmChannel channel,
                    ref CmChannelState channelState,
                    in DynamicBuffer<CmSequencerInstruction> instructions,
                    in CmSequencer sequencer,
                    in NodeUpdateState updateState) =>
                {
                    if (!updateState.PreviousFrameDataIsValid
                        || !updateState.IsLive
                        || instructions.Length == 0)
                    {
                        // Reset
                        channelState.DesiredActiveNode = instructions.Length > 0
                            ? instructions[0].Node
                            : Entity.Null;
                        channel.DefaultBlend.Length = 0; // cut
                        sequencerState.CurrentInstruction = 0;
                        sequencerState.Reverse = false;
                        return;
                    }

                    var last = instructions.Length - 1;
                    var current = math.clamp(sequencerState.CurrentInstruction, 0, last);
                    channelState.DesiredActiveNode = instructions[current].Node;
                    var holdTime = (double) math.select(
                        math.max(MinHoldTime, instructions[current].Hold + instructions[current].Blend.Length),
                        float.MaxValue, // hold forever
                        sequencer.Repeat == CmSequencer.RepeatMode.None && current == last);
                    if (channelState.CurrentTime - channelState.ActivationTime > holdTime && instructions.Length > 1)
                    {
                        // Change node
                        current += math.select(1, -1, sequencerState.Reverse);
                        if (current < 0)
                        {
                            // PingPong
                            sequencerState.Reverse = false;
                            current = 1;
                        }
                        else if (current == instructions.Length)
                        {
                            if (sequencer.Repeat == CmSequencer.RepeatMode.Loop)
                                current = 0;
                            else
                            {
                                // PingPong
                                sequencerState.Reverse = true;
                                current = last - 1;
                            }
                        }
                        channelState.DesiredActiveNode = instructions[current].Node;
                        sequencerState.CurrentInstruction = current;
                        channel.DefaultBlend = instructions[current].Blend;
                    }
                })
                .Schedule();
        }
    }
}
