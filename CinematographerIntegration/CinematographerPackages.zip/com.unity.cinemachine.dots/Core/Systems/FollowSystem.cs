using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System.Runtime.CompilerServices;
using UnityEngine;
using System;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// Component that controls a Follow behaviour for a Cinemachine Camera
    /// </summary>
    [Serializable]
    public struct FollowControl : IComponentData
    {
        /// <summary>The coordinate space to use when interpreting the offset from the target</summary>
        public FollowControlSystem.BindingMode Binding;

        /// <summary>The distance which the transposer will attempt to maintain from the transposer subject</summary>
        public float3 FollowOffset;

        /// <summary>How long it takes to respond to changes in the target's position</summary>
        [Tooltip("How long it takes to respond to changes in the target's position.")]
        public float3 Damping;

        /// <summary>How long it takes to respond to changes in the target's rotation.</summary>
        [Tooltip("How long it takes to respond to changes in the target's rotation.")]
        public float AngularDamping;
    }

    [Serializable]
    struct FollowControlState : IComponentData
    {
        /// State information used for damping
        public float3 PreviousTargetPosition;
        public quaternion PreviousTargetRotation;
        public float3 PreviousTargetOffset;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPreBodySystem))]
    [UpdateBefore(typeof(CameraPostBodySystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class FollowControlSystem : CinemachineSystemBase
    {
        /// <summary>
        /// The coordinate space to use when interpreting the offset from the target
        /// </summary>
        public enum BindingMode
        {
            /// <summary>
            /// Camera will be bound to the Follow target using a frame of reference consisting
            /// of the target's local frame, with the tilt and roll zeroed out.
            /// </summary>
            TargetAxesWithWorldUp,
            /// <summary>
            /// Camera will be bound to the Follow target using a frame of reference consisting
            /// of the target's local frame, with the roll zeroed out.
            /// </summary>
            TargetAxesNoRoll,
            /// <summary>
            /// Camera will be bound to the Follow target using the target's local frame.
            /// </summary>
            TargetAxes,
            /// <summary>Camera will be bound to the Follow target using a world space offset.</summary>
            WorldAxes,
            /// <summary>Offsets will be calculated relative to the target, using Camera-local axes</summary>
            CameraAxesWithWorldUp
        }

        EntityQuery m_missingStateGroup;

        protected override void OnCreate()
        {
            m_missingStateGroup = GetEntityQuery(
                ComponentType.Exclude<FollowControlState>(),
                ComponentType.ReadOnly<FollowControl>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing transposer state components
            EntityManager.AddComponent(m_missingStateGroup,
                ComponentType.ReadWrite<FollowControlState>());

            Entities
                .WithName("DampedFollowJob")
                .ForEach((
                    ref PositionState posState,
                    ref FollowControlState transposerState,
                    in FollowControl transposer,
                    in FollowTargetState follow,
                    in NodeUpdateState updateState) =>
                {
                    if (follow.Value.Entity == Entity.Null)
                        return;

                    if (updateState.ForcePositionAndRotation)
                    {
                        transposerState.PreviousTargetRotation = follow.Value.Rotation;
                        transposerState.PreviousTargetPosition = InferTargetPosFromCameraPos(
                            transposer.Binding, transposer.FollowOffset, posState.Up,
                            posState.RawPosition, posState.RawRotation, follow.Value.Rotation);
                        return;
                    }

                    bool previousValid = updateState.PreviousFrameDataIsValid
                        && !math.all(transposerState.PreviousTargetRotation.value == 0);
                    bool isSimpleFollow = transposer.Binding == BindingMode.CameraAxesWithWorldUp;

                    var prevPos = math.select(
                        follow.Value.Position, transposerState.PreviousTargetPosition, previousValid);
                    var prevRot = math.select(
                        follow.Value.Rotation.value, transposerState.PreviousTargetRotation.value, previousValid);

                    var targetPos = ApplyPositionDamping(
                        updateState.DeltaTime, 
                        math.select(0, transposer.Damping, previousValid),
                        prevPos, follow.Value.Position, prevRot);
                    var targetRot = GetRotationForBindingMode(
                        follow.Value.Rotation, transposer.Binding,
                        targetPos - posState.RawPosition, updateState.WorldUp);
                    targetRot = ApplyRotationDamping(
                        updateState.DeltaTime, 
                        math.select(0, transposer.AngularDamping, previousValid && !isSimpleFollow),
                        prevRot, targetRot);

                    posState.Up = math.normalize(math.mul(targetRot, math.up()));

                    var followOffset = transposer.FollowOffset;
                    followOffset.x = math.select(followOffset.x, 0, isSimpleFollow);
                    followOffset = math.mul(targetRot, followOffset);

                    // Respect minimum target distance on XZ plane
                    targetPos += GetOffsetForMinimumTargetDistance(
                        posState.RawPosition, posState.RawRotation, posState.Up,
                        math.length(followOffset.ProjectOntoPlane(posState.Up)) * 0.2f,
                        targetPos, follow.Value.Position);

                    // Assuming that the offset didn't change, where would we be?
                    var prevOffset = math.select(
                        followOffset, transposerState.PreviousTargetOffset, previousValid);

                    posState.RawPosition = targetPos + followOffset;
                    posState.DampingBypass = ComputeDampingBypass(
                        targetPos + prevOffset - follow.Value.Position,
                        posState.RawPosition - follow.Value.Position, posState.Up);

                    // If locking to target axes, we set the rotation too.
                    // GML todo: is this a good idea?  Or should we have SameAsFollowTarget in aim?
                    // Or should we add an offset to HardLockToTarget? GML
                    posState.RawRotation = math.select(
                        posState.RawRotation.value, targetRot.value,
                        transposer.Binding == BindingMode.TargetAxes);

                    transposerState.PreviousTargetPosition = targetPos;
                    transposerState.PreviousTargetRotation = targetRot;
                    transposerState.PreviousTargetOffset = followOffset;
                })
                .ScheduleParallel();
        }

        /// <summary>Applies damping to target rotation</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static quaternion ApplyRotationDamping(
            float deltaTime, float angularDamping,
            quaternion previousTargetRotation, quaternion currentTargetRotation)
        {
            float t = MathHelpers.Damp(1, angularDamping, deltaTime);
            var prevRot = math.select(
                previousTargetRotation.value, quaternion.identity.value,
                math.lengthsq(previousTargetRotation.value) == 0);
            return math.slerp(prevRot, currentTargetRotation, t);
        }

        /// <summary>Applies damping to target position</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float3 ApplyPositionDamping(
            float deltaTime, float3 damping,
            float3 previousTargetPosition, float3 currentTargetPosition,
            quaternion currentTargetRotation)
        {
            var worldOffset = currentTargetPosition - previousTargetPosition;
            float3 localOffset = math.mul(math.inverse(currentTargetRotation), worldOffset);
            localOffset = MathHelpers.Damp(localOffset, damping, deltaTime);
            worldOffset = math.mul(currentTargetRotation, localOffset);
            return previousTargetPosition + worldOffset;
        }

        /// <summary>Applies binding mode:
        /// Returns the axes for applying target offset and damping</summary>
        public static quaternion GetRotationForBindingMode(
            quaternion targetRotation,
            BindingMode bindingMode,
            float3 directionCameraToTarget, // not normalized
            float3 up)
        {
            // GML todo: optimize!  Can we get rid of the switch?
            switch (bindingMode)
            {
                case BindingMode.TargetAxesWithWorldUp:
                    return MathHelpers.Uppify(targetRotation, up);
                case BindingMode.TargetAxesNoRoll:
                    return quaternion.LookRotationSafe(math.forward(targetRotation), up);
                case BindingMode.TargetAxes:
                    return targetRotation;
                case BindingMode.CameraAxesWithWorldUp:
                {
                    directionCameraToTarget = directionCameraToTarget.ProjectOntoPlane(up);
                    float len = math.length(directionCameraToTarget);
                    return math.select(
                        quaternion.LookRotation(directionCameraToTarget / len, up).value,
                        targetRotation.value, len < MathHelpers.Epsilon);
                }
                default:
                    return quaternion.identity;
            }
        }

        public static float3 InferTargetPosFromCameraPos(
            BindingMode bindingMode, float3 followOffset, float3 up,
            float3 camPos, quaternion camRot, quaternion targetRot)
        {
            // GML todo: optimize!  Can we get rid of the switch?
            switch (bindingMode)
            {
                default:
                case BindingMode.WorldAxes: return camPos - followOffset;
                case BindingMode.TargetAxes: return camPos - math.mul(targetRot, followOffset);
                case BindingMode.TargetAxesWithWorldUp:
                    return camPos - math.mul(MathHelpers.Uppify(targetRot, up), followOffset);
                case BindingMode.TargetAxesNoRoll:
                    return camPos - math.mul(quaternion.LookRotationSafe(math.forward(targetRot), up), followOffset);
                case BindingMode.CameraAxesWithWorldUp: return camPos + math.mul(camRot, followOffset);
            }
        }

        /// <summary>Compute translation/rotation of offset vector relative to target</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static quaternion ComputeDampingBypass(
            float3 oldOffset, float3 newOffset, float3 up)
        {
            float r0 = math.length(oldOffset);
            float r1 = math.length(newOffset);
            return math.select(
                quaternion.identity.value,
                MathHelpers.FromToRotationUnit(-oldOffset / r0, -newOffset / r1, up).value,
                r0 > MathHelpers.Epsilon && r1 > MathHelpers.Epsilon);
        }

        /// <summary>Return a new damped target position that respects the minimum
        /// distance from the real target</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float3 GetOffsetForMinimumTargetDistance(
            float3 cameraPos, quaternion cameraRot, float3 up, float minDistance,
            float3 dampedTargetPos, float3 actualTargetPos)
        {
            var planeCameraPos = cameraPos.ProjectOntoPlane(up);
            var planeRealTargetPos = actualTargetPos.ProjectOntoPlane(up);
            var planeTargetPos = dampedTargetPos.ProjectOntoPlane(up);
            var d = math.dot(
                planeRealTargetPos - planeCameraPos,
                math.normalize(planeTargetPos - planeCameraPos));
            if (minDistance > 0 && d < minDistance)
            {
                var dir = math.normalizesafe(
                    planeRealTargetPos - planeTargetPos, -math.forward(cameraRot));
                return dir * (minDistance - d);
            }
            return float3.zero;
        }
    }
}
