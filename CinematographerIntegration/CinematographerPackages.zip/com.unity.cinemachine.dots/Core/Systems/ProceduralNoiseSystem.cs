using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct ProceduralNoise : IComponentData
    {
        /// <summary>
        /// Length of the arm that holds the camera.  Rotation occurs at the base of the arm.
        /// </summary>
        [Tooltip("Length of the arm that holds the camera.  Rotation occurs at the base of the arm.")]
        public float ArmLength;

        /// <summary>
        /// This guarantees repeatability of the noise, variety between cameras.
        /// </summary>
        [Tooltip("This guarantees repeatability of the noise, variety between cameras.")]
        public float NoiseSeed;
    }

    [Serializable]
    public struct ProceduralNoiseChannelElement : IBufferElementData
    {
        /// <summary>
        /// Gain to apply to the amplitudes defined in the settings asset.
        /// </summary>
        [Tooltip("Gain to apply to the amplitudes defined in the NoiseSettings asset.  "
            + "1 is normal.  Setting this to 0 completely mutes the noise.")]
        public float AmplitudeGain;

        /// <summary>
        /// Scale factor to apply to the frequencies defined in the settings asset.
        /// </summary>
        [Tooltip("Scale factor to apply to the frequencies defined in the NoiseSettings asset.  "
            + "1 is normal.  Larger magnitudes will make the noise shake more rapidly.")]
        public float FrequencyGain;

        /// <summary>
        /// State info - current position in the noise signal
        /// </summary>
        public float NoiseTime;
    }

    [Serializable]
    [InternalBufferCapacity(9)]
    public struct ProceduralRotNoiseElement : IBufferElementData
    {
        public int ChannelIndex;
        public AdditiveNoiseElement Value;
    }

    [Serializable]
    [InternalBufferCapacity(9)]
    public struct ProceduralPosNoiseElement : IBufferElementData
    {
        public int ChannelIndex;
        public AdditiveNoiseElement Value;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPreNoiseSystem))]
    [UpdateBefore(typeof(CameraFinalizeSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class GeneratedWaveSystem : CinemachineSystemBase
    {
        protected override void OnUpdate()
        {
            base.OnUpdate();

            Entities
                .WithName("ProceduralNoiseJob")
                .ForEach((
                    DynamicBuffer<ProceduralNoiseChannelElement> channels,
                    ref PositionState posState,
                    in DynamicBuffer<ProceduralPosNoiseElement> posSignal,
                    in DynamicBuffer<ProceduralRotNoiseElement> rotSignal,
                    in ProceduralNoise noise,
                    in NodeUpdateState updateState) =>
                {
                    for (int i = 0; i < channels.Length; ++i)
                    {
                        var c = channels[i];
                        c.NoiseTime += updateState.DeltaTime * c.FrequencyGain;
                        channels[i] = c;
                    }

                    float3 s = float3.zero;
                    for (int i = 0; i < rotSignal.Length; ++i)
                    {
                        var ch = rotSignal[i].ChannelIndex;
                        s[math.clamp(rotSignal[i].Value.Axis, 0, 2)]
                            += rotSignal[i].Value.GetValueAt(channels[ch].NoiseTime, noise.NoiseSeed)
                                * channels[ch].AmplitudeGain;
                    }

                    var q = quaternion.Euler(math.radians(s));
                    float3 arm = new float3(0, 0, noise.ArmLength);
                    posState.PositionCorrection += (math.mul(q, arm) - arm);
                    posState.RotationCorrection = math.mul(posState.RotationCorrection, q);

                    s = float3.zero;
                    for (int i = 0; i < posSignal.Length; ++i)
                    {
                        var ch = posSignal[i].ChannelIndex;
                        s[math.clamp(posSignal[i].Value.Axis, 0, 2)]
                            += posSignal[i].Value.GetValueAt(channels[ch].NoiseTime, noise.NoiseSeed)
                                * channels[ch].AmplitudeGain;
                    }
                    posState.PositionCorrection += s;
                })
                .ScheduleParallel();
        }
    }
}
