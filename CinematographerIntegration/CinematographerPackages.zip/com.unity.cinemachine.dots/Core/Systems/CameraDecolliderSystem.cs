#if CINEMACHINE_UNITY_PHYSICS

using Unity.Collections;
using Unity.Entities;
using Unity.Physics;
using System;
using Unity.Mathematics;
using System.Runtime.CompilerServices;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct CameraDecollider : IComponentData
    {
        /// <summary>Objects on these layers will be detected.</summary>
        [UnityEngine.Tooltip("Objects on these layers will be detected")]
        [UnityPhysicsLayerMask]
        public int CollideAgainst;

        /// <summary>
        /// Camera will try to maintain this distance from any obstacle.
        /// Increase this value if you are seeing inside obstacles due to a large
        /// FOV on the camera.
        /// </summary>
        [UnityEngine.Tooltip("Camera will try to maintain this distance from any obstacle.  "
            + "Try to keep this value small.  Increase it if you are seeing inside obstacles "
            + "due to a large FOV on the camera.")]
        public float CameraRadius;
    }

    struct CameraDecolliderState : IComponentData
    {
        public float3 previousCamPos;
        public bool IsValid;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPostBodySystem))]
    [UpdateBefore(typeof(CameraPreAimSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CameraDecolliderSystem : CinemachineSystemBase
    {
        Physics.Systems.BuildPhysicsWorld m_physicsWorldSystem;
        EntityQuery m_missingStateQuery;

        protected override void OnCreate()
        {
            m_physicsWorldSystem = World.GetOrCreateSystem<Physics.Systems.BuildPhysicsWorld>();
            m_missingStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<CameraDecollider>(),
                ComponentType.Exclude<CameraDecolliderState>());
        }

        protected override void OnStartRunning()
        {
            base.OnStartRunning();
            Physics.Systems.PhysicsRuntimeExtensions.RegisterPhysicsRuntimeSystemReadOnly(this);
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing state components
            EntityManager.AddComponent(m_missingStateQuery,
                ComponentType.ReadWrite<CameraDecolliderState>());

            PhysicsWorld physicsWorld = m_physicsWorldSystem.PhysicsWorld;
            Entities
                .WithName("CameraDecolliderJob")
                .WithAll<NodeChannelAssignment>()
                .WithReadOnly(physicsWorld)
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    ref CameraDecolliderState colliderState,
                    ref PositionState posState,
                    in CameraDecollider collider,
                    in LookAtTargetState lookAt,
                    in NodeUpdateState updateState) =>
                {
                    if (lookAt.Value.Entity == Entity.Null)
                        return;

                    bool previousValid = updateState.PreviousFrameDataIsValid 
                        & (colliderState.IsValid);
                    float3 cameraPos = posState.GetCorrectedPosition();
                    var localData = new LocalData
                    {
                        lookAtPoint = lookAt.Value.Position,
                        up = posState.Up,
                        prevCamPos = math.select(
                            lookAt.Value.Position, colliderState.previousCamPos, previousValid),
                        entity = entity,
                        targetEntity = lookAt.Value.Entity,
                        physicsWorld = physicsWorld,
                        hitBuffer = new NativeList<DistanceHit>(
                            LocalData.kHitBufferCacacity, Allocator.Temp)
                    };

#if false
                    // A prior strategy involved updating this system after Aim, while
                    // preserving the LookAt point on the screen.  This is not great,
                    // because framing is often incorrect.  Instead, updating before Aim.

                    // Save the target screen position
                    float3 dirToTarget = math.normalizesafe(
                        lookAt.Value.Position - cameraPos, new float3(0, 0, 1));
                    float2 screenRot = MathHelpers.GetCameraRotationToTarget(
                        posState.RawRotation, dirToTarget, posState.Up);
#endif
                    var newCamPos = MoveCamera(cameraPos, ref localData, collider);
                    newCamPos = RespectCameraRadius(newCamPos, ref localData, collider);
                    posState.RawPosition += newCamPos - cameraPos;
                    colliderState.previousCamPos = posState.GetCorrectedPosition();
                    colliderState.IsValid = true;

#if false
                    // See note in commented out section above

                    // Restore the target screen position
                    dirToTarget = math.normalizesafe(
                        lookAt.Value.Position - newCamPos, new float3(0, 0, 1));
                    posState.RawRotation = MathHelpers.ApplyCameraRotation(
                        quaternion.LookRotation(dirToTarget, posState.Up), screenRot, posState.Up);
#endif
                })
                .ScheduleParallel();
        }

        const float Epsilon = MathHelpers.Epsilon;

        struct LocalData
        {
            public float3 lookAtPoint;
            public float3 up;
            public float3 prevCamPos;
            public Entity entity;
            public Entity targetEntity;
            public PhysicsWorld physicsWorld;

            public const int kHitBufferCacacity = 8;
            public NativeList<DistanceHit> hitBuffer;
        };

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static CollisionFilter StandardFilter(in CameraDecollider collider)
        {
            return new CollisionFilter()
            {
                BelongsTo = unchecked((uint)collider.CollideAgainst),
                CollidesWith = unchecked((uint)collider.CollideAgainst),
                GroupIndex = 0
            };
        }

        static float3 MoveCamera(
            float3 cameraPos, ref LocalData localData,
            in CameraDecollider collider)
        {
            var dir = cameraPos - localData.prevCamPos;
            if (math.lengthsq(dir) > Epsilon)
            {
                RaycastInput input = new RaycastInput()
                {
                    Start = localData.prevCamPos,
                    End = cameraPos,
                    Filter = StandardFilter(collider)
                };
                if (CollisionHelpers.RaycastNearestIgnoreEntity(
                    localData.physicsWorld.CollisionWorld, input, localData.targetEntity, out RaycastHit hit))
                {
                    cameraPos = PullCameraInFrontOfObstacle(
                        cameraPos, ref localData, collider, hit.RigidBodyIndex);
                }
            }
            return cameraPos;
        }

        static float3 PullCameraInFrontOfObstacle(
            float3 cameraPos, ref LocalData localData,
            in CameraDecollider collider, int rigidBodyIndex)
        {
            if (rigidBodyIndex < 0)
                return cameraPos;
            var rb = localData.physicsWorld.Bodies[rigidBodyIndex];
            if (rb.Entity == localData.targetEntity)
                return cameraPos;

            RaycastInput input = new RaycastInput()
            {
                Start = localData.lookAtPoint,
                End = cameraPos,
                Filter = StandardFilter(collider)
            };
            if (CollisionHelpers.RaycastNearestSingleEntity(
                localData.physicsWorld.CollisionWorld, input, rb.Entity, out RaycastHit hit))
                cameraPos = hit.Position;
            return cameraPos;
        }

        static float3 RespectCameraRadius(
            float3 cameraPos, ref LocalData localData,
            in CameraDecollider collider)
        {
            if (collider.CameraRadius < Epsilon)
                return cameraPos;

            PointDistanceInput input = new PointDistanceInput
            {
                Position = cameraPos,
                MaxDistance = collider.CameraRadius,
                Filter = StandardFilter(collider)
            };
            localData.hitBuffer.Clear();
            localData.physicsWorld.CalculateDistance(input, ref localData.hitBuffer);

            // Move camera out of all obstacles, towards the target
            for (int i = 0; i < localData.hitBuffer.Length; ++i)
                cameraPos = PullCameraInFrontOfObstacle(
                    cameraPos, ref localData, collider, localData.hitBuffer[i].RigidBodyIndex);

            // Now a final adjustment to respect the radius... this isn't strictly correct
            input.Position = cameraPos;
            localData.hitBuffer.Clear();
            localData.physicsWorld.CalculateDistance(input, ref localData.hitBuffer);
            float3 adjustment = float3.zero;
            for (int i = 0; i < localData.hitBuffer.Length; ++i)
            {
                var offsetDir = localData.hitBuffer[i].SurfaceNormal;
                var startDir = localData.hitBuffer[i].Position - cameraPos;
                var offsetDistance = math.sign(math.dot(offsetDir, startDir)) * math.length(startDir)
                    + collider.CameraRadius;
                if (math.length(adjustment) < offsetDistance)
                    adjustment = offsetDir * offsetDistance;
            }
            return cameraPos + adjustment;
        }
    }
}
#endif
