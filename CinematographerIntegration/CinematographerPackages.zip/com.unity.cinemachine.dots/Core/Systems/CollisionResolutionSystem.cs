#if CINEMACHINE_UNITY_PHYSICS
//#define SHOW_DEBUG_PATH // GML debugging: enable for visualization of resolution path

using Unity.Collections;
using Unity.Entities;
using Unity.Burst;
using Unity.Physics;
using System;
using Unity.Mathematics;
using System.Runtime.CompilerServices;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct CollisionResolution : IComponentData
    {
        /// <summary>Objects on these layers will be detected.</summary>
        [UnityEngine.Tooltip("Objects on these layers will be detected")]
        [UnityPhysicsLayerMask]
        public int CollideAgainst;

        /// <summary>Objects on these layers will never obstruct view of the target.</summary>
        [UnityEngine.Tooltip("Objects on these layers will never obstruct view of the target")]
        [UnityPhysicsLayerMask]
        public int TransparentLayers;

        /// <summary>Obstacles closer to the target than this will be ignored</summary>
        [UnityEngine.Tooltip("Obstacles closer to the target than this will be ignored")]
        public float MinimumDistanceFromTarget;

        /// <summary>
        /// The raycast distance to test for when checking if the line of sight to this
        /// camera's target is clear.
        /// </summary>
        [UnityEngine.Space]
        [UnityEngine.Tooltip("The maximum raycast distance when checking if the line of sight to this "
            + "camera's target is clear.  If the setting is 0 or less, the current actual "
            + "distance to target will be used.")]
        public float DistanceLimit;

        /// <summary>
        /// Don't take action unless occlusion has lasted at least this long.
        /// </summary>
        [UnityEngine.Tooltip("Don't take action unless occlusion has lasted at least this long.")]
        public float MinimumOcclusionTime;

        /// <summary>
        /// Camera will try to maintain this distance from any obstacle.
        /// Increase this value if you are seeing inside obstacles due to a large
        /// FOV on the camera.
        /// </summary>
        [UnityEngine.Tooltip("Camera will try to maintain this distance from any obstacle.  "
            + "Try to keep this value small.  Increase it if you are seeing inside obstacles "
            + "due to a large FOV on the camera.")]
        public float CameraRadius;

        /// <summary>The way in which the Collider will attempt to preserve sight of the target.</summary>
        public enum ResolutionStrategy
        {
            /// <summary>Camera will be pulled forward along its Z axis until it is in front of
            /// the nearest obstacle</summary>
            PullCameraForward,
            /// <summary>In addition to pulling the camera forward, an effort will be made to
            /// return the camera to its original height</summary>
            PreserveCameraHeight,
            /// <summary>In addition to pulling the camera forward, an effort will be made to
            /// return the camera to its original distance from the target</summary>
            PreserveCameraDistance
        };
        /// <summary>The way in which the Collider will attempt to preserve sight of the target.</summary>
        [UnityEngine.Tooltip("The way in which the Collider will attempt to preserve sight of the target.")]
        public ResolutionStrategy Strategy;

        /// <summary>
        /// Upper limit on how many obstacle hits to process.  Higher numbers may impact performance.
        /// In most environments, 4 is enough.
        /// </summary>
        [UnityEngine.Range(1, 20)]
        [UnityEngine.Tooltip("Upper limit on how many obstacle hits to process.  "
            + "Higher numbers may impact performance.  In most environments, 4 is enough.")]
        public int MaximumEffort;

        /// <summary>
        /// Smoothing to apply to obstruction resolution.  Nearest camera point is held for
        /// at least this long.
        /// </summary>
        [UnityEngine.Range(0, 2)]
        [UnityEngine.Tooltip("Smoothing to apply to obstruction resolution.  Nearest camera point is "
            + "held for at least this long")]
        public float SmoothingTime;

        /// <summary>
        /// How gradually the camera returns to its normal position after having been corrected.
        /// Higher numbers will move the camera more gradually back to normal.
        /// </summary>
        [UnityEngine.Range(0, 10)]
        [UnityEngine.Tooltip("How gradually the camera returns to its normal position after having been "
            + "corrected.  Higher numbers will move the camera more gradually back to normal.")]
        public float Damping;

        /// <summary>
        /// How gradually the camera moves to resolve an occlusion.
        /// Higher numbers will move the camera more gradually.
        /// </summary>
        [UnityEngine.Range(0, 10)]
        [UnityEngine.Tooltip("How gradually the camera moves to resolve an occlusion.  Higher numbers "
            + "will move the camera more gradually.")]
        public float DampingWhenOccluded;
    }

    [BurstCompile]
    struct CollisionResolutionState : IComponentData
    {
        public float3 previousDisplacement;
        public float3 previousDisplacementCorrection;
        public float colliderDisplacement;
        public double occlusionStartTime;

        private float smoothedDistance;
        private double smoothedTime;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float ApplyDistanceSmoothing(float distance, float smoothingTime, double timeNow)
        {
            if (smoothedTime != 0 && smoothingTime > MathHelpers.Epsilon)
            {
                if ((float)(timeNow - smoothedTime) < smoothingTime)
                    return math.min(distance, smoothedDistance);
            }
            return distance;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void UpdateDistanceSmoothing(float distance, float smoothingTime, double timeNow)
        {
            if (smoothedDistance == 0 || distance <= smoothedDistance)
            {
                smoothedDistance = distance;
                smoothedTime = timeNow;
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void ResetDistanceSmoothing(float smoothingTime, double timeNow)
        {
            if ((float)(timeNow - smoothedTime) >= smoothingTime)
            {
                smoothedDistance = 0;
                smoothedTime = 0;
            }
        }
    }

#if UNITY_EDITOR // Used only if SHOW_DEBUG_PATH
    [Serializable]
    [InternalBufferCapacity(8)]
    public struct CollisionResolutionDebugElement : IBufferElementData
    {
        public float3 pathPoint;
    }
#endif

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPostBodySystem))]
    [UpdateBefore(typeof(CameraPreAimSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CollisionResolutionSystem : CinemachineSystemBase
    {
        CmChannelSystem m_channelSystem;
        Physics.Systems.BuildPhysicsWorld m_physicsWorldSystem;
        EntityQuery m_missingStateQuery;
#if SHOW_DEBUG_PATH && UNITY_EDITOR
        EntityQuery m_missingDebugQuery;
#endif

        protected override void OnCreate()
        {
            m_channelSystem = World.GetOrCreateSystem<CmChannelSystem>();
            m_physicsWorldSystem = World.GetOrCreateSystem<Physics.Systems.BuildPhysicsWorld>();
            m_missingStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<CollisionResolution>(),
                ComponentType.Exclude<CollisionResolutionState>());
#if SHOW_DEBUG_PATH && UNITY_EDITOR
            m_missingDebugQuery = GetEntityQuery(
                ComponentType.ReadOnly<CollisionResolution>(),
                ComponentType.Exclude<CollisionResolutionDebugElement>());
#endif
        }

        protected override void OnStartRunning()
        {
            base.OnStartRunning();
            Physics.Systems.PhysicsRuntimeExtensions.RegisterPhysicsRuntimeSystemReadOnly(this);
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing composer state components
            EntityManager.AddComponent(m_missingStateQuery,
                ComponentType.ReadWrite<CollisionResolutionState>());
#if SHOW_DEBUG_PATH && UNITY_EDITOR
            EntityManager.AddComponent(m_missingDebugQuery,
                ComponentType.ReadWrite<CollisionResolutionDebugElement>());
#endif

            PhysicsWorld physicsWorld = m_physicsWorldSystem.PhysicsWorld;
            var timeNow = ClientHooks.GetCurrentTime(World);

#if SHOW_DEBUG_PATH && UNITY_EDITOR
            var debugBuffers = GetBufferFromEntity<CollisionResolutionDebugElement>();
#endif
            Entities
                .WithName("CollisionResolutionJob")
                .WithReadOnly(physicsWorld)
#if SHOW_DEBUG_PATH && UNITY_EDITOR
                .WithNativeDisableParallelForRestriction(debugBuffers)
#endif
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    ref CollisionResolutionState colliderState,
                    ref PositionState posState,
                    in NodeUpdateState updateState,
                    in CollisionResolution collider,
                    in LookAtTargetState lookAt) =>
                {
                    float deltaTime = updateState.DeltaTime;
                    float3 cameraPos = posState.GetCorrectedPosition();
                    var localData = new LocalData
                    {
                        lookAtPoint = lookAt.Value.Position,
                        up = posState.Up,
                        entity = entity,
                        targetEntity = lookAt.Value.Entity,
                        physicsWorld = physicsWorld,
#if SHOW_DEBUG_PATH && UNITY_EDITOR
                        debugBuffers = debugBuffers,
#endif
                        hitBuffer = new NativeList<DistanceHit>(
                            LocalData.kHitBufferCacacity, Allocator.Temp)
                    };
                    localData.ResetDebugPath();

#if false
                    // A prior strategy involved updating this system after Aim, while
                    // preserving the LookAt point on the screen.  This is not great,
                    // because framing is often incorrect.  Instead, updating before Aim.

                    // Save the target screen position
                    float3 dirToTarget = math.normalizesafe(
                        lookAt.Value.Position - cameraPos, new float3(0, 0, 1));
                    float2 screenRot = MathHelpers.GetCameraRotationToTarget(
                        posState.RawRotation, dirToTarget, posState.Up);
#endif
                    float3 displacement = PreserveLignOfSight(
                        cameraPos, ref localData, collider, colliderState);
                    if (collider.MinimumOcclusionTime > Epsilon)
                    {
                        if (math.lengthsq(displacement) < Epsilon)
                            colliderState.occlusionStartTime = 0;
                        else
                        {
                            if (colliderState.occlusionStartTime <= 0)
                                colliderState.occlusionStartTime = timeNow;
                            if ((float)(timeNow - colliderState.occlusionStartTime) < collider.MinimumOcclusionTime)
                                displacement = colliderState.previousDisplacement;
                        }
                    }

                    // Apply distance smoothing
                    if (collider.SmoothingTime > Epsilon)
                    {
                        float3 pos = cameraPos + displacement;
                        float3 dir = pos - lookAt.Value.Position;
                        float distance = math.length(dir);
                        if (distance > Epsilon)
                        {
                            dir /= distance;
                            if (!displacement.AlmostZero())
                                colliderState.UpdateDistanceSmoothing(distance, collider.SmoothingTime, timeNow);
                            distance = colliderState.ApplyDistanceSmoothing(distance, collider.SmoothingTime, timeNow);
                            displacement += (lookAt.Value.Position + dir * distance) - pos;
                        }
                    }

                    float damping = collider.Damping;
                    if (displacement.AlmostZero())
                        colliderState.ResetDistanceSmoothing(collider.SmoothingTime, timeNow);
                    else
                        damping = collider.DampingWhenOccluded;
                    if (damping > 0 && updateState.PreviousFrameDataIsValid)
                    {
                        float3 delta = displacement - colliderState.previousDisplacement;
                        delta = MathHelpers.Damp(delta, damping, deltaTime);
                        displacement = colliderState.previousDisplacement + delta;
                    }
                    colliderState.previousDisplacement = displacement;

                    float3 correction = RespectCameraRadius(
                        cameraPos + displacement, ref localData, collider);
                    if (damping > 0 && updateState.PreviousFrameDataIsValid)
                    {
                        float3 delta = correction - colliderState.previousDisplacementCorrection;
                        delta = MathHelpers.Damp(delta, damping, deltaTime);
                        correction = colliderState.previousDisplacementCorrection + delta;
                    }
                    displacement += correction;
                    colliderState.previousDisplacementCorrection = correction;
                    colliderState.colliderDisplacement += math.length(displacement);
                    posState.RawPosition += displacement;

#if false
                    // See note in commented out section above

                    // Restore the target screen position
                    dirToTarget = math.normalizesafe(lookAt.Value.Position - (cameraPos + displacement), new float3(0, 0, 1));
                    posState.RawRotation = MathHelpers.ApplyCameraRotation(
                        quaternion.LookRotation(dirToTarget, posState.Up), screenRot, posState.Up);
#endif

                    // Not supposed to dispose - happens automatically
                    //localData.hitBuffer.Dispose();
                })
                .ScheduleParallel();
        }

        const float Epsilon = MathHelpers.Epsilon;

        struct LocalData
        {
            public float3 lookAtPoint;
            public float3 up;
            public Entity entity;
            public Entity targetEntity;
            public PhysicsWorld physicsWorld;

            public const int kHitBufferCacacity = 8;
            public NativeList<DistanceHit> hitBuffer;

#if SHOW_DEBUG_PATH && UNITY_EDITOR
            [ReadOnly] public BufferFromEntity<CollisionResolutionDebugElement> debugBuffers;

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public void AddPointToDebugPath(float3 point)
            {
                var buffer = debugBuffers[entity];
                buffer.Add(new CollisionResolutionDebugElement { pathPoint = point });
            }
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public void ResetDebugPath()
            {
                var buffer = debugBuffers[entity];
                buffer.Clear();
            }
#else
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public void AddPointToDebugPath(float3 point) {}
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public void ResetDebugPath() {}
#endif
        };

        /// This must be small but greater than 0 - reduces false results due to precision
        const float PrecisionSlush = 0.005f;

#if SHOW_DEBUG_PATH && UNITY_EDITOR

#endif

        static float3 PreserveLignOfSight(
            float3 cameraPos, ref LocalData localData,
            in CollisionResolution collider,
            in CollisionResolutionState colliderState)
        {
            float3 displacement = float3.zero;
            if (collider.CollideAgainst != 0 && collider.CollideAgainst != collider.TransparentLayers)
            {
                RaycastHit hitInfo = new RaycastHit();
                displacement = PullCameraInFrontOfNearestObstacle(
                    cameraPos,
                    unchecked((uint)collider.CollideAgainst) & ~unchecked((uint)collider.TransparentLayers),
                    ref localData, ref hitInfo, in collider);
                float3 pos = cameraPos + displacement;
                if (!hitInfo.SurfaceNormal.AlmostZero())
                {
                    localData.AddPointToDebugPath(pos);

                    if (collider.Strategy != CollisionResolution.ResolutionStrategy.PullCameraForward)
                    {
                        float3 targetToCamera = cameraPos - localData.lookAtPoint;
                        float targetDistance = math.length(targetToCamera);
                        pos = PushCameraBack(
                            pos, ref localData, targetToCamera / targetDistance, hitInfo,
                            new Plane(localData.up, -math.dot(localData.up, cameraPos)),
                            targetDistance, collider.MaximumEffort,
                            unchecked((uint)collider.CollideAgainst) & ~unchecked((uint)collider.TransparentLayers),
                            colliderState, collider.Strategy);
                    }
                }
                displacement = pos - cameraPos;
            }
            return displacement;
        }

        static float3 PullCameraInFrontOfNearestObstacle(
            float3 cameraPos, uint layerMask,
            ref LocalData localData, ref RaycastHit hitInfo,
            in CollisionResolution collider)
        {
            float3 displacement = float3.zero;
            float3 dir = cameraPos - localData.lookAtPoint;
            float targetDistance = math.length(dir);
            if (targetDistance > Epsilon)
            {
                dir /= targetDistance;
                float minDistanceFromTarget = math.max(collider.MinimumDistanceFromTarget, Epsilon);
                if (targetDistance < minDistanceFromTarget + Epsilon)
                    displacement = dir * (minDistanceFromTarget - targetDistance);
                else
                {
                    float rayLength = targetDistance - minDistanceFromTarget;
                    if (collider.DistanceLimit > Epsilon)
                        rayLength = math.min(collider.DistanceLimit, rayLength);

                    // Make a ray that looks towards the camera, to get the obstacle closest to target
                    rayLength += PrecisionSlush;
                    if (RaycastIgnoreTarget(
                        cameraPos - rayLength * dir, cameraPos, localData.physicsWorld,
                        out hitInfo, layerMask, localData.targetEntity))
                    {
                        // Pull camera forward in front of obstacle
                        var p = hitInfo.Position - dir * PrecisionSlush;
                        displacement = p - cameraPos;
                    }
                }
            }
            return displacement;
        }

        // Assumes that ray direction is normalized
        static bool RaycastIgnoreTarget(
            float3 rayStart, float3 rayEnd, in PhysicsWorld physicsWorld,
            out RaycastHit hitInfo, uint layerMask, Entity targetEntity)
        {
            RaycastInput input = new RaycastInput()
            {
                Start = rayStart,
                End = rayEnd,
                Filter = new CollisionFilter()
                {
                    BelongsTo = layerMask,
                    CollidesWith = layerMask,
                    GroupIndex = 0
                }
            };
            return CollisionHelpers.RaycastNearestIgnoreEntity(
                physicsWorld.CollisionWorld, input, targetEntity, out hitInfo);
        }

        static float3 PushCameraBack(
            float3 currentPos, ref LocalData localData,
            float3 pushDir, RaycastHit obstacle,
            Plane startPlane, float targetDistance, int iterations,
            uint layerMask, in CollisionResolutionState colliderState,
            CollisionResolution.ResolutionStrategy strategy)
        {
            // Take a step along the wall.
            float3 pos = currentPos;
            float3 dir = float3.zero;
            if (!GetWalkingDirection(pos, pushDir, obstacle, layerMask, ref dir, ref localData))
                return pos;

            Ray ray = new Ray { Origin = pos, Displacement = dir };
            float distance = GetPushBackDistance(ray, startPlane, targetDistance, ref localData, strategy);
            if (distance <= Epsilon)
                return pos;

            // Check only as far as the obstacle bounds
            var bounds = localData.physicsWorld.Bodies[obstacle.RigidBodyIndex].CalculateAabb();
            float clampedDistance = ClampRayToBounds(ray, distance, bounds);
            distance = math.min(distance, clampedDistance + PrecisionSlush);

            if (RaycastIgnoreTarget(
                pos, pos + dir + distance, localData.physicsWorld,
                out RaycastHit hitInfo, layerMask, localData.targetEntity))
            {
                // We hit something.  Stop there and take a step along that wall.
                pos = hitInfo.Position - dir * PrecisionSlush;
                localData.AddPointToDebugPath(pos);
                if (iterations > 1)
                    pos = PushCameraBack(
                        pos, ref localData, dir, hitInfo, startPlane,
                        targetDistance, iterations-1, layerMask, colliderState, strategy);

                return pos;
            }

            // Didn't hit anything.  Can we push back all the way now?
            pos = ray.Origin + ray.Displacement * distance;

            // First check if we can still see the target.  If not, abort
            dir = pos - localData.lookAtPoint;
            float d = math.length(dir);
            if (d < Epsilon + PrecisionSlush)
                return currentPos;
            dir /= d;
            if (RaycastIgnoreTarget(
                    localData.lookAtPoint, localData.lookAtPoint + dir * (d - PrecisionSlush),
                    localData.physicsWorld, out RaycastHit hitInfo2, layerMask, localData.targetEntity))
                return currentPos;

            // All clear
            ray = new Ray { Origin = pos, Displacement = dir };
            localData.AddPointToDebugPath(pos);
            distance = GetPushBackDistance(ray, startPlane, targetDistance, ref localData, strategy);
            if (distance > Epsilon)
            {
                if (!RaycastIgnoreTarget(
                    pos, pos + (dir * distance), localData.physicsWorld,
                    out hitInfo, layerMask, localData.targetEntity))
                {
                    pos = ray.Origin + dir * distance; // no obstacles - all good
                    localData.AddPointToDebugPath(pos);
                }
                else
                {
                    // We hit something.  Stop there and maybe take a step along that wall
                    pos = hitInfo.Position - dir * PrecisionSlush;
                    localData.AddPointToDebugPath(pos);
                    if (iterations > 1)
                        pos = PushCameraBack(
                            pos, ref localData, dir, hitInfo, startPlane,
                            targetDistance, iterations-1, layerMask,
                            colliderState, strategy);
                }
            }
            return pos;
        }

        static bool GetWalkingDirection(
            float3 pos, float3 pushDir, RaycastHit obstacle,
            uint layerMask, ref float3 outDir, ref LocalData localData)
        {
            if (obstacle.RigidBodyIndex < 0)
                return false;

            // Check for nearby obstacles.  Are we in a corner?
            PointDistanceInput input = new PointDistanceInput
            {
                Position = pos,
                MaxDistance = PrecisionSlush * 5,
                Filter = new CollisionFilter()
                {
                    BelongsTo = layerMask,
                    CollidesWith = layerMask,
                    GroupIndex = 0
                }
            };

            // Calculate the second normal, if any
            float3 normal2 = obstacle.SurfaceNormal;
            localData.hitBuffer.Clear();
            localData.physicsWorld.CalculateDistance(input, ref localData.hitBuffer);
            for (int i = 0; i < localData.hitBuffer.Length; ++i)
            {
                if (localData.physicsWorld.Bodies[localData.hitBuffer[i].RigidBodyIndex].Entity == localData.targetEntity)
                    continue;
                var n = localData.hitBuffer[i].SurfaceNormal;
                if (math.dot(normal2, n) > Epsilon)
                {
                    normal2 = n;
                    break;
                }
            }

            // Walk along the wall.  If we're in a corner, walk their intersecting line
            float3 dir = math.cross(obstacle.SurfaceNormal, normal2);
            if (dir.AlmostZero())
                dir = pushDir.ProjectOntoPlane(obstacle.SurfaceNormal);
            else
            {
                float dot = math.dot(dir, pushDir);
                if (math.abs(dot) < Epsilon)
                    return false;
                if (dot < 0)
                    dir = -dir;
            }
            if (dir.AlmostZero())
                return false;

            outDir = math.normalize(dir);
            return true;
        }

        static float GetPushBackDistance(
            Ray ray, Plane startPlane, float targetDistance,
            ref LocalData localData, CollisionResolution.ResolutionStrategy strategy)
        {
            float maxDistance = targetDistance - math.length(ray.Origin - localData.lookAtPoint);
            if (maxDistance < Epsilon)
                return 0;
            if (strategy == CollisionResolution.ResolutionStrategy.PreserveCameraDistance)
                return maxDistance;

            float distance = RaycastToPlane(ray, startPlane.Normal, startPlane.Normal * -startPlane.Distance);
            if (distance < Epsilon || distance == float.MaxValue)
                distance = 0;
            distance = math.min(maxDistance, distance);
            if (distance < Epsilon)
                return 0;

            // If we are close to parallel to the start plane, we have to take special action
            const float kAngleThreshold = 0.2f * math.PI / 180;
            float angle = math.abs(MathHelpers.AngleUnit(startPlane.Normal, ray.Displacement) - math.PI / 2);
            if (angle < kAngleThreshold)
                distance = math.lerp(0, distance, angle / kAngleThreshold);

            return distance;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float ClampRayToBounds(Ray ray, float distance, Aabb bounds)
        {
            distance = math.min(distance, RaycastToPlane(ray, new float3( 1, 0, 0), bounds.Max));
            distance = math.min(distance, RaycastToPlane(ray, new float3(-1, 0, 0), bounds.Min));
            distance = math.min(distance, RaycastToPlane(ray, new float3(0,  1, 0), bounds.Max));
            distance = math.min(distance, RaycastToPlane(ray, new float3(0, -1, 0), bounds.Min));
            distance = math.min(distance, RaycastToPlane(ray, new float3(0, 0,  1), bounds.Max));
            distance = math.min(distance, RaycastToPlane(ray, new float3(0, 0, -1), bounds.Min));
            return distance;
        }

        // returns float.MaxValue if parallel or plane is behind ray
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float RaycastToPlane(Ray ray, float3 planeN, float3 planeP)
        {
            float denom = math.dot(ray.Displacement, planeN); // ray.Direction assumed to be normalized
            float num =  math.dot(planeP - ray.Origin, planeN);
            return math.select(float.MaxValue, num / denom, denom > Epsilon && num > Epsilon);
        }

        static float3 RespectCameraRadius(
            float3 cameraPos, ref LocalData localData,
            in CollisionResolution collider)
        {
            float3 result = float3.zero;
            if (collider.CollideAgainst == 0 || collider.CameraRadius < Epsilon)
                return result;

            float3 targetToCameraDir = cameraPos - localData.lookAtPoint;
            float distance = math.length(targetToCameraDir);
            if (distance == 0 || distance > collider.MinimumDistanceFromTarget)
            {
                PointDistanceInput input = new PointDistanceInput
                {
                    Position = cameraPos,
                    MaxDistance = collider.CameraRadius,
                    Filter = new CollisionFilter()
                    {
                        BelongsTo = unchecked((uint)collider.CollideAgainst),
                        CollidesWith = unchecked((uint)collider.CollideAgainst),
                        GroupIndex = 0
                    }
                };

                localData.hitBuffer.Clear();
                localData.physicsWorld.CalculateDistance(input, ref localData.hitBuffer);

                // Pick the biggest displacement - this isn't strictly correct
                for (int i = 0; i < localData.hitBuffer.Length; ++i)
                {
                    var offsetDir = localData.hitBuffer[i].SurfaceNormal;
                    var startDir = localData.hitBuffer[i].Position - cameraPos;
                    var offsetDistance = math.sign(math.dot(offsetDir, startDir)) * math.length(startDir)
                        + collider.CameraRadius;
                    if (math.length(result) < offsetDistance)
                        result = offsetDir * offsetDistance;
                }
            }

            // Respect the minimum distance from target - push camera back if we have to
            if (distance > Epsilon)
            {
                float minDistance
                    = math.max(collider.MinimumDistanceFromTarget, collider.CameraRadius) + PrecisionSlush;
                float3 newOffset = cameraPos + result - localData.lookAtPoint;
                if (math.lengthsq(newOffset) < minDistance * minDistance)
                    result = localData.lookAtPoint - cameraPos + targetToCameraDir * minDistance;
            }

            return result;
        }
    }
}
#endif
