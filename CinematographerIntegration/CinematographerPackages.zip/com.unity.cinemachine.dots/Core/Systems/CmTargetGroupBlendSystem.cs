using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    [InternalBufferCapacity(8)]
    public struct CmTargetGroupBlendElement : IBufferElementData
    {
        public StableKey StableKey;
        public float TargetWeight;
        public float BlendDuration;
    }

    [UpdateBefore(typeof(CmTargetSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CmTargetGroupBlendSystem : CinemachineSystemBase
    {
        const float NegligibleWeight = 0.01f;

        protected override void OnUpdate()
        {
            base.OnUpdate();

            var deltaTime = ClientHooks.GetDeltaTime(World);

            Entities
                .WithName("GroupBlendJob")
                .ForEach((
                    DynamicBuffer<CmTargetGroupBufferElement> members,
                    DynamicBuffer<CmTargetGroupBlendElement> blends,
                    in CmTargetGroupState groupState) =>
                {
                    if (blends.Length == 0)
                        return;

                    // We will invalidate this if something changes
                    bool blendComplete = true;

                    // Lerp in the new and existing elements
                    var foundSrc = new NativeArray<bool>(members.Length, Allocator.Temp);
                    float defaultBlendTime = 0;
                    int firstMember = 0;
                    for (int i = 0; i < blends.Length; ++i)
                    {
                        var b = blends[i];
                        if (!b.StableKey.IsValid)
                            defaultBlendTime = b.BlendDuration;
                        else
                        {
                            bool found = false;
                            for (int j = firstMember; j < members.Length; ++j)
                            {
                                var m = members[j];
                                if (m.StableKey == b.StableKey)
                                {
                                    if (j == firstMember)
                                        ++firstMember;
                                    foundSrc[j] = true;

                                    float delta = MathHelpers.Damp(b.TargetWeight - m.Weight, b.BlendDuration, deltaTime);
                                    blendComplete &= (math.abs(delta) < NegligibleWeight);
                                    m.Weight += delta;
                                    members[j] = m;
                                    found = true;
                                    break;
                                }
                            }

                            if (!found)
                            {
                                float w = MathHelpers.Damp(b.TargetWeight, b.BlendDuration, deltaTime);
                                blendComplete &= (math.abs(b.TargetWeight - w) < NegligibleWeight);
                                members.Add(new CmTargetGroupBufferElement
                                {
                                    StableKey = b.StableKey,
                                    Weight = w
                                });
                            }
                        }
                    }

                    // Lerp out the stale elements
                    int memberIndex = 0;
                    for (int i = 0; i < foundSrc.Length; ++i, ++memberIndex)
                    {
                        if (!foundSrc[i])
                        {
                            var m = members[memberIndex];
                            m.Weight += MathHelpers.Damp(-m.Weight, defaultBlendTime, deltaTime);
                            blendComplete &= (m.Weight < NegligibleWeight);
                            if (m.Weight <= NegligibleWeight)
                                members.RemoveAt(memberIndex--);
                            else
                                members[memberIndex] = m;
                        }
                    }

                    // If all done, eliminate the blend elements to signal blend complete
                    if (blendComplete)
                        blends.Clear();
                })
                .ScheduleParallel();
        }

        /// <summary>
        /// Blend a group to a new member set.  Will do nothing if the same blend is already
        /// in progress, or if the target configuration is the same as the current configuration.
        ///
        /// It's best to use this to add or remove members from a group, rather than to completely
        /// swap out all the members, because in the latter case there will be a mid-blend
        /// position that equally includes everyone, which may or may not produce the desired results.
        /// </summary>
        /// <param name="group">The group to blend</param>
        /// <param name="newMembers">The final members and weights of the group</param>
        /// <param name="blendTime">The time in seconds over which to blend</param>
        public void BlendGroupTo(
            Entity group,
            NativeList<CmTargetGroupBufferElement> newMembers,
            float blendTime)
        {
            if (!EntityManager.HasComponent<CmTargetGroupBufferElement>(group))
                return;

            var blends = new NativeArray<CmTargetGroupBlendElement>(newMembers.Length + 1, Allocator.Temp);
            for (int i = 0; i < newMembers.Length; ++i)
            {
                blends[i] = new CmTargetGroupBlendElement
                {
                    StableKey = newMembers[i].StableKey,
                    TargetWeight = newMembers[i].Weight,
                    BlendDuration = blendTime
                };
            }
            blends[newMembers.Length] = new CmTargetGroupBlendElement { BlendDuration = blendTime };
            if (!EntityManager.HasComponent<CmTargetGroupBlendElement>(group))
                EntityManager.AddBuffer<CmTargetGroupBlendElement>(group);
            var buffer = EntityManager.GetBuffer<CmTargetGroupBlendElement>(group);
            buffer.ResizeUninitialized(blends.Length);
            for (int i = 0; i < blends.Length; ++i)
                buffer[i] = blends[i];
            blends.Dispose();
        }

        /// <summary>
        /// Cancel any member blend in progress
        /// </summary>
        /// <param name="group">The group to canel blending for</param>
        public void CancelBlend(Entity group)
        {
            if (EntityManager.HasComponent<CmTargetGroupBlendElement>(group))
            {
                var buffer = EntityManager.GetBuffer<CmTargetGroupBlendElement>(group);
                buffer.Clear();
            }
        }

        /// <summary>
        /// Is a group member blend currently in progress?
        /// </summary>
        /// <param name="group">The group to check</param>
        public bool IsBlending(Entity group)
        {
            if (!EntityManager.HasComponent<CmTargetGroupBlendElement>(group))
                return false;
            var buffer = EntityManager.GetBuffer<CmTargetGroupBlendElement>(group);
            return buffer.Length > 0;
        }
    }
}
