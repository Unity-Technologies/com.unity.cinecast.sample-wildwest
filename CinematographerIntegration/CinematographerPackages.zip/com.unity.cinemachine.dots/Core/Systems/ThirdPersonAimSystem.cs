using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;
using System;
#if CINEMACHINE_UNITY_PHYSICS
using Unity.Physics;
using Unity.Physics.Systems;
#endif

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct ThirdPersonAim : IComponentData
    {
        [Tooltip("Maximum distance from camera for target detection.")]
        public float AimDistance;

#if CINEMACHINE_UNITY_PHYSICS
        [Tooltip("Set this to specify which GameObjects can be aimed at.")]
        [UnityPhysicsLayerMask]
        public int TargetLayers;
#endif
    }

    [UpdateAfter(typeof(CameraPreAimSystem))]
    [UpdateBefore(typeof(CameraPostAimSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class ThirdPersonAimSystem : CinemachineSystemBase
    {
        EntityQuery m_MissingLookAtStateQuery;

#if CINEMACHINE_UNITY_PHYSICS
        BuildPhysicsWorld m_PhysicsWorldSystem;

        public static CollisionFilter StandardFilter(int layer)
        {
            return new CollisionFilter()
            {
                BelongsTo = 0xffffffff,
                CollidesWith = unchecked((uint)layer),
                GroupIndex = 0
            };
        }
#endif

        protected override void OnCreate()
        {
#if CINEMACHINE_UNITY_PHYSICS
            m_PhysicsWorldSystem = World.GetOrCreateSystem<BuildPhysicsWorld>();
#endif
            m_MissingLookAtStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<ThirdPersonAim>(),
                ComponentType.Exclude<LookAtTargetState>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing state components
            EntityManager.AddComponent(m_MissingLookAtStateQuery,
                ComponentType.ReadWrite<LookAtTargetState>());

#if CINEMACHINE_UNITY_PHYSICS
            var collisionWorld = m_PhysicsWorldSystem.PhysicsWorld.CollisionWorld;
#endif
            Entities
                .WithName("FindLookAtTarget")
#if CINEMACHINE_UNITY_PHYSICS
                .WithReadOnly(collisionWorld)
#endif
                .ForEach((
                    ref LookAtTargetState lookAtTarget,
                    ref PositionState posState,
                    in FollowTargetState followTarget,
                    in ThirdPersonAim thirdPersonAim) =>
                {
                    if (followTarget.Value.Entity == Entity.Null)
                        return;

                    // Find look at point based on follow target's rotation
                    var camPos = posState.GetCorrectedPosition(); // KGB: TODO we need to think about this. Should we use followTarget?
                    var followFwd = math.forward(followTarget.Value.Rotation);
                    var lookAtPoint = camPos + followFwd * thirdPersonAim.AimDistance;

#if CINEMACHINE_UNITY_PHYSICS
                    // Detect objects along the firing line
                    var filter = StandardFilter(thirdPersonAim.TargetLayers);
                    if (!filter.IsEmpty)
                    {
                        var raycastInput = new RaycastInput
                        {
                            // to ignore potential targets between the camera and the follow target, the ray starts
                            // from the follow target position projected on the the camera - lookAt line.
                            Start = camPos + math.project(followTarget.Value.Position - camPos, lookAtPoint - camPos),
                            End = lookAtPoint,
                            Filter = filter,
                        };
                        if (collisionWorld.CastRay(raycastInput, out var hit))
                            lookAtPoint = math.lerp(raycastInput.Start, raycastInput.End, hit.Fraction);
                    }
#endif
                    // Create a fake look at target (use the Follow target with a new position)
                    lookAtTarget.Value = new CmTargetInfo
                    {
                        Entity = followTarget.Value.Entity,
                        Position = lookAtPoint,
                        Rotation = followTarget.Value.Rotation
                    };

                    // Hard look at the target
                    var q = posState.GetCorrectedRotation();
                    var dir = math.normalizesafe(lookAtPoint - camPos, math.forward(q));
                    posState.RawRotation = q.LookRotationUnit(dir, posState.Up);
                    posState.RotationCorrection = quaternion.identity;
                })
                .ScheduleParallel();
        }
    }

    [UpdateAfter(typeof(CameraPostNoiseSystem))]
    [UpdateBefore(typeof(CameraFinalizeSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class ThirdPersonAimLockTargetSystem : SystemBase
    {
        protected override void OnUpdate()
        {
            Entities
                .WithAll<ThirdPersonAim, FollowTargetState>()
                .ForEach((
                    ref LookAtTargetState lookAtTarget,
                    ref PositionState posState) =>
                {
                    // var camPos = posState.GetCorrectedPosition(); // KGB: unused
                    var lookAtPoint = lookAtTarget.Value.Position;

                    // Hard look at the target, but retain any camera roll that has been set
                    var q = posState.GetCorrectedRotation();
                    float3 dir = math.normalizesafe(lookAtPoint - posState.GetCorrectedPosition(), math.forward(q));
                    posState.RawRotation = q.LookRotationUnit(dir, posState.Up);

                    // Preserve roll extracted from corrected rotation
                    var fwd = new float3(0, 0, 1);
                    var right = new float3(1, 0, 0);
                    var correctionRight = math.mul(posState.RotationCorrection, right);
                    correctionRight = math.normalizesafe(correctionRight.ProjectOntoPlane(fwd), right);
                    posState.RotationCorrection = quaternion.AxisAngle(
                        fwd, MathHelpers.SignedAngleUnit(right, correctionRight, fwd));
                })
                .ScheduleParallel();
        }
    }
}
