using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct HardLookAt : IComponentData
    {
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPreAimSystem))]
    [UpdateBefore(typeof(CameraPostAimSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class HardLookAtSystem : CinemachineSystemBase
    {
        protected override void OnUpdate()
        {
            base.OnUpdate();

            Entities
                .WithName("HardLookAtJob")
                .WithAll<HardLookAt>()
                .ForEach((
                    ref PositionState posState,
                    in LookAtTargetState lookAt) =>
                {
                    if (lookAt.Value.Entity == Entity.Null)
                        return;
                    var q = math.normalizesafe(posState.RawRotation, quaternion.identity);
                    float3 dir = math.normalizesafe(lookAt.Value.Position - posState.RawPosition, math.forward(q));
                    float3 up = math.normalizesafe(posState.Up, math.up());
                    posState.RawRotation = q.LookRotationUnit(dir, up);
                })
                .ScheduleParallel();
        }
    }
}
