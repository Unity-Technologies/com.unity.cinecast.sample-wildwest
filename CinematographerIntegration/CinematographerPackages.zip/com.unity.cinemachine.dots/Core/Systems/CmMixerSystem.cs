using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct CmMixerInstruction : IBufferElementData
    {
        /// <summary>The node to to add to the mix</summary>
        [Tooltip("The node to add to the mix")]
        public Entity Node;

        /// <summary>The strength of this node's participation in the mix.  Percentage will
        /// be this value divided by the sum of all node weights</summary>
        [Tooltip("The strength of this node's participation in the mix.  Percentage will "
            + "be this value divided by the sum of all node weights")]
        public float Weight;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CmChannelSystem))]
    [UpdateBefore(typeof(CmChannelFinalizeSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CmMixerSystem : CinemachineSystemBase
    {
        protected override void OnUpdate()
        {
            base.OnUpdate();

            Entities
                .WithAll<NodeChannelAssignment>()
                .ForEach((
                    DynamicBuffer<OverrideNodeBlendElement> blends,
                    ref CmChannel channel,
                    ref CmChannelState channelState,
                    in DynamicBuffer<CmMixerInstruction> instructions) =>
                {
                    // Compute the weight sum
                    int count = 0;
                    float sum = 0;
                    for (int i = 0; i < instructions.Length; ++i)
                    {
                        var w = math.max(0, instructions[i].Weight);
                        sum += w;
                        count += math.select(0, 1, w > 0);
                    }

                    blends.Capacity = math.max(blends.Capacity, count);
                    blends.Clear();
                    for (int i = 0; sum > 0 && i < instructions.Length; ++i)
                    {
                        var w = math.max(0, instructions[i].Weight);
                        blends.Add(new OverrideNodeBlendElement
                        {
                            NodeB = instructions[i].Node,
                            WeightB = w / sum
                        });
                        sum -= w;
                    }
                })
                .ScheduleParallel();
        }
    }
}
