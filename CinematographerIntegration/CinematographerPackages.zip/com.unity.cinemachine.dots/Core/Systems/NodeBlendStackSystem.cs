using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    public struct BlendState
    {
        public Entity Node;
        public float Weight;
        public Entity OutgoingNode; // top-level outgoing cam, or null
        public CameraState CameraState; // full result of blend (can involve more cams)
    }

    [Serializable]
    public struct CustomNodeBlendElement : IBufferElementData
    {
        public StableKey From;
        public StableKey To;
        public TransitionDefinition Blend;
    }

    public struct NodeBlend
    {
        public Entity Node;
        public TransitionDefinition Blend; // special handling: if -ve length, then blend curve is inverted!
        public float TimeInBlend;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool IsComplete() { return TimeInBlend >= math.abs(Blend.Length); }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float BlendWeight()
        {
            var w = Blend.Curve.Evaluate(TimeInBlend / math.abs(Blend.Length));
            return math.select(math.select(w, 1 - w, Blend.Length < 0), 1, IsComplete());
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool IsValid() { return Node != Entity.Null; }

        // Special value for undefined blends
        const float kAbsurdlyLong = 1e10f;
        public static NodeBlend UndefinedBlend
        {
            get { return new NodeBlend { Blend = new TransitionDefinition { Length = kAbsurdlyLong } }; }
        }
        public bool IsUndefined() { return Blend.Length >= kAbsurdlyLong; }

        public bool IsCut() { return Blend.Length == 0; }
    }

    [Serializable]
    [InternalBufferCapacity(4)]
    public struct CurrentNodeBlendElement : IBufferElementData
    {
        public NodeBlend Blend;
        public bool IsCut => Blend.IsCut();
    }

    [Serializable]
    [InternalBufferCapacity(4)]
    public struct NativeNodeBlendElement : IBufferElementData
    {
        public NodeBlend Blend;
        public bool IsCut => Blend.IsCut();
    }

    [Serializable]
    [InternalBufferCapacity(4)]
    public struct OverrideNodeBlendElement : IBufferElementData
    {
        public int Id; // must be kept sorted high->low
        public Entity NodeA; // outgoing Node
        public Entity NodeB; // current Node
        public float WeightB; // 0..1

        public const int SoloId = int.MaxValue; // ID reserved for SoloCamaera
    }

    public static class BlendExtensions
    {
        /// <summary>
        /// Override the current camera and current blend.  This setting will trump
        /// any in-game logic that sets node priorities and Enabled states.
        /// This is the main API for the timeline.
        /// </summary>
        /// <param name="channel">The CM channel id to affect</param>
        /// <param name="id">Id to represent a specific client.  An internal
        /// stack is maintained, with the largest override ID taking precenence.
        /// Use that id for subsequent calls.</param>
        /// <param name="cam"> The camera to set</param>
        /// <param name="signedWeight">The blend weight. If the weight is less than 0,
        /// then node is blending out, if between 0 and 1, then node is blending in.</param>
        public static void SetOverride(
            this DynamicBuffer<OverrideNodeBlendElement> b,
            int id, Entity node, float signedWeight)
        {
            var e = new OverrideNodeBlendElement { Id = id, NodeB = node, WeightB = signedWeight };
            if (signedWeight < 0)
                e = new OverrideNodeBlendElement { Id = id, NodeA = node, WeightB = 1+signedWeight };

            for (int i = 0; i < b.Length; ++i)
            {
                var item = b[i];
                if (item.Id <= id)
                {
                    if (item.Id < id)
                        b.Insert(i, e);
                    else
                    {
                        if (signedWeight < 0)
                        {
                            item.NodeA = node;
                            if (item.NodeB == node)
                                item.NodeB = Entity.Null;
                            if (item.NodeB == Entity.Null)
                                item.WeightB = e.WeightB;
                        }
                        else
                        {
                            if (signedWeight < 1 && item.NodeA != node)
                                e.NodeA = item.NodeA;
                            item = e;
                        }
                        b[i] = item;
                    }
                    return;
                }
            }
            b.Add(e);
        }

        public static void ReleaseOverride(
            this DynamicBuffer<OverrideNodeBlendElement> b,
            int id, Entity node)
        {
            for (int i = 0; i < b.Length; ++i)
            {
                var item = b[i];
                if (item.Id <= id)
                {
                    if (item.Id == id)
                    {
                        if (item.NodeB == node || node == Entity.Null)
                            item.NodeB = Entity.Null;
                        if (item.NodeA == node || node == Entity.Null)
                            item.NodeA = Entity.Null;
                        if (item.NodeA == Entity.Null && item.NodeB == Entity.Null)
                            b.RemoveAt(i);
                        else
                            b[i] = item;
                    }
                    return;
                }
            }
        }

        public static void ReleaseAllOverrides(
            this DynamicBuffer<OverrideNodeBlendElement> b,
            Entity node)
        {
            for (int i = b.Length - 1; i >= 0; --i)
            {
                var item = b[i];
                if (item.NodeB == node)
                    item.NodeB = Entity.Null;
                if (item.NodeA == node)
                    item.NodeA = Entity.Null;
                if (item.NodeA == Entity.Null && item.NodeB == Entity.Null)
                    b.RemoveAt(i);
                else
                    b[i] = item;
            }
        }

        // Does this blend involve a specific camera?
        public static bool Uses(
            this DynamicBuffer<CurrentNodeBlendElement> b,
            Entity Node)
        {
            if (Node != Entity.Null)
                for (int i = 0; i < b.Length; ++i)
                    if (Node == b[i].Blend.Node)
                        return true;
            return false;
        }

        public static bool IsBlending(this DynamicBuffer<CurrentNodeBlendElement> b)
        {
            if (b.Length > 1)
            {
                var blend = b[0].Blend;
                if (!blend.IsUndefined() && !blend.IsComplete())
                    return true;
            }
            return false;
        }

        public static void GetLiveNodes(
            this DynamicBuffer<CurrentNodeBlendElement> b, List<CmNode> nodes, World w)
        {
            for (int i = 0; i < b.Length; ++i)
            {
                var element = b[i].Blend;
                if (!element.IsUndefined() && element.BlendWeight() > 0)
                    nodes.Add(CmNode.FromEntity(element.Node, w));
                if (element.IsComplete())
                    break;
            }
        }

        public static CmNode GetNewlyActivatedNode(
            this DynamicBuffer<NativeNodeBlendElement> b, World w)
        {
            if (b.Length > 0 && b[0].Blend.IsUndefined())
                return CmNode.FromEntity(b[0].Blend.Node, w);
            return new CmNode(Entity.Null, null);
        }

        // This must be called from the main thread, in part because of the callback hook
        public static void ResolveUndefinedBlends(
            this DynamicBuffer<NativeNodeBlendElement> b,
            TransitionDefinition defaultBlend, World w, Entity channelContext)
        {
            if (w.SafeHasComponent<CustomNodeBlendElement>(channelContext))
            {
                var customBlends = w.EntityManager.GetBuffer<CustomNodeBlendElement>(channelContext);
                for (int i = b.Length-2; i >= 0; --i)
                {
                    var blend = b[i].Blend;
                    if (blend.IsUndefined())
                    {
                        var from = CmNode.FromEntity(b[i+1].Blend.Node, w);
                        var to = CmNode.FromEntity(blend.Node, w);
                        blend.Blend = customBlends.GetBlend(
                            CmNode.FromEntity(b[i+1].Blend.Node, w).GetBindingKey(),
                            CmNode.FromEntity(blend.Node, w).GetBindingKey(),
                            defaultBlend);

                        // Invoke the custom blend callback - GML is this a good idea?
                        if (ClientHooks.OnCreateBlend != null)
                            blend.Blend = ClientHooks.OnCreateBlend(
                                w, channelContext, from, to, blend.Blend);

                        b[i] = new NativeNodeBlendElement { Blend = blend };
                    }
                }
            }
            else
            {
                // No custom blends
                for (int i = b.Length-2; i >= 0; --i)
                {
                    var blend = b[i].Blend;
                    if (blend.IsUndefined())
                    {
                        var from = CmNode.FromEntity(b[i+1].Blend.Node, w);
                        var to = CmNode.FromEntity(blend.Node, w);
                        blend.Blend = defaultBlend;

                        // Invoke the custom blend callback - GML is this a good idea?
                        if (ClientHooks.OnCreateBlend != null)
                            blend.Blend = ClientHooks.OnCreateBlend(
                                w, channelContext, from, to, blend.Blend);

                        b[i] = new NativeNodeBlendElement { Blend = blend };
                    }
                }
            }
        }

        public static TransitionDefinition GetBlend(
            this DynamicBuffer<CustomNodeBlendElement> customBlends,
            StableKey fromNode, StableKey toNode, TransitionDefinition defaultBlend)
        {
            bool gotAnyToMe = false;
            bool gotMeToAny = false;
            TransitionDefinition anyToMe = defaultBlend;
            TransitionDefinition meToAny = defaultBlend;
            for (int i = 0; i < customBlends.Length; ++i)
            {
                // Attempt to find direct name first
                var blendParams = customBlends[i];
                if ((blendParams.From == fromNode)
                    && (blendParams.To == toNode))
                {
                    return blendParams.Blend;
                }
                // If we come across applicable wildcards, remember them
                if (!blendParams.From.IsValid)
                {
                    if (toNode.IsValid && blendParams.To == toNode)
                    {
                        anyToMe = blendParams.Blend;
                        gotAnyToMe = true;
                    }
                    else if (!blendParams.To.IsValid)
                        defaultBlend = blendParams.Blend;
                }
                else if (!blendParams.To.IsValid && fromNode.IsValid && blendParams.From == fromNode)
                {
                    meToAny = blendParams.Blend;
                    gotMeToAny = true;
                }
            }

            // If nothing is found try to find wild card blends from any
            // camera to our new one
            if (gotAnyToMe)
                return anyToMe;

            // Still have nothing? Try from our camera to any camera
            if (gotMeToAny)
                return meToAny;

            return defaultBlend;
        }
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CmChannelSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class NodeBlendStackSystem : CinemachineSystemBase
    {
        CmChannelSystem m_ChannelSystem;

        EntityQuery m_currentBlendGroup;
        EntityQuery m_missingCurrentBlendGroup;
        EntityQuery m_missingNativeBlendGroup;
        EntityQuery m_missingOverrideBlendGroup;

        protected override void OnCreate()
        {
            m_ChannelSystem = World.GetOrCreateSystem<CmChannelSystem>();

            m_currentBlendGroup = GetEntityQuery(
                ComponentType.ReadWrite<CmChannelState>(),
                ComponentType.ReadWrite<NativeNodeBlendElement>(),
                ComponentType.ReadOnly<OverrideNodeBlendElement>(),
                ComponentType.ReadWrite<CurrentNodeBlendElement>());

            m_missingCurrentBlendGroup = GetEntityQuery(
                ComponentType.ReadOnly<CmChannelState>(),
                ComponentType.Exclude<CurrentNodeBlendElement>());

            m_missingNativeBlendGroup = GetEntityQuery(
                ComponentType.ReadOnly<CmChannelState>(),
                ComponentType.Exclude<NativeNodeBlendElement>());

            m_missingOverrideBlendGroup = GetEntityQuery(
                ComponentType.ReadOnly<CmChannelState>(),
                ComponentType.Exclude<OverrideNodeBlendElement>());
        }

        void CreateMissingStateComponents()
        {
            if (m_missingCurrentBlendGroup.CalculateEntityCount() > 0)
            {
                var entities = m_missingCurrentBlendGroup.ToEntityArray(Allocator.TempJob);
                for (int i = 0; i < entities.Length; ++i)
                    EntityManager.AddBuffer<CurrentNodeBlendElement>(entities[i]);
                entities.Dispose();
            }
            if (m_missingNativeBlendGroup.CalculateEntityCount() > 0)
            {
                var entities = m_missingNativeBlendGroup.ToEntityArray(Allocator.TempJob);
                for (int i = 0; i < entities.Length; ++i)
                    EntityManager.AddBuffer<NativeNodeBlendElement>(entities[i]);
                entities.Dispose();
            }
            if (m_missingOverrideBlendGroup.CalculateEntityCount() > 0)
            {
                var entities = m_missingOverrideBlendGroup.ToEntityArray(Allocator.TempJob);
                for (int i = 0; i < entities.Length; ++i)
                    EntityManager.AddBuffer<OverrideNodeBlendElement>(entities[i]);
                entities.Dispose();
            }
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            CreateMissingStateComponents();
            var currentJob = new UpdateCurrentBlendJob
            {
                CurrentNodeBlendElementAccess = GetBufferTypeHandle<CurrentNodeBlendElement>(),
                NativeNodeBlendElementAccess = GetBufferTypeHandle<NativeNodeBlendElement>(),
                OverrideNodeBlendElementAccess = GetBufferTypeHandle<OverrideNodeBlendElement>(),
                ChannelStateAccess = GetComponentTypeHandle<CmChannelState>(),

                DisabledEntities = GetComponentDataFromEntity<Disabled>(true),
                UpdateStates = GetComponentDataFromEntity<NodeUpdateState>(true)
            };
            var deps = currentJob.Schedule(m_currentBlendGroup, Dependency);

            var channels = m_ChannelSystem.GetChannelsForFiltering();
            var channelEntities = new NativeArray<Entity>(channels.Count, Allocator.TempJob);
            int numTopLevelChannels = 0;
            int numChannels = channels.Count;
            for (int i = 0; i < channels.Count; ++i)
            {
                var currentTime = channels[i].State.CurrentTime;
                deps = Entities
                    .WithName("FinalizeNodeJob")
                    .WithSharedComponentFilter(channels[i].Filter)
                    .ForEach((ref NodeUpdateState updateState) =>
                    {
                        updateState.PreviousFrameDataIsValid = updateState.UpdateTime == currentTime;
                        updateState.ForcePositionAndRotation
                            = updateState.ForcePositionAndRotation && updateState.UpdateTime != currentTime;
                        updateState.IsLive = false;
                    })
                    .Schedule(deps);

                // Because channelEntities is sorted leaf-first, we reverse for roots-first
                channelEntities[numChannels - i - 1] = channels[i].ChannelEntity;
                if (channels[i].NestLevel == 0)
                    ++numTopLevelChannels;
            }
            var isLiveJob = new UpdateIsLiveJob
            {
                Channels = channelEntities, // deallocates on completion
                NumTopLevelChannels = numTopLevelChannels,
                UpdateStates = GetComponentDataFromEntity<NodeUpdateState>(false),
                Blends = GetBufferFromEntity<CurrentNodeBlendElement>(true)
            };
            Dependency = isLiveJob.Schedule(deps);
        }

        [BurstCompile]
        struct UpdateCurrentBlendJob : IJobEntityBatch
        {
            public BufferTypeHandle<CurrentNodeBlendElement> CurrentNodeBlendElementAccess;
            public BufferTypeHandle<NativeNodeBlendElement> NativeNodeBlendElementAccess;
            [ReadOnly] public BufferTypeHandle<OverrideNodeBlendElement> OverrideNodeBlendElementAccess;

            public ComponentTypeHandle<CmChannelState> ChannelStateAccess;

            [ReadOnly] public ComponentDataFromEntity<Disabled> DisabledEntities;
            [ReadOnly] public ComponentDataFromEntity<NodeUpdateState> UpdateStates; // for existence checking only

            public void Execute(ArchetypeChunk batch, int batchIndex)
            {
                var blends = batch.GetBufferAccessor(CurrentNodeBlendElementAccess);
                var natives = batch.GetBufferAccessor(NativeNodeBlendElementAccess);
                var overrides = batch.GetBufferAccessor(OverrideNodeBlendElementAccess);
                var states = batch.GetNativeArray(ChannelStateAccess);

                for (int i = 0; i < batch.Count; i++)
                {
                    var state = states[i];
                    ExecuteOne(blends[i], natives[i], overrides[i], ref state);
                    states[i] = state;
                }
            }

            // GML todo: make so that the presence of OverrideNodeBlendElement is optional
            public void ExecuteOne(
                DynamicBuffer<CurrentNodeBlendElement> blends,
                DynamicBuffer<NativeNodeBlendElement> native,
                [ReadOnly] DynamicBuffer<OverrideNodeBlendElement> overrides,
                ref CmChannelState state)
            {
                UpdateNativeFrame(
                    math.select(-1, state.DeltaTime, state.PreviousStateIsValid),
                    state.ActiveNode, ref native);
                ComputeCurrentBlend(ref blends, ref native, ref overrides);
            }

            // if deltaTime < 0 then previous state is not valid - cut to the end of all blends
            void UpdateNativeFrame(
                float deltaTime, Entity incomingCamera,
                ref DynamicBuffer<NativeNodeBlendElement> native)
            {
                // Prune the deleted or disabled nodes
                for (int i = 0; i < native.Length; ++i)
                    if (!IsValidNode(native[i].Blend.Node))
                        native.RemoveAt(i--);

                // Advance all the current blends
                for (int i = 0; i < native.Length; ++i)
                {
                    var e = native[i];
                    e.Blend.TimeInBlend = math.select(
                        e.Blend.TimeInBlend + deltaTime, e.Blend.Blend.Length, deltaTime < 0);
                    native[i] = e;
                    int tailLength = native.Length - 1 - i;
                    if (tailLength > 0 && e.Blend.IsComplete())
                        native.RemoveRange(i + 1, tailLength); // all the rest no longer contribute
                }
                // Handle any camera change
                if (IsValidNode(incomingCamera))
                {
                    if (native.Length == 0)
                        native.Add(new NativeNodeBlendElement { Blend = new NodeBlend { Node = incomingCamera } });
                    else if (native[0].Blend.Node != incomingCamera)
                    {
                        // Create an undefined blend - must be defined later or it will sit here forever
                        var blend = deltaTime < 0 ? new NodeBlend() : NodeBlend.UndefinedBlend;
                        blend.Node = incomingCamera;
                        native.Insert(0, new NativeNodeBlendElement { Blend = blend });
                    }
                }
            }

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            bool IsValidNode(Entity e)
            {
                return e != Entity.Null && UpdateStates.HasComponent(e) && !DisabledEntities.HasComponent(e);
            }

            void ComputeCurrentBlend(
                ref DynamicBuffer<CurrentNodeBlendElement> blends,
                ref DynamicBuffer<NativeNodeBlendElement> native,
                [ReadOnly] ref DynamicBuffer<OverrideNodeBlendElement> overrides)
            {
                // Most-recent overrides dominate
                blends.Clear();
                for (int i = 0; i < overrides.Length; ++i)
                {
                    var frame = overrides[i];
                    if (frame.NodeB == Entity.Null)
                    {
                        // No incoming camera
                        if (IsValidNode(frame.NodeA))
                        {
                            // Special case: track is only blending out
                            blends.Add(new CurrentNodeBlendElement
                            {
                                Blend = new NodeBlend
                                {
                                    Node = frame.NodeA,
                                    Blend = new TransitionDefinition { Curve = TransitionCurve.Linear, Length = 1 },
                                    TimeInBlend = 1 - frame.WeightB
                                }
                            });
                        }
                        continue;
                    }
                    if (IsValidNode(frame.NodeB))
                    {
                        blends.Add(new CurrentNodeBlendElement
                        {
                            Blend = new NodeBlend
                            {
                                Node = frame.NodeB,
                                Blend = new TransitionDefinition { Curve = TransitionCurve.Linear, Length = 1 },
                                TimeInBlend = frame.WeightB
                            }
                        });
                        if (frame.WeightB >= 1)
                            return; // We're done, blend is complete
                    }
                    if (IsValidNode(frame.NodeA))
                    {
                        blends.Add(new CurrentNodeBlendElement
                        {
                            Blend = new NodeBlend
                            {
                                Node = frame.NodeA,
                                Blend = new TransitionDefinition { Length = 0 }
                            }
                        });
                        return; // We're done, blend is complete
                    }
                }
                // If blend is incomplete, add the native frame
                for (int i = 0; i < native.Length; ++i)
                    blends.Add(new CurrentNodeBlendElement { Blend = native[i].Blend });
            }
        }

        [BurstCompile]
        struct UpdateIsLiveJob : IJob
        {
            [DeallocateOnJobCompletion]
            public NativeArray<Entity> Channels;    // ordered by nest level
            public int NumTopLevelChannels;

            public ComponentDataFromEntity<NodeUpdateState> UpdateStates;
            public BufferFromEntity<CurrentNodeBlendElement> Blends;

            public void Execute()
            {
                for (int i = 0; i < Channels.Length; ++i)
                {
                    var e = Channels[i];
                    bool isLive = i < NumTopLevelChannels;
                    if (UpdateStates.HasComponent(e))
                    {
                        var updateState = UpdateStates[e];
                        if (i < NumTopLevelChannels)
                        {
                            updateState.IsLive = true;
                            UpdateStates[e] = updateState;
                        }
                        else
                            isLive = updateState.IsLive;
                    }
                    if (Blends.HasComponent(e) && isLive)
                    {
                        var blends = Blends[e];
                        for (int j = 0; j < blends.Length; ++j)
                        {
                            var updateState = UpdateStates[blends[j].Blend.Node];
                            updateState.IsLive = true;
                            UpdateStates[blends[j].Blend.Node] = updateState;
                        }
                    }
                }
            }
        }
    }
}
