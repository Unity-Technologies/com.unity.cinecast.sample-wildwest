#if CINEMACHINE_UNITY_PHYSICS

using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Physics;
using System;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct RaycastShotQuality : IComponentData
    {
        [UnityPhysicsLayerMask]
        public int LayerMask;
        public float TargetRadius;

        /// <summary>If greater than zero, a higher score will be given to shots when the target 
        /// is closer to this distance.  Set this to zero to disable this feature</summary>
        [UnityEngine.Tooltip("If greater than zero, a higher score will be given to shots when "
            + "the target is closer to this distance.  Set this to zero to disable this feature.")]
        public float OptimalTargetDistance;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraFinalizeSystem))]
    [UpdateBefore(typeof(CmChannelSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class RaycastShotQualitySystem : CinemachineSystemBase
    {
        Physics.Systems.BuildPhysicsWorld m_physicsWorldSystem;
        EntityQuery m_nodeQuery;

        protected override void OnCreate()
        {
            m_physicsWorldSystem = World.GetOrCreateSystem<Physics.Systems.BuildPhysicsWorld>();
        }

        protected override void OnStartRunning()
        {
            base.OnStartRunning();
            Physics.Systems.PhysicsRuntimeExtensions.RegisterPhysicsRuntimeSystemReadOnly(this);
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            var collisionWorld = m_physicsWorldSystem.PhysicsWorld.CollisionWorld;
            var objectCount = m_nodeQuery.CalculateEntityCount();

            // This will be deallocated by the final job
            var raycastHits = new NativeArray<RaycastHit>(objectCount, Allocator.TempJob);

            Entities
                .WithName("RaycastsJob")
                .WithStoreEntityQueryInField(ref m_nodeQuery)
                .WithReadOnly(collisionWorld)
                .WithAll<NodeUpdateState>()
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    in RaycastShotQuality settings,
                    in PositionState posState,
                    in LookAtTargetState lookAt) =>
                {
                    // GML todo: handle IgnoreTag or something like that ?

                    // cast back towards the camera to filter out target's collider
                    float3 dir = math.normalizesafe(
                        posState.GetCorrectedPosition() - lookAt.Value.Position, new float3(0, 0, 1));
                    RaycastInput input = new RaycastInput()
                    {
                        Start = lookAt.Value.Position + (settings.TargetRadius * dir),
                        End = posState.GetCorrectedPosition(),
                        Filter = new CollisionFilter()
                        {
                            BelongsTo = unchecked((uint)settings.LayerMask), // GML todo: is this right?
                            CollidesWith = unchecked((uint)settings.LayerMask),
                            GroupIndex = 0
                        }
                    };
                    RaycastHit hit = new RaycastHit();
                    collisionWorld.CastRay(input, out hit);
                    raycastHits[entityInQueryIndex] = hit;
                })
                .ScheduleParallel();

            Entities
                .WithName("CalculateQualityJob")
                .WithReadOnly(raycastHits)
                .WithDisposeOnCompletion(raycastHits)
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    ref NodeUpdateState updateState,
                    in RaycastShotQuality settings,
                    in PositionState posState,
                    in LookAtTargetState lookAt) =>
                {
                    var camPos = posState.GetCorrectedPosition();
                    var offset = lookAt.Value.Position - camPos;
                    offset = math.mul(math.inverse(posState.GetCorrectedRotation()), offset); // camera-space
                    bool isOnscreen = updateState.Orthographic
                        ? ShotQualityUtils.IsTargetOnscreenOrtho(offset, posState.Lens.FOV, updateState.Aspect)
                        : ShotQualityUtils.IsTargetOnscreen(offset, posState.Lens.FOV, updateState.Aspect);
                    bool noObstruction = raycastHits[entityInQueryIndex].SurfaceNormal.AlmostZero();
                    bool isVisible = noObstruction && isOnscreen;
                    updateState.ShotQuality *= math.select(0f, 1f, isVisible);
                    updateState.ShotQuality *= ShotQualityUtils.GetQualityBoostForOptimalTargetDistance(
                        lookAt.Value.Position, camPos, settings.OptimalTargetDistance, 0.2f);
                })
                .ScheduleParallel();
            }
    }
}
#endif
