using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;
using System;
using UnityEngine.Experimental.AI;
using Unity.Transforms;
using System.Runtime.CompilerServices;
using Unity.Assertions;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// This component is used to confine a Cinemachine Camera to a NavMesh and
    /// to control how the camera travels along its NavMesh trajectories.
    /// </summary>
    [Serializable]
    public struct ConfineToNavMesh : IComponentData
    {
        /// <summary>
        /// The agent characteristics for which the NavMesh has been built.
        /// </summary>
        [Tooltip("The agent characteristics for which the NavMesh has been built")]
        [NavMeshAgentTypeProperty]
        public int AgentType;

        /// <summary>
        /// How far to place the camera above the NavMesh surface.
        /// </summary>
        [Tooltip("How far to place the camera above the NavMesh surface")]
        public float BaseOffset;

        /// <summary>
        /// The maximum speed (m/s) that the camera can travel.
        /// </summary>
        [Header("Steering")]
        [Tooltip("The maximum speed (m/s) that the camera can travel")]
        public float Speed;

        /// <summary>
        /// How gradually the camera can change speed.  The value is the approximate 
        /// time (in seconds) for the camera to accelerate to its maximum speed.
        /// </summary>
        [Tooltip("How gradually the camera can change speed.  The value is the approximate time "
            + "(in seconds) for the camera to accelerate to its maximum speed")]
        public float Damping;

        /// <summary>
        /// The camera plans a path and moves only through the selected NavMesh area types.
        /// </summary>
        [Header("Path Finding")]
        [Tooltip("The camera plans a path and moves only through the selected NavMesh area types")]
        [NavMeshAreaProperty]
        public int AreaMask;

        /// <summary>
        /// How far to search when mapping a position onto the NavMesh.  Positions that 
        /// are farther than this distance from the NavMesh will not map onto the NavMesh.
        /// </summary>
        [Tooltip("How far to search when mapping a position onto the NavMesh.  Positions that "
            + "are farther than this distance from the NavMesh will not map onto the NavMesh")]
        public float MaxSearchRadius;
    }

    [Serializable]
    struct ConfineToNavMeshState : IComponentData
    {
        public bool PathFindingInProgress;
        public int QueryIndex;
        public float PathPosition;
        public float SmoothDampSpeed;
    }

    [Serializable]
    internal struct ConfineToNavMeshPath : IBufferElementData
    {
        public float3 Position;
        public float SegmentLength; // length of the segment ending at this point
    }

#if CINEMACHINE_LEGACY_PHYSICS
    [UpdateAfter(typeof(LegacyCollisionResolutionSystem))]
#endif
#if CINEMACHINE_UNITY_PHYSICS
    [UpdateAfter(typeof(CollisionResolutionSystem))]
#endif
    [UpdateBefore(typeof(CameraPreAimSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class NavMeshFollowSystem : CinemachineSystemBase
    {
        const int MaxNavMeshQueries = 10; // must match number of members in QueryPool
        const int MaxNavMeshNodes = 2048;
        const int MaxPathSize = 30;
        const int StalePathDistance = 1;

        // Pathfinding queries
        struct QueryPool
        {
            // We have to list them explicitly since they contain managed objects,
            // making it impossible to put them in an array and still use them in jobs.

            public NavMeshQuery Query0; // reserved for scratch use, always available
            public NavMeshQuery Query1;
            public NavMeshQuery Query2;
            public NavMeshQuery Query3;
            public NavMeshQuery Query4;
            public NavMeshQuery Query5;
            public NavMeshQuery Query6;
            public NavMeshQuery Query7;
            public NavMeshQuery Query8;
            public NavMeshQuery Query9;
        }
        QueryPool m_Queries;
        NativeQueue<int> m_QueryIndexFree;

        EntityQuery m_missingStateQuery;

        void AllocateInfrastructure()
        {
            if (m_QueryIndexFree.IsCreated)
                return;

            var navMeshWorld = NavMeshWorld.GetDefaultWorld();
            m_QueryIndexFree = new NativeQueue<int>(Allocator.Persistent);

            Assert.IsTrue(MaxNavMeshQueries == 10); // number of items in QueryPool
            for (int i = 1; i < MaxNavMeshQueries; ++i) // we reserve index 0 as a scratch query
                m_QueryIndexFree.Enqueue(i);

            m_Queries.Query0 = new NavMeshQuery(navMeshWorld, Allocator.Persistent, MaxNavMeshNodes);
            m_Queries.Query1 = new NavMeshQuery(navMeshWorld, Allocator.Persistent, MaxNavMeshNodes);
            m_Queries.Query2 = new NavMeshQuery(navMeshWorld, Allocator.Persistent, MaxNavMeshNodes);
            m_Queries.Query3 = new NavMeshQuery(navMeshWorld, Allocator.Persistent, MaxNavMeshNodes);
            m_Queries.Query4 = new NavMeshQuery(navMeshWorld, Allocator.Persistent, MaxNavMeshNodes);
            m_Queries.Query5 = new NavMeshQuery(navMeshWorld, Allocator.Persistent, MaxNavMeshNodes);
            m_Queries.Query6 = new NavMeshQuery(navMeshWorld, Allocator.Persistent, MaxNavMeshNodes);
            m_Queries.Query7 = new NavMeshQuery(navMeshWorld, Allocator.Persistent, MaxNavMeshNodes);
            m_Queries.Query8 = new NavMeshQuery(navMeshWorld, Allocator.Persistent, MaxNavMeshNodes);
            m_Queries.Query9 = new NavMeshQuery(navMeshWorld, Allocator.Persistent, MaxNavMeshNodes);
        }

        void DisposeInfrastructure()
        {
            if (m_QueryIndexFree.IsCreated)
            {
                m_QueryIndexFree.Dispose();

                m_Queries.Query0.Dispose();
                m_Queries.Query1.Dispose();
                m_Queries.Query2.Dispose();
                m_Queries.Query3.Dispose();
                m_Queries.Query4.Dispose();
                m_Queries.Query5.Dispose();
                m_Queries.Query6.Dispose();
                m_Queries.Query7.Dispose();
                m_Queries.Query8.Dispose();
                m_Queries.Query9.Dispose();
            }
        }

        protected override void OnCreate()
        {
            base.OnCreate();
            m_missingStateQuery = GetEntityQuery(
                ComponentType.Exclude<ConfineToNavMeshState>(),
                ComponentType.ReadOnly<ConfineToNavMesh>());
        }

        protected override void OnDestroy()
        {
            DisposeInfrastructure();
            base.OnDestroy();
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing state and path components
            if (!m_missingStateQuery.IsEmpty)
            {
                var entities = m_missingStateQuery.ToEntityArray(Allocator.TempJob);
                EntityManager.AddComponent(m_missingStateQuery, ComponentType.ReadWrite<ConfineToNavMeshState>());
                for (int i = 0; i < entities.Length; ++i)
                    EntityManager.AddBuffer<ConfineToNavMeshPath>(entities[i]);
                entities.Dispose();

                // Take this opportunity to allocate the expensive infrastructure, since we will be using it
                AllocateInfrastructure();
            }

            var queryPool = m_Queries;
            var queryIndexFree = m_QueryIndexFree;

            Entities
                .WithName("PathfindingJob")
                .WithAll<NodeChannelAssignment>()
                .ForEach((
                    ref ConfineToNavMeshState confineState,
                    ref PositionState posState,
                    ref DynamicBuffer<ConfineToNavMeshPath> path,
                    in ConfineToNavMesh confine,
                    in LocalToWorld l2w,
                    in NodeUpdateState updateState) =>
                {
                    // Where do we want to be on the path?
                    var maxExtents = new Vector3(
                        confine.MaxSearchRadius, confine.MaxSearchRadius, confine.MaxSearchRadius);
                    var desiredPathLocation = queryPool.Query0.MapLocation(
                        posState.RawPosition, maxExtents, confine.AgentType, confine.AreaMask);
                    if (desiredPathLocation.polygon.IsNull())
                    {
                        Reset(ref confineState, ref path, ref queryIndexFree);
                        return; // do nothing, invalid navmesh or too far away
                    }

                    if (!updateState.PreviousFrameDataIsValid)
                    {
                        // Go there right away
                        posState.RawPosition = GetWorldPosition(ref queryPool.Query0, ref desiredPathLocation, confine);
                        Reset(ref confineState, ref path, ref queryIndexFree);
                        return;
                    }

                    if (updateState.DeltaTime < 0.0001f)
                    {
                        posState.RawPosition = l2w.Position; // stay still
                        return;
                    }

                    // Where are we now?
                    var currentPathLocation = queryPool.Query0.MapLocation(
                        l2w.Position, maxExtents, confine.AgentType, confine.AreaMask);
                    if (currentPathLocation.polygon.IsNull())
                        return; // do nothing, invalid navmesh or too far away

                    // If we're close to the desired destination, nothing to do
                    if (!updateState.PreviousFrameDataIsValid 
                        || math.lengthsq(currentPathLocation.position - desiredPathLocation.position) < 0.1f)
                    {
                        Reset(ref confineState, ref path, ref queryIndexFree);
                        posState.RawPosition = GetWorldPosition(ref queryPool.Query0, ref currentPathLocation, confine);
                        return;
                    }

                    // Is there a current path?  If not or if the current path is stale, request a new one
                    var noPath = path.Length == 0 || confineState.PathPosition > path.Length - 1;
                    if (!confineState.PathFindingInProgress 
                        && (noPath || math.lengthsq(
                            (float3)desiredPathLocation.position - path[path.Length - 1].Position) > StalePathDistance))
                    {
                        // Start pathfinding
                        if (!queryIndexFree.TryDequeue(out confineState.QueryIndex))
                            return; // no available queries, try again next frame

                        var query = GetQueryFromPool(ref queryPool, confineState.QueryIndex);
                        query.BeginFindPath(currentPathLocation, desiredPathLocation, confine.AreaMask);
                        confineState.PathFindingInProgress = true;
                    }

                    // If pathfinding is underway, continue it
                    if (confineState.PathFindingInProgress)
                    {
                        const int Iterations = 10;
                        var query = GetQueryFromPool(ref queryPool, confineState.QueryIndex);
                        var status = query.UpdateFindPath(Iterations, out var performed);
                        if ((status & PathQueryStatus.Success) != 0)
                        {
                            status = query.EndFindPath(out var polySize); // release query to pool
        
                            // If pathfinding is done, fetch the path
                            if ((status & PathQueryStatus.Success) != 0)
                            {
                                var polygons = new NativeArray<PolygonId>(polySize, Allocator.Temp);
                                query.GetPathResult(polygons);
                                Reset(ref confineState, ref path, ref queryIndexFree); 
                                FetchComputedPath(
                                    ref queryPool.Query0, polygons, ref path, 
                                    currentPathLocation.position, desiredPathLocation.position);
                            }
                        }
                        if ((status & PathQueryStatus.Failure) != 0)
                        {
                            // Something went wrong, give up.  GML TODO: report error
                            Reset(ref confineState, ref path, ref queryIndexFree);
                        }
                    }

                    // Walk the path
                    if (noPath)
                        posState.RawPosition = l2w.Position; // stay still
                    else
                    {
                        posState.RawPosition = MoveOnPath(
                            ref queryPool.Query0, ref path, ref confineState, confine, 
                            updateState.DeltaTime, currentPathLocation, desiredPathLocation);
                    }
                })
                .Schedule();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static ref NavMeshQuery GetQueryFromPool(ref QueryPool pool, int index)
        {
            Assert.IsTrue(index >= 0 && index < MaxNavMeshQueries);
            switch (index)
            {
                default: 
                case 0: return ref pool.Query0;
                case 1: return ref pool.Query1;
                case 2: return ref pool.Query2;
                case 3: return ref pool.Query3;
                case 4: return ref pool.Query4;
                case 5: return ref pool.Query5;
                case 6: return ref pool.Query6;
                case 7: return ref pool.Query7;
                case 8: return ref pool.Query8;
                case 9: return ref pool.Query9;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float3 GetWorldPosition(ref NavMeshQuery query, ref NavMeshLocation loc, in ConfineToNavMesh confine)
        {
            float3 up = (Vector3)query.PolygonLocalToWorldMatrix(loc.polygon).GetColumn(1);
            return (float3)loc.position + up * confine.BaseOffset;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static void Reset(
            ref ConfineToNavMeshState confineState, 
            ref DynamicBuffer<ConfineToNavMeshPath> path, 
            ref NativeQueue<int> queryIndexFree)
        {
            confineState.PathFindingInProgress = false;
            if (confineState.QueryIndex > 0)
                queryIndexFree.Enqueue(confineState.QueryIndex);
            confineState.QueryIndex = 0;
            confineState.PathPosition = 0;
            path.Clear();
        }

        static void FetchComputedPath(
            ref NavMeshQuery query, NativeArray<PolygonId> polygons, 
            ref DynamicBuffer<ConfineToNavMeshPath> path, Vector3 startPoint, Vector3 endPoint)
        {
            var straightPath = new NativeArray<NavMeshLocation>(MaxPathSize, Allocator.Temp);
            var straightPathFlags = new NativeArray<PathUtils.StraightPathFlags>(MaxPathSize, Allocator.Temp);
            var vertexSide = new NativeArray<float>(MaxPathSize, Allocator.Temp);

            var wpCount = 0;
            var pathStatus = PathUtils.FindStraightPath(
                query, startPoint, endPoint,
                polygons, polygons.Length,
                ref straightPath, ref straightPathFlags, ref vertexSide,
                ref wpCount, MaxPathSize);

            path.Clear();
            if ((pathStatus & PathQueryStatus.Success) != 0 && wpCount > 1 && wpCount <= MaxPathSize)
            {
                // Add the first point - fudge it to be the current position
                path.Add(new ConfineToNavMeshPath { Position = startPoint });
                for (var i = 1; i < wpCount; ++i)
                {
                    path.Add(new ConfineToNavMeshPath 
                    { 
                        Position = straightPath[i].position,
                        SegmentLength = math.length(straightPath[i].position - straightPath[i-1].position)
                    });
                }
            }
        }

        static float3 MoveOnPath(
            ref NavMeshQuery query, 
            ref DynamicBuffer<ConfineToNavMeshPath> path, ref ConfineToNavMeshState confineState, 
            in ConfineToNavMesh confine, float deltaTime,
            NavMeshLocation currentPathLocation, NavMeshLocation desiredPathLocation)
        {
            var pos = (float3)currentPathLocation.position;
            var wp = math.floor(confineState.PathPosition);
            var wpFraction = confineState.PathPosition - wp;
            var wpIndex = (int)wp;
            var lastIndex = path.Length - 1;
            var target = (float3)desiredPathLocation.position;

            // Fudge the end of the path
            var lastPoint = path[lastIndex];
            lastPoint.Position = target;
            lastPoint.SegmentLength = math.length(path[lastIndex-1].Position - target);
            if (wpIndex == lastIndex - 1)
                wpFraction *= lastPoint.SegmentLength / path[lastIndex].SegmentLength;

            var newPos = pos;
            if (wpIndex >= lastIndex)
            {
                // Past end of path - go straight to target
                var dir = target - pos;
                var distance = math.length(dir);
                if (distance > 0.001f)
                {
                    dir /= distance;
                    distance = MathHelpers.SmoothDamp(
                        distance, 0, ref confineState.SmoothDampSpeed, confine.Damping, deltaTime, confine.Speed);
                    newPos = target - distance * dir;
                }
            }
            else
            {
                // Compute remaining path distance
                var distance = lastPoint.SegmentLength;
                for (int i = wpIndex + 1; i < lastIndex; ++i)
                    distance += path[i].SegmentLength;
                distance -= wpFraction * path[wpIndex + 1].SegmentLength;

                // Travel some of that distance
                distance = MathHelpers.SmoothDamp(
                    distance, 0, ref confineState.SmoothDampSpeed, confine.Damping, deltaTime, confine.Speed);

                // Find the new point on the path
                float pathLength = lastPoint.SegmentLength;
                for (wpIndex = lastIndex - 1; pathLength < distance; --wpIndex)
                    pathLength += path[wpIndex].SegmentLength;

                var remainder = pathLength - distance;
                var endPoint = wpIndex == lastIndex - 1 ? lastPoint : path[wpIndex + 1];
                var fraction = remainder / endPoint.SegmentLength;
                newPos = path[wpIndex].Position + fraction * (endPoint.Position - path[wpIndex].Position);
                confineState.PathPosition = wpIndex + fraction;
            }

            var maxExtents = new Vector3(
                confine.MaxSearchRadius, confine.MaxSearchRadius, confine.MaxSearchRadius);
            var newLocation = query.MapLocation(
                newPos, maxExtents, confine.AgentType, confine.AreaMask);

            float3 up = (Vector3)query.PolygonLocalToWorldMatrix(newLocation.polygon).GetColumn(1);
            return (float3)newLocation.position + up * confine.BaseOffset;
        }
    }


    //
    // Copyright (c) 2009-2010 Mikko Mononen memon@inside.org
    //
    // This software is provided 'as-is', without any express or implied
    // warranty.  In no event will the authors be held liable for any damages
    // arising from the use of this software.
    // Permission is granted to anyone to use this software for any purpose,
    // including commercial applications, and to alter it and redistribute it
    // freely, subject to the following restrictions:
    // 1. The origin of this software must not be misrepresented; you must not
    //    claim that you wrote the original software. If you use this software
    //    in a product, an acknowledgment in the product documentation would be
    //    appreciated but is not required.
    // 2. Altered source versions must be plainly marked as such, and must not be
    //    misrepresented as being the original software.
    // 3. This notice may not be removed or altered from any source distribution.
    //

    // The original source code has been modified by Unity Technologies.

    class PathUtils
    {
        [Flags]
        public enum StraightPathFlags
        {
            Start = 0x01,              // The vertex is the start position.
            End = 0x02,                // The vertex is the end position.
            OffMeshConnection = 0x04   // The vertex is start of an off-mesh link.
        }

        // Calculate the closest point of approach for line-segment vs line-segment.
        public static bool SegmentSegmentCPA(out float3 c0, out float3 c1, float3 p0, float3 p1, float3 q0, float3 q1)
        {
            var u = p1 - p0;
            var v = q1 - q0;
            var w0 = p0 - q0;

            float a = math.dot(u, u);
            float b = math.dot(u, v);
            float c = math.dot(v, v);
            float d = math.dot(u, w0);
            float e = math.dot(v, w0);

            float den = (a * c - b * b);
            float sc, tc;

            if (den == 0)
            {
                sc = 0;
                tc = d / b;

                // todo: handle b = 0 (=> a and/or c is 0)
            }
            else
            {
                sc = (b * e - c * d) / (a * c - b * b);
                tc = (a * e - b * d) / (a * c - b * b);
            }

            c0 = math.lerp(p0, p1, sc);
            c1 = math.lerp(q0, q1, tc);

            return den != 0;
        }
        
        public static float Perp2D(Vector3 u, Vector3 v)
        {
            return u.z * v.x - u.x * v.z;
        }

        public static void Swap(ref Vector3 a, ref Vector3 b)
        {
            var temp = a;
            a = b;
            b = temp;
        }

        // Retrace portals between corners and register if type of polygon changes
        public static int RetracePortals(
            NavMeshQuery query, int startIndex, int endIndex, 
            NativeSlice<PolygonId> path, int n, Vector3 termPos, 
            ref NativeArray<NavMeshLocation> straightPath, 
            ref NativeArray<StraightPathFlags> straightPathFlags, 
            int maxStraightPath)
        {
    #if DEBUG_CROWDSYSTEM_ASSERTS
            Assert.IsTrue(n < maxStraightPath);
            Assert.IsTrue(startIndex <= endIndex);
    #endif

            for (var k = startIndex; k < endIndex - 1; ++k)
            {
                var type1 = query.GetPolygonType(path[k]);
                var type2 = query.GetPolygonType(path[k + 1]);
                if (type1 != type2)
                {
                    Vector3 l, r;
                    var status = query.GetPortalPoints(path[k], path[k + 1], out l, out r);

    #if DEBUG_CROWDSYSTEM_ASSERTS
                    Assert.IsTrue(status); // Expect path elements k, k+1 to be verified
    #endif

                    float3 cpa1, cpa2;
                    SegmentSegmentCPA(out cpa1, out cpa2, l, r, straightPath[n - 1].position, termPos);
                    straightPath[n] = query.CreateLocation(cpa1, path[k + 1]);

                    straightPathFlags[n] = (type2 == NavMeshPolyTypes.OffMeshConnection) ? StraightPathFlags.OffMeshConnection : 0;
                    if (++n == maxStraightPath)
                    {
                        return maxStraightPath;
                    }
                }
            }
            straightPath[n] = query.CreateLocation(termPos, path[endIndex]);
            straightPathFlags[n] = query.GetPolygonType(path[endIndex]) == NavMeshPolyTypes.OffMeshConnection ? StraightPathFlags.OffMeshConnection : 0;
            return ++n;
        }

        public static PathQueryStatus FindStraightPath(NavMeshQuery query, Vector3 startPos, Vector3 endPos
            , NativeSlice<PolygonId> path, int pathSize
            , ref NativeArray<NavMeshLocation> straightPath
            , ref NativeArray<StraightPathFlags> straightPathFlags
            , ref NativeArray<float> vertexSide
            , ref int straightPathCount
            , int maxStraightPath)
        {
    #if DEBUG_CROWDSYSTEM_ASSERTS
            Assert.IsTrue(pathSize > 0, "FindStraightPath: The path cannot be empty");
            Assert.IsTrue(path.Length >= pathSize, "FindStraightPath: The array of path polygons must fit at least the size specified");
            Assert.IsTrue(maxStraightPath > 1, "FindStraightPath: At least two corners need to be returned, the start and end");
            Assert.IsTrue(straightPath.Length >= maxStraightPath, "FindStraightPath: The array of returned corners cannot be smaller than the desired maximum corner count");
            Assert.IsTrue(straightPathFlags.Length >= straightPath.Length, "FindStraightPath: The array of returned flags must not be smaller than the array of returned corners");
    #endif

            if (!query.IsValid(path[0]))
            {
                straightPath[0] = new NavMeshLocation(); // empty terminator
                return PathQueryStatus.Failure; // | PathQueryStatus.InvalidParam;
            }

            straightPath[0] = query.CreateLocation(startPos, path[0]);

            straightPathFlags[0] = StraightPathFlags.Start;

            var apexIndex = 0;
            var n = 1;

            if (pathSize > 1)
            {
                var startPolyWorldToLocal = query.PolygonWorldToLocalMatrix(path[0]);

                var apex = startPolyWorldToLocal.MultiplyPoint(startPos);
                var left = new Vector3(0, 0, 0); // Vector3.zero accesses a static readonly which does not work in burst yet
                var right = new Vector3(0, 0, 0);
                var leftIndex = -1;
                var rightIndex = -1;

                for (var i = 1; i <= pathSize; ++i)
                {
                    var polyWorldToLocal = query.PolygonWorldToLocalMatrix(path[apexIndex]);

                    Vector3 vl, vr;
                    if (i == pathSize)
                    {
                        vl = vr = polyWorldToLocal.MultiplyPoint(endPos);
                    }
                    else
                    {
                        var success = query.GetPortalPoints(path[i - 1], path[i], out vl, out vr);
                        if (!success)
                        {
                            return PathQueryStatus.Failure; // | PathQueryStatus.InvalidParam;
                        }

    #if DEBUG_CROWDSYSTEM_ASSERTS
                        Assert.IsTrue(query.IsValid(path[i - 1]));
                        Assert.IsTrue(query.IsValid(path[i]));
    #endif

                        vl = polyWorldToLocal.MultiplyPoint(vl);
                        vr = polyWorldToLocal.MultiplyPoint(vr);
                    }

                    vl = vl - apex;
                    vr = vr - apex;

                    // Ensure left/right ordering
                    if (Perp2D(vl, vr) < 0)
                        Swap(ref vl, ref vr);

                    // Terminate funnel by turning
                    if (Perp2D(left, vr) < 0)
                    {
                        var polyLocalToWorld = query.PolygonLocalToWorldMatrix(path[apexIndex]);
                        var termPos = polyLocalToWorld.MultiplyPoint(apex + left);

                        n = RetracePortals(query, apexIndex, leftIndex, path, n, termPos, ref straightPath, ref straightPathFlags, maxStraightPath);
                        if (vertexSide.Length > 0)
                        {
                            vertexSide[n - 1] = -1;
                        }

                        //Debug.Log("LEFT");

                        if (n == maxStraightPath)
                        {
                            straightPathCount = n;
                            return PathQueryStatus.Success; // | PathQueryStatus.BufferTooSmall;
                        }

                        apex = polyWorldToLocal.MultiplyPoint(termPos);
                        left.Set(0, 0, 0);
                        right.Set(0, 0, 0);
                        i = apexIndex = leftIndex;
                        continue;
                    }
                    if (Perp2D(right, vl) > 0)
                    {
                        var polyLocalToWorld = query.PolygonLocalToWorldMatrix(path[apexIndex]);
                        var termPos = polyLocalToWorld.MultiplyPoint(apex + right);

                        n = RetracePortals(query, apexIndex, rightIndex, path, n, termPos, ref straightPath, ref straightPathFlags, maxStraightPath);
                        if (vertexSide.Length > 0)
                        {
                            vertexSide[n - 1] = 1;
                        }

                        //Debug.Log("RIGHT");

                        if (n == maxStraightPath)
                        {
                            straightPathCount = n;
                            return PathQueryStatus.Success; // | PathQueryStatus.BufferTooSmall;
                        }

                        apex = polyWorldToLocal.MultiplyPoint(termPos);
                        left.Set(0, 0, 0);
                        right.Set(0, 0, 0);
                        i = apexIndex = rightIndex;
                        continue;
                    }

                    // Narrow funnel
                    if (Perp2D(left, vl) >= 0)
                    {
                        left = vl;
                        leftIndex = i;
                    }
                    if (Perp2D(right, vr) <= 0)
                    {
                        right = vr;
                        rightIndex = i;
                    }
                }
            }

            // Remove the the next to last if duplicate point - e.g. start and end positions are the same
            // (in which case we have get a single point)
            if (n > 0 && (straightPath[n - 1].position == endPos))
                n--;

            n = RetracePortals(query, apexIndex, pathSize - 1, path, n, endPos, ref straightPath, ref straightPathFlags, maxStraightPath);
            if (vertexSide.Length > 0)
            {
                vertexSide[n - 1] = 0;
            }

            if (n == maxStraightPath)
            {
                straightPathCount = n;
                return PathQueryStatus.Success; // | PathQueryStatus.BufferTooSmall;
            }

            // Fix flag for final path point
            straightPathFlags[n - 1] = StraightPathFlags.End;

            straightPathCount = n;
            return PathQueryStatus.Success;
        }
    }
}
