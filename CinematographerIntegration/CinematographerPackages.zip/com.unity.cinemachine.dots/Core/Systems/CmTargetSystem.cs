using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Transforms;
using Unity.Mathematics;
using System;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct CmTarget : IComponentData
    {
        public float3 Offset;
        public float Radius;
    }

    [Serializable]
    [InternalBufferCapacity(4)]
    public struct CmTargetGroupBufferElement : IBufferElementData
    {
        public StableKey StableKey;
        public float Weight;
    }

    // Contains group's last known position/rotation
    internal struct CmTargetGroupState : IComponentData
    {
        public float3 Position;
        public quaternion Rotation;
        public float Radius;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    //[UpdateAfter(typeof(EndFrameWorldToLocalSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CmTargetSystem : CinemachineSystemBase
    {
        EntityQuery m_threadQuery;
        EntityQuery m_groupQuery;
        EntityQuery m_missingGroupQuery;

        NativeHashMap<StableKey, CmTargetInfo> m_targetLookup;

        protected override void OnCreate()
        {
            m_threadQuery = GetEntityQuery(ComponentType.ReadOnly(typeof(CmTarget)));

            m_missingGroupQuery = GetEntityQuery(
                ComponentType.ReadOnly(typeof(CmTargetGroupBufferElement)),
                ComponentType.Exclude<CmTargetGroupState>());

            m_targetLookup = new NativeHashMap<StableKey, CmTargetInfo>(64, Allocator.Persistent);
        }

        protected override void OnDestroy()
        {
            m_targetLookup.Dispose();
            base.OnDestroy();
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing group components
            if (!m_missingGroupQuery.IsEmpty)
            {
                var entities = m_missingGroupQuery.ToEntityArray(Allocator.TempJob);
                EntityManager.AddComponent(m_missingGroupQuery, ComponentType.ReadWrite<CmTargetGroupState>());
                for (int i = 0; i < entities.Length; ++i)
                    EntityManager.SetComponentData(entities[i], new CmTargetGroupState { Rotation = quaternion.identity });
                entities.Dispose();
            }
            // Make sure all readers have finished with the table
            TargetTableReadJobHandle.Complete();
            TargetTableReadJobHandle = default(JobHandle);

            var threadCount = m_threadQuery.CalculateEntityCount();
            m_targetLookup.Clear();
            m_targetLookup.Capacity = math.max(m_targetLookup.Capacity, threadCount);

            var targetLookupWriter = m_targetLookup.AsParallelWriter();

            Entities
                .WithName("UpdateTargetsJob")
                .WithNone<CmTargetGroupState, StoryLookaheadWindow, StoryLookaheadInfo>()
                .ForEach((
                    Entity entity, 
                    in LocalToWorld l2w,
                    in CmTarget t,
                    in StableKeyData key) =>
                {
                    var rot = l2w.Value.GetRotationFromTRS();
                    targetLookupWriter.TryAdd(key.Value, new CmTargetInfo()
                    {
                        Entity = entity,
                        Rotation = rot,
                        Position = l2w.Value.GetTranslationFromTRS() + math.mul(rot, t.Offset),
                        Radius = t.Radius
                    });
                })
                .ScheduleParallel();

            Entities
                .WithName("UpdateLookaheadTargetsJob")
                .WithNone<CmTargetGroupState>()
                .ForEach((
                    Entity entity, 
                    DynamicBuffer<StoryLookaheadInfo> data,
                    in StoryLookaheadWindow lookahead,
                    in LocalToWorld l2w,
                    in CmTarget t,
                    in StableKeyData key) =>
                {
                    if (lookahead.IsEmpty())
                    {
                        // Fallback to non-story-window position
                        var rot = l2w.Value.GetRotationFromTRS();
                        targetLookupWriter.TryAdd(key.Value, new CmTargetInfo()
                        {
                            Entity = entity,
                            Rotation = rot,
                            Position = l2w.Value.GetTranslationFromTRS() + math.mul(rot, t.Offset),
                            Radius = t.Radius
                        });
                    }
                    else
                    {
                        var info = lookahead.GameTimeValue(data).Info;
                        targetLookupWriter.TryAdd(key.Value, new CmTargetInfo()
                        {
                            Entity = entity,
                            Position = info.Position + math.mul(info.Rotation, t.Offset),
                            Rotation = info.Rotation,
                            Radius = t.Radius
                        });
                    }
                })
                .ScheduleParallel();

            var groupCount = m_groupQuery.CalculateEntityCount();
            if (groupCount > 0)
            {
                // Update the group's pos/rot/radius
                var infoArray = new NativeArray<CmTargetInfo>(groupCount, Allocator.TempJob);
                var targetLookup = m_targetLookup;

                Entities
                    .WithName("UpdateTargetGroupStateJob")
                    .WithStoreEntityQueryInField(ref m_groupQuery)
                    .WithReadOnly(targetLookup)
                    .WithAll<StableKeyData, CmTarget>()
                    .ForEach((
                        Entity entity, int entityInQueryIndex,
                        DynamicBuffer<CmTargetGroupBufferElement> buffer,
                        ref CmTargetGroupState groupState) =>
                    {
                        float3 avgPos = float3.zero;
                        float weightSum = 0;
                        float maxWeight = 0;
                        if (buffer.Length > 0)
                        {
                            var items = new NativeArray<CmTargetInfo>(buffer.Length, Allocator.Temp);
                            int numItems = 0;
                            for (int i = 0; i < buffer.Length; ++i)
                            {
                                var b = buffer[i];
                                if (targetLookup.TryGetValue(b.StableKey, out CmTargetInfo item))
                                {
                                    avgPos += item.Position * b.Weight;
                                    weightSum += b.Weight;
                                    maxWeight = math.max(maxWeight, b.Weight);
                                    item.Entity.Index = i; // abuse the Entity field to hold the buffer index
                                    items[numItems++] = item;
                                }
                            }

                            // Update AABB center and (crude) average rotation 
                            if (maxWeight > MathHelpers.Epsilon)
                            {
                                float3 minPos = float3.zero;
                                float3 maxPos = float3.zero;
                                avgPos /= weightSum;

                                quaternion avgRot = quaternion.identity;
                                float weightedRotAverage = 0;

                                bool gotOne = false;
                                for (int i = 0; i < numItems; ++i)
                                {
                                    var item = items[i];
                                    var b = buffer[item.Entity.Index];

                                    float w = b.Weight / maxWeight;
                                    float3 p = math.lerp(avgPos, item.Position, w);
                                    float3 r = math.lerp(0, item.Radius, w) * new float3(1, 1, 1);
                                    float3 p0 = p - r;
                                    float3 p1 = p + r;
                                    minPos = math.select(p0, math.min(minPos, p0), gotOne);
                                    maxPos = math.select(p1, math.max(maxPos, p1), gotOne);

                                    avgRot = math.mul(avgRot, math.slerp(Quaternion.identity, item.Rotation, w));
                                    weightedRotAverage += w;

                                    gotOne = true;
                                }

                                groupState = new CmTargetGroupState
                                {
                                    Position = (minPos + maxPos) / 2,
                                    Rotation = math.slerp(quaternion.identity, avgRot, 1.0f / weightedRotAverage),
                                    Radius = math.length(maxPos - minPos) / 2
                                };

                            }
                        }
#if UNITY_EDITOR
                        if (entityInQueryIndex < infoArray.Length)
#endif
                            infoArray[entityInQueryIndex] = new CmTargetInfo
                            {
                                Entity = entity,
                                Position = groupState.Position,
                                Radius = groupState.Radius,
                                Rotation = groupState.Rotation
                            };
                    })
                    .ScheduleParallel();

                targetLookupWriter = m_targetLookup.AsParallelWriter();
                Entities
                    .WithName("SetGroupTargetRadiusJob")
                    .WithReadOnly(infoArray)
                    .WithDisposeOnCompletion(infoArray)
                    .WithAll<CmTargetGroupBufferElement, CmTargetGroupState>()
                    .ForEach((
                        Entity entity, int entityInQueryIndex,
                        ref CmTarget t,
                        in StableKeyData key) =>
                    {
#if UNITY_EDITOR
                        if (entityInQueryIndex < infoArray.Length)
#endif
                        {
                            // Push the target groups to the main target lookup table
                            var info = infoArray[entityInQueryIndex];
                            targetLookupWriter.TryAdd(key.Value, info);
                            // Update CmTarget.Radius to match GML is this necessary? (probably not)
                            t.Radius = info.Radius;
                        }
                    })
                .ScheduleParallel();
            }
            TargetTableWriteHandle = Dependency;
        }

        JobHandle TargetTableReadJobHandle = default(JobHandle);

        /// <summary>
        /// This job handle can be used to wait for completion of the target lookup table
        /// build.  Jobs that need to depend on the target lookup table can use this handle as
        /// a dependency.
        /// </summary>
        public JobHandle TargetTableWriteHandle { get; private set; }

        /// <summary>
        /// Get the singleton TargetLookup table, which may not be written yet, for access by jobs.
        /// This table converts a StableKey to CmTargetInfo.
        /// </summary>
        /// <param name="inputDeps">Will be combined with dependency on the jobs that write the table</param>
        /// <param name="targetLookup">The returned lookup table.  Read-only</param>
        /// <returns>The new job input dependency
        /// (inputDeps combined with dependency on the jobs that write the table)</returns>
        public JobHandle GetTargetLookupForJobs(
            JobHandle inputDeps, out NativeHashMap<StableKey, CmTargetInfo> targetLookup)
        {
            targetLookup = m_targetLookup;
            return JobHandle.CombineDependencies(inputDeps, TargetTableWriteHandle);
        }

        /// <summary>
        /// Get the singleton TargetLookup table for immediate access.
        /// Waits for table write jobs to complete.
        /// This table converts a StableKey to CmTargetInfo.
        /// </summary>
        /// <returns>The lookup table.</returns>
        public NativeHashMap<StableKey, CmTargetInfo> GetTargetLookupNow()
        {
            TargetTableWriteHandle.Complete();
            return m_targetLookup;
        }

        /// <summary>
        /// Register the jobs that are reading from the singleton target lookup table,
        /// so that table will not be prematurely corrupted.
        /// </summary>
        /// <param name="h">Jobs that are reading from the table</param>
        /// <returns>the same h as passed in, for convenience</returns>
        public JobHandle RegisterTargetLookupReadJobs(JobHandle h)
        {
            TargetTableReadJobHandle = JobHandle.CombineDependencies(TargetTableReadJobHandle, h);
            return h;
        }
    }
}
