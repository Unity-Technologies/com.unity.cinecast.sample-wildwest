using Unity.Entities;
using Unity.Jobs;
using UnityEngine;
using System;
using Unity.Mathematics;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct NodeChannelAssignment : ISharedComponentData
    {
        public StableKey ChannelId;
    }

    [Serializable]
    public struct NodePriority : IComponentData
    {
        /// <summary>The priority will determine which node becomes active based on the
        /// state of other cameras and this camera.  Higher numbers have greater priority.
        /// </summary>
        public int Priority;
    }

    [Serializable]
    public struct NodeBlendHint : IComponentData
    {
        /// <summary>
        /// These hints can be or'ed toether to influence how blending is done, and how state
        /// is applied to the camera
        /// </summary>
        public enum BlendHintValue
        {
            /// <summary>Normal state blending</summary>
            Nothing = 0,
            /// <summary>This state does not affect the camera position</summary>
            NoPosition = 1,
            /// <summary>This state does not affect the camera rotation</summary>
            NoOrientation = 2,
            /// <summary>Combination of NoPosition and NoOrientation</summary>
            NoTransform = NoPosition | NoOrientation,
            /// <summary>This state does not affect the lens</summary>
            NoLens = 4,
            /// <summary>Ignore the LookAt target and just slerp the orientation</summary>
            IgnoreLookAtTarget = 8,
            /// <summary>Spherical blend about the LookAt target (if any)</summary>
            SphericalPositionBlend = 16,
            /// <summary>Cylindrical blend about the LookAt target (if any)</summary>
            CylindricalPositionBlend = 32,
        }

        /// <summary>
        /// These hints can be or'ed toether to influence how blending is done, and how state
        /// is applied to the camera
        /// </summary>
        public BlendHintValue Hint;
    }

    [Serializable]
    public struct NodeUpdateState : IComponentData
    {
        public bool PreviousFrameDataIsValid; // GML todo: flags
        public bool IsLive;
        public double UpdateTime;

        /// <summary>
        /// Subjective estimation of how "good" the shot is.
        /// Larger values mean better quality.  Default is 1.
        /// </summary>
        public float ShotQuality;

        /// <summary>Used as second key for priority sorting</summary>
        public int Sequence;

        /// <summary>While this field is set, this node cannot become active</summary>
        public bool ForceDisable;

        /// <summary>If set, then camera position and rotation will be read from the
        /// transform for this frame, overriding the procedural placement</summary>
        public bool ForcePositionAndRotation;

        // These are snapshotted from Channel state
        public float3 WorldUp;
        public bool Orthographic;
        public float Aspect;
        public float DeltaTime;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CmTargetSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class NodeInitSystem : CinemachineSystemBase
    {
        CmChannelSystem m_channelSystem;

        EntityQuery m_NodeQuery;
        EntityQuery m_missingNodeStateQuery;

        protected override void OnCreate()
        {
            m_channelSystem = World.GetOrCreateSystem<CmChannelSystem>();

            m_missingNodeStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<NodeChannelAssignment>(),
                ComponentType.Exclude<NodeUpdateState>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing state components
            EntityManager.AddComponent(m_missingNodeStateQuery,
                ComponentType.ReadWrite<NodeUpdateState>());

            Dependency = m_channelSystem.InitChannelStates(Dependency);

            var channels = m_channelSystem.GetChannelsForFiltering();
            var defaultUp = new float3(0, 1, 0);
            for (int i = 0; i < channels.Count; ++i)
            {
                var previousStateIsValid = channels[i].State.PreviousStateIsValid;
                var currentTime = channels[i].State.CurrentTime;
                var up = math.normalizesafe(math.mul(channels[i].Settings.WorldOrientation, defaultUp), defaultUp);
                
                var orthographic = channels[i].Settings.IsOrthographic;
                var aspect = channels[i].Settings.Aspect;
                var deltaTime = channels[i].State.DeltaTime;

                Entities
                    .WithName("InitNodeJob")
                    .WithStoreEntityQueryInField(ref m_NodeQuery)
                    .WithSharedComponentFilter(channels[i].Filter)
                    .ForEach((ref NodeUpdateState updateState) =>
                    {
                        updateState.PreviousFrameDataIsValid &= previousStateIsValid;
                        updateState.UpdateTime = currentTime;
                        updateState.WorldUp = up;
                        updateState.Aspect = aspect;
                        updateState.DeltaTime = deltaTime;
                        updateState.ShotQuality = 1; // behaviours will scale this to influence quality
                    })
                    .ScheduleParallel();
            }
            m_NodeQuery.ResetFilter();
        }
    }
}
