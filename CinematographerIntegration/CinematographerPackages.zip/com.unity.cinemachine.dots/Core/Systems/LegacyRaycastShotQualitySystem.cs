#if CINEMACHINE_LEGACY_PHYSICS

using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;
using System;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct LegacyRaycastShotQuality : IComponentData
    {
        public LayerMask LayerMask;
        public float TargetRadius;

        /// <summary>If greater than zero, a higher score will be given to shots when the target
        /// is closer to this distance.  Set this to zero to disable this feature</summary>
        [Tooltip("If greater than zero, a higher score will be given to shots when "
            + "the target is closer to this distance.  Set this to zero to disable this feature.")]
        public float OptimalTargetDistance;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraFinalizeSystem))]
    [UpdateBefore(typeof(CmChannelSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class LegacyRaycastShotQualitySystem : CinemachineSystemBase
    {
        EntityQuery m_nodeQuery;

        protected override void OnUpdate()
        {
            base.OnUpdate();

            var objectCount = m_nodeQuery.CalculateEntityCount();

            // These will be deallocated by the final job
            var raycastCommands = new NativeArray<RaycastCommand>(objectCount, Allocator.TempJob);
            var raycastHits = new NativeArray<RaycastHit>(objectCount, Allocator.TempJob);

            Entities
                .WithName("SetupRaycastsJob")
                .WithStoreEntityQueryInField(ref m_nodeQuery)
                .WithAll<NodeChannelAssignment>()
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    in LegacyRaycastShotQuality settings,
                    in LookAtTargetState lookAt,
                    in PositionState posState,
                    in NodeUpdateState updateState) =>
                {
                    // GML todo: handle IgnoreTag or something like that ?

                    // cast back towards the camera to filter out target's collider
                    float3 dir = posState.GetCorrectedPosition() - lookAt.Value.Position;
                    float distance = math.length(dir);
                    dir /= distance;
                    raycastCommands[entityInQueryIndex] = new RaycastCommand(
                        lookAt.Value.Position + settings.TargetRadius * dir, dir,
                        math.max(0, distance - settings.TargetRadius), settings.LayerMask);
                })
                .ScheduleParallel();

            Dependency = RaycastCommand.ScheduleBatch(raycastCommands, raycastHits, 32, Dependency);

            Entities
                .WithName("CalculateQualityJob")
                .WithReadOnly(raycastHits)
                .WithReadOnly(raycastCommands)
                .WithDisposeOnCompletion(raycastHits)
                .WithDisposeOnCompletion(raycastCommands)
                .WithAll<NodeChannelAssignment>()
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    ref NodeUpdateState updateState,
                    in LegacyRaycastShotQuality settings,
                    in PositionState posState,
                    in LookAtTargetState lookAt) =>
                {
                    var camPos = posState.GetCorrectedPosition();
                    var offset = lookAt.Value.Position - camPos;
                    offset = math.mul(math.inverse(posState.GetCorrectedRotation()), offset); // camera-space
                    bool isOnscreen = updateState.Orthographic
                        ? ShotQualityUtils.IsTargetOnscreenOrtho(offset, posState.Lens.FOV, updateState.Aspect)
                        : ShotQualityUtils.IsTargetOnscreen(offset, posState.Lens.FOV, updateState.Aspect);
                    bool noObstruction = raycastHits[entityInQueryIndex].normal == Vector3.zero;
                    bool isVisible = noObstruction && isOnscreen;
                    updateState.ShotQuality *= math.select(0f, 1f, isVisible);
                    updateState.ShotQuality *= ShotQualityUtils.GetQualityBoostForOptimalTargetDistance(
                        lookAt.Value.Position, camPos, settings.OptimalTargetDistance, 0.2f);

                    // GML hack workaround for bug DOTS-3634: reference it so raycastCommands can be deallocated
                    var foo = raycastCommands[entityInQueryIndex].layerMask;
                })
                .ScheduleParallel();
        }
    }
}
#endif
