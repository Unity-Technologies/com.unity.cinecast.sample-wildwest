using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using System;
using UnityEngine;
using System.Runtime.CompilerServices;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct ScreenComposerZones : IComponentData
    {
        /// <summary>Screen position for target. The camera will position
        /// the tracked object here on the screen.  Zero is center.</summary>
        [Tooltip("Screen position for target. The camera will position the "
            + "tracked object here on the screen.  Zero is center.")]
        public float2 ScreenPosition;

        /// <summary>Camera will not rotate horizontally if the target is within
        /// this range of the screen position</summary>
        [Tooltip("Camera will not adjust horizontally if the target is within "
            + "this range of the screen position.")]
        public float2 DeadZoneSize;

        /// <summary>When target is within this region, camera will gradually move
        /// to re-align towards the desired position, depending on the damping speed</summary>
        [Tooltip("When target is within this region, camera will gradually move "
            + "to re-align towards the desired position, depending on the damping speed.")]
        public float2 SoftZoneSize;

        /// <summary>A non-zero bias will move the targt position away from the center
        /// of the soft zone</summary>
        [Tooltip("A non-zero bias will move the targt position away from the center "
            + "of the soft zone.")]
        public float2 SoftZoneBias;

        /// <summary>Internal API for the inspector editor</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public MathHelpers.rect2d GetSoftGuideRect()
        {
            return new MathHelpers.rect2d
            {
                Center = ScreenPosition,
                HalfSize = DeadZoneSize * 0.5f
            };
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void SetSoftGuideRect(MathHelpers.rect2d value)
        {
            var hard = GetHardGuideRect();
            ScreenPosition = value.Center;
            DeadZoneSize = math.clamp(value.HalfSize * 2, 0, 1);
            SoftZoneSize = math.max(SoftZoneSize, DeadZoneSize);
            SetBias(hard.Center);
        }

        /// <summary>Internal API for the inspector editor</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public MathHelpers.rect2d GetHardGuideRect()
        {
            return new MathHelpers.rect2d
            {
                Center = ScreenPosition + SoftZoneBias * (SoftZoneSize - DeadZoneSize),
                HalfSize = SoftZoneSize * 0.5f
            };
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void SetHardGuideRect(MathHelpers.rect2d value)
        {
            SoftZoneSize = math.clamp(value.HalfSize * 2, 0, 2);
            DeadZoneSize = math.min(DeadZoneSize, SoftZoneSize);
            SetBias(value.Center);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        void SetBias(float2 hardRectCenter)
        {
            float2 bias = hardRectCenter - ScreenPosition;
            float2 biasSize = math.max(0, SoftZoneSize - DeadZoneSize);
            SoftZoneBias = math.select(
                math.clamp(bias / biasSize, -0.5f, 0.5f), 0, biasSize < MathHelpers.Epsilon);
        }

        // Can be called from authoring components to ensure sanity
        public void Validate()
        {
            ScreenPosition = math.clamp(ScreenPosition, new float2(-1, -1), new float2(1, 1));
            DeadZoneSize = math.max(float2.zero, DeadZoneSize);
            SetSoftGuideRect(GetSoftGuideRect());
            SetHardGuideRect(GetHardGuideRect());
            SoftZoneBias = math.clamp(SoftZoneBias, new float2(-1, -1), new float2(1, 1));
        }
    }

    [Serializable]
    public struct ComposedLookAt : IComponentData
    {
        /// <summary>Target position prediction controls</summary>
        public TargetPositionPredictor Lookahead;

        /// <summary>Force target to center of screen when this camera activates.
        /// If false, will clamp target to the edges of the dead zone</summary>
        [Tooltip("Force target to center of screen when this camera activates. "
            + "If false, will clamp target to the edges of the dead zone.")]
        public bool CenterOnActivate; // GML todo: flags

        /// <summary>How long it takes to bring the target to the desired screen position</summary>
        [Tooltip("How long it takes to bring the target to the desired screen position.")]
        public float2 Damping;
    }

    internal struct ComposedLookAtState : IComponentData
    {
        public quaternion CameraOrientationPrevFrame;
        public TargetPositionPredictor.StateData Predictor;

        // Caching some expensive stuff, all in radians
        public MathHelpers.rect2d FovSoftGuideRect;
        public MathHelpers.rect2d FovHardGuideRect;
        public float2 Fov2;
        public float3 TargetDir;
        public float TargetDistance;

        // Maintain the cache
        public float cachedAspect;
        public float cachedVFov;
        public MathHelpers.rect2d cachedSoftGuideRect;
        public MathHelpers.rect2d cachedHardGuideRect;

        // This is expensive - GML any way to optimize?
        public void UpdateCache(
            bool isOrthographic, float aspect, float vFov,
            MathHelpers.rect2d softGuide, MathHelpers.rect2d hardGuide,
            float3 cameraPos, float3 targetPos)
        {
            var prevDistance = TargetDistance;
            TargetDir = targetPos - cameraPos;
            TargetDistance = math.length(TargetDir);
            if (TargetDistance < MathHelpers.Epsilon || aspect <= 0 || vFov <= 0)
                return;

            bool rectsAreValid = softGuide == cachedSoftGuideRect && hardGuide == cachedHardGuideRect;
            bool distanceInvalid = isOrthographic
                && math.abs(TargetDistance - prevDistance) > MathHelpers.Epsilon;
            bool fovInvalid = !isOrthographic && cachedVFov != vFov;
            if (aspect == cachedAspect && rectsAreValid && !distanceInvalid && !fovInvalid)
                return;

            if (isOrthographic)
            {
                // Calculate effective fov - fake it for ortho based on target distance
                float ood = math.abs(vFov / TargetDistance);
                Fov2 = 2 * new float2(math.atan(aspect * ood), math.atan(ood));
                cachedVFov = 0;
            }
            else
            {
                float radFov = math.radians(vFov);
                Fov2 = new float2(2 * math.atan(math.tan(radFov * 0.5f) * aspect), radFov);
                cachedVFov = vFov;
            }
            FovSoftGuideRect = ScreenToFOV(softGuide, Fov2, aspect);
            FovHardGuideRect = ScreenToFOV(hardGuide, Fov2, aspect);
            cachedSoftGuideRect = softGuide;
            cachedHardGuideRect = hardGuide;
            cachedAspect = aspect;
        }

        // Convert from screen coords to normalized FOV angular coords
        // GML todo: surely this can be simplified!
        private static MathHelpers.rect2d ScreenToFOV(
            MathHelpers.rect2d rScreen, float2 fov, float aspect)
        {
            var r = rScreen;

            var fwd = new float3(0, 0, 1);
            var left = new float3 (-1, 0, 0);
            var up = new float3(0, 1, 0);

            var persp = math.inverse(float4x4.PerspectiveFov(fov.y, aspect, 0.0001f, 2f));

            var rMin = r.Min;
            var pX = math.mul(persp, new float4(rMin.x * 2f, 0, 0.5f, 1)); pX.z = -pX.z;
            var pY = math.mul(persp, new float4(0, rMin.y * 2f, 0.5f, 1)); pY.z = -pY.z;
            var angle = new float2(
                MathHelpers.SignedAngleUnit(fwd, math.normalize(pX.xyz), up),
                MathHelpers.SignedAngleUnit(fwd, math.normalize(pY.xyz), left));
            rMin = angle / fov;

            var rMax = r.Max;
            pX = math.mul(persp, new float4(rMax.x * 2f, 0, 0.5f, 1)); pX.z = -pX.z;
            pY = math.mul(persp, new float4(0, rMax.y * 2f, 0.5f, 1)); pY.z = -pY.z;
            angle = new float2(
                MathHelpers.SignedAngleUnit(fwd, math.normalize(pX.xyz), up),
                MathHelpers.SignedAngleUnit(fwd, math.normalize(pY.xyz), left));
            rMax = angle / fov;

            var halfSize = (rMax - rMin) * 0.5f;
            return new MathHelpers.rect2d { Center = rMin + halfSize, HalfSize = halfSize };
        }
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPreAimSystem))]
    [UpdateBefore(typeof(CameraPostAimSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class ComposedLookAtSystem : CinemachineSystemBase
    {
        EntityQuery m_missingStateQuery;

        protected override void OnCreate()
        {
            m_missingStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<PositionState>(),
                ComponentType.ReadOnly<ComposedLookAt>(),
                ComponentType.ReadOnly<ScreenComposerZones>(),
                ComponentType.Exclude<ComposedLookAtState>());
        }

        protected override void OnUpdate()
        {
            base.OnUpdate();

            // Add any missing composer state components
            EntityManager.AddComponent(m_missingStateQuery,
                ComponentType.ReadWrite<ComposedLookAtState>());

            Entities
                .WithName("ComposerJob")
                .ForEach((
                    ref ComposedLookAtState composerState,
                    ref PositionState posState,
                    in LookAtTargetState lookAt,
                    in ComposedLookAt composer,
                    in ScreenComposerZones composerZones,
                    in NodeUpdateState updateState) =>
                {
                    if (lookAt.Value.Entity == Entity.Null)
                        return;

                    var previousValid = updateState.PreviousFrameDataIsValid
                        && !math.all(composerState.CameraOrientationPrevFrame.value == 0);

                    composerState.Predictor.Update(
                        lookAt.Value.Position, posState.Up, composer.Lookahead,
                        math.select(-1, updateState.DeltaTime, previousValid));

                    composerState.CameraOrientationPrevFrame = math.select(
                        posState.RawRotation.value, composerState.CameraOrientationPrevFrame.value, previousValid);

                    composerState.UpdateCache(
                        updateState.Orthographic, updateState.Aspect, posState.Lens.FOV,
                        composerZones.GetSoftGuideRect(), composerZones.GetHardGuideRect(),
                        posState.GetCorrectedPosition(), composerState.Predictor.PredictedPosition);

                    float targetDistance = composerState.TargetDistance;
                    if (targetDistance < MathHelpers.Epsilon)
                    {
                        posState.RawRotation = math.normalizesafe(
                            composerState.CameraOrientationPrevFrame, quaternion.identity);
                        return; // navel-gazing, get outa here
                    }

                    if (updateState.ForcePositionAndRotation)
                        return; // posState already contains desired pos and rot

                    var rigOrientation = posState.RawRotation;
                    var targetDir = composerState.TargetDir / targetDistance;
                    float r = math.atan2(lookAt.Value.Radius, targetDistance);
                    var softGuide = composerState.FovSoftGuideRect.Inflate(-r / composerState.Fov2);
                    if (!previousValid)
                    {
                        // No damping or lookahead, just snap to dead zone
                        softGuide.HalfSize = math.select(
                            softGuide.HalfSize, float2.zero, composer.CenterOnActivate);
                        var rot = RotateToScreenBounds(targetDir, posState.Up, softGuide,
                            rigOrientation, composerState.Fov2);
                        rigOrientation = rigOrientation.ApplyCameraRotation(rot, posState.Up);
                    }
                    else
                    {
                        // Start with previous frame's orientation (but with current up)
                        var bypass = posState.DampingBypass;
                        var prevOrient = math.mul(bypass, composerState.CameraOrientationPrevFrame);
                        float3 fwd = new float3(0, 0, 1);
                        rigOrientation = quaternion.LookRotation(math.mul(prevOrient, fwd), posState.Up);

                        // GML todo: check for rigOrientation in upside-down state due to bypass rotation
                        // and force it back to sanity:
                        // if (math.dot(posState.up, math.mul(rigOrientation, math.up())) <= 0)...

                        // Move target through the soft zone, with damping
                        var rot = RotateToScreenBounds(targetDir, posState.Up, softGuide,
                            rigOrientation, composerState.Fov2);
                        rot = MathHelpers.Damp(rot, composer.Damping, updateState.DeltaTime);
                        rigOrientation = rigOrientation.ApplyCameraRotation(rot, posState.Up);

                        // Force the actual target (not the lookahead one) into the hard bounds, no damping
                        var hardGuide = composerState.FovHardGuideRect.Inflate(-r / composerState.Fov2);
                        var dir = lookAt.Value.Position - posState.GetCorrectedPosition();
                        dir = math.normalizesafe(dir, targetDir);
                        rot = RotateToScreenBounds(
                            dir, posState.Up, hardGuide, rigOrientation, composerState.Fov2);
                        rigOrientation = rigOrientation.ApplyCameraRotation(rot, posState.Up);
                    }

                    composerState.CameraOrientationPrevFrame = math.normalize(rigOrientation);
                    posState.RawRotation = composerState.CameraOrientationPrevFrame;
                })
                .ScheduleParallel();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static float2 RotateToScreenBounds(
            float3 targetDirUnit, float3 upUnit, MathHelpers.rect2d screenRect,
            quaternion rigOrientation, float2 fov)
        {
            var rotToRect = rigOrientation.GetCameraRotationToTarget(targetDirUnit, upUnit);

            // Bring it to the edge of screenRect, if outside.  Leave it alone if inside.
            ClampVerticalBounds(ref screenRect, targetDirUnit, upUnit, fov.y);
            float min = screenRect.Min.y * fov.y;
            float max = screenRect.Max.y * fov.y;
            rotToRect.y = math.select(
                math.select(0, rotToRect.y - max, rotToRect.y > max),
                rotToRect.y - min,
                rotToRect.y < min);

            min = screenRect.Min.x * fov.x;
            max = screenRect.Max.x * fov.x;
            rotToRect.x = math.select(
                math.select(0, rotToRect.x - max, rotToRect.x > max),
                rotToRect.x - min,
                rotToRect.x < min);

            return rotToRect;
        }

        /// <summary>
        /// Prevent upside-down camera situation.  This can happen if we have a high
        /// camera pitch combined with composer settings that cause the camera to tilt
        /// beyond the vertical in order to produce the desired framing.  We prevent this by
        /// clamping the composer's vertical settings so that this situation can't happen.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static void ClampVerticalBounds(ref MathHelpers.rect2d r, float3 dirUnit, float3 upUnit, float fov)
        {
            fov += math.PI / 90; // add a little slush to keep just shy of vertical
            float angle = MathHelpers.AngleUnit(dirUnit, upUnit);
            float halfFov = fov * 0.5f;
            float halfSize = r.HalfSize.y;

            float maxAllowed = angle / fov;
            float minAllowed = -math.abs(angle - math.PI) / fov;

            float rMinY = r.Min.y;
            float yMin = math.select(
                math.select(
                    rMinY - halfSize,
                    math.max(rMinY - halfSize, minAllowed),
                    angle > (math.PI - halfFov) && minAllowed > rMinY - halfSize),
                math.min(r.Min.y - halfSize, maxAllowed),
                angle < halfFov && r.Min.y + halfSize > maxAllowed);

            float yMax = math.select(
                math.select(
                    rMinY + halfSize,
                    math.max(rMinY + halfSize, minAllowed),
                    angle > (math.PI - halfFov) && minAllowed > rMinY - halfSize),
                math.min(rMinY + halfSize, maxAllowed),
                angle < halfFov && rMinY + halfSize > maxAllowed);

            var yRange = yMax - yMin;
            r.HalfSize.y = 0.5f * yRange;
            r.Center.y = yMin + yRange;
        }
    }
}
