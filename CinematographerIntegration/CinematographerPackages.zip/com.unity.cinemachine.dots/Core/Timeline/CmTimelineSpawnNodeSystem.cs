#if CINEMACHINE_TIMELINE && !UNITY_DOTSRUNTIME

using Unity.Entities;
using Unity.Jobs;
using Unity.Scheduler;
using Unity.Timeline;
using Unity.Transforms;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// Component used by Timeline clips for instantiating nodes from prefabs
    /// </summary>
    public struct CmTimelineSpawnNode : IComponentData
    {
        /// <summary>The prefab To spawn</summary>
        public SpawnPrefab Value;
    }

    /// <summary>Node that was spawned by this system</summary>
    public struct CmTimelineSpawnedNode : ISystemStateComponentData
    {
        public Entity Value;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateInGroup(typeof(TimelineSpawnGroup))]
    [UpdateBefore(typeof(EndTimelineSpawnGroupCommandBuffer))]
    public partial class CmTimelineSpawnNodeSystem : SystemBase
    {
        private EntityCommandBufferSystem m_system;

        EntityQuery m_missingStateQuery;
        EntityQuery m_danglingStateQuery;

        protected override void OnCreate()
        {
            m_system = World.GetOrCreateSystem<EndTimelineSpawnGroupCommandBuffer>();

            m_missingStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<CmTimelineSpawnNode>(),
                ComponentType.Exclude<CmTimelineSpawnedNode>());

            m_danglingStateQuery = GetEntityQuery(
                ComponentType.Exclude<CmTimelineSpawnNode>(),
                ComponentType.ReadWrite<CmTimelineSpawnedNode>());
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            CleanupDanglingState();
        }

        protected override void OnUpdate()
        {
            // Add any missing group components
            CleanupDanglingState();
            EntityManager.AddComponent(
                m_missingStateQuery, ComponentType.ReadWrite<CmTimelineSpawnedNode>());

            var commandBuffer = m_system.CreateCommandBuffer().AsParallelWriter();
            Entities
                .WithName("ClipPrefabSpawnJob")
                .WithoutBurst()
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    ref CmTimelineSpawnedNode state,
                    in CmTimelineClipInfo clipInfo,
                    in ActiveState active,
                    in CmTimelineSpawnNode spawn) =>
                {
                    var e = state.Value;
                    if (active.BecameActive && e == default
                        && spawn.Value.Prefab != default)
                    {
                        // The spawned entity referred needs to be fixed up in the command buffer
                        e = SpawnNodePrefab(entityInQueryIndex, ref commandBuffer, spawn.Value, clipInfo.ChannelKey);
                        commandBuffer.SetComponent(entityInQueryIndex, entity, new CmTimelineSpawnedNode { Value = e });
                    }
                    else if (active.BecameInActive && e != default)
                    {
                        commandBuffer.DestroyEntity(entityInQueryIndex, e);
                        commandBuffer.SetComponent(entityInQueryIndex, entity, new CmTimelineSpawnedNode());
                    }
                })
                .ScheduleParallel();

            Entities
                .WithName("ClipPrefabCleanupJob")
                .WithNone<CmTimelineSpawnNode>()
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    in CmTimelineSpawnedNode state) =>
                {
                    if (state.Value != default)
                        commandBuffer.DestroyEntity(entityInQueryIndex, state.Value);
                })
                .ScheduleParallel();

            m_system.AddJobHandleForProducer(Dependency);
        }

        void CleanupDanglingState()
        {
            if (m_danglingStateQuery.CalculateEntityCount() > 0)
                EntityManager.RemoveComponent<CmTimelineSpawnedNode>(m_danglingStateQuery);
        }

        static Entity SpawnNodePrefab(
            int index, ref EntityCommandBuffer.ParallelWriter commandBuffer,
            SpawnPrefab spawnPrefab, StableKey channelId)
        {
            var e = commandBuffer.Instantiate(index, spawnPrefab.Prefab);

            commandBuffer.AddComponent<Translation>(index, e);
            commandBuffer.AddComponent<Rotation>(index, e);
            commandBuffer.AddComponent<NodeForcedStandby>(index, e);

            commandBuffer.SetComponent(index, e, new Translation { Value = spawnPrefab.Translation });
            commandBuffer.SetComponent(index, e, new Rotation { Value = spawnPrefab.Rotation });

            // GML todo: Burst complains about this line.  how to fix?
            commandBuffer.SetSharedComponent(index, e, new NodeChannelAssignment { ChannelId = channelId });

            if (!spawnPrefab.Tag.Equals(default))
                commandBuffer.AddBuffer<TrackBindingElement>(index, e).Add(
                    new TrackBindingElement() { Value = spawnPrefab.Tag });

            return e;
        }
    }
}
#endif
