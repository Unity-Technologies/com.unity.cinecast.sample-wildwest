﻿#if false // temporary change - With Entities 14, generic jobs can produce bad output. This will be changed in a future release of Timeline.DOTS
#if CINEMACHINE_TIMELINE && !UNITY_DOTSRUNTIME
using Unity.Entities;
using Unity.Mathematics;
using Unity.Cinemachine.Core;
using Unity.Timeline;

[assembly: RegisterGenericComponentType(typeof(AnimatedComponent<ScreenComposerZones>))]
[assembly: RegisterGenericComponentType(typeof(DefaultComponentValue<ScreenComposerZones>))]

namespace Unity.Cinemachine.Core
{
    public struct ScreenComposerZonesMixer : IComponentMixer<ScreenComposerZones>
    {
        public ScreenComposerZones Lerp(
            ref ScreenComposerZones A, ref ScreenComposerZones B, float s)
        {
            return new ScreenComposerZones()
            {
                ScreenPosition = math.lerp(A.ScreenPosition, B.ScreenPosition, s),
                DeadZoneSize = math.lerp(A.DeadZoneSize, B.DeadZoneSize, s),
                SoftZoneSize = math.lerp(A.SoftZoneSize, B.SoftZoneSize, s),
                SoftZoneBias = math.lerp(A.SoftZoneBias, B.SoftZoneBias, s)
            };
        }

        public ScreenComposerZones Add(
            ref ScreenComposerZones A, ref ScreenComposerZones B)
        {
            return new ScreenComposerZones() 
            {
                ScreenPosition = A.ScreenPosition + B.ScreenPosition,
                DeadZoneSize = A.DeadZoneSize + B.DeadZoneSize,
                SoftZoneSize = A.SoftZoneSize + B.SoftZoneSize,
                SoftZoneBias = A.SoftZoneBias + B.SoftZoneBias
            };
        }
    }

    public class CmScreenComposerZonesAnimationSystem 
        : ComponentAnimationSystem<ScreenComposerZones, ScreenComposerZonesMixer>
    {
    }
}
#endif
#endif
