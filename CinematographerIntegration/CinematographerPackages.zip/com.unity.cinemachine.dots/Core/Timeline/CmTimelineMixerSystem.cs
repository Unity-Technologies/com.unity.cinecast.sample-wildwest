#if CINEMACHINE_TIMELINE && !UNITY_DOTSRUNTIME

using Unity.Entities;
using Unity.Jobs;
using Unity.Scheduler;
using Unity.Timeline;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    public struct CmTimelineClipInfo : IComponentData
    {
        public int Id;
        public StableKey ChannelKey;
        public double BlendOutStartTime;
    }

    public struct CmTimelineClipInfoState : ISystemStateComponentData
    {
        public Entity Node;
        public Entity Channel;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateInGroup(typeof(TimelineSystemGroup))]
    [UpdateAfter(typeof(ClipWeightSystem))]
    public partial class CmTimelineMixerSystem : SystemBase
    {
        CmChannelSystem m_ChannelSystem;
        EntityQuery m_missingStateQuery;
        EntityQuery m_danglingStateQuery;

        protected override void OnCreate()
        {
            m_ChannelSystem = World.GetOrCreateSystem<CmChannelSystem>();

            m_missingStateQuery = GetEntityQuery(
                ComponentType.ReadOnly<CmTimelineClipInfo>(),
                ComponentType.Exclude<CmTimelineClipInfoState>());

            m_danglingStateQuery = GetEntityQuery(
                ComponentType.Exclude<CmTimelineClipInfo>(),
                ComponentType.ReadWrite<CmTimelineClipInfoState>());
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            CleanupDanglingState();
        }

        protected override void OnUpdate()
        {
            CleanupDanglingState();
            EntityManager.AddComponent(
                m_missingStateQuery, ComponentType.ReadWrite<CmTimelineClipInfoState>());

            var channelLookup = m_ChannelSystem.GetChannelLookup();
            var channelOverrides = GetBufferFromEntity<OverrideNodeBlendElement>(false);

            Entities
                .WithName("SetChannelOverrideJob")
                .WithReadOnly(channelLookup)
                .ForEach((
                    ref CmTimelineClipInfoState clipState,
                    in CmTimelineSpawnedNode spawn,
                    in CmTimelineClipInfo clipInfo,
                    in ActiveState activeState,
                    in ClipWeight weight,
                    in LocalTime time) =>
                {
                    if (clipState.Channel == Entity.Null 
                            && !channelLookup.TryGetValue(clipInfo.ChannelKey, out clipState.Channel))
                        return;
                    if (!channelOverrides.HasComponent(clipState.Channel))
                        return;
                    var b = channelOverrides[clipState.Channel];
                    var w = weight.Value;
                    if (!activeState.Active || w == 0)
                    {
                        if (clipState.Node != Entity.Null)
                            b.ReleaseOverride(clipInfo.Id, clipState.Node);
                        clipState.Node = Entity.Null;
                    }
                    else
                    {
                        if (weight.Value < 1 && time.Value > clipInfo.BlendOutStartTime)
                            w = -w;
                        clipState.Node = spawn.Value;
                        if (clipState.Node != Entity.Null)
                            b.SetOverride(clipInfo.Id, spawn.Value, w);
                    }
                })
                .Schedule();

            m_ChannelSystem.RegisterChannelLookupReadDependencies(Dependency);

            Entities
                .WithName("ReleaseChannelOverrideJob")
                .WithAll<NodeUpdateState>()
                .WithNone<CmTimelineClipInfo>()
                .ForEach((in CmTimelineClipInfoState clipState) =>
                {
                    if (clipState.Channel != Entity.Null && clipState.Node != Entity.Null 
                        && channelOverrides.HasComponent(clipState.Channel))
                    {
                        var b = channelOverrides[clipState.Channel];
                        b.ReleaseAllOverrides(clipState.Node);
                    }
                })
                .Schedule();
        }

        void CleanupDanglingState()
        {
            if (m_danglingStateQuery.CalculateEntityCount() > 0)
                EntityManager.RemoveComponent<CmTimelineClipInfoState>(m_danglingStateQuery);
        }

    }
}
#endif
