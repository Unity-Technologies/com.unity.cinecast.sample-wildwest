using System;
using System.Runtime.CompilerServices;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using System.Runtime.InteropServices;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct TCBSplinePath : IComponentData
    {
        /// <summary>If true, then the path ends are joined to form a continuous loop</summary>
        [Tooltip("If true, then the path ends are joined to form a continuous loop.")]
        public bool Looped;

        /// <summary>Path samples per waypoint</summary>
        [Tooltip("Path samples per waypoint.  This is used for calculating path distances.")]
        [Range(1, 100)]
        public int Resolution;
    }

    [Serializable]
    [InternalBufferCapacity(8)]
    public struct TCBSplinePathWaypointElement : IBufferElementData
    {
        /// <summary>Position of the waypoint in path-local space</summary>
        [Tooltip("Position of the waypoint in path-local space, and roll")]
        public float3 Position;

        /// <summary>
        /// Tension, Continuity, and Bias.  Affects the shape of the path.  0,0,0 is default.
        /// </summary>
        [Tooltip("Tension, Continuity, and Bias.  Affects the shape of the path.  0,0,0 is default.")]
        public float3 TCB;

        /// <summary>Roll along the axis defined by the path tangent</summary>
        [Tooltip("Roll along the axis defined by the path tangent")]
        public float Roll;
    }

    /// Cache of path distances
    public struct TCBSplinePathState : ISystemStateComponentData
    {
        [StructLayout(LayoutKind.Explicit, Size = 32)]
        internal unsafe struct DistanceCache
        {
            [FieldOffset(0)] float2* P2d2p;   // x = p2d, y = d2p

            [FieldOffset(8)] public float2 P2d2pStep;
            [FieldOffset(24)] int mLength;
            [FieldOffset(28)] public bool Valid;

            public int Length { get { return mLength; } }

            public void Allocate(int size)
            {
                Dispose();
                if (size > 0)
                {
                    P2d2p = (float2*)UnsafeUtility.Malloc(
                        sizeof(float2) * size, UnsafeUtility.AlignOf<float2>(), Allocator.Persistent);
                }
                mLength = size;
            }

            public void Dispose()
            {
                if (P2d2p != null)
                    UnsafeUtility.Free(P2d2p, Allocator.Persistent);
                P2d2p = null;
                mLength = 0;
            }

            public ref float2 p2d2pAt(int i)
            {
#if ENABLE_UNITY_COLLECTIONS_CHECKS
                if (i < 0 || i >= Length)
                    throw new IndexOutOfRangeException("SplinePathState Array access out of range");
#endif
                return ref P2d2p[i];
            }
        }
        internal DistanceCache cache;

        public float PathLength { get { return cache.Length < 2 ? 0 : cache.p2d2pAt(cache.Length-1).x; } }
        public bool Looped;
        public float4x4 localToWorld;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
//    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class TCBSplinePathSystem : SystemBase
    {
        EntityQuery m_missingStateGroup;
        EntityQuery m_danglingStateGroup;

        protected override void OnCreate()
        {
            m_missingStateGroup = GetEntityQuery(
                ComponentType.ReadOnly<TCBSplinePath>(),
                ComponentType.Exclude<TCBSplinePathState>());

            m_danglingStateGroup = GetEntityQuery(
                ComponentType.Exclude<TCBSplinePath>(),
                ComponentType.ReadWrite<TCBSplinePathState>());
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            CleanupDanglingState();
        }

        protected override void OnUpdate()
        {
            CleanupDanglingState();

            // Add any missing group components
            EntityManager.AddComponent(m_missingStateGroup, ComponentType.ReadWrite<TCBSplinePathState>());

            Entities
                .WithName("DistanceCacheJob")
                .WithAll<StableKeyData>()
                .ForEach((
                    ref TCBSplinePathState state,
                    in TCBSplinePath path,
                    in LocalToWorld l2w,
                    in DynamicBuffer<TCBSplinePathWaypointElement> waypoints) =>
                {
                    ValidatePathState(
                        ref UnsafeUtilityExtensions.AsRef(in path),
                        ref UnsafeUtilityExtensions.AsRef(in l2w),
                        waypoints, ref state);
                })
                .ScheduleParallel();
        }

        void CleanupDanglingState()
        {
            // Deallocate our resources
            if (m_danglingStateGroup.CalculateEntityCount() > 0)
            {
                var a = m_danglingStateGroup.ToEntityArray(Allocator.TempJob);
                for (int i = 0; i < a.Length; ++i)
                {
                    var s = EntityManager.GetComponentData<TCBSplinePathState>(a[i]);
                    s.cache.Dispose();
                }
                a.Dispose();
                EntityManager.RemoveComponent<TCBSplinePathState>(m_danglingStateGroup);
            }
        }

        static unsafe bool ValidatePathState(
            [ReadOnly] ref TCBSplinePath path,
            [ReadOnly] ref LocalToWorld l2w,
            DynamicBuffer<TCBSplinePathWaypointElement> waypoints,
            ref TCBSplinePathState state)
        {
            bool changed = (state.Looped != path.Looped)
                || UnsafeUtility.MemCmp(
                    UnsafeUtility.AddressOf(ref state.localToWorld),
                    UnsafeUtility.AddressOf(ref l2w.Value),
                    UnsafeUtility.SizeOf<float4x4>()) != 0;

            state.localToWorld = l2w.Value;
            state.Looped = path.Looped;

            int resolution = math.max(1, path.Resolution);
            int numPoints = waypoints.Length;
            float maxPos = math.select(numPoints - 1, numPoints, path.Looped);
            maxPos = math.select(maxPos, 0, numPoints < 2);

            int numKeys = (int)math.round(resolution * maxPos);
            numKeys = math.select(numKeys, 0, numPoints < 2) + 1;
            if (state.cache.Valid && state.cache.Length == numKeys)
                return changed;

            // Sample the positions
            float stepSize = 1f / resolution;
            state.cache.Allocate(numKeys);
            state.cache.P2d2pStep = new float2(stepSize, 0);

            float pathLength = 0;
            float3 p0 = EvaluatePosition(0, ref state, ref waypoints);
            state.cache.p2d2pAt(0).x = 0;
            float pos = 0;
            for (int i = 1; i < numKeys; ++i)
            {
                pos += stepSize;
                float3 p = EvaluatePosition(pos, ref state, ref waypoints);
                float d = math.distance(p0, p);
                pathLength += d;
                p0 = p;
                state.cache.p2d2pAt(i).x = pathLength;
            }

            // Resample the distances
            state.cache.p2d2pAt(0).y = 0;
            if (numKeys > 1)
            {
                stepSize = pathLength / (numKeys - 1);
                state.cache.P2d2pStep.y = stepSize;
                float distance = 0;
                int posIndex = 1;
                for (int i = 1; i < numKeys; ++i)
                {
                    distance += stepSize;
                    float d = state.cache.p2d2pAt(posIndex).x;
                    while (d < distance && posIndex < numKeys-1)
                            d = state.cache.p2d2pAt(++posIndex).x;
                    float d0 = state.cache.p2d2pAt(posIndex-1).x;
                    float delta = d - d0;
                    float t = (distance - d0) / delta;
                    state.cache.p2d2pAt(i).y = state.cache.P2d2pStep.x * (t + posIndex - 1);
                }
                state.cache.Valid = true;
            }
            return true;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static void ComputeControlPoints(
            int indexA, int indexB, out float4 d0, out float4 d1,
            [ReadOnly] ref TCBSplinePathState state,
            [ReadOnly] ref DynamicBuffer<TCBSplinePathWaypointElement> buffer)
        {
            int iAA = math.select(math.select(indexA, buffer.Length - 1, state.Looped), indexA - 1, indexA > 0);
            int iBB = math.select(math.select(indexB, 0, state.Looped), indexB + 1, indexB < buffer.Length - 1);
            var p0 = new float4(buffer[iAA].Position, buffer[iAA].Roll);
            var p1 = new float4(buffer[indexA].Position, buffer[indexA].Roll);
            var p2 = new float4(buffer[indexB].Position, buffer[indexB].Roll);
            var p3 = new float4(buffer[iBB].Position, buffer[iBB].Roll);
            var wpA = buffer[indexA];
            var wpB = buffer[indexB];
            d0 = ((1 - wpA.TCB.x) * (1 + wpA.TCB.z) * (1 + wpA.TCB.y) * (p1 - p0))
                + ((1 - wpA.TCB.x) * (1 - wpA.TCB.z) * (1 - wpA.TCB.y) * (p2 - p1));
            d0 = p1 + d0 * 0.1666666666f;
            d1 = ((1 - wpB.TCB.x) * (1 + wpB.TCB.z) * (1 - wpB.TCB.y) * (p2 - p1))
                + ((1 - wpB.TCB.x) * (1 - wpB.TCB.z) * (1 + wpB.TCB.y) * (p3 - p2));
            d1 = p2 - d1 * 0.1666666666f;
        }

        /// <summary>Get a standardized clamped path position, taking spins into account if looped</summary>
        /// <param name="v">Value to clamp, any units</param>
        /// <param name="maxValue">Maximum allowed path value. If looped then maxValue an 0 are the same point</param>
        /// <param name="looped">True if path is looped</param>
        /// <returns>Standardized position, between 0 and MaxPos</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float ClampValue(float v, float maxValue, bool looped)
        {
            v = math.select(v, v % maxValue, looped && maxValue > MathHelpers.Epsilon);
            v = math.select(v, v + maxValue, looped && v < 0);
            v = math.select(v, 0, looped && v > maxValue - MathHelpers.Epsilon);
            return math.clamp(v, 0, maxValue);
        }

        /// <summary>Get a worldspace position of a point along the path</summary>
        /// <param name="pos">Waypoint continuous index, spins and negatives allowed if looped</param>
        /// <returns>worldspace position of the point along at path at pos</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float3 EvaluatePosition(
            float pos,
            [ReadOnly] ref TCBSplinePathState state,
            [ReadOnly] ref DynamicBuffer<TCBSplinePathWaypointElement> buffer)
        {
            var result = float3.zero;

            // GML todo: get rid of this check
            if (buffer.IsCreated && buffer.Length > 0)
            {
                float t = GetBoundingIndices(pos, buffer.Length, state.Looped, out int indexA, out int indexB);
                ComputeControlPoints(
                    indexA, indexB, out float4 d0, out float4 d1, ref state, ref buffer);
                result = MathHelpers.Bezier(
                    t, buffer[indexA].Position, d0.xyz, d1.xyz, buffer[indexB].Position);
            }
            return math.transform(state.localToWorld, result);
        }

        /// <summary>Get the tangent of the curve at a point along the path.</summary>
        /// <param name="pos">Waypoint continuous index, spins and negatives allowed if looped</param>
        /// <returns>Local-space direction of the path tangent.
        /// Length of the vector represents the tangent strength</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float3 EvaluateTangent(
            float pos,
            [ReadOnly] ref TCBSplinePathState state,
            [ReadOnly] ref DynamicBuffer<TCBSplinePathWaypointElement> buffer)
        {
            float3 result = new float3(0, 0, 1);
            // GML todo: get rid of this check
            if (buffer.IsCreated && buffer.Length > 1)
            {
                float t = GetBoundingIndices(pos, buffer.Length, state.Looped, out int indexA, out int indexB);
                ComputeControlPoints(indexA, indexB, out float4 d0, out float4 d1, ref state, ref buffer);
                result = MathHelpers.BezierTangent(
                    t, buffer[indexA].Position, d0.xyz, d1.xyz, buffer[indexB].Position);
            }
            return math.rotate(state.localToWorld, result);
        }

        /// <summary>Get the orientation the curve at a point along the path.</summary>
        /// <param name="pos">Waypoint continuous index, spins and negatives allowed if looped</param>
        /// <returns>World-space orientation of the path, as defined by tangent, up, and roll.</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static quaternion EvaluateOrientation(
            float pos,
            [ReadOnly] ref TCBSplinePathState state,
            [ReadOnly] ref DynamicBuffer<TCBSplinePathWaypointElement> buffer)
        {
            float3 fwd = EvaluateTangent(pos, ref state, ref buffer);
            float roll = 0;
            // GML todo: get rid of this check
            if (buffer.IsCreated && buffer.Length > 0)
            {
                float t = GetBoundingIndices(pos, buffer.Length, state.Looped, out int indexA, out int indexB);
                ComputeControlPoints(indexA, indexB, out float4 d0, out float4 d1, ref state, ref buffer);
                roll = MathHelpers.Bezier(t, buffer[indexA].Roll, d0.w, d1.w, buffer[indexB].Roll);
            }
            var up = math.rotate(state.localToWorld, math.up());
            quaternion q = quaternion.LookRotationSafe(fwd, up);
            return math.mul(q, quaternion.AxisAngle(new float3(0, 0, 1), roll));
        }

        /// <summary>Find the closest point on the path to a given worldspace target point.</summary>
        /// <param name="p">World-space target that we want to approach</param>
        /// <param name="startSegment">In what segment of the path to start the search.
        /// A Segment is a section of path between 2 waypoints.</param>
        /// <param name="searchRadius">How many segments on either side of the startSegment
        /// to search.  0 means no limit, i.e. search the entire path</param>
        /// <param name="stepsPerSegment">We search a segment by dividing it into this many
        /// straight pieces.  The higher the number, the more accurate the result, but performance
        /// is proportionally slower for higher numbers</param>
        /// <returns>The position along the path that is closest to the target point.
        /// The value is in Path Units, not Distance units.</returns>
        public static float FindClosestPoint(
            float3 p, int startSegment, int searchRadius, int stepsPerSegment,
            [ReadOnly] ref TCBSplinePathState state,
            [ReadOnly] ref DynamicBuffer<TCBSplinePathWaypointElement> waypoints)
        {
            int count = waypoints.Length;
            float maxPos = math.select(0, math.select(count - 1, count, state.Looped), count > 1);
            float start = 0;
            float end = maxPos;

            if (searchRadius > 0 && 2 * searchRadius < maxPos)
            {
                int r = (int)math.floor(math.min(searchRadius, end * 0.5));
                start = startSegment - r;
                end = startSegment + r + 1;
                start = math.select(math.max(start, 0), start, state.Looped);
                end = math.select(math.max(end, maxPos), end, state.Looped);
            }
            stepsPerSegment = math.clamp(stepsPerSegment, 2, 100);
            float stepSize = 1f / stepsPerSegment;
            float bestPos = startSegment;
            float bestDistance = float.MaxValue;
            for (int i = 0; i < 3; ++i)
            {
                float3 v0 = EvaluatePosition(start, ref state, ref waypoints);
                for (float f = start + stepSize; f <= end; f += stepSize)
                {
                    float3 v = EvaluatePosition(f, ref state, ref waypoints);
                    float t = p.ClosestPointOnSegment(v0, v);
                    float d = math.lengthsq(p - math.lerp(v0, v, t));
                    if (d < bestDistance)
                    {
                        bestDistance = d;
                        bestPos = f - (1 - t) * stepSize;
                    }
                    v0 = v;
                }
                start = bestPos - stepSize;
                end = bestPos + stepSize;
                stepSize /= stepsPerSegment;
            }
            return bestPos;
        }

        /// <summary>Returns lerp amount between bounds A and B</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float GetBoundingIndices(
            float pos, int length, bool looped, out int indexA, out int indexB)
        {
            pos = ClampValue(pos, math.select(length - 1, length, looped), looped);
            indexA = (int)math.floor(pos);
            indexA = math.select(indexA, 0, indexA == length);
            indexA = math.select(indexA, indexA - 1, !looped && indexA > 0 && indexA == length - 1);
            indexB = math.select(indexA + 1, 0, indexA == length - 1);
            return pos - indexA;
        }

        /// <summary>How to interpret the Path Position</summary>
        public enum PositionUnits
        {
            /// <summary>Use PathPosition units, where 0 is first waypoint, 1 is second waypoint, etc</summary>
            PathUnits,
            /// <summary>Use Distance Along Path.  Path will be sampled according to its Resolution
            /// setting, and a distance lookup table will be cached internally</summary>
            Distance,
            /// <summary>Normalized units, where 0 is the start of the path, and 1 is the end.
            /// Path will be sampled according to its Resolution
            /// setting, and a distance lookup table will be cached internally</summary>
            Normalized
        }

        /// <summary>Standardize the unit, so that it lies between MinUmit and MaxUnit</summary>
        /// <param name="pos">The value to be standardized</param>
        /// <param name="units">The unit type</param>
        /// <returns>The standardized value of pos, between MinUnit and MaxUnit</returns>
        public static float ClampUnit(
            [ReadOnly] ref DynamicBuffer<TCBSplinePathWaypointElement> waypoints,
            [ReadOnly] ref TCBSplinePathState state,
            float pos, PositionUnits units)
        {
            if (units == PositionUnits.PathUnits)
            {
                int count = waypoints.Length;
                return ClampValue(pos, math.select(count - 1, count, state.Looped), state.Looped);
            }
            if (units == PositionUnits.Normalized)
                return ClampValue(pos, 1, state.Looped);

            float len = state.PathLength;
            return ClampValue(pos, len, state.Looped);
        }


        /// <summary>Get the maximum value, for the given unit type</summary>
        /// <param name="units">The unit type</param>
        /// <returns>The maximum allowable value for this path</returns>
        public static float MaxUnit(
            [ReadOnly] ref DynamicBuffer<TCBSplinePathWaypointElement> waypoints,
            [ReadOnly] ref TCBSplinePathState state,
            PositionUnits units)
        {
            if (units == PositionUnits.Normalized)
                return 1;
            if (units == PositionUnits.Distance)
                return state.PathLength;
            int count = waypoints.Length;
            return math.select(0, math.select(count - 1, count, state.Looped), count > 1);
        }

        /// <summary>Get the path position (in native path units) corresponding to the psovided
        /// value, in the units indicated.
        /// If the distance cache is not valid, then calling this will
        /// trigger a potentially costly regeneration of the path distance cache</summary>
        /// <param name="pos">The value to convert from</param>
        /// <param name="units">The units in which pos is expressed</param>
        /// <returns>The length of the path in native units, when sampled at this rate</returns>
        public static float ToNativePathUnits(
            [ReadOnly] ref DynamicBuffer<TCBSplinePathWaypointElement> waypoints,
            [ReadOnly] ref TCBSplinePathState state,
            float pos, PositionUnits units)
        {
            if (units == PositionUnits.PathUnits)
                return pos;

            float len = state.PathLength;
            if (state.cache.Length < 1 || len < MathHelpers.Epsilon)
                return 0;

            if (units == PositionUnits.Normalized)
                pos *= state.PathLength;

            // Distance units
            pos = ClampValue(pos, len, state.Looped);
            float d = pos / state.cache.P2d2pStep.y;
            int i = (int)math.floor(d);
            if (i >= state.cache.Length-1)
                return MaxUnit(ref waypoints, ref state, PositionUnits.PathUnits);
            float t = d - (float)i;
            return math.lerp(state.cache.p2d2pAt(i).y, state.cache.p2d2pAt(i+1).y, t);
        }

        /// <summary>Get the path position (in path units) corresponding to this distance along the path.
        /// If the distance cache is not valid, then calling this will
        /// trigger a potentially costly regeneration of the path distance cache</summary>
        /// <param name="pos">The value to convert from, in native units</param>
        /// <param name="units">The units to convert toexpressed</param>
        /// <returns>The length of the path in distance units, when sampled at this rate</returns>
        public static float FromPathNativeUnits(
            [ReadOnly] ref DynamicBuffer<TCBSplinePathWaypointElement> waypoints,
            [ReadOnly] ref TCBSplinePathState state,
            float pos, PositionUnits units)
        {
            if (units == PositionUnits.PathUnits)
                return pos;

            float len = state.PathLength;
            if (state.cache.Length < 1 || len < MathHelpers.Epsilon)
                return 0;

            pos = ClampUnit(ref waypoints, ref state, pos, PositionUnits.PathUnits);
            float d = pos / state.cache.P2d2pStep.x;
            int i = (int)math.floor(d);
            if (i >= state.cache.Length-1)
                pos = len;
            else
                pos = math.lerp(state.cache.p2d2pAt(i).x, state.cache.p2d2pAt(i+1).x, d - (float)i);
            return math.select(pos, pos/len, units == PositionUnits.Normalized);
        }

        /// <summary>Call this if the path changes in such a way as to affect distances
        /// or other cached path elements</summary>
        public void InvalidatePathCache(Entity path)
        {
            var w = World;
            if (path != Entity.Null && w.SafeHasComponent<TCBSplinePathState>(path))
            {
                var state = w.SafeGetComponentData<TCBSplinePathState>(path);
                if (state.cache.Valid)
                {
                    state.cache.Valid = false;
                    EntityManager.SetComponentData(path, state);
                }
            }
        }

        /// <summary>
        /// Instance this to directly query a path.  Do not store the instance.
        /// </summary>
        public struct PathSnapshot
        {
            TCBSplinePath pathComponent;
            LocalToWorld l2w;
            TCBSplinePathState state;
            public DynamicBuffer<TCBSplinePathWaypointElement> waypoints;

            /// <summary>
            /// Create an accessor to query a path.  Do not store the accessor.
            /// </summary>
            /// <param name="w">The current world</param>
            /// <param name="path">The Path entity</param>
            /// <returns></returns>
            public static PathSnapshot Create(World w, Entity path)
            {
                var pa = new PathSnapshot
                {
                    pathComponent = w.SafeGetComponentData<TCBSplinePath>(path),
                    l2w = w.SafeGetComponentData<LocalToWorld>(path),
                    state = w.SafeGetComponentData<TCBSplinePathState>(path),
                    waypoints = w.SafeGetBuffer<TCBSplinePathWaypointElement>(path)
                };
                if (pa.waypoints.IsCreated)
                    TCBSplinePathSystem.ValidatePathState(
                        ref pa.pathComponent, ref pa.l2w, pa.waypoints, ref pa.state);
                return pa;
            }

            /// <summary>
            /// True if path data is valid and can be queried
            /// </summary>
            public bool IsValid => waypoints.IsCreated && state.cache.Valid;

            /// <summary>Get the maximum value, for the given unit type</summary>
            /// <param name="units">The unit type</param>
            /// <returns>The maximum allowable value for this path</returns>
            public float MaxUnit(PositionUnits units)
            {
                return TCBSplinePathSystem.MaxUnit(ref waypoints, ref state, units);
            }

            /// <summary>Standardize the unit, so that it lies between MinUmit and MaxUnit</summary>
            /// <param name="pos">The value to be standardized</param>
            /// <param name="units">The unit type</param>
            /// <returns>The standardized value of pos, between MinUnit and MaxUnit</returns>
            public float ClampUnit(float pos, PositionUnits units)
            {
                return TCBSplinePathSystem.ClampUnit(ref waypoints, ref state, pos, units);
            }

            /// <summary>Get the path position (in native path units) corresponding to the psovided
            /// value, in the units indicated.
            /// If the distance cache is not valid, then calling this will
            /// trigger a potentially costly regeneration of the path distance cache</summary>
            /// <param name="pos">The value to convert from</param>
            /// <param name="units">The units in which pos is expressed</param>
            /// <returns>The length of the path in native units, when sampled at this rate</returns>
            public float ToNativePathUnits(float pos, PositionUnits units)
            {
                return TCBSplinePathSystem.ToNativePathUnits(ref waypoints, ref state, pos, units);
            }

            /// <summary>Get the path position (in path units) corresponding to this distance along the path.
            /// If the distance cache is not valid, then calling this will
            /// trigger a potentially costly regeneration of the path distance cache</summary>
            /// <param name="pos">The value to convert from, in native units</param>
            /// <param name="units">The units to convert toexpressed</param>
            /// <returns>The length of the path in distance units, when sampled at this rate</returns>
            public float FromPathNativeUnits(float pos, PositionUnits units)
            {
                return TCBSplinePathSystem.FromPathNativeUnits(ref waypoints, ref state, pos, units);
            }

            /// <summary>Get a worldspace position of a point along the path</summary>
            /// <param name="pos">The value to convert from, in native units</param>
            /// <param name="units">The units to convert toexpressed</param>
            /// <returns>Local-space position of the point along at path at pos</returns>
            public float3 EvaluatePositionAtUnit(float pos, PositionUnits units)
            {
                pos = TCBSplinePathSystem.ToNativePathUnits(ref waypoints, ref state, pos, units);
                return TCBSplinePathSystem.EvaluatePosition(pos, ref state, ref waypoints);
            }

            /// <summary>Get the orientation the curve at a point along the path.</summary>
            /// <param name="pos">The value to convert from, in native units</param>
            /// <param name="units">The units to convert toexpressed</param>
            /// <returns>World-space orientation of the path, as defined by tangent, up, and roll.</returns>
            public quaternion EvaluateOrientationAtUnit(float pos, PositionUnits units)
            {
                pos = TCBSplinePathSystem.ToNativePathUnits(ref waypoints, ref state, pos, units);
                return TCBSplinePathSystem.EvaluateOrientation(pos, ref state, ref waypoints);
            }
        }
    }
}
