using System;
using Unity.Mathematics;
using UnityEngine;
using Unity.Entities;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// Definition of an impulse signal that gets propagated to listeners.
    /// 
    /// Given a raw signal source, this struct defines an envelope for time-scaling
    /// it to craft the complete Impulse signal shape.  Also, you provide here parameters 
    /// that define how the signal dissipates with spatial distance from the source location.
    /// Finally, you specify the Impulse Channel on which the signal will be sent.
    /// 
    /// An API method is provided here to take these parameters, create an Impulse Event,
    /// and broadcast it on the channel.
    /// 
    /// When creating a custom Impulse Source class, you will have an instance of this class
    /// as a field in your custom class.  Be sure also to include the
    /// [CmImpulseDefinition] attribute on the field, to get the right property drawer for it.
    /// </summary>
    [Serializable]
    public struct CmImpulseDefinition
    {
        /// <summary>This defines the time-envelope of the signal.
        /// Thie raw signal will be scaled to fit inside the envelope.</summary>
        [Serializable]
        public struct EnvelopeDefinition
        {
            /// <summary>Normalized curve defining the shape of the start of the envelope.</summary>
            [Tooltip("Normalized curve defining the shape of the start of the envelope.")]
            [TransitionDefinitionUnitsLabel("s", "The duration (in seconds) of the attack")]
            public TransitionDefinition Attack;

            /// <summary>Normalized curve defining the shape of the end of the envelope.</summary>
            [Tooltip("Normalized curve defining the shape of the end of the envelope.")]
            [TransitionDefinitionUnitsLabel("s", "The duration (in seconds) of the decay")]
            [InvertedTransitionGraph]
            public TransitionDefinition Decay;

            /// <summary>Duration in seconds of the central fully-scaled part of the envelope.  
            /// Must be >= 0.</summary>
            [Tooltip("Duration in seconds of the central fully-scaled part of the envelope.  Must be >= 0.")]
            public float SustainTime; // Must be >= 0

            /// <summary>If checked, signal amplitude scaling will also be applied to the time 
            /// envelope of the signal.  Bigger signals will last longer</summary>
            [Tooltip("If checked, signal amplitude scaling will also be applied to the time "
                + "envelope of the signal.  Stronger signals will last longer.")]
            public bool ScaleWithImpact;
        }

        /// <summary>
        /// Impulse events generated here will appear on the channels included in the mask.
        /// </summary>
        [CmImpulseChannelProperty]
        [Tooltip("Impulse events generated here will appear on the channels included in the mask.")]
        public int ImpulseChannelMask;

        /// <summary>
        /// Gain to apply to the amplitudes defined in the signal source asset.
        /// </summary>
        [Tooltip("Gain to apply to the amplitudes defined in the signal source.  1 is normal.  "
            + "Setting this to 0 completely mutes the signal.")]
        public float AmplitudeGain;

        /// <summary>
        /// Scale factor to apply to the time axis.
        /// </summary>
        [Tooltip("Scale factor to apply to the time axis.  1 is normal.  "
            + "Larger magnitudes will make the signal progress more rapidly.")]
        public float FrequencyGain;

        /// <summary>Randomize the signal start time</summary>
        [Tooltip("Randomize the signal start time")]
        public bool RandomizeStartTime;

        /// <summary>
        /// This defines the time-envelope of the signal.  
        /// The raw signal will be time-scaled to fit in the envelope.
        /// </summary>
        [Tooltip("This defines the time-envelope of the signal.  "
            + "The raw signal will be time-scaled to fit in the envelope.")]
        [HideFoldout]
        [Header("Signal Envelope")]
        public EnvelopeDefinition TimeEnvelope;

        /// <summary>
        /// The signal will have full amplitude in this radius surrounding the impact point.  
        /// Beyond that it will dissipate with distance.
        /// </summary>
        [Header("Spatial Range")]
        [Tooltip("The signal will have full amplitude in this radius surrounding the impact point.  "
            + "Beyond that it will dissipate with distance.")]
        public float ImpactRadius;

        /// <summary>Beyond the impact radius, signal dissipates over this distance.</summary>
        [Tooltip("Beyond the impact radius, signal dissipates over this distance.")]
        [TransitionDefinitionUnitsLabel("m", "The distance (in metres) of the dissipation")]
        [InvertedTransitionGraph]
        public TransitionDefinition Dissipation;

        /// <summary>How the signal behaves as the listener moves away from the origin.</summary>
        public enum DirectionModes
        {
            /// <summary>Signal direction remains constant everywhere.</summary>
            Fixed,
            /// <summary>Signal is rotated in the direction of the source.</summary>
            RotateTowardSource
        }

        /// <summary>How the signal direction behaves as the listener moves away from the origin.</summary>
        [Tooltip("How the signal direction behaves as the listener moves away from the origin.")]
        public DirectionModes DirectionMode;
    }

    /// <summary>
    /// Extensions for CmImpulseDefinition, for improved performance
    /// </summary>
    public static class CmImpulseDefinitionExtensions
    {
        /// <summary>Duration of the envelope, in seconds.</summary>
        public static float Duration(this CmImpulseDefinition.EnvelopeDefinition def)
        {
            return def.Attack.Length + def.SustainTime + def.Decay.Length; 
        }

        /// <summary>
        /// Get the value of the envelope at a given time relative to the envelope start.
        /// </summary>
        /// <param name="offset">Time in seconds fromt he envelope start</param>
        /// <returns>Envelope amplitude.  This will range from 0...1</returns>
        public static float GetValueAt(this CmImpulseDefinition.EnvelopeDefinition def, float offset)
        {
            // GML todo: optimize - get rid of ifs
            if (offset >= 0)
            {
                if (offset < def.Attack.Length && def.Attack.Length > MathHelpers.Epsilon)
                    return def.Attack.Curve.Evaluate(offset / def.Attack.Length);
                offset -= def.Attack.Length;
                if (offset < def.SustainTime)
                    return 1;
                offset -= def.SustainTime;
                if (offset < def.Decay.Length && def.Decay.Length > MathHelpers.Epsilon)
                    return 1 - def.Decay.Curve.Evaluate(offset / def.Decay.Length);
            }
            return 0;
        }

        /// <summary>
        /// Change the envelope so that it stops at a specific offset from its start time.
        /// Use this to extend or cut short an existing envelope, while respecting the
        /// attack and decay as much as possible.
        /// </summary>
        /// <param name="offset">When to stop the envelope</param>
        /// <param name="forceNoDecay">If true, enevlope will not decay, but cut off instantly</param>
        public static void ChangeStopTime(
            this CmImpulseDefinition.EnvelopeDefinition def, double offset, bool forceNoDecay)
        {
            offset = math.max(offset, 0);
            def.Attack.Length = math.select(
                def.Attack.Length, 0, offset < def.Attack.Length); // GML todo: How to prevent pop? 
            def.SustainTime = (float)(offset - def.Attack.Length);
            def.Decay.Length = math.select(def.Decay.Length, 0, forceNoDecay);
        }


        /// <summary>
        /// Get a reasonable default value for this struct
        /// </summary>
        public static CmImpulseDefinition Default
        {
            get
            {
                return new CmImpulseDefinition
                {
                    ImpulseChannelMask = 1,
                    AmplitudeGain = 1,
                    FrequencyGain = 1,
                    RandomizeStartTime = true,
                    TimeEnvelope = new CmImpulseDefinition.EnvelopeDefinition
                    {
                        Decay = new TransitionDefinition { Length = 0.7f },
                        SustainTime = 0.2f,
                        ScaleWithImpact = true
                    },
                    ImpactRadius = 100,
                    Dissipation = new TransitionDefinition { Length = 1000 }
                };
            }
        }

        /// <summary>Call this to validate the fields here</summary>
        public static void Validate(this CmImpulseDefinition def)
        {
            def.ImpactRadius = math.max(0, def.ImpactRadius);
            def.Dissipation.Length = math.max(0, def.Dissipation.Length);
            def.TimeEnvelope.Attack.Length = math.max(0, def.TimeEnvelope.Attack.Length);
            def.TimeEnvelope.Decay.Length = math.max(0, def.TimeEnvelope.Decay.Length);
            def.TimeEnvelope.SustainTime = math.max(0, def.TimeEnvelope.SustainTime);
        }
    }
}
