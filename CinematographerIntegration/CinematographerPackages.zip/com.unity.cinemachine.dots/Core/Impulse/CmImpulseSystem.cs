using System;
using System.Runtime.CompilerServices;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// Convenience methods for Impulse system clients
    /// </summary>
    public static class CmImpulse
    {
        /// <summary>
        /// Modes in which impulse time may be calculated.
        /// </summary>
        public enum TimeMode
        {
            /// <summary>
            /// Use Game time.  When game is paused or scaled in time, impulses will
            /// also pause or scale in time.
            /// </summary>
            ScaledTime,

            /// <summary>
            /// Impulses happen in real-world time, and ignore game pauses and time scaling
            /// </summary>
            UnscaledTime
        };

        /// <summary>
        /// Set this to control whether that impulses pause with the game, or continue
        /// in real time while the game is paused.
        /// </summary>
        public static TimeMode ImpulseTimeMode { get; set; }

        /// <summary>
        /// Get the current time for the purposes of Impulse.  Takes ImpulseTimeMode into account.
        /// </summary>
        /// <param name="w">The current entity World</param>
        /// <returns></returns>
        public static double GetImpulseTime(World w)
        {
            return ImpulseTimeMode == TimeMode.ScaledTime
                ? ClientHooks.GetCurrentTime(w)
                : System.DateTime.UtcNow.ToFileTimeUtc() * 1e-7;
        }

        /// <summary>
        /// Generate an impulse event at a location in space,
        /// and broadcast it on the appropriate impulse channel.
        /// </summary>
        /// <param name="definition">The characteristics of the impulse event</param>
        /// <param name="posSignal">The raw position waveform to generate inside the signal envelope</param>
        /// <param name="rotSignal">The raw rtoation waveform to generate inside the signal envelope</param>
        /// <param name="position">The event origin in world space</param>
        /// <param name="intensity">Scale multiplier for the intensity of the impact (normal = 1)</param>
        /// <param name="orientation">Defines the local axes for the signal - normal is Identity</param>
        public static void EmitImpulse(
            in World world,
            in CmImpulseDefinition definition,
            in NativeArray<AdditiveNoiseElement> posSignal,
            in NativeArray<AdditiveNoiseElement> rotSignal,
            float3 position, float intensity, quaternion orientation)
        {
            if (world == null || (posSignal.Length == 0 && rotSignal.Length == 0)
                    || definition.TimeEnvelope.Duration() < MathHelpers.Epsilon)
                return;

            var m = world.EntityManager;
            var ev = new CmImpulseEvent
            {
                StartTime = GetImpulseTime(world),
                EventOrigin = position,
                EventOrientation = math.normalizesafe(orientation, quaternion.identity),
                ImpulseDefinition = definition
            };

            // Randomize signal start time
            if (definition.RandomizeStartTime)
            {
                var s = world.GetOrCreateSystem<CmImpulseSourceSystem>();
                ev.SignalTimeOffset = s.GetRandomStartTime();
            }

            // Scale the time-envelope decay as the root of the amplitude scale
            if (definition.TimeEnvelope.ScaleWithImpact)
                ev.ImpulseDefinition.TimeEnvelope.Decay.Length *= intensity;

            // Scale the signal with the intensity
            ev.ImpulseDefinition.AmplitudeGain *= intensity;

            // Create new signal source
            var e = m.CreateEntity();
            m.AddComponentData(e, ev);

            var pos = m.AddBuffer<ImpulsePosNoiseElement>(e);
            for (int i = 0; i < posSignal.Length; ++i)
                pos.Add(new ImpulsePosNoiseElement { Value = posSignal[i] });

            var rot = m.AddBuffer<ImpulseRotNoiseElement>(e);
            for (int i = 0; i < rotSignal.Length; ++i)
                rot.Add(new ImpulseRotNoiseElement { Value = rotSignal[i] });
        }
    }


    [Serializable]
    [InternalBufferCapacity(9)]
    struct ImpulsePosNoiseElement : IBufferElementData
    {
        public AdditiveNoiseElement Value;
    }

    [Serializable]
    [InternalBufferCapacity(9)]
    struct ImpulseRotNoiseElement : IBufferElementData
    {
        public AdditiveNoiseElement Value;
    }

    [Serializable]
    struct CmImpulseEvent : IComponentData
    {
        /// <summary>Start time of the event.</summary>
        public double StartTime;

        /// <summary>The raw (undecayed) position component of the signal at the current time.</summary>
        public float3 RawSignalPosition;

        /// <summary>The raw (undecayed) rotation component of the signal at the current time.</summary>
        public float3 RawSignalOrientation;

        /// <summary>This can be randomized to avoid always getting the same signal shape</summary>
        public float SignalTimeOffset;

        /// <summary>Worldspace origin of the signal event.</summary>
        public float3 EventOrigin;

        /// <summary>Defines the local axes of the signal event</summary>
        public quaternion EventOrientation;

        /// <summary>Characteristics of the impulse signal</summary>
        public CmImpulseDefinition ImpulseDefinition;
    }

    static class CmImpulseEventExtensions
    {
        /// <summary>Returns true if the event is generating a signal</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsLive(this CmImpulseEvent e, double currentTime)
        {
            return e.StartTime < currentTime && !e.IsExpired(currentTime);
        }

        /// <summary>Returns true if the event is no longer generating a signal because
        /// its time has expired</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsExpired(this CmImpulseEvent e, double currentTime)
        {
            double d = e.ImpulseDefinition.TimeEnvelope.Duration();
            return d > 0 && e.StartTime + d <= currentTime;
        }

        /// <summary>Cancel the event at the supplied time</summary>
        /// <param name="time">The time at which to cancel the event</param>
        /// <param name="forceNoDecay">If true, event will be cut immediately at the time,
        /// otherwise its envelope's decay curve will begin at the cancel time</param>
        public static void Cancel(this CmImpulseEvent e, double time, bool forceNoDecay)
        {
            e.ImpulseDefinition.TimeEnvelope.ChangeStopTime(time - e.StartTime, forceNoDecay);
        }

        /// <summary>Get the signal that a listener at a given position would perceive</summary>
        /// <param name="listenerPosition">The listener's position in world space</param>
        /// <param name="use2D">True if distance calculation should ignore Z</param>
        /// <param name="pos">The position impulse signal</param>
        /// <param name="rot">The rotation impulse signal</param>
        /// <returns>true if non-trivial signal is returned</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void GetDecayedSignal(
            this CmImpulseEvent e, 
            double currentTime, float3 listenerPosition, bool use2D,
            out float3 pos, out float3 rot)
        {
            // GML todo: optimize - get rid of ifs
            var position = e.EventOrigin;
            position.y = math.select(position.y, 0, use2D);
            listenerPosition.y = math.select(listenerPosition.y, 0, use2D);
            float distance = math.distance(listenerPosition, position);
            var time = (float)(currentTime - e.StartTime);
            float scale = e.ImpulseDefinition.TimeEnvelope.GetValueAt(time) * e.DistanceDecay(distance);
            pos = e.RawSignalPosition * scale;
            rot = e.RawSignalOrientation * scale;
            if (e.ImpulseDefinition.DirectionMode == CmImpulseDefinition.DirectionModes.RotateTowardSource
                && distance > MathHelpers.Epsilon)
            {
                var q = MathHelpers.FromToRotationUnit(
                    new float3(0, 1, 0),
                    math.normalizesafe(listenerPosition - position, new float3(0, 0, 1)),
                    new float3 (0, 0, 1));
                if (e.ImpulseDefinition.ImpactRadius > MathHelpers.Epsilon)
                {
                    float t = math.clamp(distance / e.ImpulseDefinition.ImpactRadius, 0, 1);
                    q = math.slerp(q, quaternion.identity, math.cos(math.PI * t / 2));
                }
                pos = math.mul(q, pos);
                // GML todo: is this correct? used to be rot = Quaternion.Inverse(q) * rot * q)
                rot = math.mul(q, math.mul(math.inverse(q), rot));
            }
        }

        /// <summary>Calculate the the decay applicable at a given distance from the impact point</summary>
        /// <returns>Scale factor 0...1</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float DistanceDecay(this CmImpulseEvent e, float distance)
        {
            // GML todo: optimize - get rid of ifs
            float radius = math.max(e.ImpulseDefinition.ImpactRadius, 0);
            if (distance < radius)
                return 1;
            distance -= radius;
            return 1 - e.ImpulseDefinition.Dissipation.Curve.Evaluate(
                distance / e.ImpulseDefinition.Dissipation.Length);
        }
    }

    [UpdateBefore(typeof(CameraPreBodySystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CmImpulseSourceSystem : SystemBase
    {
        EntityQuery m_impulseSourceQuery;
        EntityCommandBufferSystem m_commandBufferSystem;

        Mathematics.Random Random = new Mathematics.Random(1087);

        /// <summary>
        /// Get a randomized start time for an impulse event
        /// </summary>
        internal float GetRandomStartTime() { return Random.NextFloat(-100f, 100f); }

        protected override void OnCreate()
        {
            m_commandBufferSystem = World.GetOrCreateSystem<EndSimulationEntityCommandBufferSystem>();

            m_impulseSourceQuery = GetEntityQuery(
                ComponentType.ReadWrite<CmImpulseEvent>(),
                ComponentType.ReadOnly<ImpulsePosNoiseElement>(),
                ComponentType.ReadOnly<ImpulseRotNoiseElement>());
        }

        public JobHandle SourceJobDeps { get; private set; }

        protected override void OnUpdate()
        {
            var commandBuffer = m_commandBufferSystem.CreateCommandBuffer().AsParallelWriter();
            var currentTime = CmImpulse.GetImpulseTime(World);

            Entities
                .WithName("ImpulseSourceJob")
                .WithStoreEntityQueryInField(ref m_impulseSourceQuery)
                .ForEach((
                    Entity entity, int entityInQueryIndex,
                    ref CmImpulseEvent impulse,
                    in DynamicBuffer<ImpulsePosNoiseElement> posSignal,
                    in DynamicBuffer<ImpulseRotNoiseElement> rotSignal) =>
                {
                    if (impulse.IsExpired(currentTime))
                        commandBuffer.DestroyEntity(entityInQueryIndex, entity);
                    else if (impulse.IsLive(currentTime))
                    {
                        // Advance the raw signal
                        float t = (float)(currentTime - impulse.StartTime) * impulse.ImpulseDefinition.FrequencyGain;
                        float3 p = float3.zero;
                        for (int i = 0; i < posSignal.Length; ++i)
                            p[math.clamp(posSignal[i].Value.Axis, 0, 2)]
                                += posSignal[i].Value.GetValueAt(t, impulse.SignalTimeOffset);
                        float3 r = float3.zero;
                        for (int i = 0; i < rotSignal.Length; ++i)
                            r[math.clamp(rotSignal[i].Value.Axis, 0, 2)]
                                += rotSignal[i].Value.GetValueAt(t, impulse.SignalTimeOffset);
                        // orient the position offset, but not the rotations.  Listener handles rotations
                        impulse.RawSignalPosition = math.mul(
                            impulse.EventOrientation, p * impulse.ImpulseDefinition.AmplitudeGain);
                        impulse.RawSignalOrientation = math.radians(r * impulse.ImpulseDefinition.AmplitudeGain);
                    }
                })
                .ScheduleParallel();
            SourceJobDeps = Dependency;
        }
    }


    [Serializable]
    public struct ImpulseListener : IComponentData
    {
        /// <summary>
        /// Impulse events on channels not included in the mask will be ignored.
        /// </summary>
        [Tooltip("Impulse events on channels not included in the mask will be ignored.")]
        [CmImpulseChannelProperty]
        public int ImpulseChannelMask;

        /// <summary>
        /// Gain to apply to the Impulse signal.
        /// </summary>
        [Tooltip("Gain to apply to the Impulse signal.  1 is normal strength.  "
            + "Setting this to 0 completely mutes the signal.")]
        public float Gain;

        /// <summary>
        /// Enable this to perform distance calculation in 2D (ignore Z).
        /// </summary>
        [Tooltip("Enable this to perform distance calculation in 2D (ignore Z)")]
        public bool Use2DDistance;
    }


    [UpdateAfter(typeof(CameraPostNoiseSystem))]
    [UpdateBefore(typeof(CameraFinalizeSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class CmImpulseListenerSystem : SystemBase
    {
        EntityQuery m_impulseSourceQuery;
        CmImpulseSourceSystem m_impulseSourceSystem;

        protected override void OnCreate()
        {
            m_impulseSourceQuery = GetEntityQuery(ComponentType.ReadWrite<CmImpulseEvent>());
            m_impulseSourceSystem = World.GetOrCreateSystem<CmImpulseSourceSystem>();
        }

        protected override void OnUpdate()
        {
            // Make sure the impulse writing jobs are finished before trying to read.
            // GML todo: consider instead making the source run after the listener
            m_impulseSourceSystem.SourceJobDeps.Complete();

            var events = m_impulseSourceQuery.ToComponentDataArray<CmImpulseEvent>(Allocator.TempJob);
            if (events.Length == 0)
            {
                events.Dispose();
                return;
            }
            var currentTime = CmImpulse.GetImpulseTime(World);

            Entities
                .WithName("ImpulseListenerJob")
                .WithDisposeOnCompletion(events)
                .WithReadOnly(events)
                .ForEach((ref PositionState posState,in ImpulseListener listener) =>
                {
                    // Get combined impulse signal
                    var pos = float3.zero;
                    var rot = float3.zero;
                    for (int i = 0; i < events.Length; ++i)
                    {
                        if ((events[i].ImpulseDefinition.ImpulseChannelMask & listener.ImpulseChannelMask) != 0)
                        {
                            events[i].GetDecayedSignal(
                                currentTime, posState.RawPosition, listener.Use2DDistance,
                                out float3 pos0, out float3 rot0);
                            pos += pos0;
                            rot += rot0;
                        }
                    }
                    // Apply to node state - pos in world space, rot in camera-local space
                    posState.PositionCorrection -= pos * listener.Gain;
                    posState.RotationCorrection
                        = math.mul(posState.RotationCorrection, quaternion.Euler(rot * listener.Gain));
                })
                .ScheduleParallel();
        }
    }
}
