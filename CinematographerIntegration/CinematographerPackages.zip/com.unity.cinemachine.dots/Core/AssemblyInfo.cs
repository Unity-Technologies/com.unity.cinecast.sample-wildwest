using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.Cinemachine.Editor")]
[assembly: InternalsVisibleTo("Unity.Cinemachine.Hybrid")]
[assembly: InternalsVisibleTo("Unity.Cinecast.Cinematographer.Core")]
