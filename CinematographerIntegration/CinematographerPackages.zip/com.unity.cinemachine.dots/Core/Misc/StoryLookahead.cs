//#define ENABLE_SANITY_CHECK // Note: Burst must be disabled for this

using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using System.Runtime.CompilerServices;
using System;
using Unity.Collections.LowLevel.Unsafe;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    [InternalBufferCapacity(StoryLookaheadWindow.GrowAmount)]
    public struct StoryLookaheadInfo : IBufferElementData
    {
        public struct TargetInfo
        {
            public float Value;
            public float3 Position;
            public quaternion Rotation;
            public float Radius;
        }
        public TargetInfo Info;
        public long FrameNumber;

    }

    [Serializable]
    public struct StoryLookaheadWindow : IComponentData
    {
        public const int GrowAmount = 64;

        /// <summary>
        /// How many frames of data are present
        /// </summary>
        public int NumFrames;

        /// <summary>
        /// Index of the first valid element in the buffer
        /// </summary>
        public int TailIndex;

        /// <summary>
        /// Offset from TailIndex of the first (past-most) element in the 
        /// value time window.  This is Movie Time.
        /// </summary>
        public int MovieTimeOffset;

        /// <summary>
        /// How many frames in he lookahead window.  The last frame is Game Time.
        /// </summary>
        public int LookheadWindowNumFrames;

        /// <summary>
        /// Sum of the values of the from MovieTimeFrame to GameTimeFrame, inclusive
        /// </summary>
        public float LookaheadWindowValueSum;
    }

    /// <summary>
    /// Circular buffer implementation and helpers
    /// </summary>
    public static class StoryLookaheadWindowExtensions
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsEmpty(this in StoryLookaheadWindow w) => w.NumFrames == 0;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Clear(this ref StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data)
        {
            w.NumFrames = w.TailIndex = w.MovieTimeOffset = w.LookheadWindowNumFrames = 0;
            w.LookaheadWindowValueSum = 0;
            data.Clear();
        }

        /// <summary>
        /// Head is the future-most value in the buffer
        /// </summary>
        /// <param name="w"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static StoryLookaheadInfo HeadValue(
            this in StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data)
                => data[data.ComputeIndex(w.TailIndex, w.NumFrames - 1)];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static long HeadTimeFrame(
            this in StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data)
                => data[data.ComputeIndex(w.TailIndex, w.NumFrames - 1)].FrameNumber;


        /// <summary>
        /// Tail is the past-most value in the buffer
        /// </summary>
        /// <param name="w"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static StoryLookaheadInfo TailValue(
            this in StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data) => data[w.TailIndex];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static long TailTimeFrame(
            this in StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data) => data[w.TailIndex].FrameNumber;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void AddHead(
            this ref StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data, 
            StoryLookaheadInfo value)
        {
#if ENABLE_SANITY_CHECK
            if (value.Info.Value < 0)
                UnityEngine.Debug.Log("Adding negative value: " + value.Info.Value);
#endif
            if (w.NumFrames >= data.Length)
                Grow(ref w, data);
            var index = data.ComputeIndex(w.TailIndex, w.NumFrames);
            data[index] = value;
            if (++w.NumFrames == 1)
            {
                w.MovieTimeOffset = 0;
                w.LookheadWindowNumFrames = 1;
                w.LookaheadWindowValueSum = data[index].Info.Value;
            }
#if ENABLE_SANITY_CHECK
            SanityCheck(w, data);
#endif
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void RemoveTail(
            this ref StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data)
        {
            if (w.NumFrames > 0)
            {
                var oldIndex = w.TailIndex;
                w.TailIndex = data.ComputeIndex(oldIndex, 1);
                if (--w.NumFrames == 0)
                    w.Clear(data);
                else if (--w.MovieTimeOffset < 0)
                {
                    // Push movie time
                    w.MovieTimeOffset = 0;
                    w.LookaheadWindowValueSum = math.max(0, w.LookaheadWindowValueSum - data[oldIndex].Info.Value);
                    if (--w.LookheadWindowNumFrames <= 0)
                    {
#if ENABLE_SANITY_CHECK
                        SanityCheck(w, data);
#endif
                        // Push game time
                        w.LookheadWindowNumFrames = 1;
                        w.LookaheadWindowValueSum = data[w.TailIndex].Info.Value;
                    }
                }
#if ENABLE_SANITY_CHECK
                SanityCheck(w, data);
#endif
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int ComputeIndex(this DynamicBuffer<StoryLookaheadInfo> data, int i, int delta)
        {
            var index = (i + delta) % math.select(data.Length, 1, data.Length == 0);
            return math.select(index, index + data.Length, index < 0);
        }

        static unsafe void Grow(ref StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data)
        {
            var newData = new NativeArray<StoryLookaheadInfo>(
                data.Length + StoryLookaheadWindow.GrowAmount, Allocator.Temp);

            var elemSize = sizeof(StoryLookaheadInfo);
            var dst = (byte*)newData.GetUnsafePtr();
            var src = (byte*)data.GetUnsafePtr();

            var firstChunkStartOffset = w.TailIndex * elemSize;
            var firstChunkBytes = (data.Length - w.TailIndex) * elemSize;
            UnsafeUtility.MemCpy(dst, src + firstChunkStartOffset, firstChunkBytes);
            var headIndex = data.ComputeIndex(w.TailIndex, w.NumFrames);
            if (headIndex <= w.TailIndex)
                UnsafeUtility.MemCpy(dst + firstChunkBytes, src, firstChunkStartOffset);

            data.Clear();
            data.AddRange(newData);
            w.TailIndex = 0;
        }

        /// <summary>
        /// Movie time is the past-most value in the lookahead window.  A Value sum
        /// is maintained within this window, for rapid average value computation.
        /// </summary>
        /// <param name="w"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static StoryLookaheadInfo MovieTimeValue(
            this in StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data) 
                => data[data.ComputeIndex(w.TailIndex, w.MovieTimeOffset)];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static long MovieTimeFrame(
            this in StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data) 
                => data[data.ComputeIndex(w.TailIndex, w.MovieTimeOffset)].FrameNumber;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool AdvanceMovieTime(
            this ref StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data)
        {
            var movieTimeIndex = data.ComputeIndex(w.TailIndex, w.MovieTimeOffset);
            if (w.NumFrames <= 1 || data.ComputeIndex(w.TailIndex, w.NumFrames - 1) == movieTimeIndex)
                return false; // nothing there
            w.LookaheadWindowValueSum = math.max(0, w.LookaheadWindowValueSum - data[movieTimeIndex].Info.Value);
            ++w.MovieTimeOffset;
            if (--w.LookheadWindowNumFrames <= 0)
            {
#if ENABLE_SANITY_CHECK
                SanityCheck(w, data);
#endif
                // Push gmame time
                movieTimeIndex = data.ComputeIndex(w.TailIndex, w.MovieTimeOffset);
                w.LookheadWindowNumFrames = 1;
                w.LookaheadWindowValueSum = data[movieTimeIndex].Info.Value;
            }
#if ENABLE_SANITY_CHECK
            SanityCheck(w, data);
#endif
            return true;
        }


        /// <summary>
        /// Game time is the future-most value in the lookahead window.  A Value sum
        /// is maintained within this window, for rapid average value computation.
        /// </summary>
        /// <param name="w"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static StoryLookaheadInfo GameTimeValue(
            this in StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data) 
                => data[data.ComputeIndex(w.TailIndex, w.MovieTimeOffset + w.LookheadWindowNumFrames - 1)];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static long GameTimeFrame(
            this in StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data) 
                => data[data.ComputeIndex(w.TailIndex, w.MovieTimeOffset + w.LookheadWindowNumFrames - 1)].FrameNumber;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool AdvanceGameTime(
            this ref StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data)
        {
            var nextIndex = data.ComputeIndex(w.TailIndex, w.MovieTimeOffset + w.LookheadWindowNumFrames);
            if (w.NumFrames <= 1 || data.ComputeIndex(w.TailIndex, w.NumFrames) == nextIndex)
                return false; // already fully advanced
            ++w.LookheadWindowNumFrames;
            w.LookaheadWindowValueSum += data[nextIndex].Info.Value;
#if ENABLE_SANITY_CHECK
            SanityCheck(w, data);
#endif
            return true;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void ResetGameTime(
            this ref StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data)
        {
            if (w.NumFrames > 0)
            {
                var movieTimeIndex = data.ComputeIndex(w.TailIndex, w.MovieTimeOffset);
                w.LookheadWindowNumFrames = 1;
                w.LookaheadWindowValueSum = data[movieTimeIndex].Info.Value;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float GetAverageLookaheadValue(this in StoryLookaheadWindow w)
        {
            return math.select(
                w.LookaheadWindowValueSum / w.LookheadWindowNumFrames,
                0, w.LookheadWindowNumFrames <= 0);
        }

#if ENABLE_SANITY_CHECK
        static void SanityCheck(this in StoryLookaheadWindow w, DynamicBuffer<StoryLookaheadInfo> data)
        {
            if (w.NumFrames < w.LookheadWindowNumFrames)
                UnityEngine.Debug.Log($"NumFrames < LookheadWindowNumFrames: {w.NumFrames} < {w.LookheadWindowNumFrames}");
            if (w.LookheadWindowNumFrames < 0)
                UnityEngine.Debug.Log("LookheadWindowNumFrames is negative: " + w.LookheadWindowNumFrames);
            if (w.LookaheadWindowValueSum < 0)
                UnityEngine.Debug.Log("LookaheadWindowValueSum is negative: " + w.LookaheadWindowValueSum);
        }
#endif
    }
}
