#if CINEMACHINE_UNITY_PHYSICS

using Unity.Collections;
using Unity.Entities;
using Unity.Burst;
using Unity.Physics;

namespace Unity.Cinemachine.Core
{
    public static class CollisionHelpers
    {
        /// <summary>
        /// Custom hit collector that ignores stuff.
        /// Important Note: you have to ignore hits where Hit.ColliderKey.Value == 0
        /// </summary>
        [BurstCompile]
        struct ClosestHitWithIgnoreCollector : ICollector<RaycastHit>
        {
            public NativeSlice<RigidBody> Bodies;
            public Entity EntityToIgnore;

            public bool EarlyOutOnFirstHit => false;
            public float MaxFraction { get; private set; }
            public int NumHits { get; private set; }

            private RaycastHit m_OldHit;
            private RaycastHit m_ClosestHit;
            public RaycastHit Hit => m_ClosestHit;

            public ClosestHitWithIgnoreCollector(
                float maxFraction, NativeSlice<RigidBody> rigidBodies, Entity entityToIgnore)
            {
                m_OldHit = default(RaycastHit);
                m_ClosestHit = default(RaycastHit);
                MaxFraction = maxFraction;
                NumHits = 0;
                Bodies = rigidBodies;
                EntityToIgnore = entityToIgnore;
            }

            public bool AddHit(RaycastHit hit)
            {
                if (hit.Fraction == 0 || hit.Fraction >= MaxFraction) // ignore object if ray origin is inside it
                    return false;

                var isAcceptable = 0 <= m_ClosestHit.RigidBodyIndex;
                if (isAcceptable)
                {
                    var body = Bodies[m_ClosestHit.RigidBodyIndex];
                    unsafe
                    {
                        isAcceptable = body.Entity != EntityToIgnore
                            && !IsTrigger((Collider*)body.Collider.GetUnsafePtr(), 
                                m_ClosestHit.ColliderKey);
                    }
                }
                if (!isAcceptable)
                    return false;

                MaxFraction = hit.Fraction;
                m_OldHit = m_ClosestHit;
                m_ClosestHit = hit;
                NumHits = 1;
                return true;
            }

            public static unsafe bool IsTrigger(Collider* c, ColliderKey key)
            {
                bool bIsTrigger = false;
                {
                    var cc = ((ConvexCollider*)c);
                    if (cc->CollisionType != CollisionType.Convex)
                    {
                        c->GetLeaf(key, out ChildCollider child);
                        cc = (ConvexCollider*)child.Collider;
                        UnityEngine.Assertions.Assert.IsTrue(cc->CollisionType == CollisionType.Convex);
                    }
                    bIsTrigger = cc->Material.CollisionResponse == CollisionResponsePolicy.RaiseTriggerEvents;
                }
                return bIsTrigger;
            }
        }

        /// <summary>
        /// Custom hit collector that ignores everything except one entity.
        /// Important Note: you have to ignore hits where Hit.ColliderKey.Value == 0
        /// </summary>
        [BurstCompile]
        struct ClosestHitOnSingleEntityCollector : ICollector<RaycastHit>
        {
            public NativeSlice<RigidBody> Bodies;
            public Entity MyEntity;

            public bool EarlyOutOnFirstHit => false;
            public float MaxFraction { get; private set; }
            public int NumHits { get; private set; }

            private RaycastHit m_OldHit;
            public RaycastHit Hit { get; private set; }

            public ClosestHitOnSingleEntityCollector(
                float maxFraction, NativeSlice<RigidBody> rigidBodies, Entity myEntity)
            {
                m_OldHit = default(RaycastHit);
                Hit = default(RaycastHit);
                MaxFraction = maxFraction;
                NumHits = 0;
                Bodies = rigidBodies;
                MyEntity = myEntity;
            }

            public bool AddHit(RaycastHit hit)
            {
                if (hit.Fraction == 0 || hit.Fraction >= MaxFraction) // ignore object if ray origin is inside it
                    return false;

                var isAcceptable = 0 <= Hit.RigidBodyIndex;
                if (isAcceptable)
                {
                    var body = Bodies[Hit.RigidBodyIndex];
                    isAcceptable = body.Entity == MyEntity;
                }
                if (!isAcceptable)
                    return false;
                
                MaxFraction = hit.Fraction;
                m_OldHit = Hit;
                Hit = hit;
                NumHits = 1;
                return true;
            }
        }

        /// <summary>
        /// Raycast returning the nearest hit, but ignoring hits to a specific entity
        /// </summary>
        /// <param name="world">Physics world</param>
        /// <param name="input">Raycast input.  Remember: ray Direction includes length</param>
        /// <param name="ignoreEntity">Ignore all hits to this entity</param>
        /// <param name="hitInfo">return data for nearest hit, if functon returns true</param>
        /// <returns>true if comething hit</returns>
        public static bool RaycastNearestIgnoreEntity(
            CollisionWorld world, RaycastInput input, Entity ignoreEntity, out RaycastHit hitInfo)
        {
            var collector = new ClosestHitWithIgnoreCollector(1f, world.Bodies, ignoreEntity);
            if (world.CastRay(input, ref collector) && collector.Hit.ColliderKey.Value != 0)
            {
                hitInfo = collector.Hit;
                return true;
            }
            hitInfo = default;
            return false;
        }

        /// <summary>
        /// Raycast returning the nearest hit on a specific entity
        /// </summary>
        /// <param name="world">Physics world</param>
        /// <param name="input">Raycast input.  Remember: ray Direction includes length</param>
        /// <param name="myEntity">Consider only hits to this entity</param>
        /// <param name="hitInfo">return data for nearest hit, if functon returns true</param>
        /// <returns>true if comething hit</returns>
        public static bool RaycastNearestSingleEntity(
            CollisionWorld world, RaycastInput input, Entity myEntity, out RaycastHit hitInfo)
        {
            var collector = new ClosestHitOnSingleEntityCollector(1f, world.Bodies, myEntity);
            if (world.CastRay(input, ref collector) && collector.Hit.ColliderKey.Value != 0)
            {
                hitInfo = collector.Hit;
                return true;
            }
            hitInfo = default;
            return false;
        }
    }
}
#endif
