using Unity.Mathematics;
using System.Runtime.CompilerServices;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// The output of the Cinemachine engine for a specific node.  The information
    /// in this struct can be blended, and provides what is needed to calculate an
    /// appropriate camera position, orientation, and lens setting.
    ///
    /// Raw values are what the Cinemachine behaviours generate.  The correction channel
    /// holds perturbations to the raw values - e.g. noise or smoothing, or obstacle
    /// avoidance corrections.  Coirrections are not considered when making time-based
    /// calculations such as damping.
    ///
    /// The Final position and orientation is the comination of the raw values and
    /// their corrections.
    /// </summary>
    public struct CameraState
    {
        /// <summary>
        /// Camera Lens Settings.
        /// </summary>
        public LensSettings Lens { get; set; }

        /// <summary>
        /// Which way is up.  World space unit vector.  Must have a length of 1.
        /// </summary>
        public float3 ReferenceUp { get; set; }

        /// <summary>
        /// The world space focus point of the camera.  What the camera wants to look at.
        /// There is a special constant define to represent "nothing".  Be careful to
        /// check for that (or check the HasLookAt property).
        /// </summary>
        public float3 ReferenceLookAt { get; set; }
        public float ReferenceLookAtRadius { get; set; }

        /// <summary>
        /// Returns true if this state has a valid ReferenceLookAt value.
        /// </summary>
        public bool HasLookAt { get { return !ReferenceLookAt.IsNan(); } }

        /// <summary>
        /// This constant represents "no point in space" or "no direction".
        /// </summary>
        public static float3 kNoPoint = new float3(float.NaN, float.NaN, float.NaN);

        /// <summary>
        /// Raw (un-corrected) world space position of this camera
        /// </summary>
        public float3 RawPosition { get; set; }

        /// <summary>
        /// Raw (un-corrected) world space orientation of this camera
        /// </summary>
        public quaternion RawOrientation { get; set; }

        /// <summary>
        /// Subjective estimation of how "good" the shot is.
        /// Larger values mean better quality.  Default is 1.
        /// </summary>
        public float ShotQuality { get; set; }

        /// <summary>
        /// Position correction.  This will be added to the raw position.
        /// This value doesn't get fed back into the system when calculating the next frame.
        /// Can be noise, or smoothing, or both, or something else.
        /// </summary>
        public float3 PositionCorrection { get; set; }

        /// <summary>
        /// Orientation correction.  This will be added to the raw orientation.
        /// This value doesn't get fed back into the system when calculating the next frame.
        /// Can be noise, or smoothing, or both, or something else.
        /// </summary>
        public quaternion OrientationCorrection { get; set; }

        /// <summary>
        /// Position with correction applied.
        /// </summary>
        public float3 CorrectedPosition { get { return RawPosition + PositionCorrection; } }

        /// <summary>
        /// Orientation with correction applied.
        /// </summary>
        public quaternion CorrectedOrientation { get { return math.mul(RawOrientation, OrientationCorrection); } }

        /// <summary>
        /// Position with correction applied.  This is what the final camera gets.
        /// </summary>
        public float3 FinalPosition { get { return RawPosition + PositionCorrection; } }

        /// <summary>
        /// Orientation with correction and dutch applied.  This is what the final camera gets.
        /// </summary>
        public quaternion FinalOrientation
        {
            get
            {
                return math.mul(
                    CorrectedOrientation,
                    quaternion.AxisAngle(new float3(0, 0, 1), math.radians(Lens.Dutch)));
            }
        }

        /// <summary>
        /// These hints can be or'ed toether to influence how blending is done, and how state
        /// is applied to the camera
        /// </summary>
        public NodeBlendHint.BlendHintValue BlendHint { get; set; }

        /// <summary>
        /// State with default values
        /// </summary>
        public static CameraState Default
        {
            get
            {
                return new CameraState
                {
                    Lens = LensSettings.Default,
                    ReferenceUp = math.up(),
                    ReferenceLookAt = kNoPoint,
                    RawPosition = float3.zero,
                    RawOrientation = quaternion.identity,
                    ShotQuality = 1,
                    PositionCorrection = float3.zero,
                    OrientationCorrection = quaternion.identity,
                    BlendHint = NodeBlendHint.BlendHintValue.Nothing
                };
            }
        }
/*
        /// <summary>Opaque structure represent extra blendable stuff and its weight.
        /// The base system ignores this data - it is intended for extension modules</summary>
        public struct CustomBlendable
        {
            /// <summary>The custom stuff that the extension module will consider</summary>
            public Object Custom;
            /// <summary>The weight of the custom stuff.  Must be 0...1</summary>
            public float Weight;
        };

        // This is to avoid excessive GC allocs
        CustomBlendable mCustom0;
        CustomBlendable mCustom1;
        CustomBlendable mCustom2;
        CustomBlendable mCustom3;
        List<CustomBlendable> mCustomOverflow;

        /// <summary>The number of custom blendables that will be applied to the camera.
        /// The base system manages but otherwise ignores this data - it is intended for
        /// extension modules</summary>
        public int NumCustomBlendables { get; private set; }

        /// <summary>Get a custom blendable that will be applied to the camera.
        /// The base system manages but otherwise ignores this data - it is intended for
        /// extension modules</summary>
        /// <param name="index">Which one to get.  Must be in range [0...NumCustomBlendables)</param>
        /// <returns>The custom blendable at the specified index.</returns>
        public CustomBlendable GetCustomBlendable(int index)
        {
            switch (index)
            {
                case 0: return mCustom0;
                case 1: return mCustom1;
                case 2: return mCustom2;
                case 3: return mCustom3;
                default:
                {
                    index -= 4;
                    if (mCustomOverflow != null && index < mCustomOverflow.Count)
                        return mCustomOverflow[index];
                    return new CustomBlendable();
                }
            }
        }

        int FindCustomBlendable(Object custom)
        {
            if (mCustom0.Custom == custom)
                return 0;
            if (mCustom1.Custom == custom)
                return 1;
            if (mCustom2.Custom == custom)
                return 2;
            if (mCustom3.Custom == custom)
                return 3;
            if (mCustomOverflow != null)
            {
                for (int i = 0; i < mCustomOverflow.Count; ++i)
                    if (mCustomOverflow[i].Custom == custom)
                        return i + 4;
            }
            return -1;
        }

        /// <summary>Add a custom blendable to the pot for eventual application to the camera.
        /// The base system manages but otherwise ignores this data - it is intended for
        /// extension modules</summary>
        /// <param name="b">The custom blendable to add.  If b.m_Custom is the same as an
        /// already-added custom blendable, then they will be merged and the weights combined.</param>
        public void AddCustomBlendable(CustomBlendable b)
        {
            // Attempt to merge common blendables to avoid growth
            int index = FindCustomBlendable(b.Custom);
            if (index >= 0)
                b.Weight += GetCustomBlendable(index).Weight;
            else
            {
                index = NumCustomBlendables;
                NumCustomBlendables = index + 1;
            }
            switch (index)
            {
                case 0: mCustom0 = b; break;
                case 1: mCustom1 = b; break;
                case 2: mCustom2 = b; break;
                case 3: mCustom3 = b; break;
                default:
                {
                    if (mCustomOverflow == null)
                        mCustomOverflow = new List<CustomBlendable>();
                    mCustomOverflow.Add(b);
                    break;
                }
            }
        }
*/
        /// <summary>Intelligently blend the contents of two states.</summary>
        /// <param name="stateA">The first state, corresponding to t=0</param>
        /// <param name="stateB">The second state, corresponding to t=1</param>
        /// <param name="t">How much to interpolate.  Internally clamped to 0..1</param>
        /// <returns>Linearly interpolated CameraState</returns>
        public static CameraState Lerp(CameraState stateA, CameraState stateB, float t)
        {
            t = math.clamp(t, 0, 1);
            float adjustedT = t;

            CameraState state = new CameraState();

            // Combine the blend hints intelligently
            if (((stateA.BlendHint & stateB.BlendHint) & NodeBlendHint.BlendHintValue.NoPosition) != 0)
                state.BlendHint |= NodeBlendHint.BlendHintValue.NoPosition;
            if (((stateA.BlendHint & stateB.BlendHint) & NodeBlendHint.BlendHintValue.NoOrientation) != 0)
                state.BlendHint |= NodeBlendHint.BlendHintValue.NoOrientation;
            if (((stateA.BlendHint & stateB.BlendHint) & NodeBlendHint.BlendHintValue.NoLens) != 0)
                state.BlendHint |= NodeBlendHint.BlendHintValue.NoLens;
            if (((stateA.BlendHint | stateB.BlendHint) & NodeBlendHint.BlendHintValue.SphericalPositionBlend) != 0)
                state.BlendHint |= NodeBlendHint.BlendHintValue.SphericalPositionBlend;
            if (((stateA.BlendHint | stateB.BlendHint) & NodeBlendHint.BlendHintValue.CylindricalPositionBlend) != 0)
                state.BlendHint |= NodeBlendHint.BlendHintValue.CylindricalPositionBlend;

            if (((stateA.BlendHint | stateB.BlendHint) & NodeBlendHint.BlendHintValue.NoLens) == 0)
                state.Lens = LensSettings.Lerp(stateA.Lens, stateB.Lens, t);
            else if (((stateA.BlendHint & stateB.BlendHint) & NodeBlendHint.BlendHintValue.NoLens) == 0)
            {
                if ((stateA.BlendHint & NodeBlendHint.BlendHintValue.NoLens) != 0)
                    state.Lens = stateB.Lens;
                else
                    state.Lens = stateA.Lens;
            }
            state.ReferenceUp = math.normalizesafe(math.lerp(stateA.ReferenceUp, stateB.ReferenceUp, t), math.up());
            state.ShotQuality = math.lerp(stateA.ShotQuality, stateB.ShotQuality, t);

            state.PositionCorrection = ApplyPosBlendHint(
                stateA.PositionCorrection, stateA.BlendHint,
                stateB.PositionCorrection, stateB.BlendHint,
                state.PositionCorrection,
                math.lerp(stateA.PositionCorrection, stateB.PositionCorrection, t));

            state.OrientationCorrection = ApplyRotBlendHint(
                stateA.OrientationCorrection, stateA.BlendHint,
                stateB.OrientationCorrection, stateB.BlendHint,
                state.OrientationCorrection,
                math.slerp(stateA.OrientationCorrection, stateB.OrientationCorrection, t));

            // LookAt target
            state.ReferenceLookAtRadius = math.lerp(
                stateA.ReferenceLookAtRadius, stateB.ReferenceLookAtRadius, t);
            if (!stateA.HasLookAt || !stateB.HasLookAt)
                state.ReferenceLookAt = kNoPoint;
            else
            {
                // Re-interpolate FOV to preserve target composition, if possible
                float fovA = stateA.Lens.FieldOfView;
                float fovB = stateB.Lens.FieldOfView;
                if (((stateA.BlendHint | stateB.BlendHint) & NodeBlendHint.BlendHintValue.NoLens) == 0
                    && !state.Lens.Orthographic && math.abs(fovA - fovB) > MathHelpers.Epsilon)
                {
                    LensSettings lens = state.Lens;
                    lens.FieldOfView = InterpolateFOV(
                            fovA, fovB,
                            math.max(math.length(stateA.ReferenceLookAt - stateA.CorrectedPosition), stateA.Lens.NearClipPlane),
                            math.max(math.length(stateB.ReferenceLookAt - stateB.CorrectedPosition), stateB.Lens.NearClipPlane), t);
                    state.Lens = lens;

                    // Make sure we preserve the screen composition through FOV changes
                    adjustedT = math.abs((lens.FieldOfView - fovA) / (fovB - fovA));
                }

                // Linear interpolation of lookAt target point
                state.ReferenceLookAt = math.lerp(stateA.ReferenceLookAt, stateB.ReferenceLookAt, adjustedT);
            }

            // Raw position
            state.RawPosition = ApplyPosBlendHint(
                stateA.RawPosition, stateA.BlendHint,
                stateB.RawPosition, stateB.BlendHint,
                state.RawPosition, state.InterpolatePosition(
                    stateA.RawPosition, stateA.ReferenceLookAt,
                    stateB.RawPosition, stateB.ReferenceLookAt,
                    t));

            // Clever orientation interpolation
            quaternion newOrient = state.RawOrientation;
            if (((stateA.BlendHint | stateB.BlendHint) & NodeBlendHint.BlendHintValue.NoOrientation) == 0)
            {
                var dirTarget = float3.zero;
                if (state.HasLookAt)
                {
                    // If orientations are different, use LookAt to blend them
                    if (math.distancesq(stateA.RawOrientation.value, stateB.RawOrientation.value) > MathHelpers.Epsilon)
                        dirTarget = state.ReferenceLookAt - state.CorrectedPosition;
                }
                if (dirTarget.AlmostZero()
                    || ((stateA.BlendHint | stateB.BlendHint) & NodeBlendHint.BlendHintValue.IgnoreLookAtTarget) != 0)
                {
                    // Don't know what we're looking at - can only slerp
                    newOrient = math.slerp(stateA.RawOrientation, stateB.RawOrientation, t);
                }
                else
                {
                    // Rotate while preserving our lookAt target
                    dirTarget = math.normalize(dirTarget);
                    if ((dirTarget - state.ReferenceUp).AlmostZero()
                        || (dirTarget + state.ReferenceUp).AlmostZero())
                    {
                        // Looking up or down at the pole
                        newOrient = math.slerp(stateA.RawOrientation, stateB.RawOrientation, t);
                    }
                    else
                    {
                        // Put the target in the center
                        newOrient = quaternion.LookRotation(dirTarget, state.ReferenceUp);

                        // Blend the desired offsets from center
                        float2 deltaA = -stateA.RawOrientation.GetCameraRotationToTarget(
                                math.normalize(stateA.ReferenceLookAt - stateA.CorrectedPosition), stateA.ReferenceUp);
                        float2 deltaB = -stateB.RawOrientation.GetCameraRotationToTarget(
                                math.normalize(stateB.ReferenceLookAt - stateB.CorrectedPosition), stateB.ReferenceUp);
                        newOrient = newOrient.ApplyCameraRotation(
                                math.lerp(deltaA, deltaB, adjustedT), state.ReferenceUp);
                    }
                }
            }
            state.RawOrientation = ApplyRotBlendHint(
                stateA.RawOrientation, stateA.BlendHint,
                stateB.RawOrientation, stateB.BlendHint,
                state.RawOrientation, newOrient);
/*
            // Accumulate the custom blendables and apply the weights
            for (int i = 0; i < stateA.NumCustomBlendables; ++i)
            {
                CustomBlendable b = stateA.GetCustomBlendable(i);
                b.Weight *= (1-t);
                if (b.Weight > UnityVectorExtensions.Epsilon)
                    state.AddCustomBlendable(b);
            }
            for (int i = 0; i < stateB.NumCustomBlendables; ++i)
            {
                CustomBlendable b = stateB.GetCustomBlendable(i);
                b.Weight *= t;
                if (b.Weight > MathHelpers.Epsilon)
                    state.AddCustomBlendable(b);
            }
*/
            return state;
        }

        static float InterpolateFOV(float fovA, float fovB, float dA, float dB, float t)
        {
            // We interpolate shot height
            float hA = dA * 2f * math.tan(math.radians(fovA) * 0.5f);
            float hB = dB * 2f * math.tan(math.radians(fovB) * 0.5f);
            float h = math.lerp(hA, hB, t);
            float d = math.lerp(dA, dB, t);
            float fov = math.select(179f, math.degrees(2f * math.atan(h / (2 * d))), d > MathHelpers.Epsilon);
            return math.clamp(fov, math.min(fovA, fovB), math.max(fovA, fovB));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float3 ApplyPosBlendHint(
            in float3 posA, NodeBlendHint.BlendHintValue hintA,
            in float3 posB, NodeBlendHint.BlendHintValue hintB,
            in float3 original, in float3 blended)
        {
            return math.select(
                math.select(
                    math.select(posA, posB, (hintA & NodeBlendHint.BlendHintValue.NoPosition) != 0),
                    original,
                    ((hintA & hintB) & NodeBlendHint.BlendHintValue.NoPosition) != 0),
                blended,
                ((hintA | hintB) & NodeBlendHint.BlendHintValue.NoPosition) == 0);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static quaternion ApplyRotBlendHint(
            in quaternion rotA, NodeBlendHint.BlendHintValue hintA,
            in quaternion rotB, NodeBlendHint.BlendHintValue hintB,
            in quaternion original, in quaternion blended)
        {
            return math.select(
                math.select(
                    math.select(
                        rotA.value, rotB.value, 
                        (hintA & NodeBlendHint.BlendHintValue.NoOrientation) != 0),
                    original.value,
                    ((hintA & hintB) & NodeBlendHint.BlendHintValue.NoOrientation) != 0),
                blended.value,
                ((hintA | hintB) & NodeBlendHint.BlendHintValue.NoOrientation) == 0);
        }

        float3 InterpolatePosition(
            in float3 posA, in float3 pivotA,
            in float3 posB, in float3 pivotB,
            float t)
        {
            if (!pivotA.IsNan() && !pivotB.IsNan())
            {
                if ((BlendHint & NodeBlendHint.BlendHintValue.CylindricalPositionBlend) != 0)
                {
                    // Cylindrical interpolation about pivot
                    var a = MathHelpers.ProjectOntoPlane(posA - pivotA, ReferenceUp);
                    var b = MathHelpers.ProjectOntoPlane(posB - pivotB, ReferenceUp);
                    var c = MathHelpers.Slerp(a, b, t);
                    return math.lerp((posA - a) + c, (posB - b) + c, t);
                }
                else if ((BlendHint & NodeBlendHint.BlendHintValue.SphericalPositionBlend) != 0)
                {
                    // Spherical interpolation about pivot
                    var c = MathHelpers.Slerp(posA - pivotA, posB - pivotB, t);
                    return math.lerp(pivotA + c, pivotB + c, t);
                }
            }
            return math.lerp(posA, posB, t);
        }
    }
}
