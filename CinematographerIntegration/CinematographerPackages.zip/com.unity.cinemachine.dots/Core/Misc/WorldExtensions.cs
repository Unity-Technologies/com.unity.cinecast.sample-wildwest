using Unity.Entities;

namespace Unity.Cinemachine.Core
{
    public static class WorldExtensions
    {
        /// <summary>Get a current active system.  May be null</summary>
        public static T SafeGetSystem<T>(this World w) where T : ComponentSystemBase
        {
            return w != null && w.IsCreated ? w.GetExistingSystem<T>() : null;
        }

        /// <summary>Does entity have a component?</summary>
        public static bool SafeHasComponent<T>(this World w, Entity e)
        {
            return w != null && w.IsCreated && e != Entity.Null 
                && w.EntityManager.Exists(e) && w.EntityManager.HasComponent<T>(e);
        }

        /// <summary>Add component data, but only if absent</summary>
        public static void SafeAddComponentData<T>(
            this World w, Entity e, T c) where T : struct, IComponentData
        {
            if (w != null && w.IsCreated && e != Entity.Null 
                    && w.EntityManager.Exists(e) && !w.EntityManager.HasComponent<T>(e))
                w.EntityManager.AddComponentData(e, c);
        }

        /// <summary>Get component data, with all the null checks.
        /// Returns default if nonexistant</summary>
        public static T SafeGetComponentData<T>(
            this World w, Entity e) where T : struct, IComponentData
        {
            if (w != null && w.IsCreated && w.EntityManager.Exists(e) && w.EntityManager.HasComponent<T>(e))
                return w.EntityManager.GetComponentData<T>(e);
            return new T();
        }

        /// <summary>Set component data, with all the null checks. Will add if necessary</summary>
        public static void SafeSetComponentData<T>(
            this World w, Entity e, T c) where T : struct, IComponentData
        {
            if (w != null && w.IsCreated && w.EntityManager.Exists(e))
            {
                if (w.EntityManager.HasComponent<T>(e))
                    w.EntityManager.SetComponentData(e, c);
            }
        }

        /// <summary>Set component data, with all the null checks. Will add if necessary</summary>
        public static void SafeSetSharedComponentData<T>(
            this World w, Entity e, T c) where T : struct, ISharedComponentData
        {
            if (w != null && w.IsCreated && e != Entity.Null && w.EntityManager.Exists(e))
            {
                if (w.EntityManager.HasComponent<T>(e))
                    w.EntityManager.SetSharedComponentData(e, c);
            }
        }

        /// <summary>Get component data, with all the null checks.
        /// Returns default if nonexistant</summary>
        public static DynamicBuffer<T> SafeGetBuffer<T>(
            this World w, Entity e) where T : unmanaged, IBufferElementData
        {
            if (w != null && w.IsCreated && w.EntityManager.Exists(e) && w.EntityManager.HasComponent<T>(e))
                return w.EntityManager.GetBuffer<T>(e);
            return new DynamicBuffer<T>();
        }
    }
}
