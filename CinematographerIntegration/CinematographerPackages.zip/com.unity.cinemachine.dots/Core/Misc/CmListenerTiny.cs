using Unity.Entities;

namespace Unity.Cinemachine.Core
{
    public struct CmListenerTiny : IComponentData
    {
        public StableKey ChannelOverride;
        public Entity OutputCamera;
    }
}
