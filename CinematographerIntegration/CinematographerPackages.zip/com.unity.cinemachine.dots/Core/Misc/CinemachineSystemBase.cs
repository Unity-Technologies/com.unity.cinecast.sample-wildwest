using System.Collections;
using System.Collections.Generic;
using Unity.Entities;

public abstract partial class CinemachineSystemBase : SystemBase
{
    class WorldInfo
    {
        public double LastUpdateTime;
        public List<CinemachineSystemBase> Systems;
    }
    static Dictionary<World, WorldInfo> s_AllWorlds = new Dictionary<World, WorldInfo>();
    static List<World> s_StaleWorlds = new List<World>();
    static bool s_DoingManualUpdate;

    /// <summary>
    /// Update all registered Cinemachine systems for this world
    /// </summary>
    /// <param name="world">The world to update</param>
    /// <returns>True if updated, false otherwise</returns>
    public static bool ManualUpdate(World world)
    {
        if (!s_AllWorlds.TryGetValue(world, out var worldInfo) || s_DoingManualUpdate)
            return false;

        s_DoingManualUpdate = true;
        for (int i = 0; i < worldInfo.Systems.Count; ++i)
            worldInfo.Systems[i].Update();
        s_DoingManualUpdate = false;

        return true;
    }

    /// <summary>
    /// Derived classes must call the base class implementation, which tracks 
    /// update order and provides an interface for manual updating.
    /// </summary>
    protected override void OnUpdate()
    {
        if (s_DoingManualUpdate)
            return;

        if (!s_AllWorlds.TryGetValue(World, out var worldInfo))
        {
            worldInfo = new WorldInfo { Systems = new List<CinemachineSystemBase>() };
            s_AllWorlds[World] = worldInfo;
        }

        var timeNow = World.Time.ElapsedTime;
        if (worldInfo.LastUpdateTime != timeNow)
        {
            // Clear the systems list, to record current system order this frame
            worldInfo.LastUpdateTime = timeNow;
            worldInfo.Systems.Clear();

            // Clean stale worlds
            foreach (var wi in s_AllWorlds)
                if (wi.Value.LastUpdateTime < timeNow - 1)
                    s_StaleWorlds.Add(wi.Key);
            for (int i = 0; i < s_StaleWorlds.Count; ++i)
                s_AllWorlds.Remove(s_StaleWorlds[i]);
            s_StaleWorlds.Clear();
        }

        // Track the system
        worldInfo.Systems.Add(this);
    }
}
