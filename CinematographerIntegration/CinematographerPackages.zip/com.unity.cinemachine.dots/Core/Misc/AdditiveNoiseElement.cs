using System;
using System.Runtime.CompilerServices;
using Unity.Mathematics;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct AdditiveNoiseElement
    {
        public float Frequency;
        public float Amplitude;
        public bool Randomize;
        public byte Axis; // Which axis this signal affects.  Use 0, 1, 2 for X, Y, Z

        /// <summary>Get the signal value at a given time, offset by a given amount</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetValueAt(float time, float timeOffset)
        {
            float t = (Frequency * time) + timeOffset;
            return math.select(
                math.cos(t * 2f * math.PI) * Amplitude * 0.5f,
                noise.snoise(new float2(t, 0)) * Amplitude,
                Randomize);
        }
    }
}
