using Unity.Mathematics;
using System;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    // GML todo: OnTargetObjectWarped

    /// <summary>
    /// Controls for position prediction, aka lookahead.  
    /// Include this struct in your component to control the lookahead settings.
    /// </summary>
    [Serializable]
    public struct TargetPositionPredictor
    {
        [Tooltip("Attempt to predict the target's position as it will be this much time in the future.  ")]
        [Range(0f, 1f)]
        public float LookaheadTime;

        /// <summary>Controls the smoothness of the lookahead algorithm.  Larger values smooth out
        /// jittery predictions and also increase prediction lag</summary>
        [Tooltip("Controls the smoothness of the lookahead algorithm.  Larger values smooth out "
            + "jittery predictions and also increase prediction lag")]
        [Range(0, 10)]
        public float Smoothing;

        /// <summary>If checked, movement along the Y axis will be ignored for lookahead calculations</summary>
        [Tooltip("If checked, movement along the Y axis will be ignored for lookahead calculations")]
        public bool IgnoreVertical;

        /// <summary>Validate the settings, making sure it's not nonsense</summary>
        public void Validate()
        {
            LookaheadTime = math.max(0, LookaheadTime);
            Smoothing = math.max(0, Smoothing);
        }

        /// <summary>
        /// Volatile state data for position proediction.
        /// Include this struct in your state component.
        /// </summary>
        [Serializable]
        public struct StateData
        {
            float3 Velocity;
            float3 SmoothDampVelocity;
            float3 Pos;
            float SqrSpeed;
            bool HavePos;

            /// <summary>The predicted position, valid after calling Update()</summary>
            public float3 PredictedPosition;

            /// <summary>Reset prediction, to start fresh at the next call to Update()</summary>
            public void Reset()
            {
                HavePos = false; 
                SmoothDampVelocity = float3.zero; 
                SqrSpeed = 0;
            }

            /// <summary>
            /// Call this from your system's job to update the internal state and predict
            /// the position according to the lookahead settings
            /// </summary>
            /// <param name="pos">The latest actual target position</param>
            /// <param name="up">Which way is up (for ignoring vertical movement)</param>
            /// <param name="predictor">Lookahead settings</param>
            /// <param name="deltaTime">Delta time this frame - if negative, then Reset will be called.</param>
            public void Update(
                float3 pos, float3 up, in TargetPositionPredictor predictor, float deltaTime)
            {
                if (predictor.LookaheadTime > MathHelpers.Epsilon)
                {
                    if (deltaTime < 0)
                        Reset();
                    if (HavePos && deltaTime > MathHelpers.Epsilon)
                    {
                        var vel = (pos - Pos) / deltaTime;
                        var sqrSpeed = math.lengthsq(vel);
                        var smoothing = predictor.Smoothing;
                        smoothing *= math.select(0.3f, 0.1f, sqrSpeed < SqrSpeed);
                        Velocity = MathHelpers.SmoothDamp(
                            Velocity, vel, ref SmoothDampVelocity, 
                            smoothing, deltaTime);
                        SqrSpeed = math.lengthsq(Velocity);
                    }
                    Pos = pos;
                    HavePos = true;

                    var delta = Velocity * predictor.LookaheadTime;
                    if (predictor.IgnoreVertical)
                        delta = delta.ProjectOntoPlane(up);
                    pos += delta;
                }
                PredictedPosition = pos;
            }
        }
    }
}
