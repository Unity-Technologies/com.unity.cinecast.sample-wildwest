﻿using System;
using System.Runtime.CompilerServices;
using Unity.Burst;
using Unity.Mathematics;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    internal static class ShotQualityUtils
    {
        [BurstCompile]
        public static float GetQualityBoostForOptimalTargetDistance(
            float3 targetPos, float3 cameraPos, float optimalTargetDistance, float maxBoostFactor)
        {
            // GML todo: optimize!  get rid of ifs
            // Boost quality if target is close to optimal nearness
            float nearnessBoost = 0;
            if (optimalTargetDistance > 1f)
            {
                float distance = math.length(targetPos - cameraPos);
                if (distance <= optimalTargetDistance)
                {
                    float threshold = optimalTargetDistance * 0.5f;
                    nearnessBoost = math.select(
                        maxBoostFactor * (distance - threshold) / (optimalTargetDistance - threshold), 0,
                        distance < threshold);
                }
                else
                {
                    distance -= optimalTargetDistance;
                    float threshold = optimalTargetDistance * 3;
                    nearnessBoost = math.select(
                        0, maxBoostFactor * (1f - (distance / threshold)),
                        distance < threshold);
                }
            }
            return 1f + nearnessBoost;
        }

        [BurstCompile]
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsTargetOnscreen(float3 dir, float size, float aspect)
        {
            float fovY = 0.5f * math.radians(size);    // size is vFov in deg.  need half-fov in rad
            float2 fov = new float2(math.atan(math.tan(fovY) * aspect), fovY);
            float2 angle = new float2(
                MathHelpers.AngleUnit(
                    math.normalize(dir.ProjectOntoPlane(math.up())), new float3(0, 0, 1)),
                MathHelpers.AngleUnit(
                    math.normalize(dir.ProjectOntoPlane(new float3(1, 0, 0))), new float3(0, 0, 1)));
            return math.all(angle <= fov);
        }

        [BurstCompile]
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsTargetOnscreenOrtho(float3 dir, float size, float aspect)
        {
            float2 s = new float2(size * aspect, size);
            return math.all(math.abs(new float2(dir.x, dir.y)) < s);
        }
    }
}
