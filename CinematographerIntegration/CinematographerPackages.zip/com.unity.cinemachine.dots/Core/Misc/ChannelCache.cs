using System.Collections.Generic;
using Unity.Collections;
using Unity.Entities;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// Internal helper functions for CmChannelSystem.
    /// </summary>
    internal struct ChannelCache
    {
        public struct Item
        {
            public Entity e;
            public StableKey k;
            public CmChannel c;
            public CmChannelState state;

            public StableKey ParentChannel;
            public int ParentChannelIndex;
            public int NestLevel;
            public int TopLevelParentIndex;
            public bool IsDefaultChannel;
        }

        public struct CandidateInfo
        {
            public Entity Entity;
            public NodePriority NodePriority;
            public int Sequence;
            public float ShotQuality;
        }

        // Must call RecreateCache() before accessing
        public List<Item> Cache { get; private set; }

        // Mapper to get leaf-first channel ordering
        public NativeArray<int> LeafFirstCacheSort { get => m_LeafFirstCacheSort; }
        NativeArray<int> m_LeafFirstCacheSort;

        // These each have 1 entry per channel
        public NativeArray<CandidateInfo> BestCandidateNode { get; private set; }
        public NativeArray<CandidateInfo> DefaultBestCandidateNode { get; private set; }

        public void RecreateCache(NativeArray<Entity> channels, World w)
        {
            // GML todo: be more clever in detecting structural changes and preserving state
            var m = w.EntityManager;
            int numChannels = channels.Length;

            if (BestCandidateNode.IsCreated)
                BestCandidateNode.Dispose();
            BestCandidateNode = new NativeArray<CandidateInfo>(numChannels, Allocator.Persistent);
            if (DefaultBestCandidateNode.IsCreated)
                DefaultBestCandidateNode.Dispose();
            DefaultBestCandidateNode = new NativeArray<CandidateInfo>(numChannels, Allocator.Persistent);

            int defaultChannel = -1;
            if (Cache == null)
                Cache = new List<Item>(numChannels);
            Cache.Clear();
            Cache.Capacity = numChannels;
            for (int i = 0; i < numChannels; ++i)
            {
                var e = channels[i];
                var item = new Item
                {
                    e = e,
                    k = m.GetComponentData<StableKeyData>(e).Value,
                    c = m.GetComponentData<CmChannel>(e),
                    state = m.GetComponentData<CmChannelState>(e),
                    ParentChannel = m.GetSharedComponentData<NodeChannelAssignment>(e).ChannelId,
                    ParentChannelIndex = -1,
                    TopLevelParentIndex = -1,
                    NestLevel = 0
                };
                item.state.CacheIndex = i;
                m.SetComponentData(e, item.state);

                // GML if no NodePriority is present, we assume that this can be a top-level channel
                if (defaultChannel < 0 && !item.ParentChannel.IsValid && !m.HasComponent<NodePriority>(e))
                {
                    item.IsDefaultChannel = true;
                    defaultChannel = i;
                }
                Cache.Add(item);
            }

            // Find the parent index for each channel
            for (int i = 0; i < numChannels; ++i)
            {
                var item = Cache[i];
                if (item.ParentChannel.IsValid)
                {
                    for (int j = 0; j < numChannels; ++j)
                    {
                        if (Cache[j].k == item.ParentChannel)
                        {
                            item.ParentChannelIndex = j;
                            Cache[i] = item;
                            break;
                        }
                    }
                }
                else if (defaultChannel >= 0 && i != defaultChannel && m.HasComponent<NodePriority>(item.e))
                {
                    item.ParentChannelIndex = defaultChannel;
                    Cache[i] = item;
                }
            }

            // Compute NestLevel and TopLevelParentIndex for each channel
            for (int i = 0; i < numChannels; ++i)
            {
                var item = Cache[i];
                if (numChannels == 1 || item.IsDefaultChannel || item.ParentChannelIndex == -1)
                    continue;
                var parentIndex = item.ParentChannelIndex;
                int index = i;
                while (parentIndex != -1 && ++item.NestLevel < numChannels)
                {
                    index = parentIndex;
                    parentIndex = Cache[index].ParentChannelIndex;
                }
                item.TopLevelParentIndex = index;
                Cache[i] = item;
            }

            CreateLeafFirstCacheSort();
        }

        struct NestLevelComparer : IComparer<Item>
        {
            public int Compare(Item x, Item y) => y.NestLevel - x.NestLevel;
        }
            
        public void Dispose()
        {
            if (BestCandidateNode.IsCreated)
                BestCandidateNode.Dispose();
            if (DefaultBestCandidateNode.IsCreated)
                DefaultBestCandidateNode.Dispose();
            if (m_LeafFirstCacheSort.IsCreated)
                m_LeafFirstCacheSort.Dispose();
            if (Cache != null)
                Cache.Clear();
            Cache = null;
        }

        void CreateLeafFirstCacheSort()
        {
            int count = Cache.Count;
            if (m_LeafFirstCacheSort.IsCreated)
                m_LeafFirstCacheSort.Dispose();
            m_LeafFirstCacheSort = new NativeArray<int>(count, Allocator.Persistent);
            for (int i = 0; i < count; ++i)
                m_LeafFirstCacheSort[i] = i;
            if (count > 1)
                m_LeafFirstCacheSort.Sort(new CompareNestLevel { Cache = Cache });
        }

        struct CompareNestLevel : IComparer<int>
        {
            public List<Item> Cache;
            public int Compare(int x, int y) => Cache[y].NestLevel - Cache[x].NestLevel;
        }
    }
}
