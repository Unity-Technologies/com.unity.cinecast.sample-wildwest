﻿using System;
using System.Runtime.CompilerServices;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.Serialization;

namespace Unity.Cinemachine.Core
{
    [Serializable]
    public struct TransitionCurve
    {
        [Range(0, 1)]
        public float A;

        [Range(0, 1)]
        public float B;

        [Range(-1, 1)]
        public float Bias;

        public static TransitionCurve Default { get { return new TransitionCurve{ A = 0, B = 0, Bias = 0 }; } }
        public static TransitionCurve Linear { get { return new TransitionCurve{ A = 0.3333f, B = 0.3333f, Bias = 0 }; } }
    }

    [Serializable]
    public struct TransitionDefinition
    {
        [Tooltip("The shape of the transition curve")]
        public TransitionCurve Curve;
        [Tooltip("The length of the transition, in context-appropriate units")]
        [FormerlySerializedAs("Duration")]
        public float Length;
    }

    public static class TransitionCurveExtensions
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float Evaluate(this TransitionCurve c, float t)
        {
            t = MathHelpers.Bias(t, (1f - c.Bias) * 0.5f);
            // The following is equivalent to MathHelpers.Bezier(t, 0, c.A, 1 - c.B, 1)
            // but optimized a little 
            var t2 = t * t;
            var d = 1f - t;
            return 3f * d * d * t * c.A + 3f * d * t2 * (1 - c.B) + t * t2;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float Evaluate(this TransitionDefinition b, float v, float defaultValue = 0)
        {
            return b.Curve.Evaluate(math.select(defaultValue, v / b.Length, b.Length > 0.001f));
        }
    }
}
