#if !UNITY_DOTSRUNTIME
    using UnityEngine;
#else
    // Define some stubs here - when in pure dots mode there is no UnityEngine
    public class PropertyAttribute : System.Attribute {}
    public class HeaderAttribute : PropertyAttribute { public HeaderAttribute(string x) {}  }
    public class RangeAttribute : PropertyAttribute { public RangeAttribute(float a, float b) { } }
    public class HideInInspectorAttribute : PropertyAttribute {}
#endif

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// Property applied to float2 to treat (x, y) as (min, max).
    /// Used for custom drawing in the inspector.
    /// </summary>
    public sealed class Float2AsRangePropertyAttribute : PropertyAttribute {}

    /// <summary>
    /// A dummy class for dependency checking.  GML todo: replace with something else
    /// </summary>
    public sealed class AssemblyDependencyClass {};

    /// <summary>
    /// Hint to the property drawer to invert the transition definition graph
    /// </summary>
    public sealed class InvertedTransitionGraphAttribute : PropertyAttribute { }

    /// <summary>
    /// Hint to the property drawer to customize the label of the transition length
    /// </summary>
    public class TransitionDefinitionUnitsLabelAttribute : PropertyAttribute
    {
        public readonly string Label;
        public readonly string Tooltip;
        public TransitionDefinitionUnitsLabelAttribute(string label, string tooltip)
        {
            Label = label;
            Tooltip = tooltip;
        }
    }

    /// <summary>
    /// int property is a physics layer mask
    /// </summary>
    public sealed class UnityPhysicsLayerMaskAttribute : PropertyAttribute {}

    /// <summary>
    /// Property applied to LensSettings.  Used for custom drawing in the inspector.
    /// </summary>
    public sealed class LensSettingsPropertyAttribute : PropertyAttribute {}

    /// <summary>Property field is a GeneratedWaveProfile asset.</summary>
    public sealed class GeneratedWaveProfilePropertyAttribute : PropertyAttribute {}

    /// <summary>
    /// Property applied to CinemachineImpulseManager Channels.
    /// Used for custom drawing in the inspector.
    /// </summary>
    public sealed class CmImpulseChannelPropertyAttribute : PropertyAttribute { }

    /// <summary>
    /// Property applied to NavMesh Area fields.
    /// Used for custom drawing in the inspector.
    /// </summary>
    public sealed class NavMeshAreaPropertyAttribute : PropertyAttribute { }

    /// <summary>
    /// Property applied to NavMesh AgentType fields.
    /// Used for custom drawing in the inspector.
    /// </summary>
    public sealed class NavMeshAgentTypePropertyAttribute : PropertyAttribute { }
}

