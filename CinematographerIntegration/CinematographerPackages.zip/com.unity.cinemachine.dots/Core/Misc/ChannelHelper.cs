using Unity.Collections;
using Unity.Entities;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// Helper functions for doing stuff with channel entities.
    /// Instantiate as needed, don't keep.
    /// </summary>
    public struct ChannelHelper
    {
        /// <summary>The entity that holds the CmChannel component</summary>
        public readonly Entity Entity;

        /// <summary>The current World context</summary>
        public readonly World World;

        /// <summary>Constructor to wrap a channel entity</summary>
        /// <param name="e">The entity that holds the CmChannel component</param>
        /// <param name="w">The world in which the entity lives</param>
        public ChannelHelper(Entity e, World w) { Entity = e; World = w; }

        /// <summary>Constructor to wrap a channel entity</summary>
        /// <param name="channelValue">The value of the channel field.
        /// <param name="w">The world in which the entity lives</param>
        /// This constructor might cause a sync point, so use with caution</param>
        public ChannelHelper(StableKey channelId, World w)
        {
            var cs = w.SafeGetSystem<CmChannelSystem>();
            Entity = cs == null ? Entity.Null : cs.GetChannelEntity(channelId);
            World = w;
        }

        /// <summary>Convert to generic CmNode</summary>
        public CmNode Node { get => CmNode.FromEntity(Entity, World); }

        /// <summary>Is this entity actually wrapping a channel?</summary>
        public bool IsChannel { get => World.SafeHasComponent<CmChannel>(Entity); }

        /// <summary>Get the channel attached to this entity.  May cause syncpoint.</summary>
        public CmChannel ChannelData { get => World.SafeGetComponentData<CmChannel>(Entity); }

        /// <summary>Get the channel state attached to this entity. May cause syncpoint</summary>
        public CmChannelState ChannelState 
            { get => World.SafeGetComponentData<CmChannelState>(Entity); }

        /// <summary>Get the stableKey of the channel attached to this entity.  May cause syncpoint.</summary>
        public StableKey StableKey 
            { get => World.SafeGetComponentData<StableKeyData>(Entity).Value; }

        /// <summary>Convenience to get the channel system for this world.  May be null</summary>
        public CmChannelSystem ChannelSystem { get => World.SafeGetSystem<CmChannelSystem>(); }

        /// <summary>Display name for the channel</summary>
        public string Name { get => CmNode.FromEntity(Entity, World).GetName(); }

        /// <summary>Get the current active CmNode on the channel. May cause syncpoint</summary>
        public CmNode ActiveNode
        {
            get
            {
                if (!World.SafeHasComponent<CurrentNodeBlendElement>(Entity))
                    return new CmNode(Entity.Null, null);
                var b = World.EntityManager.GetBuffer<CurrentNodeBlendElement>(Entity);
                return b.Length > 0 ? CmNode.FromEntity(b[0].Blend.Node, World) : new CmNode(Entity.Null, null);
            }
        }

        /// <summary>Is there a blend in progress? May cause syncpoint</summary>
        public bool IsBlending { get =>
            World.SafeHasComponent<CurrentNodeBlendElement>(Entity)
                && World.EntityManager.GetBuffer<CurrentNodeBlendElement>(Entity).IsBlending(); }

        /// <summary>
        /// Get the current fully blended camera state (may or may not be the result of a blend).
        /// May cause syncpoint
        /// </summary>
        public CameraState State { get => ActiveBlend.CameraState; }

        /// <summary>Get the current blend in progress.  Will be empty if none. May cause syncpoint.</summary>
        public BlendState ActiveBlend 
        { 
            get
            {
                if (World.SafeHasComponent<CurrentNodeBlendElement>(Entity))
                {
                    var b = World.EntityManager.GetBuffer<CurrentNodeBlendElement>(Entity);
                    int count = b.Length;
                    if (count != 0)
                    {
                        var stack = new NativeList<Entity>(MaxRecursionDepth, Allocator.TempJob);
                        var blend0 = b[0].Blend;
                        var state = new BlendState
                        {
                            Node = blend0.Node,
                            Weight = count == 1 ? 1 : blend0.BlendWeight(),
                            OutgoingNode = count == 1 ? Entity.Null : b[1].Blend.Node,
                            CameraState = CalculateCameraState(stack)
                        };
                        stack.Dispose();
                        return state;
                    }
                }
                return new BlendState { CameraState = CameraState.Default };
            }
        }

        CameraState CalculateCameraState(NativeList<Entity> stack)
        {
            if (World.SafeHasComponent<CurrentNodeBlendElement>(Entity))
            {
                var b = World.EntityManager.GetBuffer<CurrentNodeBlendElement>(Entity);
                if (b.Length > 0 && PushOntoStack(stack))
                {
                    var ch = new ChannelHelper(b[b.Length-1].Blend.Node, World);
                    var state = ch.IsChannel ? ch.CalculateCameraState(stack) : ch.Node.GetState();
                    for (int i = b.Length-2; i >= 0; --i)
                    {
                        ch = new ChannelHelper(b[i].Blend.Node, World);
                        var s2 = ch.IsChannel ? ch.CalculateCameraState(stack) : ch.Node.GetState();
                        state = CameraState.Lerp(state, s2, b[i].Blend.BlendWeight());
                    }
                    stack.RemoveAtSwapBack(stack.Length - 1); // pop from stack
                    return state;
                }
            }
            return CameraState.Default;
        }

        const int MaxRecursionDepth = 32;

        bool PushOntoStack(NativeList<Entity> stack)
        {
            if (stack.Contains(Entity))
            {
                Debug.LogError($"CM Channel recursion detected at { Name }.  "
                    + "Do you have a CM Node that is (directly or indirectly) a child of itself?");
                return false;
            }
            if (stack.Length == stack.Capacity)
            {
                Debug.LogError($"Too much CM Channel nesting.  "
                    + $"Trying to push beyond the hard capacity of { stack.Capacity }");
                return false;
            }
            stack.Add(Entity);
            return true;
        }

        /// <summary>Get the current solo node. May cause syncpoint.</summary>
        public CmNode SoloCamera 
        {
            get
            {
                if (World.SafeHasComponent<OverrideNodeBlendElement>(Entity))
                {
                    var b = World.EntityManager.GetBuffer<OverrideNodeBlendElement>(Entity);
                    if (b.Length > 0 && b[0].Id == OverrideNodeBlendElement.SoloId)
                        return CmNode.FromEntity(b[0].NodeB, World);
                }
                return new CmNode(Entity.Null, null);
            }
            set
            {
                if (World.SafeHasComponent<OverrideNodeBlendElement>(Entity))
                {
                    var b = World.EntityManager.GetBuffer<OverrideNodeBlendElement>(Entity);
                    if (!value.IsValidNode())
                        b.ReleaseOverride(OverrideNodeBlendElement.SoloId, Entity.Null);
                    else
                        b.SetOverride(OverrideNodeBlendElement.SoloId, value.Entity, 1);
                }
            }
        }

        /// <Summary>
        /// Helper to prevent recursion: if it's an owned channel, don't assign
        /// this channel to it. May cause syncpoint.
        /// </Summary>
        public bool IsOwnedChannel(StableKey channelId)
        {
            if (!IsChannel)
                return false;
            var myId = StableKey;
            if (channelId == myId)
                return true;
            ChannelHelper ch = new ChannelHelper(channelId, World);
            if (!ch.IsChannel)
                return false;
            var parentNode = CmNode.FromEntity(ch.Entity, World);
            while (parentNode.IsValidNode())
            {
                ch = new ChannelHelper(parentNode.GetChannelAssignment(), World);
                if (ch.Entity == parentNode.Entity || ch.StableKey == myId)
                    return true;
                parentNode = CmNode.FromEntity(ch.Entity, World);
            }
            return false;
        }
    }
}
