using System;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;

namespace Unity.Cinemachine.Core
{
    /// <summary>
    /// Simple wrapper for a Cinemachine Node entity, for stronger typing in the API.
    /// Also provides some convenience methods for querying Node values.
    /// Insantiate as needed, don't keep.
    /// </summary>
    /// GML TODO: rethink this.  Is it rreally necessary?
    public struct CmNode : IEquatable<CmNode>
    {
        /// <summary>
        /// CmNode instances are equal if they refer to the same entity.
        /// CmNode instances are equal if they refer to the same entity.
        /// </summary>
        /// <param name="lhs">A CmNode object.</param>
        /// <param name="rhs">Another CmNode object.</param>
        /// <returns>True, if both Entities are identical.</returns>
        public static bool operator == (CmNode a, CmNode b) => a.Entity == b.Entity && a.World == b.World; 

        /// <summary>
        /// CmNode instances are equal if they refer to the same entity.
        /// </summary>
        /// <param name="lhs">A CmNode object.</param>
        /// <param name="rhs">Another CmNode object.</param>
        /// <returns>True, if entities are different.</returns>
        public static bool operator != (CmNode a, CmNode b) => !(a == b); 

        /// <summary>
        /// CmNode instances are equal if they refer to the same entity.
        /// </summary>
        /// <param name="compare">The object to compare to this CmNode.</param>
        /// <returns>True, if the compare parameter contains an CmNode object
        /// wrapping the same entity
        /// as this Entity.</returns>
        public override bool Equals(object compare) => this == (CmNode)compare;

        /// <summary>
        /// A hash used for comparisons.
        /// </summary>
        /// <returns>A unique hash code.</returns>
        public override int GetHashCode() => Entity.GetHashCode();

        /// <summary>Constructor to wrap a Node entity</summary>
        /// <param name="e">The entity that is the CM Node</param>
        /// <param name="w">The world in which the entity lives</param>
        public CmNode(Entity e, World w) { Entity = e; World = w; }

        /// <summary>
        /// CmNode instances are equal if they represent the same entity.
        /// </summary>
        /// <param name="o">The other CmNode.</param>
        /// <returns>True, if the CmNode instances wrap the same entity.</returns>
        public bool Equals(CmNode o) => Entity == o.Entity && World == o.World;

        /// <summary>
        /// Provides a debugging string.
        /// </summary>
        /// <returns>A string containing the entity index and generational version.</returns>
        public override string ToString() => Entity.ToString();

        /// <summary>The CM Node entity wrapped by this object</summary>
        public readonly Entity Entity;

        /// <summary>The World containing the CM Node entity wrapped by this object</summary>
        public readonly World World;

        /// <summary>Wrap a CM Node entity</summary>
        /// <param name="e">The entity corresponding to the CM node</param>
        /// <param name="w">The World in which the entity lives</param>
        /// <returns>A CmNode object wrapping entity and world</returns>
        public static CmNode FromEntity(Entity e, World w) => new CmNode(e, w);

        /// <summary>
        /// Get the value of a StableKeyData component attached to this node.
        /// This calls GetComponentData which can cause a sync point, so use with caution.
        /// </summary>
        /// <returns>The value of the StableKeyData component attached to this entity, or default</returns>
        public StableKey GetBindingKey() => World != null ? World.SafeGetComponentData<StableKeyData>(Entity).Value : StableKey.Default;

        /// <summary>Is this a null entity?</summary>
        public bool IsNull => Entity == Entity.Null; 

        /// <summary>Does this entity really wrap a CmNode?</summary>
        public bool IsValidNode() => World != null && World.SafeHasComponent<NodeChannelAssignment>(Entity);

        /// <summary>Is the node currently conrolling a Camera?</summary>
        public bool IsLive() => World != null && World.SafeGetComponentData<NodeUpdateState>(Entity).IsLive;

        /// <summary>
        /// Get the channel assignment for this node.
        /// This calls GetComponentData which can cause a sync point, so use with caution.
        /// </summary>
        /// <returns>The StableKey of the channel to which this node is assigned</returns>
        public StableKey GetChannelAssignment()
        {
            if (World != null && World.SafeHasComponent<NodeChannelAssignment>(Entity))
                return World.EntityManager.GetSharedComponentData<NodeChannelAssignment>(Entity).ChannelId;
            return StableKey.Default;
        }

        /// <summary>
        /// Walk up the chain of node parents to the top channel.
        /// This calls GetComponentData which can cause a sync point, so use with caution.
        /// </summary>
        /// <returns>The StableKey of the topmost chgannel in the chain of channel assignments endning at this node</returns>
        public StableKey FindTopLevelChannel()
        {
            var ch = new ChannelHelper(GetChannelAssignment(), World);
            var parentNode = FromEntity(ch.Entity, World);
            while (parentNode.IsValidNode())
            {
                ch = new ChannelHelper(parentNode.GetChannelAssignment(), World);
                if (ch.Entity == parentNode.Entity)
                    break;
                parentNode = FromEntity(ch.Entity, World);
            }
            return ch.StableKey;
        }

        /// <summary>Get the display name for the node, also used in custom blend asset</summary>
        public string GetName()
        {
            var e = Entity;
            var name = string.Empty;
            if (World != null && World.EntityManager.Exists(e))
            {
#if UNITY_EDITOR
                name = World.EntityManager.GetName(e);
                if (name.Length == 0 && World.EntityManager.HasComponent<Transform>(e))
                {
                    var o = World.EntityManager.GetComponentObject<Transform>(e);
                    if (o != null)
                        name = $"{o.name}";
                }
#endif
            }
            name += $" ({e.Index},{e.Version})";
            return name;
        }

        /// <summary>Set the Standby state of a node</summary>
        /// <param name="standby">True to put into standby mode, false otherwise</param>
        public void SetStandby(bool standby)
        {
            if (IsValidNode() && World.EntityManager.HasComponent<NodeUpdateState>(Entity))
            {
                var updateState = World.EntityManager.GetComponentData<NodeUpdateState>(Entity);
                if (updateState.ForceDisable != standby)
                {
                    updateState.ForceDisable = standby;
                    if (!standby && !updateState.IsLive)
                        updateState.Sequence = CmChannelSystem.NextNodeSequence;
                    World.EntityManager.SetComponentData(Entity, updateState);
                }
            }
        }

        /// <summary>Invalidate the previous frame's state.  This will bypass any camera damping,
        /// causing the camera to snap to its desired position.</summary>
        public void InvalidatePreviousFrameData()
        {
            if (IsValidNode() && World.EntityManager.HasComponent<NodeUpdateState>(Entity))
            {
                var updateState = World.EntityManager.GetComponentData<NodeUpdateState>(Entity);
                if (updateState.PreviousFrameDataIsValid)
                {
                    updateState.PreviousFrameDataIsValid = false;
                    World.EntityManager.SetComponentData(Entity, updateState);
                }
            }
        }

        /// <summary>Set this node as the dominant node among the set 
        /// of nodes with the same priority</summary>
        public void Prioritize()
        {
            if (IsValidNode() && World.EntityManager.HasComponent<NodeUpdateState>(Entity))
            {
                var updateState = World.EntityManager.GetComponentData<NodeUpdateState>(Entity);
                if (!updateState.IsLive)
                {
                    updateState.Sequence = CmChannelSystem.NextNodeSequence;
                    World.EntityManager.SetComponentData(Entity, updateState);
                }
            }
        }

        /// <summary>Set this node as the dominant node among the set 
        /// of nodes with the same priority</summary>
        public void ForceCameraPosition(float3 pos, quaternion rot)
        {
            if (IsValidNode()
                && World.EntityManager.HasComponent<NodeUpdateState>(Entity)
                && World.EntityManager.HasComponent<PositionState>(Entity))
            {
                var updateState = World.EntityManager.GetComponentData<NodeUpdateState>(Entity);
                if (!updateState.ForcePositionAndRotation)
                {
                    updateState.ForcePositionAndRotation = true;
                    updateState.PreviousFrameDataIsValid = false;
                    World.EntityManager.SetComponentData(Entity, updateState);
                }
                var posState = World.EntityManager.GetComponentData<PositionState>(Entity);
                posState.RawPosition = pos;
                posState.PositionCorrection = float3.zero;
                posState.RawRotation = rot;
                posState.RotationCorrection = quaternion.identity;
                World.EntityManager.SetComponentData(Entity, posState);
            }
        }

        /// <summary>Current state of the node or channel, may be the result of blends</summary>
        public CameraState GetState()
        {
            var state = CameraState.Default;
            var e = Entity;
            if (World != null && e != Entity.Null)
            {
                // Is this entity a channel?
                var ch = new ChannelHelper(Entity, World);
                if (ch.IsChannel)
                    return ch.State;

                // Fetch the state from the relevant components
                var updateState = World.SafeGetComponentData<NodeUpdateState>(e);
                state.ShotQuality = updateState.ShotQuality;

                NodeBlendHint.BlendHintValue suppress = 0;
                if (!World.EntityManager.HasComponent<PositionState>(e))
                    suppress |= NodeBlendHint.BlendHintValue.NoPosition
                        | NodeBlendHint.BlendHintValue.NoOrientation | NodeBlendHint.BlendHintValue.NoLens;
                else
                {
                    var c = World.EntityManager.GetComponentData<PositionState>(e);
                    state.RawPosition = c.RawPosition;
                    state.ReferenceUp = c.Up;
                    state.PositionCorrection = c.PositionCorrection;
                    state.RawOrientation = math.normalizesafe(c.RawRotation, quaternion.identity);
                    state.OrientationCorrection = math.normalizesafe(c.RotationCorrection, quaternion.identity);
                    state.Lens = new LensSettings
                    {
                        FieldOfView = c.Lens.FOV,
                        OrthographicSize = c.Lens.FOV,
                        NearClipPlane = c.Lens.NearClip,
                        FarClipPlane = c.Lens.FarClip,
                        Dutch = c.Lens.Dutch,
                        LensShift = c.Lens.LensShift,
                        Orthographic = updateState.Orthographic,
                        SensorSize = new float2(updateState.Aspect < MathHelpers.Epsilon ? 1 : updateState.Aspect, 1f) // GML todo: physical camera
                    };
                }
                if (World.EntityManager.HasComponent<LookAtTargetState>(e))
                {
                    var c = World.EntityManager.GetComponentData<LookAtTargetState>(e);
                    state.ReferenceLookAt = c.Value.Position;
                    state.ReferenceLookAtRadius = c.Value.Radius;
                }
                if (World.EntityManager.HasComponent<NodeBlendHint>(e))
                {
                    var c = World.EntityManager.GetComponentData<NodeBlendHint>(e);
                    state.BlendHint = c.Hint;
                }
                state.BlendHint |= suppress;
            }
            return state;
        }
    }
}
