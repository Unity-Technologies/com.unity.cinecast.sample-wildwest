using System.Runtime.CompilerServices;
using Unity.Entities;
using Unity.Mathematics;

namespace Unity.Cinemachine.Core
{
    public static class ClientHooks
    {
        /// <summary>Delegate for overriding Unity's default input system.  Returns the value
        /// of the named axis.</summary>
        public delegate float AxisInputDelegate(string axisName);

        /// <summary>Delegate for overriding Unity's default input system.
        /// If you set this, then your delegate will be called instead of
        /// System.Input.GetAxis(axisName) whenever in-game user input is needed.</summary>
        public static AxisInputDelegate GetInputAxis = DefaultGetInputAxis;

        /// <summary>Calls UnityEngine.Input.GetAxis(axisName).</summary>
        public static float DefaultGetInputAxis(string axisName)
        {
#if !UNITY_DOTSRUNTIME // Input does not exist in tiny.  GML todo: Solve this problem
            return UnityEngine.Input.GetAxis(axisName);
#else
            return 0;
#endif
        }

        /// <summary>Hook for custom blend - called whenever a blend is created,
        /// allowing client to override the blend definition</summary>
        public delegate TransitionDefinition CreateBlendDelegate(
            World w, Entity context, CmNode fromCam, CmNode toCam,
            TransitionDefinition defaultBlend);

        /// <summary>Hook for custom blend - called whenever a blend is created,
        /// allowing client to override the blend definition</summary>
        public static CreateBlendDelegate OnCreateBlend;

        /// <summary>
        /// Cinemachine authoring behaviours will call this when they need to access
        /// the Entity World.  If not set, World.DefaultGameObjectInjectionWorld will be used.
        /// Clients should set this if they want Cinemachine to use a different world, 
        /// but remember to clean it up after the world is destroyed!
        /// </summary>
        public static World DefaultWorld 
        { 
            set { DefaultWorldOverride = value; }
            get { return DefaultWorldOverride ?? World.DefaultGameObjectInjectionWorld; }
        }
        static World DefaultWorldOverride = null;

        /// <summary>
        /// Client can override Cinemachine's view of current time, for all worlds.
        /// All of Cinemachines systems will get the current time and deltaTime via this class, and
        /// if a time override is enabled, the overridden time will be returned.  
        /// Disable time override by setting CurrentTimeOvewrride to a negative value.
        /// </summary>
        public static double CurrentTimeOverride { get => s_CurrentTimeOverride; set => s_CurrentTimeOverride = value; }

        public static double s_CurrentTimeOverride = -1;
        static double s_LastOverrideTime;
        static double s_DeltaTimeOverride;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static void UpdateTimeOverride()
        {
            var now = s_CurrentTimeOverride;
            if (now != s_LastOverrideTime)
            {
                var delta = now - s_LastOverrideTime;
                s_DeltaTimeOverride = math.select(delta, 0, delta < 0 || delta > 0.5);
                s_LastOverrideTime = now;
            }
        }

        /// <summary>
        /// Cinemachine gets the current time from here, allowing the overridden time
        /// to be returned in the event that a time override is enabled.
        /// </summary>
        public static double GetCurrentTime(World world)
        {
            if (s_CurrentTimeOverride < 0)
                return world.Time.ElapsedTime;
            UpdateTimeOverride();
            return s_CurrentTimeOverride;
        }

        /// <summary>
        /// Cinemachine gets the current DeltaTime from here, allowing the overridden time
        /// to be returned in the event that a time override is enabled.
        /// </summary>
        public static float GetDeltaTime(World world)
        {
            if (s_CurrentTimeOverride < 0)
                return world.Time.DeltaTime;
            UpdateTimeOverride();
            return (float)s_DeltaTimeOverride;
        }
    }
}
