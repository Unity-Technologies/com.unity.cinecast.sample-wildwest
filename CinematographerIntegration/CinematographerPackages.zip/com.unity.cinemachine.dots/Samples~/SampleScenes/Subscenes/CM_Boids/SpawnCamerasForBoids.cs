﻿using System;
using Unity.Entities;
using UnityEngine;
using System.Collections.Generic;
using Unity.Collections;
using Samples.Boids;
using Unity.Cinemachine.Core;
using Unity.Transforms;
using Unity.Entities.Hybrid;
using Unity.Cinemachine.Hybrid;

namespace Cinemachine3.Samples
{
    namespace Authoring
    {
        public class SpawnCamerasForBoids
            : MonoBehaviour, IDeclareReferencedPrefabs, IConvertGameObjectToEntity
        {
            public GameObject Prefab;
            public StableReference<CmChannelBindingKey> ChannelOwner = new StableReference<CmChannelBindingKey>();

            // Lets you convert the editor data representation to the entity optimal
            // runtime representation
            public void Convert(
                Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
            {
                if (enabled)
                {
                    var spawnerData = new SpawnCamerasForBoidsData
                    {
                        // The referenced prefab will be converted due to DeclareReferencedPrefabs.
                        // So here we simply map the game object to an entity reference to that prefab.
                        prefab = conversionSystem.GetPrimaryEntity(Prefab),
                        channelId = ChannelOwner.Referent
                    };
                    dstManager.AddSharedComponentData(entity, spawnerData);
                }
            }

            // Referenced prefabs have to be declared so that the conversion system
            // knows about them ahead of time
            public void DeclareReferencedPrefabs(List<GameObject> referencedPrefabs)
            {
                referencedPrefabs.Add(Prefab);
            }

            void Update() {} // For the little checkbox
        }
    }

    [Serializable]
    public struct SpawnCamerasForBoidsData : ISharedComponentData
    {
        public Entity prefab;
        public StableKey channelId;
    }

    [UpdateAfter(typeof(CmTargetSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public class SpawnCamerasForBoidsSystem : ComponentSystem
    {
        protected override void OnUpdate()
        {
            // For each spawner, instantiate a node for all targets
            EntityQuery targetGroup = GetEntityQuery(
                ComponentType.ReadOnly<Boid>(),
                ComponentType.ReadOnly<StableKeyData>(),
                ComponentType.ReadOnly<StableKeyValidState>(),
                ComponentType.Exclude<CmTarget>());

            var targetEntityArray = targetGroup.ToEntityArray(Allocator.TempJob);
            var targets = new NativeArray<Entity>(targetEntityArray.Length, Allocator.TempJob);
            targets.CopyFrom(targetEntityArray);
            targetEntityArray.Dispose();

            Entities.ForEach((Entity e, SpawnCamerasForBoidsData spawner) =>
            {
                // Calling Instantiate once per spawned Entity is rather slow, and not recommended
                // This code is placeholder until we add the ability to bulk-instantiate many 
                // nodes from an ECB
                for (int i = 0; i < targets.Length; ++i)
                {
                    PostUpdateCommands.AddComponent(targets[i], new CmTarget { Radius = 1 });

                    var node = PostUpdateCommands.Instantiate(spawner.prefab);
                    StableKey bindingKey = EntityManager.GetComponentData<StableKeyData>(targets[i]).Value;
                    PostUpdateCommands.AddComponent(node, new FollowTarget { Target = bindingKey });
                    PostUpdateCommands.AddComponent(node, new LookAtTarget { Target = bindingKey });
                    PostUpdateCommands.SetSharedComponent(
                        node, new NodeChannelAssignment { ChannelId = spawner.channelId });

                    // GML why do we have to do this?  Seems to be needed for scale
                    PostUpdateCommands.RemoveComponent<Translation>(node);
                    PostUpdateCommands.RemoveComponent<Rotation>(node);
                    PostUpdateCommands.RemoveComponent<Transform>(node);
                }
                //PostUpdateCommands.RemoveComponent<SpawnCamerasForBoidsData>(e);
            });

            targets.Dispose();
        }
    }
}
