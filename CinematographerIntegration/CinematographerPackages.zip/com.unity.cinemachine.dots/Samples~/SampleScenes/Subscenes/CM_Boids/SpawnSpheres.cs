﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnSpheres : MonoBehaviour
{
    public float minSize = 0.5f;
    public float maxSize = 3;
    public float spawnRadius = 50;
    public int numSpheres = 500;

    public bool spawnNow = true;

    private void Update()
    {
        if (spawnNow)
            Spawn();
        spawnNow = false;
    }

    void Spawn()
    {
        Vector3 origin = transform.position;
        for (int i = 0; i < numSpheres; ++i)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            var t = go.transform;
            float scale = Random.Range(minSize, maxSize);
            Vector3 pos = new Vector3(
                Random.Range(-spawnRadius, spawnRadius),
                Random.Range(-spawnRadius, spawnRadius),
                Random.Range(-spawnRadius, spawnRadius));
            t.localScale = Vector3.one * scale;
            t.position = origin + pos;
            t.SetParent(transform);
        }
    }
}
