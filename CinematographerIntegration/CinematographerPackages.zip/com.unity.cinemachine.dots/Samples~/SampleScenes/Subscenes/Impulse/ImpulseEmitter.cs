﻿using UnityEngine;
using Unity.Collections;
using Unity.Mathematics;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;
using Unity.Entities;

namespace Unity.Cinemachine.Samples
{
    public class ImpulseEmitter : MonoBehaviour
    {
        public float EmitInterval;

        [Header("Raw Signal")]
        [Tooltip("The asset containing the Noise Profile.  Define the frequencies and amplitudes "
            + "there to make a characteristic noise profile.  "
            + "Make your own or just use one of the many presets.")]
        [GeneratedWaveProfileProperty]
        public GeneratedWaveProfile RawSignalAsset;

        [HideFoldout]
        public CmImpulseDefinition ImpulseDefinition;

        float m_LastImpulseTime = 0;

        private void Reset()
        {
            ImpulseDefinition = CmImpulseDefinitionExtensions.Default;
            EmitInterval = 1;
        }

        private void OnValidate()
        {
            ImpulseDefinition.Validate();
        }

        private void Start()
        {
            m_LastImpulseTime = Time.realtimeSinceStartup;
        }

        private void Update()
        {
            if (RawSignalAsset == null)
                return;

            // Emit the signal
            var now = Time.realtimeSinceStartup;
            if (now - m_LastImpulseTime > EmitInterval)
            {
                var pos = GeneratedWaveProfile.ToNoiseArray(Allocator.Temp, RawSignalAsset.PositionNoise);
                var rot = GeneratedWaveProfile.ToNoiseArray(Allocator.Temp, RawSignalAsset.OrientationNoise);
                CmImpulse.EmitImpulse(
                    ClientHooks.DefaultWorld,
                    ImpulseDefinition, pos, rot, 
                    transform.position, 1, quaternion.identity);
                pos.Dispose();
                rot.Dispose();

                m_LastImpulseTime = now;
            }
            // Flash the mesh to make a visual indication that something happened
            var renderer = GetComponent<MeshRenderer>();
            if (renderer != null)
                renderer.enabled = now - m_LastImpulseTime < 0.1f;
        }
    }
}
