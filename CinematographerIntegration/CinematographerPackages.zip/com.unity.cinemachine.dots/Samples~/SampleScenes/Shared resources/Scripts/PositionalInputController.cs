using System;
using Unity.Cinemachine.Core;
using Unity.Entities;
using Unity.Entities.Hybrid;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;

namespace Unity.Cinemachine.Samples
{
    /// <summary>
    /// Input controller for controller the Value (Translation) of an object.
    /// </summary>
    public class PositionalInputController : ComponentAuthoringBase<PositionalInput>
    {
        /// <summary>
        /// Controls movement on the X axis
        /// </summary>
        [Tooltip("Controls movement on the X axis")]
        public InputAxisWithName HorizontalAxis;

        /// <summary>
        /// Controls movement on the Z axis
        /// </summary>
        [Tooltip("Controls movement on the Z axis")]
        public InputAxisWithName VerticalAxis;

        protected override void OnValidate()
        {
            HorizontalAxis.Axis.Validate();
            VerticalAxis.Axis.Validate();
            base.OnValidate();
        }
        
        protected override void Reset()
        {
            m_Value = new PositionalInput
            {
                MaxSpeed = 10,
                AccelTime = 1,
                Direction = PositionalInput.DirectionMode.Camera,
                RotatePlayer = true
            };

            HorizontalAxis = new InputAxisWithName
            {
                InputName = "Horizontal",
                Axis = new InputAxis
                {
                    InputControl = new InputAxisControl
                    {
                        Multiplier = 1,
                        AccelTime = 0.2f,
                        DecelTime = 0.2f
                    },
                    Value = new InputAxisValue { Range = new float2(-1, 1) },
                    Recentering = new InputAxisRecentering { Enabled = true, Wait = 0, Time = 0.2f }
                }
            };

            VerticalAxis = new InputAxisWithName
            {
                InputName = "Vertical",
                Axis = new InputAxis
                {
                    InputControl = new InputAxisControl
                    {
                        Multiplier = 1,
                        AccelTime = 0.2f,
                        DecelTime = 0.2f
                    },
                    Value = new InputAxisValue { Range = new float2(-1, 1) },
                    Recentering = new InputAxisRecentering { Enabled = true, Wait = 0, Time = 0.2f }
                }
            };
            base.Reset();
        }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            base.PushToEntity(entity, context);
            var index = InputAxisXYZ.AddInputToEntity(context.EntityManager, entity, new InputAxisXYZ
            {
                X = InputAxis.WithInputName(HorizontalAxis.Axis, HorizontalAxis.InputName),
                Y = InputAxis.WithInputName(VerticalAxis.Axis, VerticalAxis.InputName),
                DecoupledRecentering = true
            });
            context.EntityManager.AddComponentData(
                entity, new PositionalInputState { InputAxisIndex = index });
        }
    }

    [Serializable]
    public struct PositionalInput : IComponentData
    {
        [Tooltip("Maximum speed")]
        public float MaxSpeed;
            
        [Tooltip("Acceleration")]
        public float AccelTime;
            
        public enum DirectionMode { World, Target, Camera }

        [Tooltip("Direction modes defines the forward vector. In World mode, the forward is along the world Z " +
            "axis. In Target mode, the forward is the follow target's forward. In Camera mode, the forward " +
            "is the main camera's forward.")]
        public DirectionMode Direction;

        [Tooltip("If set, player will rotate to face direction of movement")]
        public bool RotatePlayer;
    }

    [Serializable]
    public struct PositionalInputState : IComponentData
    {
        public float3 CurrentVelocity;
        public int InputAxisIndex;
    }

    [UpdateAfter(typeof(RotationalInputSystem))]
    [UpdateBefore(typeof(TransformSystemGroup))]
    public partial class PositionalInputSystem : SystemBase
    {
        Camera m_MainCamera;

        protected override void OnUpdate()
        {
            if (m_MainCamera == null)
                m_MainCamera = Camera.main;
            quaternion cameraRot = m_MainCamera != null ? m_MainCamera.transform.rotation : Quaternion.identity;
            var deltaTime = Time.DeltaTime;

            Entities
                .WithName("PositionalInputJob")
                .ForEach((
                    DynamicBuffer<InputAxisXYZ> inputBuffer,
                    ref Translation translation, 
                    ref PositionalInput positionalInput, 
                    ref PositionalInputState positionalState,
                    ref Rotation rotation) =>
                {
                    float3 fwd = math.forward();
                    switch (positionalInput.Direction)
                    {
                        default:
                        case PositionalInput.DirectionMode.World:
                            break;
                        case PositionalInput.DirectionMode.Target:
                            fwd = math.forward(rotation.Value);
                            break;
                        case PositionalInput.DirectionMode.Camera:
                            fwd = math.forward(cameraRot);
                            break;
                    }

                    fwd.y = 0;
                    fwd = math.normalizesafe(fwd, math.forward());
                    quaternion inputFrame = quaternion.LookRotation(fwd, math.up());

                    var inputXYZ = inputBuffer[positionalState.InputAxisIndex];
                    var input = new float3(inputXYZ.X.Value.Value, 0, inputXYZ.Y.Value.Value);
                    input = math.mul(inputFrame, input);

                    var desiredVelocity = input * positionalInput.MaxSpeed;
                    var deltaVel = desiredVelocity - positionalState.CurrentVelocity;
                    positionalState.CurrentVelocity += MathHelpers.Damp(deltaVel, positionalInput.AccelTime, deltaTime);

                    translation.Value += positionalState.CurrentVelocity * deltaTime;

                    if (positionalInput.RotatePlayer && math.length(positionalState.CurrentVelocity) > 0.001f)
                        rotation.Value = quaternion.LookRotation(math.normalizesafe(positionalState.CurrentVelocity), math.up());

                }).ScheduleParallel();
        }
    }
}
