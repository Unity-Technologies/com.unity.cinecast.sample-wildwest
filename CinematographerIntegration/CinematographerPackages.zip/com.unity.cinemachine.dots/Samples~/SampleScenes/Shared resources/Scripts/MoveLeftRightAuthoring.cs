﻿﻿using Unity.Entities;
using UnityEngine;

namespace Unity.Cinemachine.Samples
{
    public class MoveLeftRightAuthoring : MonoBehaviour, IConvertGameObjectToEntity
    {
        public float Distance;
        public Vector3 Velocity;
    
        public void Convert(
            Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
        {
    #if UNITY_EDITOR
            dstManager.SetName(entity, transform.name);
    #endif
            dstManager.AddComponentData(entity, new MoveLeftRight
            {
                Velocity = Velocity,
                StartingPosition = gameObject.transform.position,
                Distance = Distance,
            });
        }
    }
}