﻿using System.Collections.Generic;
using UnityEngine;
using System;
using Unity.Entities.Hybrid;
using Unity.Cinemachine.Hybrid;

#if UNITY_EDITOR
using UnityEditor;
using UnityEditorInternal;
#endif

namespace Unity.Cinemachine.Samples
{
    public partial class CmNodePrioritizerGUI : MonoBehaviour
    {
        public Vector2 Position = new Vector3(30, 10);
        public float Width = 100;
        public int Priority = 100;

        [Serializable]
        public class Item
        {
            public StableReference<CmNodeBindingKey> Node = new StableReference<CmNodeBindingKey>();
        }
        [HideInInspector]
        public List<Item> Nodes;

        public void OnGUI()
        {
            var numNodes = Nodes?.Count;
            if (numNodes == 0)
                return;
            var style = GUI.skin.button;
            var pos = Position;
            var size = style.CalcSize(new GUIContent("Button")); size.x = Width;
            const float vSpace = 3.0f;
            var baseColor = GUI.color;
            var liveColor = CmChannelAuthoring.GetSoloGUIColor();
            for (int i = 0; i < numNodes; ++i)
            {
                var go = StableIDGameObjectManager.Resolve(Nodes[i].Node.Referent);
                var n = go == null ? null : go.GetComponent<CmNodeAuthoringBase>();
                if (n != null)
                {
                    GUI.color = n.IsLive ? liveColor : baseColor;
                    if (GUI.Button(new Rect(pos, size), go.name))
                    {
                        n.Priority = Priority;
                        n.Prioritize();
                    }
                    pos.y += size.y + vSpace;
                }
            }
            GUI.color = baseColor;
        }
    }


#if UNITY_EDITOR
    [CustomEditor(typeof(CmNodePrioritizerGUI))]
    class CmNodePrioritizerGUIEditor : UnityEditor.Editor
    {
        private ReorderableList m_Nodes;

        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();
            if (m_Nodes == null)
                SetupNodeList();
            m_Nodes.DoLayoutList();
            serializedObject.ApplyModifiedProperties();
        }

        void SetupNodeList()
        {
            var propertyName = "Nodes";
            m_Nodes = new ReorderableList(serializedObject,
                serializedObject.FindProperty(propertyName), true, true, true, true);

            m_Nodes.drawHeaderCallback = (Rect r) =>
            {
                EditorGUI.LabelField(r, propertyName);
            };

            m_Nodes.elementHeightCallback = (int index) =>
            {
                SerializedProperty element = m_Nodes.serializedProperty.GetArrayElementAtIndex(index);
                var h = EditorGUI.GetPropertyHeight(element.FindPropertyRelative("Node"));
                return h + EditorGUIUtility.standardVerticalSpacing;
            };

            m_Nodes.drawElementCallback = (Rect rect, int index, bool isActive, bool isFocused) =>
            {
                var oldLabelWidth = EditorGUIUtility.labelWidth;
                EditorGUIUtility.labelWidth = 1;
                SerializedProperty element = m_Nodes.serializedProperty.GetArrayElementAtIndex(index);
                var p = element.FindPropertyRelative("Node");
                EditorGUI.PropertyField(rect, p, GUIContent.none);
                EditorGUIUtility.labelWidth = oldLabelWidth;
            };
        }
    }
#endif
}
