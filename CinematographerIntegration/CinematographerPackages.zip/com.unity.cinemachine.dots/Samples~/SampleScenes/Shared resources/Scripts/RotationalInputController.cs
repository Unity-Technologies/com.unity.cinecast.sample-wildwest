using System;
using Unity.Cinemachine.Core;
using Unity.Entities;
using Unity.Entities.Hybrid;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;

namespace Unity.Cinemachine.Samples
{
    /// <summary>
    /// Input controller for controller the Rotation of an object.
    /// </summary>
    public class RotationalInputController : EntityBehaviourAuthoringBase
    {
        /// <summary>
        /// Controls rotation around the local Y axis.
        /// </summary>
        [Tooltip("Controls rotation around the local Y axis.")]
        public InputAxisWithName HorizontalAxis;

        /// <summary>
        /// Controls rotation around the local X axis.
        /// </summary>
        [Tooltip("Controls rotation around the local X axis.")]
        public InputAxisWithName VerticalAxis;

        protected override void OnValidate()
        {
            HorizontalAxis.Axis.Validate();
            VerticalAxis.Axis.Validate();
            base.OnValidate();
        }

        protected override void Reset()
        {
            HorizontalAxis = new InputAxisWithName
            {
                InputName = "Mouse X",
                Axis = new InputAxis
                {
                    InputControl = new InputAxisControl
                    {
                        Multiplier = 2f,
                        AccelTime = 0.2f,
                        DecelTime = 0.1f
                    },
                    Value = new InputAxisValue { Range = new float2(-180, 180), Wrap = true },
                    Recentering = new InputAxisRecentering { Wait = 1, Time = 2 }
                }
            };

            VerticalAxis = new InputAxisWithName
            {
                InputName = "Mouse Y",
                Axis = new InputAxis
                {
                    InputControl = new InputAxisControl
                    {
                        Multiplier = 2f,
                        AccelTime = 0.2f,
                        DecelTime = 0.21f
                    },
                    Value = new InputAxisValue { Range = new float2(-100, 100) },
                    Recentering = new InputAxisRecentering { Wait = 1, Time = 2 }
                }
            };
            base.Reset();
        }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            var index = InputAxisXYZ.AddInputToEntity(context.EntityManager, entity, new InputAxisXYZ
            {
                X = InputAxis.WithInputName(HorizontalAxis.Axis, HorizontalAxis.InputName),
                Y = InputAxis.WithInputName(VerticalAxis.Axis, VerticalAxis.InputName),
                DecoupledRecentering = true
            });
            context.EntityManager.AddComponentData(
                entity, new RotationalInputSystem.RotationalInput { InputAxisIndex = index });
        }

        protected override void PullFromEntity(Entity entity, ConversionContext context) {}
    }

    [UpdateBefore(typeof(PositionalInputSystem))]
    [UpdateBefore(typeof(TransformSystemGroup))]
    public partial class RotationalInputSystem : SystemBase
    {
        public struct RotationalInput : IComponentData 
        {
            public int InputAxisIndex;
        }

        protected override void OnUpdate()
        {
            Entities
                .WithName("RotationalInputJob")
                .ForEach((
                    DynamicBuffer<InputAxisXYZ> inputBuffer,
                    ref Rotation rotation,
                    in RotationalInput rotationalInput) =>
                {
                    var inputXYZ = inputBuffer[rotationalInput.InputAxisIndex];
                    quaternion a = quaternion.RotateY(math.radians(inputXYZ.X.Value.Value));
                    quaternion b = quaternion.RotateX(-math.radians(inputXYZ.Y.Value.Value));
                    rotation.Value = math.mul(a, b);
                }).ScheduleParallel();
        }
    }
}
