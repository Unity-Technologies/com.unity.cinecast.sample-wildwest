using System;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.UI;

namespace Unity.Cinemachine.Samples
{
    public class HitMarkerGrabber : MonoBehaviour
    {
        RectTransform m_Transform;
        MaskableGraphic m_Image;

        void Start()
        {
            m_Transform = GetComponent<RectTransform>();
            m_Image = GetComponent<MaskableGraphic>();
            var listener = Camera.main.GetComponent<CmListener>();
            if (listener != null)
                listener.Events.CameraUpdated.AddListener(OnCameraUpdated);
        }

        void OnCameraUpdated(CmListener listener)
        {
            if (HitMarkerGetFromEntities.HitPointFound)
                m_Transform.position = Camera.main.WorldToScreenPoint(HitMarkerGetFromEntities.HitPointPosition);
            if (m_Image != null)
                m_Image.enabled = HitMarkerGetFromEntities.HitPointFound;
        }
    }

    [UpdateAfter(typeof(CameraFinalizeSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    partial class HitMarkerGetFromEntities : SystemBase
    {
        public static Vector3 HitPointPosition;
        public static bool HitPointFound;

        protected override void OnUpdate()
        {
            HitPointFound = false;
            Entities.WithoutBurst().ForEach((
                ref PlayerHitPosition hitPos,
                in NodeUpdateState updateState) =>
            {
                if (updateState.IsLive)
                {
                    HitPointPosition = hitPos.Value;
                    HitPointFound = true;
                }
            }).Run();
        }
    }
}
