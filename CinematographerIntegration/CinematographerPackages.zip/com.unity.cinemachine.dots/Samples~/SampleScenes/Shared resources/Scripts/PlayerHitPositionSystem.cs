using Unity.Entities;
using Unity.Mathematics;
using System;
using Unity.Cinemachine.Core;
#if CINEMACHINE_UNITY_PHYSICS
using Unity.Physics;
using Unity.Physics.Systems;
#endif

namespace Unity.Cinemachine.Samples
{
    [Serializable]
    public struct PlayerHitPosition : IComponentData
    {
        public float3 Value;
    }

    [UpdateAfter(typeof(CameraFinalizeSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class PlayerHitPositionSystem : SystemBase
    {
#if CINEMACHINE_UNITY_PHYSICS
        BuildPhysicsWorld m_PhysicsWorldSystem;
#endif
        
        protected override void OnCreate()
        {
#if CINEMACHINE_UNITY_PHYSICS
            m_PhysicsWorldSystem = World.GetOrCreateSystem<BuildPhysicsWorld>();
#endif
        }

        protected override void OnUpdate()
        {
#if CINEMACHINE_UNITY_PHYSICS
            var collisionWorld = m_PhysicsWorldSystem.PhysicsWorld.CollisionWorld;
#endif
            Entities
#if CINEMACHINE_UNITY_PHYSICS
                .WithReadOnly(collisionWorld)
#endif
                .ForEach((
                    ref PlayerHitPosition playerHitPosition,
                    in FollowTargetState followTarget,
                    in LookAtTargetState lookAtTarget,
                    in ThirdPersonAim thirdPersonAim) =>
                {
                    if (lookAtTarget.Value.Entity == Entity.Null)
                        return;

                    var lookAtTargetPosition = lookAtTarget.Value.Position;
#if CINEMACHINE_UNITY_PHYSICS
                    var filter = ThirdPersonAimSystem.StandardFilter(thirdPersonAim.TargetLayers);
                    if (!filter.IsEmpty)
                    {
                        var raycastInput = new RaycastInput
                        {
                            Start = followTarget.Value.Position,
                            End = lookAtTargetPosition,
                            Filter = filter,
                        };
                        if (collisionWorld.CastRay(raycastInput, out var hit))
                            lookAtTargetPosition = math.lerp(raycastInput.Start, raycastInput.End, hit.Fraction);
                    }
#endif
                    playerHitPosition.Value = lookAtTargetPosition;
                })
                .Run();
        }
    }
}
