﻿using UnityEngine;
using Unity.Cinemachine.Hybrid;

namespace Unity.Cinemachine.Samples
{
    public class CmMixerGUI : MonoBehaviour
    {
        public Vector2 Position = new Vector3(30, 30);
        public float Width = 200;

        CmMixerAuthoring m_mixer;

        private void Start()
        {
            m_mixer = GetComponent<CmMixerAuthoring>();
        }

        public void OnGUI()
        {
            var nodes = m_mixer == null ? null : m_mixer.InputNodes;
            var numNodes = nodes?.Count;
            if (numNodes == 0)
                return;

            var style = GUI.skin.button;
            var pos = Position;
            var size = style.CalcSize(new GUIContent("Button")); size.x = Width;
            const float vSpace = 3.0f;
            bool changed = false;
            for (int i = 0; i < numNodes; ++i)
            {
                var node = nodes[i];
                var w = GUI.HorizontalSlider(new Rect(pos, size), node.Weight, 0, 1);
                if (w != node.Weight)
                {
                    node.Weight = w;
                    nodes[i] = node;
                    changed = true;
                }
                pos.y += size.y + vSpace;
            }
            if (changed)
                m_mixer.InputNodes = nodes;
        }
    }
}
