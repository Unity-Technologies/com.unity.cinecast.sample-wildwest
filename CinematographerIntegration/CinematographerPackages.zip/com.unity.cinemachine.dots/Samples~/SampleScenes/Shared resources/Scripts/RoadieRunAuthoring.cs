using System;
using Unity.Cinemachine.Core;
using Unity.Cinemachine.Hybrid;
using Unity.Entities;
using Unity.Entities.Hybrid;
using Unity.Mathematics;
using UnityEngine;

namespace Unity.Cinemachine.Samples
{
    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [DisallowMultipleComponent]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Extensions/Roadie Run")]
    public class RoadieRunAuthoring : ComponentAuthoringBase<RoadieRunData>
    {
        protected override void Reset()
        {
            m_Value = new RoadieRunData
            {
                MaxAmplitude = 1,
                Transition = new TransitionDefinition { Curve = TransitionCurve.Default, Length = 5 }
            };
            base.Reset();
        }
    }


    [Serializable]
    public struct RoadieRunData : IComponentData
    {
        [Tooltip("The Noise channel that contains the roadie run noise.  This is the index "
            + "into the Precedural Noise signal list.  The amplitude of this signal will be "
            + "controlled by the RoadieRunData extension."
            + "A Procedural Noise component is required for this extension")]
        public int NoiseSignalIndex;

        [Tooltip("How much of the signal is present at zero speed.  Normally this will be 0.")]
        public float RestAmplitude;

        [Tooltip("How much of the signal is present at the maximum speed")]
        public float MaxAmplitude;

        [Tooltip("How to transition from rest to maximum speed.  The \"Druration\" field in "
            + "the transition defines the max speed, e.g. if it's set to 10, "
            + "then the max speed is 10 m/s")]
        [TransitionDefinitionUnitsLabel("m/s", "The speed at which the noise is fully applied.  "
            + "e.g. if it's set to 10, then at 10 m/s the full noise, offset, and boost is applied")]
        public TransitionDefinition Transition;

        [Tooltip("How much to boost the FOV at maximum speed.  A value of 0 is no boost, a value of 1 will double the FOV")]
        public float BoostFOV;

        [Tooltip("How to shift the camera position at maximum speed.  The value is in camera coords.")]
        public float3 CameraOffset;
    }

    [Serializable]
    public struct RoadieRunState : IComponentData
    {
        public float Speed;
        public float DampVelocity;
    }

    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [UpdateAfter(typeof(CameraPostBodySystem))]
    [UpdateBefore(typeof(CameraPreAimSystem))]
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    public partial class RoadieRunSystem : SystemBase
    {
        EntityQuery m_missingStateQuery;

        protected override void OnCreate()
        {
            base.OnCreate();
            m_missingStateQuery = GetEntityQuery(
                ComponentType.ReadWrite<RoadieRunData>(),
                ComponentType.Exclude<RoadieRunState>());
        }

        protected override void OnUpdate()
        {
            EntityManager.AddComponent(m_missingStateQuery,
                ComponentType.ReadWrite<RoadieRunState>());

            Entities
                .WithName("RoadieRunJob")
                .ForEach((
                    DynamicBuffer<ProceduralNoiseChannelElement> channels,
                    ref PositionState posState,
                    ref RoadieRunState state,
                    in RoadieRunData roadieRun,
                    in NodeUpdateState updateState) =>
                {
                    var newSpeed = math.select(
                        0, math.length(posState.RawPosition.xz - posState.PreviousPosition.xz) / updateState.DeltaTime, 
                        updateState.PreviousFrameDataIsValid && updateState.DeltaTime > 0.01f);
                    var prevSpeed = math.select(0, state.Speed, updateState.PreviousFrameDataIsValid);
                    var vel = math.select(0, state.DampVelocity, updateState.PreviousFrameDataIsValid);
                    var speed = MathHelpers.SmoothDamp(prevSpeed, newSpeed, ref vel, 0.2f, updateState.DeltaTime);

                    state.Speed = speed;
                    state.DampVelocity = vel;

                    var t = roadieRun.Transition.Curve.Evaluate(speed / math.max(0.01f, roadieRun.Transition.Length));
                    if (roadieRun.NoiseSignalIndex >= 0 && roadieRun.NoiseSignalIndex < channels.Length)
                    {
                        var c = channels[roadieRun.NoiseSignalIndex];
                        c.AmplitudeGain = math.lerp(roadieRun.RestAmplitude, roadieRun.MaxAmplitude, t);
                        channels[roadieRun.NoiseSignalIndex] = c;
                    }
                    posState.Lens.FOV *= 1 + t * roadieRun.BoostFOV;
                    posState.PositionCorrection += t * math.mul(posState.RawRotation, roadieRun.CameraOffset);
                })
                .ScheduleParallel();
        }
    }
}
