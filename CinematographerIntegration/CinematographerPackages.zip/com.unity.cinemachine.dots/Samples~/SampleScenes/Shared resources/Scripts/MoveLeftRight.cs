﻿using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;

namespace Unity.Cinemachine.Samples
{
    public struct MoveLeftRight : IComponentData
    {
        public float3 Velocity;
        public float Distance;
        public float3 StartingPosition;
    }

    [UpdateInGroup(typeof(SimulationSystemGroup))]
    public partial class MoveLeftRightSystem : SystemBase
    {
        protected override void OnUpdate()
        {
            var deltaTime = Time.DeltaTime;
            Entities
                .WithName("MoveLeftRightJob")
                .ForEach((
                    ref MoveLeftRight move, 
                    ref Translation translation, 
                    in LocalToWorld localToWorld) =>
                {
                    var delta = localToWorld.Position - move.StartingPosition;
                    if (math.lengthsq(delta) > move.Distance * move.Distance
                        && math.dot(delta, move.Velocity) > 0)
                    {
                        move.Velocity = -move.Velocity;
                    }
                    translation.Value += move.Velocity * deltaTime;
                })
                .ScheduleParallel();
        }
    }
}
