using UnityEngine;
using Unity.Cinemachine.Hybrid;
using Unity.Entities;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Samples
{
    /// <summary>
    /// Custom Cinemachine Extension that calculates the world position of the first intersection
    /// point from the follow target to the lookAt target. Useful for positioning a secondary
    /// crosshair that shows actual hit location found often in third person games.
    /// </summary>
    [WorldSystemFilter(WorldSystemFilterFlags.Default | WorldSystemFilterFlags.Editor)]
    [DisallowMultipleComponent]
    [CameraExtension]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Extensions/Player Hit Position")]
    public class PlayerHitPositionAuthoring : EntityBehaviourAuthoringBase
    {
        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
        }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            context.EntityManager.AddComponentData(entity, new PlayerHitPosition());
        }
    }
}