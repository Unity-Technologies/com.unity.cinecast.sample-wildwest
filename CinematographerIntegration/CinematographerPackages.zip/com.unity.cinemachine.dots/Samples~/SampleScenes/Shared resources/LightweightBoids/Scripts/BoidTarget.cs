using Unity.Entities;
using UnityEngine;

namespace Samples.Boids
{
    public struct BoidTarget : IComponentData {}
}
