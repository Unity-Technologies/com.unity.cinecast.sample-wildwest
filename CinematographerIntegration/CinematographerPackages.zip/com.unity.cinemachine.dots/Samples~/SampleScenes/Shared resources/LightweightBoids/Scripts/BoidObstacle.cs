using Unity.Entities;
using UnityEngine;

namespace Samples.Boids
{
    public struct BoidObstacle : IComponentData
    {
    }
}
