using UnityEngine;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;
using Unity.Mathematics;
using Unity.Cinemachine.Core;
using Unity.Entities;

[TestFixture]
public class StoryLookaheadTest
{
    [Test]
    public void SanityTest()
    {
        var m = ClientHooks.DefaultWorld.EntityManager;
        var e = m.CreateEntity();
        m.AddComponentData(e, new StoryLookaheadWindow());
        var w = m.GetComponentData<StoryLookaheadWindow>(e);
        var data = m.AddBuffer<StoryLookaheadInfo>(e);

        Assert.That(w.NumFrames == 0);
        Assert.That(w.LookheadWindowNumFrames == 0);
        Assert.That(w.GetAverageLookaheadValue() == 0);

        // Add 30 frames, framenumber and value set to the same thing for simplicity
        for (int i = 0; i < 30; ++i)
            w.AddHead(data, new StoryLookaheadInfo
                { FrameNumber = i, Info = new StoryLookaheadInfo.TargetInfo { Value = (float)i } });

        // MovieTime and GameTime should be 0, average should be 0
        Assert.That(w.MovieTimeFrame(data) == 0);
        Assert.That(w.GameTimeFrame(data) == 0);
        Assert.That(w.LookheadWindowNumFrames == 1);
        Assert.That(w.GetAverageLookaheadValue() == 0);
        Assert.That(w.NumFrames == 30);

        w.AdvanceGameTime(data);
        Assert.That(w.MovieTimeFrame(data) == 0);
        Assert.That(w.GameTimeFrame(data) == 1);
        Assert.That(w.LookheadWindowNumFrames == 2);
        var expectedAverage = (0 + 1) / (float)w.LookheadWindowNumFrames;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - expectedAverage) < 0.0001f);
        Assert.That(w.NumFrames == 30);

        for (int i = 2; i < 10; ++i)
            w.AdvanceGameTime(data);
        Assert.That(w.MovieTimeFrame(data) == 0);
        Assert.That(w.GameTimeFrame(data) == 9);
        Assert.That(w.LookheadWindowNumFrames == 10);
        expectedAverage = (0 + 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9) / (float)w.LookheadWindowNumFrames;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - expectedAverage) < 0.0001f);
        Assert.That(w.NumFrames == 30);

        for (int i = 0; i < 5; ++i)
            w.AdvanceMovieTime(data);
        Assert.That(w.MovieTimeFrame(data) == 5);
        Assert.That(w.GameTimeFrame(data) == 9);
        Assert.That(w.LookheadWindowNumFrames == 5);
        expectedAverage = (5 + 6 + 7 + 8 + 9) / (float)w.LookheadWindowNumFrames;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - expectedAverage) < 0.0001f);
        Assert.That(w.NumFrames == 30);

        for (int i = 0; i < 5; ++i)
            w.AdvanceMovieTime(data);
        Assert.That(w.MovieTimeFrame(data) == 10);
        Assert.That(w.GameTimeFrame(data) == 10);
        Assert.That(w.LookheadWindowNumFrames == 1);
        expectedAverage = (10) / (float)w.LookheadWindowNumFrames;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - expectedAverage) < 0.0001f);
        Assert.That(w.NumFrames == 30);

        for (int i = 1; i < 10; ++i)
            w.AdvanceGameTime(data);
        Assert.That(w.MovieTimeFrame(data) == 10);
        Assert.That(w.GameTimeFrame(data) == 19);
        Assert.That(w.LookheadWindowNumFrames == 10);
        expectedAverage = (10 + 11 + 12 + 13 + 14 + 15 + 16 + 17 + 18 + 19) / (float)w.LookheadWindowNumFrames;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - expectedAverage) < 0.0001f);
        Assert.That(w.NumFrames == 30);

        for (int i = 0; i < 10; ++i)
            w.RemoveTail(data);
        Assert.That(w.MovieTimeFrame(data) == 10);
        Assert.That(w.GameTimeFrame(data) == 19);
        Assert.That(w.LookheadWindowNumFrames == 10);
        expectedAverage = (10 + 11 + 12 + 13 + 14 + 15 + 16 + 17 + 18 + 19) / (float)w.LookheadWindowNumFrames;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - expectedAverage) < 0.0001f);
        Assert.That(w.NumFrames == 20);

        for (int i = 0; i < 5; ++i)
            w.RemoveTail(data);
        Assert.That(w.MovieTimeFrame(data) == 15);
        Assert.That(w.GameTimeFrame(data) == 19);
        Assert.That(w.LookheadWindowNumFrames == 5);
        expectedAverage = (15 + 16 + 17 + 18 + 19) / 5.0f;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - expectedAverage) < 0.0001f);
        Assert.That(w.NumFrames == 15);

        for (int i = 0; i < 10; ++i)
            w.AdvanceGameTime(data);
        Assert.That(w.MovieTimeFrame(data) == 15);
        Assert.That(w.GameTimeFrame(data) == 29);
        Assert.That(w.LookheadWindowNumFrames == 15);
        expectedAverage = (15 + 16 + 17 + 18 + 19 + 20 + 21 + 22 + 23 + 24 + 25 + 26 + 27 + 28 + 29) / (float)w.LookheadWindowNumFrames;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - expectedAverage) < 0.0001f);
        Assert.That(w.NumFrames == 15);

        w.AdvanceGameTime(data); // should do nothing, GameTime was already at the last frame
        Assert.That(w.MovieTimeFrame(data) == 15);
        Assert.That(w.GameTimeFrame(data) == 29);
        Assert.That(w.LookheadWindowNumFrames == 15);
        expectedAverage = (15 + 16 + 17 + 18 + 19 + 20 + 21 + 22 + 23 + 24 + 25 + 26 + 27 + 28 + 29) / (float)w.LookheadWindowNumFrames;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - expectedAverage) < 0.0001f);
        Assert.That(w.NumFrames == 15);

        for (int i = 0; i < 5; ++i)
            w.AdvanceMovieTime(data);
        Assert.That(w.MovieTimeFrame(data) == 20);
        Assert.That(w.GameTimeFrame(data) == 29);
        Assert.That(w.LookheadWindowNumFrames == 10);
        expectedAverage = (20 + 21 + 22 + 23 + 24 + 25 + 26 + 27 + 28 + 29) / (float)w.LookheadWindowNumFrames;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - expectedAverage) < 0.0001f);
        Assert.That(w.NumFrames == 15);

        for (int i = 0; i < 14; ++i)
            w.RemoveTail(data);
        Assert.That(w.MovieTimeFrame(data) == 29);
        Assert.That(w.GameTimeFrame(data) == 29);
        Assert.That(w.LookheadWindowNumFrames == 1);
        expectedAverage = (29) / (float)w.LookheadWindowNumFrames;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - expectedAverage) < 0.0001f);
        Assert.That(w.NumFrames == 1);

        w.RemoveTail(data);
        Assert.That(w.NumFrames == 0);
        Assert.That(w.LookheadWindowNumFrames == 0);
        Assert.That(w.GetAverageLookaheadValue() == 0);

        m.DestroyEntity(e);
    }

    [Test]
    public void WraparoundTest()
    {
        var m = ClientHooks.DefaultWorld.EntityManager;
        var e = m.CreateEntity();
        m.AddComponentData(e, new StoryLookaheadWindow());
        var w = m.GetComponentData<StoryLookaheadWindow>(e);
        var data = m.AddBuffer<StoryLookaheadInfo>(e);

        Assert.That(w.NumFrames == 0);
        Assert.That(w.LookheadWindowNumFrames == 0);
        Assert.That(w.GetAverageLookaheadValue() == 0);

        // Add frames, framenumber and value set to the same thing for simplicity
        for (int i = 0; i < StoryLookaheadWindow.GrowAmount; ++i)
            w.AddHead(data, new StoryLookaheadInfo
                { FrameNumber = i, Info = new StoryLookaheadInfo.TargetInfo { Value = (float)i } });

        // MovieTime and GameTime should be 0, average should be 0
        Assert.That(w.MovieTimeFrame(data) == 0);
        Assert.That(w.GameTimeFrame(data) == 0);
        Assert.That(w.LookheadWindowNumFrames == 1);
        Assert.That(w.GetAverageLookaheadValue() == 0);
        Assert.That(w.NumFrames == StoryLookaheadWindow.GrowAmount);

        for (int i = 0; i < StoryLookaheadWindow.GrowAmount - 1; ++i)
            w.AdvanceGameTime(data);
        Assert.That(w.MovieTimeFrame(data) == 0);
        Assert.That(w.GameTimeFrame(data) == StoryLookaheadWindow.GrowAmount - 1);
        Assert.That(w.LookheadWindowNumFrames == StoryLookaheadWindow.GrowAmount);
        float sum = 0;
        for (int i = 0; i < StoryLookaheadWindow.GrowAmount; ++i)
            sum += (float)i;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - sum / w.LookheadWindowNumFrames) < 0.0001f);
        Assert.That(w.NumFrames == StoryLookaheadWindow.GrowAmount);

        w.AddHead(data, new StoryLookaheadInfo
        {
            FrameNumber = StoryLookaheadWindow.GrowAmount,
            Info = new StoryLookaheadInfo.TargetInfo { Value = (float)StoryLookaheadWindow.GrowAmount }
        });
        Assert.That(w.NumFrames == StoryLookaheadWindow.GrowAmount + 1);

        w.AdvanceGameTime(data);
        Assert.That(w.MovieTimeFrame(data) == 0);
        Assert.That(w.GameTimeFrame(data) == StoryLookaheadWindow.GrowAmount);
        Assert.That(w.LookheadWindowNumFrames == StoryLookaheadWindow.GrowAmount + 1);
        sum += StoryLookaheadWindow.GrowAmount;
        Assert.That(math.abs(w.GetAverageLookaheadValue() - sum / w.LookheadWindowNumFrames) < 0.0001f);
        Assert.That(w.NumFrames == StoryLookaheadWindow.GrowAmount + 1);

        // Reacreate the same thing, but with wraparound eliminating the first value (which is 0)
        w.Clear(data);
        Assert.That(w.NumFrames == 0);
        Assert.That(w.LookheadWindowNumFrames == 0);
        Assert.That(w.GetAverageLookaheadValue() == 0);

        for (int i = 0; i < StoryLookaheadWindow.GrowAmount; ++i)
            w.AddHead(data, new StoryLookaheadInfo
                { FrameNumber = i, Info = new StoryLookaheadInfo.TargetInfo { Value = (float)i } });

        Assert.That(w.MovieTimeFrame(data) == 0);
        Assert.That(w.GameTimeFrame(data) == 0);

        for (int i = 1; i < StoryLookaheadWindow.GrowAmount; ++i)
            w.AdvanceGameTime(data);

        Assert.That(w.NumFrames == StoryLookaheadWindow.GrowAmount);
        Assert.That(w.MovieTimeFrame(data) == 0);
        Assert.That(w.GameTimeFrame(data) == StoryLookaheadWindow.GrowAmount - 1);

        w.RemoveTail(data);
        Assert.That(w.NumFrames == StoryLookaheadWindow.GrowAmount - 1);

        w.AddHead(data, new StoryLookaheadInfo
        {
            FrameNumber = StoryLookaheadWindow.GrowAmount,
            Info = new StoryLookaheadInfo.TargetInfo { Value = (float)StoryLookaheadWindow.GrowAmount }
        });
        Assert.That(w.NumFrames == StoryLookaheadWindow.GrowAmount);

        w.AdvanceGameTime(data);
        Assert.That(w.AdvanceGameTime(data) == false);

        // note: sum is the same (first element was 0) but average should be different
        Assert.That(w.MovieTimeFrame(data) == 1);
        Assert.That(w.GameTimeFrame(data) == StoryLookaheadWindow.GrowAmount);
        Assert.That(w.LookheadWindowNumFrames == StoryLookaheadWindow.GrowAmount);
        Assert.That(math.abs(w.GetAverageLookaheadValue() - sum / w.LookheadWindowNumFrames) < 0.0001f);

        for (int i = 0; i < StoryLookaheadWindow.GrowAmount; ++i)
            w.AdvanceMovieTime(data);

        Assert.That(w.LookheadWindowNumFrames == 1);
        Assert.That(math.abs(w.GetAverageLookaheadValue() - StoryLookaheadWindow.GrowAmount / w.LookheadWindowNumFrames) < 0.0001f);
        Assert.That(w.AdvanceMovieTime(data) == false);

        for (int i = 0; i < StoryLookaheadWindow.GrowAmount; ++i)
            w.RemoveTail(data);

        Assert.That(w.NumFrames == 0);

        w.AddHead(data, new StoryLookaheadInfo
        {
            FrameNumber = StoryLookaheadWindow.GrowAmount + 1,
            Info = new StoryLookaheadInfo.TargetInfo { Value = (float)StoryLookaheadWindow.GrowAmount + 1 }
        });
        Assert.That(w.MovieTimeFrame(data) == StoryLookaheadWindow.GrowAmount + 1);
        Assert.That(w.GameTimeFrame(data) == StoryLookaheadWindow.GrowAmount + 1);
        Assert.That(w.LookheadWindowNumFrames == 1);
        Assert.That(math.abs(w.GetAverageLookaheadValue() - (StoryLookaheadWindow.GrowAmount + 1) / w.LookheadWindowNumFrames) < 0.0001f);

        m.DestroyEntity(e);
    }
}

