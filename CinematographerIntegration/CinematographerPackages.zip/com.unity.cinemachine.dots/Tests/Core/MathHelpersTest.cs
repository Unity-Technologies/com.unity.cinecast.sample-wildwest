using UnityEngine;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;
using Unity.Mathematics;
using Unity.Cinemachine.Core;

[TestFixture]
public class MathHelpersTest
{
    [Test]
	public void AlmostZero()
    {
        Assert.That(new float3(0, 0, 0).AlmostZero());
        Assert.That(new float3(0, 0, -0.0001f).AlmostZero());
        Assert.That(new float3(-0.0001f, 0.0001f, -0.0001f).AlmostZero());

        Assert.That(!new float3(0, 0, 0.001f).AlmostZero());
        Assert.That(!new float3(-0.001f, 0.001f, 0.001f).AlmostZero());
        Assert.That(!new float3(0.1f, 0.01f, 0).AlmostZero());
    }

    [Test]
	public void ProjectOntoPlane()
    {
        var d1 = math.normalize(new float3(1, 2, 3));
        var d2 = math.normalize(new float3(2, 3, 1));
        Assert.That(MathHelpers.ProjectOntoPlane(d1, d1).AlmostZero());
        var v = MathHelpers.ProjectOntoPlane(d1, d2);
        Assert.That(!v.AlmostZero());
        Assert.That(math.length(v) < 1);
        Assert.That(math.abs(math.dot(v, d2)) < MathHelpers.Epsilon);
        Assert.That(!math.cross(v, d2).AlmostZero());
    }

    [Test]
	public void DampFloat()
    {
        const float dampTime = 10f;
        const float initial = 100f;

        float t = 0;
        float r = MathHelpers.Damp(initial, dampTime, t);
        Assert.AreEqual(0, r);
        Assert.Less(r, initial);
        const int iterations = 10;
        for (int i = 0; i < iterations; ++i)
        {
            t += dampTime / iterations;
            string msg = "i = " + i + ", t = " + t;
            if (i != iterations-1)
                Assert.Less(t, dampTime, msg);
            else
                t = dampTime;
            float r2 = MathHelpers.Damp(initial, dampTime, t);
            Assert.Less(r, r2, msg);
            r = r2;
        }
        //Assert.AreEqual(initial * (1 - MathHelpers.kNegligibleResidual), r, "f = " + f);
	}

    [Test]
	public void DampFloat3()
    {
        float3 dampTime = new float3(10f, 9f, 8f);
        float3 initial = new float3(100f, 110f, 120f);

        float t = 0;
        float3 r = MathHelpers.Damp(initial, dampTime, t);
        Assert.AreEqual(0, r.x);
        Assert.AreEqual(0, r.y);
        Assert.AreEqual(0, r.z);
        const int iterations = 10;
        for (int i = 0; i < iterations; ++i)
        {
            t += math.cmax(dampTime) / iterations;
            string msg = "i = " + i + ", t = " + t;
            if (i != iterations-1)
                Assert.Less(t, math.cmax(dampTime), msg);
            else
                t = math.cmax(dampTime);
            float3 r2 = MathHelpers.Damp(initial, dampTime, t);
            Assert.LessOrEqual(r.x, r2.x, msg);
            Assert.LessOrEqual(r.y, r2.y, msg);
            Assert.LessOrEqual(r.z, r2.z, msg);
            r = r2;
        }
        //Assert.AreEqual(initial * (1 - MathHelpers.kNegligibleResidual), r, "f = " + f);
	}

    [Test]
	public void DampFloat2()
    {
        float2 dampTime = new float2(10f, 9f);
        float2 initial = new float2(100f, 110f);

        float t = 0;
        float2 r = MathHelpers.Damp(initial, dampTime, t);
        Assert.AreEqual(0, r.x);
        Assert.AreEqual(0, r.y);
        const int iterations = 10;
        for (int i = 0; i < iterations; ++i)
        {
            t += math.cmax(dampTime) / iterations;
            string msg = "i = " + i + ", t = " + t;
            if (i != iterations-1)
                Assert.Less(t, math.cmax(dampTime), msg);
            else
                t = math.cmax(dampTime);
            float2 r2 = MathHelpers.Damp(initial, dampTime, t);
            Assert.LessOrEqual(r.x, r2.x, msg);
            Assert.LessOrEqual(r.y, r2.y, msg);
            r = r2;
        }
        //Assert.AreEqual(initial * (1 - MathHelpers.kNegligibleResidual), r, "f = " + f);
	}

    [Test]
    public void IsNan()
    {
        float infinity = float.MaxValue * 10;
        Assert.IsTrue(math.isinf(infinity));

        float nan = infinity / infinity;
        Assert.IsTrue(math.isnan(nan));
            
        float3 inf1 = new float3(infinity, 0, 0);
        float3 inf2 = new float3(0, infinity, 0);
        float3 inf3 = new float3(0, 0, infinity);
        Assert.IsFalse(inf1.IsNan());
        Assert.IsFalse(inf2.IsNan());
        Assert.IsFalse(inf3.IsNan());

        float3 nan1 = new float3(nan, 0, 0 );
        float3 nan2 = new float3(0, nan, 0 );
        float3 nan3 = new float3(0, 0, nan );
        Assert.IsTrue(nan1.IsNan());
        Assert.IsTrue(nan2.IsNan());
        Assert.IsTrue(nan3.IsNan());
    }

    [Test]
    public void ClosestPointOnSegment() 
    {
        Unity.Mathematics.Random random = new Unity.Mathematics.Random(1);
        float3 start = new float3(0, 0, 0);
        float3 end = new float3(1, 0, 0);
            
        for (int i = 0; i < 200; ++i)
        {
            float3 p = new float3(random.NextFloat(start.x - 100, start.x), random.NextFloat(), random.NextFloat());
            Assert.IsTrue(MathHelpers.ClosestPointOnSegment(p, start, end) == 0);
        }
        for (int i = 0; i < 200; ++i)
        {
            float3 p = new float3(random.NextFloat(end.x, end.x + 100), random.NextFloat(), random.NextFloat());
            Assert.IsTrue(MathHelpers.ClosestPointOnSegment(p, start, end) == 1);
        }
        for (int i = 0; i < 200; ++i)
        {
            float3 p = new float3(random.NextFloat(start.x, end.x), random.NextFloat(), random.NextFloat());
            Assert.IsTrue(Mathf.Approximately(MathHelpers.ClosestPointOnSegment(p, start, end), p.x));
        }
            
        float3 data = new float3(float.MinValue, float.MaxValue, 0);
        for (int c = 0; c < 2; ++c)
        for (int i = 0; i < 3; ++i) 
        for (int j = 0; j < 3; ++j)
        {
            float3 p = new float3(data[c], data[i], data[j]);
            Assert.IsTrue(
                MathHelpers.ClosestPointOnSegment(new float3(data[c], data[i], data[j]),
                    start, end) == c);
        }
    }

    [Test]
    public void AngleUnit() 
    {
        float3 unitVector1 = new float3(1, 0, 0);
        float3 unitVector2 = new float3(0, 1, 0);

        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(unitVector1, -unitVector1), math.PI, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(-unitVector1, unitVector1), math.PI, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(-unitVector1, -unitVector1), 0, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(unitVector1, unitVector1), 0, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(unitVector1, unitVector2), math.PI / 2, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(unitVector2, unitVector1), math.PI / 2, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(-unitVector1, unitVector2), math.PI / 2, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(unitVector2, -unitVector1), math.PI / 2, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(unitVector1, -unitVector2), math.PI / 2, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(-unitVector2, unitVector1), math.PI / 2, 0.0001f);

        float3 unitVectorVeryCloseTo1 = new float3(0.999999f, 0.001001f, 0.001001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(unitVectorVeryCloseTo1, unitVectorVeryCloseTo1), 0, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(unitVectorVeryCloseTo1, -unitVectorVeryCloseTo1), math.PI, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(-unitVectorVeryCloseTo1, unitVectorVeryCloseTo1), math.PI, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(-unitVectorVeryCloseTo1, -unitVectorVeryCloseTo1), 0, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(unitVector1, unitVectorVeryCloseTo1), 0.00141563f, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(unitVectorVeryCloseTo1, unitVector1), 0.00141563f, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(-unitVector1, unitVectorVeryCloseTo1), 3.14018f, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(unitVectorVeryCloseTo1, -unitVector1), 3.14018f, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(unitVector1, -unitVectorVeryCloseTo1), 3.14018f, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(-unitVectorVeryCloseTo1, unitVector1), 3.14018f, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(-unitVector1, -unitVectorVeryCloseTo1), 0.00141563f, 0.0001f);
        UnityEngine.Assertions.Assert.AreApproximatelyEqual(MathHelpers.AngleUnit(-unitVectorVeryCloseTo1, -unitVector1), 0.00141563f, 0.0001f);
    }

    [Test]
    public void Axis() 
    {
        float3 vx = new float3(1, 0, 0);
        float3 vy = new float3(0, 1, 0);
        float3 vz = new float3(0, 0, 1);
        float3 vDefault = new float3(3, 1, 2);

        Assert.IsTrue(MathHelpers.Axis(vx, vy, vDefault).Equals(vz));
        Assert.IsTrue(MathHelpers.Axis(vy, vx, vDefault).Equals(-vz));
        Assert.IsTrue(MathHelpers.Axis(vx, vx, vDefault).Equals(vDefault));

        float3 v1 = new float3(1, 0.001001f, 0.001001f);
        float3 v2 = new float3(0.001001f, 1, 0.001001f);
        float3 referenceResult = new float3(-0.000999998f, -0.000999998f, 0.999999f);

        float3 result1 = MathHelpers.Axis(v1, v2, vDefault);
        float3 result2 = MathHelpers.Axis(v2, v1, vDefault);
        for (int i = 0; i < 3; ++i)
        {
            UnityEngine.Assertions.Assert.AreApproximatelyEqual(result1[i], referenceResult[i], 0.0001f);
            UnityEngine.Assertions.Assert.AreApproximatelyEqual(result2[i], -referenceResult[i], 0.0001f);
        }

        Assert.IsTrue(MathHelpers.Axis(v1, v1, vDefault).Equals(vDefault));
        Assert.IsTrue(MathHelpers.Axis(v2, v2, vDefault).Equals(vDefault));
    }

    [Test]
    public void FromToRotationUnit() 
    {
        float3 vx = new float3(1, 0, 0);
        float3 vy = new float3(0, 1, 0);
        float3 vDefault = new float3(3, 1, 2);
        Assert.IsTrue(MathHelpers.FromToRotationUnit(vx, vx, vDefault).Equals(new quaternion(0,0,0,1)));
        Assert.IsTrue(MathHelpers.FromToRotationUnit(vy, vy, vDefault).Equals(new quaternion(0,0,0,1)));
            
        quaternion result1 = MathHelpers.FromToRotationUnit(vx, vy, vDefault);
        quaternion result2 = MathHelpers.FromToRotationUnit(vy, vx, vDefault);
        float sqrt2over2 = (float) math.sqrt(2.0) / 2.0f;
        quaternion referenceResult1 = new quaternion(0, 0, sqrt2over2, sqrt2over2);
        quaternion referenceResult2 = new quaternion(0, 0, -sqrt2over2, sqrt2over2);
        for (int i = 0; i < 4; ++i)
        {
            UnityEngine.Assertions.Assert.AreApproximatelyEqual(result1.value[i], referenceResult1.value[i], 0.0001f);
            UnityEngine.Assertions.Assert.AreApproximatelyEqual(result2.value[i], referenceResult2.value[i], 0.0001f);
        }
    }

    [Test]
    public void BezierFloat() 
    {
        float p1 = 0;
        float p2 = 1;
        float p3 = 2;
        float p4 = 3;
            
        Assert.IsTrue(MathHelpers.Bezier(-10.0f, p1, p2, p3, p4).Equals(p1));
        Assert.IsTrue(MathHelpers.Bezier(0.0f, p1, p2, p3, p4).Equals(p1));
        Assert.IsTrue(MathHelpers.Bezier(0.5f, p1, p2, p3, p4).Equals(1.5f));
        Assert.IsTrue(MathHelpers.Bezier(1.0f, p1, p2, p3, p4).Equals(p4));
        Assert.IsTrue(MathHelpers.Bezier(10.0f, p1, p2, p3, p4).Equals(p4));
    }

    [Test]
    public void BezierFloat2() 
    {
        float2 p1 = new float2(0, 0);
        float2 p2 = new float2(1, 1);
        float2 p3 = new float2(2, 0);
        float2 p4 = new float2(3, 1);
            
        Assert.IsTrue(MathHelpers.Bezier(-10.0f, p1, p2, p3, p4).Equals(p1));
        Assert.IsTrue(MathHelpers.Bezier(0.0f, p1, p2, p3, p4).Equals(p1));
        Assert.IsTrue(MathHelpers.Bezier(0.5f, p1, p2, p3, p4).Equals(new float2(1.5f, 0.5f)));
        Assert.IsTrue(MathHelpers.Bezier(1.0f, p1, p2, p3, p4).Equals(p4));
        Assert.IsTrue(MathHelpers.Bezier(10.0f, p1, p2, p3, p4).Equals(p4));
    }

    [Test]
    public void BezierFloat3() 
    {
        float3 p1 = new float3(0, 0, 1);
        float3 p2 = new float3(1, 1, 0);
        float3 p3 = new float3(2, 0, 0);
        float3 p4 = new float3(3, 1, 1);
            
        Assert.IsTrue(MathHelpers.Bezier(-10.0f, p1, p2, p3, p4).Equals(p1));
        Assert.IsTrue(MathHelpers.Bezier(0.0f, p1, p2, p3, p4).Equals(p1));
        Assert.IsTrue(MathHelpers.Bezier(0.5f, p1, p2, p3, p4).Equals(new float3(1.5f, 0.5f, 0.25f)));
        Assert.IsTrue(MathHelpers.Bezier(1.0f, p1, p2, p3, p4).Equals(p4));
        Assert.IsTrue(MathHelpers.Bezier(10.0f, p1, p2, p3, p4).Equals(p4));
    }

    [Test]
    public void BezierFloat4() 
    {
        float4 p1 = new float4(0, 0, 1, 1);
        float4 p2 = new float4(1, 1, 0, -1);
        float4 p3 = new float4(2, 0, 0, -1);
        float4 p4 = new float4(3, 1, 1, 1);
            
        Assert.IsTrue(MathHelpers.Bezier(-10.0f, p1, p2, p3, p4).Equals(p1));
        Assert.IsTrue(MathHelpers.Bezier(0.0f, p1, p2, p3, p4).Equals(p1));
        Assert.IsTrue(MathHelpers.Bezier(0.5f, p1, p2, p3, p4).Equals(new float4(1.5f, 0.5f, 0.25f, -0.5f)));
        Assert.IsTrue(MathHelpers.Bezier(1.0f, p1, p2, p3, p4).Equals(p4));
        Assert.IsTrue(MathHelpers.Bezier(10.0f, p1, p2, p3, p4).Equals(p4));
    }

#if false
	// A UnityTest behaves like a coroutine in PlayMode
	// and allows you to yield null to skip a frame in EditMode
	[UnityTest]
	public IEnumerator PlayModeSampleTestWithEnumeratorPasses()
    {
		// Use the Assert class to test conditions.
		// yield to skip a frame
		yield return null;
	}
#endif
}

