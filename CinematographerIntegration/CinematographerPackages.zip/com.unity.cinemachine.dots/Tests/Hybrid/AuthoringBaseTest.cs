#if false
using UnityEngine;
using UnityEditor;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;
using Unity.Cinemachine.Authoring;
using Unity.Entities;

public struct AuthoringBaseTestData : IComponentData
{
    public int IntValue;
}
/*

public class AuthoringBaseTest : ComponentAuthoringBase<AuthoringBaseTestData>
{
    [OneTimeSetUp]
    public static void SetUpOnce()
    {
	}

    [SetUp]
    public static void SetUp()
    {
    }

    [TearDown]
    public static void TearDown()
    {
    }

    [OneTimeTearDown]
    public static void TearDownOnce()
    {
    }
*/
/*        
    [Test]
	public void DefaultEntityTest() 
	{
		// Use the Assert class to test conditions.
        GameObject go = ObjectFactory.CreateGameObject("TestObject", typeof(AuthoringBaseTest));
        var a = go.GetComponent<AuthoringBaseTest>();
        Assert.IsTrue(a.DefaultEntity != default, "DefaultEntity is null");
        DestroyImmediate(go);
	}
*/
/*
	// A UnityTest behaves like a coroutine in PlayMode
	// and allows you to yield null to skip a frame in EditMode
	[UnityTest]
	public IEnumerator EditorSampleTestWithEnumeratorPasses() 
	{
		// Use the Assert class to test conditions.
		// yield to skip a frame
		yield return null;
	}
*/
}
#endif
