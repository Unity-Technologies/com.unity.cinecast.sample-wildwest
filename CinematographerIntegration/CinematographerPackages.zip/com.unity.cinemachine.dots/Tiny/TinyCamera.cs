﻿using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Tiny.Rendering;
using UnityEngine;

namespace Unity.Cinemachine3.Tiny
{
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    [UpdateBefore(typeof(CmTargetSystem))]
    [AlwaysUpdateSystem]
    public class CmReadFromCameraTiny : SystemBase
    {
        protected override void OnUpdate()
        {
            // Update the channel settings to match camera settings
            Entities
                .WithoutBurst()
                .WithStructuralChanges()
                .ForEach((Entity Entity, CmListenerTiny listener) =>
                {
                    if (listener.OutputCamera == Entity.Null)
                        return;

                    var ch = ChannelHelperFor(listener);
                    var camera = EntityManager.GetComponentData<Camera>(listener.OutputCamera);
                    
                    CmChannel.ChannelSettings.ProjectionType projectionType;
                    if (camera.Mode == ProjectionMode.Orthographic)
                        projectionType = CmChannel.ChannelSettings.ProjectionType.Orthographic;
                    else if (camera.Mode == ProjectionMode.Perspective)
                        projectionType = CmChannel.ChannelSettings.ProjectionType.Perspective;
                    else
                    {
                        Debug.LogWarning("Cinemachine3 CmListener asked to drive a camera with Explicit ProjectionType");
                        return; // explicit
                    }

                    var c = ch.ChannelData;
                    if (c.Settings.Aspect != camera.Aspect || c.Settings.Projection != projectionType)
                    {
                        c.Settings.Aspect = camera.Aspect;
                        c.Settings.Projection = projectionType;

                        World.SafeSetComponentData(ch.Entity, c);
                    }
                }).Run();
        }

        public ChannelHelper ChannelHelperFor(CmListenerTiny listener)
        {
            return new ChannelHelper(listener.ChannelOverride, World);
        }

        public CameraState CameraStateFor(CmListenerTiny listener)
        {
            return ChannelHelperFor(listener).State;
        }
    }
    
    [UpdateInGroup(typeof(LateSimulationSystemGroup))]
    [UpdateBefore(typeof(CmChannelFinalizeSystem))]
    [AlwaysUpdateSystem]
    public class CmWriteToCameraTiny : SystemBase
    {
        protected override void OnUpdate()
        {
            // Write to the camera -- CmListener.ProcessActiveNode() equivalent
            Entities
                .WithoutBurst()
                .WithStructuralChanges()
                .ForEach((Entity Entity, CmListenerTiny listener) =>
                {
                    var ch = ChannelHelperFor(listener);
                    var state = ch.State;

                    if (ch.ActiveNode.IsValidNode(World))
                    {
                        if ((state.BlendHint & NodeBlendHint.BlendHintValue.NoPosition) == 0)
                        {
                            World.SafeSetComponentData(listener.OutputCamera, new Transforms.Translation { Value = state.FinalPosition });
                        }

                        if ((state.BlendHint & NodeBlendHint.BlendHintValue.NoOrientation) == 0)
                        {
                            World.SafeSetComponentData(listener.OutputCamera, new Transforms.Rotation { Value = state.FinalOrientation });
                        }

                        if ((state.BlendHint & NodeBlendHint.BlendHintValue.NoLens) == 0 &&
                            listener.OutputCamera != Entity.Null)
                        {
                            var cam = EntityManager.GetComponentData<Camera>(listener.OutputCamera);
                            cam.ClipZNear = state.Lens.NearClipPlane;
                            cam.ClipZFar = state.Lens.FarClipPlane;
                            cam.VerticalFieldOfView = state.Lens.FieldOfView;
                            if (cam.Mode == ProjectionMode.Orthographic)
                            {
                                // this is also orthographicSize
                                cam.VerticalFieldOfView = state.Lens.OrthographicSize;
                            }

                            World.SafeSetComponentData(listener.OutputCamera, cam);
                        }
                    }
                }).Run();
        }

        public ChannelHelper ChannelHelperFor(CmListenerTiny listener)
        {
            return new ChannelHelper(listener.ChannelOverride, World);
        }

        public CameraState CameraStateFor(CmListenerTiny listener)
        {
            return ChannelHelperFor(listener).State;
        }
    }

    public class Position
    {
        public Position(float3 stateFinalPosition)
        {
            throw new System.NotImplementedException();
        }
    }
}
