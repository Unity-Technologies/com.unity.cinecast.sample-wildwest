# Changelog

## [Unreleased]

### Added
- Added CinemachineSystemBase, to implement manual camera updating.
- Added shot quality degradation to collider.
- Added TrackerPostBodySystem and TrackerPreAimSystem for better system ordering control.
- Added ConfineToNavMesh extension and sample scene.
### Changed
- Changed: Only noise and impulse use the PositionCorrection and RotationCorrection channels.  All others write directly to RawPosition and RawRotation.
- Changed: Renamed BlendCurve to TransitionCurve.
- Samples upgraded to URP.
### Deprecated
### Removed
- NodeShotQuality and NodSequence components removed, fields moved to NodeUpdateState.
### Fixed
### Security


## [0.1.0] - 2021-09-17
- Namespace and package rename to Unity.Cinemachine
- 3rdPersonFollow's built-in collision detection now has damping in and out options, just like the cinemachine collider. 
- Refactor of ThirdPersonFollow sample scene

## Formerly known as Cinemachine3

## [3.0.0-preview.16] - 2021-02-22
### Cleanup
- Minimum Unity is 2020.2
- Minimum Entities is 0.18.0-preview.42
- Refactor: IJobForEach removed
- Refactor: BindingKeys moved into separate assemblies and namespace, in prep for becoming separate package
- Repository restructure: BindingKeys renamed and moved into a separate package (com.unity.stableid), alongside cinemachine.dots

## [3.0.0-preview.15] - 2021-01-15
### Maintenance
- Minimum Entities is 0.17.0-preview.41
- EntityBehaviour bugfix: transform synching was incorrect

## [3.0.0-preview.14] - 2020-12-17
### Maintenance
- Minimum Entities is 0.17.0-preview.39

## [3.0.0-preview.13] - 2020-12-01
### Introduction of EntityBehaviour
- Cinemachine authoring classes are now based on EntityBehaviour - an authoring behaviour that functions both within conversion contexts and outside of them also.  The result is that Cinemachine components can now be added to ordinary non-DOTS game objects and used in GameObject-based projects.  Some of the sample scene have been updated to function in this way.
- Shot QualityEvaluator has OptimalTargetDistance property, to favour cameras closer to that distance
- Tracker gizmos are displayed in the scene view
- Minimum Entities is 0.17.0-preview.38

## [3.0.0-preview.12] - 2020-10-21
### Maintenance
- Minimum Entities is 0.16

## [3.0.0-preview.11] - 2020-09-23
### DOTS.Timeline API change workaropund
- Temporarily disabled Timeline animation of composer settings

## [3.0.0-preview.10] - 2020-09-02
### Maintenance
- Minimum Unity is 2020.1
- Minimum Entities is 0.14
- Minimum DOTS Timeline version is now 0.7.0-preview.2
- Minimum Unity.Physics version is now 0.5.0-preview

## [3.0.0-preview.9] - 2020-07-31
### Maintenance
- Minimum Unity is 2020.1
- Minimum Entities is 0.13
- Minimum DOTS Timeline version is now 0.7.0-preview.1
- Minimum Unity.Physics version is now 0.4.1-preview

## [3.0.0-preview.6] - 2020-06-16
### New features
- Upgrade to Entities 0.11
- Noise performance improvement
- Sample scenes asset size reduction (10x)
- Bugfix: Solo works when not in play mode

## [3.0.0-preview.5] - 2020-05-12
### New features
- Added CmMixer
- Multi-object editing support added for Cinemachine Components.
- Upgrade to Entities 0.9.0

## [3.0.0-preview.4] - 2020-04-12
### Repo reorg, and some new features
- Reorg of repo: package is at the top, sample content is under Samples~ and importable from packman
- Upgrade to Entities 0.8.0
- Added Blend Hints
- Added Composer Lookahead
- Added multi-channel ability to ProceduralNoise

## [3.0.0-preview.3] - 2020-03-30
### Tiny support, BindingKey refactor, and some new features.
- Cinemachine can now be used in Tiny applications - no UnityEngine references
- BindingKey refactoring: Only a single binding key per entity, binding key types share it.  This change will require re-authoring of relevant components
- Added system to automatically generate unique BindingKeys for spawned entities
- BindinKey reference UX improvements: only one line in inspector (but it's expandable)
- Added ClientHooks.DefaultWorld to customize the default conversion world for vcams
- Added TargetGroup inspector
- Added Custom Blends support

## [3.0.0-preview.2] - 2020-01-31
### Keeping up to date with DOTS.Timeline.  And some new features.
- Upgrade to use latest DOTS.Timeline API and latest preview DOTS API (Entities 0.6.0-preview.0)
- Added ThirdPersonCamera to CM core
- Added group member blending system
- Added Impulse system and example scene
- Added Noise Profile inspector with signal preview
- Added Standby mode to vcams, so they can be disabled without touching the priority setting
- Cinecast greybox scene is working - no lookahead yet
- Improved handling of orbital damping when target is moving
- Orbital: added minimum distance from target setting, to keep target in view when it's moving towards the camera with lots of damping
- More unit tests for MathHelpers

## [3.0.0-preview.1] - 2019-12-15
### Initial version.
