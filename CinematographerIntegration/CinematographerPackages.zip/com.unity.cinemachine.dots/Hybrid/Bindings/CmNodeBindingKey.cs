using UnityEngine;
using Unity.Entities.Hybrid;
using Unity.Entities;

namespace Unity.Cinemachine.Hybrid
{
    [AddComponentMenu("")] // hide in menu
    [RequireComponent(typeof(StableID))]
    public class CmNodeBindingKey : MonoBehaviour
    {
        public StableKey StableKey => GetComponent<StableID>().Value;
    }
}
