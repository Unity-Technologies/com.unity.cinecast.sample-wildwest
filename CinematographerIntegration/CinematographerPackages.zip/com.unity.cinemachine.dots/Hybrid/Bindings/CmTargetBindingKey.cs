﻿using UnityEngine;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [AddComponentMenu("")] // hide in menu
    [RequireComponent(typeof(StableID))]
    public class CmTargetBindingKey : MonoBehaviour
    {
    }
}
