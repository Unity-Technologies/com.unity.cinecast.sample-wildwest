using UnityEngine;
using Unity.Entities;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [AddComponentMenu("")] // hide in menu
    [RequireComponent(typeof(StableID))]
#if CINEMACHINE_TIMELINE
    public class CmChannelBindingKey : Timeline.Hybrid.TrackBaseBinding
    {
        public override Entities.Hash128 Tag => new Entities.Hash128((uint) GetInstanceID(), 0, 0, 0); 
        public StableKey StableKey => GetComponent<StableID>().Value;
    }
#else
    public class CmChannelBindingKey : MonoBehaviour
    {
        public StableKey StableKey => GetComponent<StableID>().Value;
    }
#endif
}
