using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Cinemachine.Editor")]
