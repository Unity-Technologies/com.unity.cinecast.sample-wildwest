using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [DisallowMultipleComponent]
    [CameraExtension]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Extensions/Impulse Listener")]
    public class ImpulseListenerAuthoring : ComponentAuthoringBase<ImpulseListener> 
    {
        protected override void Reset()
        {
            m_Value = new ImpulseListener
            {
                ImpulseChannelMask = 1,
                Gain = 1
            };
            base.Reset();
        }
    }
}
