﻿#if CINEMACHINE_TIMELINE
using System;
using Unity.Timeline.Hybrid;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Timeline;

namespace Unity.Cinemachine.Hybrid
{
    /// <summary>
    /// Implement this interface to be placed on the spawn track
    /// </summary>
    public interface ICreateNodeClip {}

    [Serializable]
    [TrackColor(0.53f, 0.0f, 0.08f)]
    [TrackBindingType(typeof(CmChannelBindingKey))]
    [TrackClipType(typeof(ICreateNodeClip))]
    public class CmTimelineTrack : DOTSTrack, ILayerable
    {
        public Playable CreateLayerMixer(
            PlayableGraph graph, GameObject go, int inputCount)
        {
            return Playable.Null;
        }
    }
}
#endif
