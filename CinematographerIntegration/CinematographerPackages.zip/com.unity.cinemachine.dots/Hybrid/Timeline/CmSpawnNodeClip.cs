﻿#if CINEMACHINE_TIMELINE
using System.Collections.Generic;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Timeline;
using Unity.Timeline.Hybrid;
using Unity.Transforms;
using Unity.Scheduler;
using Unity.Time;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Timeline;
using System.Linq;
using Hash128 = Unity.Entities.Hash128;

namespace Unity.Cinemachine.Hybrid
{
    public class CmSpawnNodeClip
        : DOTSClip, IEntityTransformProvider, ITimelineClipAsset, ICreateNodeClip
    {
        public string DisplayName;

        /// <summary>
        /// The prefab to spawn
        /// </summary>
        [Tooltip("The prefab to spawn")]
        public GameObject Prefab;

        public float3 Position;
        public float3 Rotation;

        /// <summary>
        /// An optional timeline asset that is automatically bound to the spawned object
        /// </summary>
        [Tooltip("An optional timeline to attach that is automatically bound to the spawned object")]
        public TimelineAsset AnimationTimeline;

        /// <summary>
        /// How the timeline plays back
        /// </summary>
        public DirectorWrapMode WrapMode = DirectorWrapMode.Loop;


        float3 IEntityTransformProvider.EntityTranslation
        {
            get => Position;
            set => Position = value;
        }
        float3 IEntityTransformProvider.EntityRotation
        {
            get => Rotation;
            set => Rotation = value;
        }
        float3 IEntityTransformProvider.EntityScale
        {
            get => new float3(1);
            set { }
        }

        public override void DeclareReferencedPrefabs(
            ConversionContext context, List<GameObject> referencedPrefabs)
        {
            base.DeclareReferencedPrefabs(context, referencedPrefabs);
            referencedPrefabs.Add(Prefab);
            if (AnimationTimeline != null)
                TimelineConversion.DeclareReferencedPrefabs(
                    context, AnimationTimeline, referencedPrefabs);
        }

        public override void Convert(Entity clipEntity, ConversionContext context)
        {
            if (Prefab == null)
                return;

            var tag = TimelineExtensions.GenerateRandomGuid();

            context.EntityManager.AddComponentData(clipEntity, new CmTimelineSpawnNode()
            {
                Value = new SpawnPrefab()
                {
                    Prefab = context.ConversionSystem.GetPrimaryEntity(Prefab),
                    Translation = Position,
                    Rotation = quaternion.Euler(math.radians(Rotation)),
                    Scale = new float3(1),
                    Tag = tag
                }
            });
            var channel = context.Director.GetGenericBinding(context.Track) as CmChannelBindingKey;
            context.EntityManager.AddComponentData(
                clipEntity, new CmTimelineClipInfo
                {
                    Id = GetTrackId(context),
                    ChannelKey = channel != null ? channel.StableKey : default,
                    BlendOutStartTime
                        = context.Clip.ToLocalTime(context.Clip.end - context.Clip.mixOutDuration)
                           - context.Clip.ToLocalTime(context.Clip.start)
                });

            if (AnimationTimeline != null)
            {
                context = context.CreateCompositeTimer();
                context.Director = null;

                if (WrapMode != DirectorWrapMode.None)
                {
                    switch (WrapMode)
                    {
                        case DirectorWrapMode.Hold:
                            context.EntityManager.SetTimerAutoPause(context.Timer, DiscreteTime.Zero, new DiscreteTime(duration));
                            break;
                        case DirectorWrapMode.Loop:
                            context.EntityManager.SetTimerLoop(context.Timer, DiscreteTime.Zero, new DiscreteTime(duration));
                            break;
                    }
                }

                var range = context.Clip.GetSubTimelineRange();
                foreach (var track in AnimationTimeline.GetDOTSTracks())
                {
                    context.Tag = tag;
                    context.Track = track;
                    context.Clip = null;
                    TimelineConversion.ConvertTrack(context, range);
                }
            }
        }

        /// <summary>
        /// The default duration of the clip
        /// </summary>
        public override double duration => AnimationTimeline != null ? AnimationTimeline.duration : base.duration;

        protected int GetTrackId(ConversionContext context)
        {
            int index = 0;
            int layer = 0;
            var track = context.Track;
            var parentTrack = context.Clip.GetParentTrack();
            if (parentTrack.isSubTrack)
            {
                var kids = track.GetChildTracks();
                foreach (var c in kids)
                {
                    ++layer;
                    if (c == parentTrack)
                        break;
                }
            }
            foreach (var t in track.timelineAsset.GetOutputTracks())
            {
                if (t == context.Track)
                    break;
                ++index;
            }
            return (index << 16) | layer;
        }

        public ClipCaps clipCaps => ClipCaps.All; //GML ClipCaps.ClipIn | ClipCaps.Blending;

        public void OnTransformUpdate(Entity entity, EntityManager manager)
        {
            if (!manager.World.SafeHasComponent<SpawnClipPrefabComponent>(entity))
                return;

            // update the spawn component
            var rot = quaternion.Euler(math.radians(Rotation));
            var data = manager.GetComponentData<SpawnClipPrefabComponent>(entity);
            data.Value.Translation = Position;
            data.Value.Rotation = rot;
            data.Value.Scale = new float3(1);
            manager.SetComponentData(entity, data);

            // update the spawned entity
            var target = data.Entity;
            manager.World.SafeAddComponentData(target, new Translation() { Value = Position });
            manager.World.SafeAddComponentData(target, new Rotation() { Value = rot });
        }
    }

    static class TimelineExtensions
    {
        public static ActiveRange GetSubTimelineRange(this TimelineClip clip)
        {
            return new ActiveRange()
            {
                Start = new DiscreteTime(clip.ToLocalTimeUnbound(clip.extrapolatedStart)),
                End = new DiscreteTime(clip.ToLocalTimeUnbound(clip.extrapolatedStart + clip.extrapolatedDuration))
            };
        }
        /// <summary>
        /// Get all the DOTS-compatible tracks from a timeline 
        /// </summary>
        /// <param name="asset"></param>
        /// <returns></returns>
        public static IEnumerable<DOTSTrack> GetDOTSTracks(this TimelineAsset asset)
        {
            if (asset == null)
                return Enumerable.Empty<DOTSTrack>();

            return asset.GetOutputTracks().OfType<DOTSTrack>().Where(x => x.hasClips && !x.mutedInHierarchy).ToList();
        }

        /// <summary>Get the active range of the timeline asset</summary>
        public static ActiveRange GetRange(this TimelineAsset asset)
        {
            return new ActiveRange() { Start = DiscreteTime.Zero, End = new DiscreteTime(asset.duration) };
        }

        public static unsafe Hash128 GenerateRandomGuid()
        {
            var guid = System.Guid.NewGuid();
            var hash = new Hash128();
            hash = *(Hash128*)&guid;
            return hash;
        }
    }
}
#endif
