﻿#if CINEMACHINE_TIMELINE
using Unity.Timeline.Hybrid;
using Unity.Timeline.ECS;

namespace Unity.Cinemachine.Hybrid
{
    [System.Serializable]
    public class CmScreenComposerBehaviourData : ClipBehaviourData<ScreenComposerZones> {}

    [ClipColor(0x20, 0x6F, 0xF7)]
    [System.Serializable]
    public class CmComposerComponentClip : ComponentClip<ScreenComposerZones>
    {
        public CmScreenComposerBehaviourData template = new CmScreenComposerBehaviourData();

        public override ScreenComposerZones ComponentData
        {
            get { return template.ComponentData; }
        }
    }
}
#endif
