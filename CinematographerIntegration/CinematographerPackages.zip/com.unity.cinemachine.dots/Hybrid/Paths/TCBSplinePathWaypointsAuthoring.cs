using UnityEngine;
using Unity.Mathematics;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [AddComponentMenu("")] // Don't display in add component menu
    public class TCBSplinePathWaypointsAuthoring : DynamicBufferAuthoringBase<TCBSplinePathWaypointElement>
    {
        protected override void OnValidate()
        {
            var pathSystem = SynchronizedWorld?.GetExistingSystem<TCBSplinePathSystem>();
            pathSystem?.InvalidatePathCache(SynchronizedEntity);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Values.Clear();
            m_Values.Add(new TCBSplinePathWaypointElement { Position = new float3(0, 0, -5) });
            m_Values.Add(new TCBSplinePathWaypointElement { Position = new float3(0, 0, 5) });
            base.Reset();
        }
    }
}
