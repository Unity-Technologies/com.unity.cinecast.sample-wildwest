using UnityEngine;
using Unity.Mathematics;
using System;
using Unity.Entities.Hybrid;
using Unity.Entities;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    [DisallowMultipleComponent]
    [ExecuteAlways]
    [RequireComponent(typeof(CmPathBindingKey))]
    [RequireComponent(typeof(TCBSplinePathWaypointsAuthoring))]
    [AddComponentMenu("Cinemachine/Paths/TCB Spline Path")]
    public class TCBSplinePathAuthoring : ComponentAuthoringBase<TCBSplinePath>
    {
        /// <summary>This class holds the settings that control how the path
        /// will appear in the editor scene view.  The path is not visible in the game view</summary>
        [Serializable] public struct AppearanceSettings
        {
            [Tooltip("The color of the path itself when it is active in the editor")]
            public Color PathColor;
            [Tooltip("The color of the path itself when it is inactive in the editor")]
            public Color InactivePathColor;
            [Tooltip("The width of the railroad-tracks that are drawn to represent the path")]
            [Range(0f, 10f)]
            public float Width;
        }

        /// <summary>The settings that control how the path
        /// will appear in the editor scene view.</summary>
        [Tooltip("The settings that control how the path will appear in the editor scene view.")]
        public AppearanceSettings Appearance;

        public StableKey StableKey 
            { get { return GetComponent<StableID>().Value; } }
            
        protected override void OnValidate()
        {
            m_Value.Resolution = math.max(1, m_Value.Resolution);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new TCBSplinePath
            {
                Looped = false,
                Resolution = 50
            };
            Appearance = new AppearanceSettings
            {
                PathColor = new Color(0.5f, 1, 0.1f, 1),
                InactivePathColor = Color.gray,
                Width = 0.2f
            };
            base.Reset();
        }

        /// <summary>Hybrid mode: Call this if the path changes in such a way as to affect distances
        /// or other cached path elements</summary>
        public void InvalidatePathCache()
        {
            var s = SynchronizedWorld?.GetOrCreateSystem<TCBSplinePathSystem>();
            if (s != null)
                s.InvalidatePathCache(SynchronizedEntity);
        }

        /// <summary>
        /// Get an accessor to directly query the path.  
        /// Creates a syncpoint, so can affect performance.
        /// Do not store the accessor across multiple frames.
        /// </summary>
        /// <returns>A path accessor</returns>
        public TCBSplinePathSystem.PathSnapshot GetPathSnapshot()
        {
            if (!IsSynchronized)
                return new TCBSplinePathSystem.PathSnapshot();
            return TCBSplinePathSystem.PathSnapshot.Create(SynchronizedWorld, SynchronizedEntity);
        }
    }
}
