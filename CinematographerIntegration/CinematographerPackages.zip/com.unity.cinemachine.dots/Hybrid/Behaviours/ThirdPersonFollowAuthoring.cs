using UnityEngine;
using Unity.Mathematics;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [CameraPipeline(PipelineStage.Body)]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Procedural/Position Control/Third Person Follow")]
    public class ThirdPersonFollowAuthoring : ComponentAuthoringBase<ThirdPersonFollow>
    {
        protected override void OnValidate()
        {
            m_Value.CameraSide = Mathf.Clamp(m_Value.CameraSide, -1.0f, 1.0f);
            m_Value.Damping = math.max(0, m_Value.Damping);
#if CINEMACHINE_UNITY_PHYSICS
            m_Value.CameraRadius = math.max(1e-05f, m_Value.CameraRadius);
            m_Value.DampingIntoCollision = math.max(0, m_Value.DampingIntoCollision);
            m_Value.DampingFromCollision = math.max(0, m_Value.DampingFromCollision);
#endif
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new ThirdPersonFollow
            {
                ShoulderOffset = new float3(0.7f, 0.5f, 0.0f),
                VerticalArmLength = 1,
                CameraSide = 1.0f,
                CameraDistance = 3.0f,
                Damping = new float3(0.1f, 0.2f, 0.2f),
#if CINEMACHINE_UNITY_PHYSICS
                CameraRadius = 0.2f,
                CameraCollideAgainst = 0,
                DampingIntoCollision = 0.1f,
                DampingFromCollision = 1,
#endif
            };
            base.Reset();
        }
    }
}
