using Unity.Mathematics;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [CameraExtension]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Extensions/Size Framing")]
    public class SizeFramingAuthoring : ComponentAuthoringBase<SizeFraming>
    {
        protected override void OnValidate()
        {
            m_Value.ScreenFit = math.max(SizeFraming.kMinScreenFitSize, m_Value.ScreenFit);
            m_Value.ScreenFit.y = math.max(m_Value.ScreenFit.x, m_Value.ScreenFit.y);
            m_Value.Damping = math.max(0, m_Value.Damping);
            m_Value.DollyRange.y = math.max(m_Value.DollyRange.x, m_Value.DollyRange.y);
            m_Value.TargetDistance = math.max(float2.zero, m_Value.TargetDistance);
            m_Value.TargetDistance.y = math.max(m_Value.TargetDistance.x, m_Value.TargetDistance.y);
            m_Value.FovRange.x = math.clamp(m_Value.FovRange.x, 1, 179);
            m_Value.FovRange.y = math.clamp(m_Value.FovRange.y, m_Value.FovRange.x, 179);
            m_Value.OrthoSizeRange.x = math.max(0, m_Value.OrthoSizeRange.x);
            m_Value.OrthoSizeRange.y = math.max(m_Value.OrthoSizeRange.x, m_Value.OrthoSizeRange.y);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new SizeFraming
            {
                ScreenFit = 0.8f,
                Damping = 1f,
                Framing = SizeFraming.FramingMode.Horizontal,
                Adjustment = SizeFraming.AdjustmentMode.ZoomOnly,
                DollyRange = new float2(-5000f, 5000f),
                TargetDistance = new float2(1, 5000f),
                FovRange = new float2(3, 60),
                OrthoSizeRange = new float2(1, 5000)
            };
            base.Reset();
        }
    }
}
