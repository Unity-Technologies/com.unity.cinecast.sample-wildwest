using UnityEngine;
using Unity.Entities;
using UnityEngine.Serialization;
using Unity.Entities.Hybrid;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    public interface CmNodeDebugGizmoDrawer
    {
        void DrawDebugGizmosForNode();
    }
    
    [RequireComponent(typeof(CmNodeBindingKey))]
    [ExecuteAlways]
    public abstract class CmNodeAuthoringBase : EntityBehaviourAuthoringBase
    {
        /// <summary>What CM Channel this node will broadcast to.  Setting it to none will produce default
        /// behaviour: node will output to the default top-level channel</summary>
        [FormerlySerializedAs("AssignTo")]
        [Tooltip("What CM Channel this node will broadcast to.  Setting it to none will produce default "
            + "behaviour: node will output to the default top-level channel.")]
        public StableReference<CmChannelBindingKey> OutputChannel = new StableReference<CmChannelBindingKey>();

        /// <summary>The priority will determine which camera becomes active based on the
        /// state of other cameras and this camera.  Higher numbers have greater priority.
        /// </summary>
        [SerializeField]
        [FormerlySerializedAs("Priority")]
        [Tooltip("The priority will determine which camera becomes active based on the "
            + "state of other cameras and this camera.  Higher numbers have greater priority.")]
        int m_Priority = 10;

        public int Priority
        {
            get
            {
                if (IsSynchronized)
                    return SynchronizedWorld.EntityManager.GetComponentData<NodePriority>(SynchronizedEntity).Priority;
                return m_Priority;
            }
            set
            {
                m_Priority = value;
                if (IsSynchronized)
                    SynchronizedWorld.EntityManager.SetComponentData(SynchronizedEntity, new NodePriority { Priority = m_Priority });
            }
        }

        /// <summary>Hint for blending positions to and from this node</summary>
        /// // GML todo: make bitfield not enum
        public enum BlendHintValue
        {
            /// <summary>Normal state blending</summary>
            None = NodeBlendHint.BlendHintValue.Nothing,
            /// <summary>Spherical blend about the LookAt target (if any)</summary>
            SphericalPositionBlend = NodeBlendHint.BlendHintValue.SphericalPositionBlend,
            /// <summary>Cylindrical blend about the LookAt target (if any)</summary>
            CylindricalPositionBlend = NodeBlendHint.BlendHintValue.CylindricalPositionBlend,
            /// <summary>Just slerp the rotation, don't consider the LookAt target</summary>
            IgnoreLookAtTarget = NodeBlendHint.BlendHintValue.IgnoreLookAtTarget
        }
        /// <summary>Hint for blending positions to and from this node</summary>
        [Tooltip("Hint for blending positions to and from this node")]
        public BlendHintValue m_BlendHint;

        public BlendHintValue BlendHint
        {
            get
            {
                if (IsSynchronized)
                    return (BlendHintValue)SynchronizedWorld.EntityManager.GetComponentData<NodeBlendHint>(SynchronizedEntity).Hint;
                return m_BlendHint;
            }
            set
            {
                m_BlendHint = value;
                if (IsSynchronized)
                    SynchronizedWorld.EntityManager.SetComponentData(
                        SynchronizedEntity, new NodeBlendHint { Hint = (NodeBlendHint.BlendHintValue)m_BlendHint });
            }
        }

/* GML todo: maybe we don't need this, if we handle user input properly
        /// <summary>When this node goes Live, attempt to force the position to be the 
        /// same as the current position of the Unity Camera</summary>
        [Tooltip("When this node goes Live, attempt to force the position to be the "
            + "same as the current position of the Unity Camera")]
        public bool InheritPosition;
*/

        public StableKey StableKey
        {
            get
            {
                var b = GetComponent<StableID>();
                return b != null ? b.Value : StableKey.Default;
            }
        }

        /// <summary>Get the CmNode representation of this node</summary>
        public CmNode Node 
        { 
            get { return IsSynchronized ? CmNode.FromEntity(SynchronizedEntity, SynchronizedWorld) : new CmNode(); } 
        }

        /// <summary>Is the node currently controlling a Camera?</summary>
        public bool IsLive { get { return Node.IsLive(); } }

        /// <summary>Prioritize the Node. This makes it dominant among all nodes 
        /// with the same priority. If there is no higher priority node, this 
        /// node will become Live</summary>
        public void Prioritize() { Node.Prioritize(); }

        /// <summary>The CameraState object holds all of the information
        /// necessary to position the Unity camera.  It is the output of this class.</summary>
        public virtual CameraState State { get { return Node.GetState(); } }

        public StableKey GetParentChannelId()
        {
            if (!OutputChannel.Referent.IsValid)
            {
                if (transform.parent != null)
                {
                    var c = transform.parent.GetComponentInParent<CmChannelBindingKey>();
                    if (c != null)
                        return c.StableKey;
                }
            }
            return OutputChannel.Referent;
        }

        protected override void Reset()
        {
            m_Priority = 10;
            base.Reset();
        }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            context.EntityManager.AddSharedComponentData(
                entity, new NodeChannelAssignment { ChannelId = GetParentChannelId() });

            context.EntityManager.AddComponentData(entity, new NodePriority { Priority = m_Priority });
            context.EntityManager.AddComponentData(entity, new NodeBlendHint
            {
                Hint = (NodeBlendHint.BlendHintValue)m_BlendHint,
            });
        }

        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            m_Priority = context.EntityManager.GetComponentData<NodePriority>(entity).Priority;
            m_BlendHint = (BlendHintValue)context.EntityManager.GetComponentData<NodeBlendHint>(entity).Hint;
        }
    }

    [RequireComponent(typeof(CmChannelBindingKey))]
    public abstract class CmChannelNodeBase : CmNodeAuthoringBase
    {
        /// <summary>When enabled, the current camera and blend will be indicated
        /// in the game window, for debugging</summary>
        [Header("Channel")]
        [Tooltip("When enabled, the current child camera and blend will be indicated in "
         + "the game window, for debugging")]
        public bool ShowDebugText = false;

        [SerializeField]
        [HideFoldout]
        [FormerlySerializedAs("Channel")]
        public CmChannel m_Channel;

        public CmChannel Channel
        {
            get
            {
                if (IsSynchronized)
                    return SynchronizedWorld.EntityManager.GetComponentData<CmChannel>(SynchronizedEntity);
                return m_Channel;
            }
            set
            {
                m_Channel = value;
                if (IsSynchronized)
                    SynchronizedWorld.EntityManager.SetComponentData(SynchronizedEntity, m_Channel);
            }
        }
        
        protected override void OnValidate()
        {
            m_Channel.Validate();
            base.OnValidate();
        }

        /// <summary>Makes sure the internal child cache is up to date</summary>
        protected virtual void OnEnable()
        {
#if UNITY_EDITOR
            DebugHelpers.OnGUIHandlers -= OnGuiHandler;
            DebugHelpers.OnGUIHandlers += OnGuiHandler;
#endif
        }

        protected virtual void OnDisable()
        {
#if UNITY_EDITOR
            DebugHelpers.OnGUIHandlers -= OnGuiHandler;
#endif
        }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            base.PushToEntity(entity, context);
            context.EntityManager.AddComponentData(entity, m_Channel);
        }
        
        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            base.PullFromEntity(entity, context);
            m_Channel = context.EntityManager.GetComponentData<CmChannel>(entity);
        }

#if UNITY_EDITOR
        /// Will only be called if Unity Editor - never in build
        private void OnGuiHandler()
        {
            if (!ShowDebugText)
                DebugHelpers.ReleaseScreenPos(this);
            else
            {
                var s = Node.GetDescription(SynchronizedWorld);
                Rect r = DebugHelpers.GetScreenPos(this, s, GUI.skin.box);
                GUI.Label(r, s, GUI.skin.box);
            }
        }
#endif
    }
}
