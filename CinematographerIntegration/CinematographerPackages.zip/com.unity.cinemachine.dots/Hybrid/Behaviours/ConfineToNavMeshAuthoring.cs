using Unity.Mathematics;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [CameraExtension]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Extensions/Confine to NavMesh")]
    public class ConfineToNavMeshAuthoring : ComponentAuthoringBase<ConfineToNavMesh>
    {
        public bool ShowDebugPath;

        protected override void OnValidate()
        {
            m_Value.Speed = math.max(0, m_Value.Speed);
            m_Value.Damping = math.max(0, m_Value.Damping);
            m_Value.MaxSearchRadius = math.max(1, m_Value.MaxSearchRadius);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new ConfineToNavMesh
            {
                Speed = 10,
                Damping = 0.3f,
                BaseOffset = 2,
                AgentType = 0,
                AreaMask = -1,
                MaxSearchRadius = 100
            };
            base.Reset();
        }

        void OnDrawGizmos()
        {
            if (ShowDebugPath && IsSynchronized 
                && SynchronizedWorld.EntityManager.HasComponent<ConfineToNavMeshPath>(SynchronizedEntity))
            {
                var oldColor = Gizmos.color;
                Gizmos.color = Color.yellow;
                var path = SynchronizedWorld.EntityManager.GetBuffer<ConfineToNavMeshPath>(SynchronizedEntity);
                for (int i = 1; i < path.Length; ++i)
                    Gizmos.DrawLine(path[i-1].Position, path[i].Position);
                Gizmos.color = oldColor;
            }
        }
    }
}
