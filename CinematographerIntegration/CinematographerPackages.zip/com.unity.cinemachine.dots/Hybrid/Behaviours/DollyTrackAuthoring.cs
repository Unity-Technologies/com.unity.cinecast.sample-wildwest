using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;
using Unity.Entities.Hybrid;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [CameraPipeline(PipelineStage.Body)]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Procedural/Position Control/Dolly Track")]
    public class DollyTrackAuthoring : ComponentAuthoringBase<DollyTrack>
    {
        /// <summary>The path to which the camera will be constrained.  This must be non-null.</summary>
        [Tooltip("The path to which the camera will be constrained.  This must be non-null.")]
        public StableReference<CmPathBindingKey> Path = new StableReference<CmPathBindingKey>();

        protected override void OnValidate()
        {
            m_Value.Damping = math.max(0, m_Value.Damping);
            m_Value.AngularDamping = math.max(0, m_Value.AngularDamping);
            var a = m_Value.AutoDolly;
            a.SearchRadius = math.max(0, a.SearchRadius);
            a.SearchResolution = math.max(1, a.SearchResolution);
            m_Value.AutoDolly = a;
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new DollyTrack
            {
                PositionUnits = TCBSplinePathSystem.PositionUnits.Distance,
                Damping = new float3(0, 0, 1),
                CameraUp = DollyTrack.CameraUpMode.Default,
                AutoDolly = new DollyTrack.AutoDollySettings
                {
                    SearchRadius = 2,
                    SearchResolution = 5
                }
            };
            base.Reset();
        }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            // Don't call the base class, because of the reference
            var v = m_Value;
            v.PathKey.StableKey = Path.Referent;
            context.EntityManager.AddComponentData(entity, v);
        }

        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            // Don't call the base class, because of the reference
            m_Value = context.EntityManager.GetComponentData<DollyTrack>(entity);
            m_Value.PathKey = default;
        }
    }
}
