using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [CameraPipeline(PipelineStage.Body)]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Procedural/Position Control/Orbital Follow")]
    public class OrbitalFollowAuthoring : ComponentAuthoringBase<OrbitalFollow>
    {
        /// <summary>The Horizontal axis.  -180..180.  0 is the center.
        /// Rotates the camera horizontally around the target</summary>
        [Tooltip("The Horizontal axis.  Value is -180..180.  0 is the center.  "
            + "Rotates the camera horizontally around the target")]
        public InputAxisWithName HorizontalAxis;

        /// <summary>The Vertical axis.  Value is -1..1.</summary>
        [Tooltip("The Vertical axis.  Value is -1..1.  0.5 is the middle rig.")]
        public InputAxisWithName VerticalAxis;

        /// <summary>The Radial axis.  Scales the orbits.  Value is the base radius of the orbits</summary>
        [Tooltip("The Radial axis.  Scales the orbits.  Value is the base radius of the orbits")]
        public InputAxisWithName RadialAxis;

        protected override void OnValidate()
        {
            m_Value.Damping = math.max(float3.zero, m_Value.Damping);
            m_Value.AngularDamping = math.max(0, m_Value.AngularDamping);
            m_Value.SplineCurvature = math.clamp(m_Value.SplineCurvature, 0, 1);
            HorizontalAxis.Axis.Validate();
            VerticalAxis.Axis.Validate();
            RadialAxis.Axis.Validate();
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new OrbitalFollow
            {
                Binding = FollowControlSystem.BindingMode.WorldAxes,
                Damping = new float3(1, 1, 1),
                AngularDamping = 1,
                Top = new OrbitalFollow.Orbit { Height = 10, Radius = 4 },
                Middle = new OrbitalFollow.Orbit { Height = 2, Radius = 8 },
                Bottom = new OrbitalFollow.Orbit { Height = 0, Radius = 5 },
                SplineCurvature = 0,
            };

            HorizontalAxis = new InputAxisWithName
            {
                InputName = "Mouse X",
                Axis = new InputAxis
                {
                    InputControl = new InputAxisControl
                    {
                        Multiplier = -1f,
                        AccelTime = 0.2f,
                        DecelTime = 0.1f
                    },
                    Value = new InputAxisValue { Range = new float2(-180, 180), Wrap = true },
                    Recentering = new InputAxisRecentering { Wait = 1, Time = 2 }
                }
            };

            VerticalAxis = new InputAxisWithName
            {
                InputName = "Mouse Y",
                Axis = new InputAxis
                {
                    InputControl = new InputAxisControl
                    {
                        Multiplier = 1.5f,
                        AccelTime = 0.2f,
                        DecelTime = 0.2f
                    },
                    Value = new InputAxisValue { Range = new float2(-80, 80) },
                    Recentering = new InputAxisRecentering { Wait = 1, Time = 2 }
                }
            };

            RadialAxis = new InputAxisWithName
            {
                InputName = "Mouse ScrollWheel",
                Axis = new InputAxis
                {
                    InputControl = new InputAxisControl
                    {
                        Multiplier = 1f,
                        AccelTime = 0.2f,
                        DecelTime = 0.2f
                    },
                    Value = new InputAxisValue { Range = new float2(1, 10) },
                    Recentering = new InputAxisRecentering { Wait = 1, Time = 2 }
                }
            };
            base.Reset();
        }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            base.PushToEntity(entity, context);
            var index = InputAxisXYZ.AddInputToEntity(context.EntityManager, entity, new InputAxisXYZ
            {
                X = InputAxis.WithInputName(HorizontalAxis.Axis, HorizontalAxis.InputName),
                Y = InputAxis.WithInputName(VerticalAxis.Axis, VerticalAxis.InputName),
                Z = InputAxis.WithInputName(RadialAxis.Axis, RadialAxis.InputName)
            });
            context.EntityManager.AddComponentData(entity, new OrbitalFollowState { InputAxisIndex = index });
        }

        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            base.PullFromEntity(entity, context);
            var state = context.EntityManager.GetComponentData<OrbitalFollowState>(entity);
            var buffer = context.EntityManager.GetBuffer<InputAxisXYZ>(entity);
            var xyz = buffer[state.InputAxisIndex];
            HorizontalAxis.Axis = xyz.X;
            VerticalAxis.Axis = xyz.Y;
            RadialAxis.Axis = xyz.Z;
        }
    }
}
