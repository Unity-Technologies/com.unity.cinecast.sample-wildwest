using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Mathematics;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [CameraPipeline(PipelineStage.Aim)]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Procedural/Rotation Control/Third Person Aim")]
    public class ThirdPersonAimAuthoring : ComponentAuthoringBase<ThirdPersonAim>
    {
        protected override void OnValidate()
        {
            m_Value.AimDistance = math.max(MathHelpers.Epsilon, m_Value.AimDistance);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new ThirdPersonAim
            {
                AimDistance = 200f,
#if CINEMACHINE_UNITY_PHYSICS
                TargetLayers = 1
#endif
            };
            base.Reset();
        }
    }
}
