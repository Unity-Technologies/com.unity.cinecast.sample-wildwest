using UnityEngine;
using Unity.Entities;
using System;
using System.Collections.Generic;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    /// <summary>
    /// This component in the Cinemachine procedural camera pipline adds a custom noise
    /// to the camera's position and/or rotation.
    /// </summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [CameraPipeline(PipelineStage.Noise)]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Procedural/Noise/Procedural Noise")]
    public class ProceduralNoiseAuthoring : ComponentAuthoringBase<ProceduralNoise>
    {
        /// <summary>
        /// Noise settings for a single noise channel.  Results of all the channels are combined 
        /// additively for the final noise output.
        /// </summary>
        [Serializable]
        public struct Channel
        {
            /// <summary>
            /// Serialized property for referencing a NoiseSettings asset
            /// </summary>
            [Tooltip("The asset containing the Noise Profile.  Define the frequencies and amplitudes "
                + "there to make a characteristic noise profile.  "
                + "Make your own or just use one of the many presets.")]
            [GeneratedWaveProfileProperty]
            public GeneratedWaveProfile NoiseProfile;

            /// <summary>
            /// Gain to apply to the amplitudes defined in the settings asset.
            /// </summary>
            [Tooltip("Gain to apply to the amplitudes defined in the NoiseSettings asset.  "
                + "1 is normal.  Setting this to 0 completely mutes the noise.")]
            public float AmplitudeGain;

            /// <summary>
            /// Scale factor to apply to the frequencies defined in the settings asset.
            /// </summary>
            [Tooltip("Scale factor to apply to the frequencies defined in the NoiseSettings asset.  "
                + "1 is normal.  Larger magnitudes will make the noise shake more rapidly.")]
            public float FrequencyGain;
        }

        /// <summary>
        /// This is a collection of independent signals, each defined by a noise profile.
        /// All signals are generated simultaneously and added together.
        /// </summary>
        public List<Channel> SignalDefinition = new List<Channel>();

        /// <summary>Standard EntityBehaviour implementation</summary>
        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            base.PushToEntity(entity, context);
            if (enabled && SignalDefinition != null)
            {
                var m = context.EntityManager;
                for (int i = 0; i < SignalDefinition.Count; ++i)
                {
                    var c = SignalDefinition[i];
                    if (c.NoiseProfile == null)
                        continue;

                    var channelBuffer = m.AddBuffer<ProceduralNoiseChannelElement>(entity);
                    channelBuffer.Add(new ProceduralNoiseChannelElement 
                    {
                        AmplitudeGain = c.AmplitudeGain,
                        FrequencyGain = c.FrequencyGain
                    });

                    var noise = GeneratedWaveProfile.ToNoiseArray(
                        Collections.Allocator.Temp, c.NoiseProfile.PositionNoise);
                    var posBuffer = m.AddBuffer<ProceduralPosNoiseElement>(entity);
                    for (int j = 0; j < noise.Length; ++j)
                        posBuffer.Add(new ProceduralPosNoiseElement { ChannelIndex = i, Value = noise[j] });
                    noise.Dispose();

                    noise = GeneratedWaveProfile.ToNoiseArray(
                        Collections.Allocator.Temp, c.NoiseProfile.OrientationNoise);
                    var rotBuffer = m.AddBuffer<ProceduralRotNoiseElement>(entity);
                    for (int j = 0; j < noise.Length; ++j)
                        rotBuffer.Add(new ProceduralRotNoiseElement { ChannelIndex = i, Value = noise[j] });
                    noise.Dispose();
                }
            }
        }

        /// <summary>Standard EntityBehaviour implementation</summary>
        protected override void Reset()
        {
            m_Value = new ProceduralNoise
            {
                ArmLength = 0.2f,
                NoiseSeed = 0
            };
            SignalDefinition.Clear();
            SignalDefinition.Add(new Channel { AmplitudeGain = 1, FrequencyGain = 1 });
            base.Reset();
        }
    }
}
