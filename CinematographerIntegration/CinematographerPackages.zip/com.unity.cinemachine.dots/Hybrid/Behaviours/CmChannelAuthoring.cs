#if UNITY_EDITOR
#define SHOW_DEBUG_TEXT
#endif

using UnityEngine;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine.Serialization;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    /// <summary>
    /// A Cinemachine channel is a node that manages multiple CM nodes, and mixes
    /// them to generate a single CmaeraState output, so that it can drive a Unity Camera.
    ///
    /// Channels can have different strategies to do the mixing, and custom versions with
    /// proprietary mixing srategies can be authored.
    ///
    /// Cm nodes are assigned to a Cm Channel.  Cm channels can be assigned to other Cm
    /// Channels, nesting them all the way to a top-level (or root) channel.  Multiple top-level
    /// channels can co-exist.
    ///
    /// It is up to the content author to manage these channels and pipe their output to
    /// the desired destination.  A Cm Listener behaviour can be used, for example, to
    /// pipe the output to a Unity Camera object.
    /// </summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [RequireComponent(typeof(CmChannelBindingKey))]
    [AddComponentMenu("Cinemachine/Channels/Cm Channel")]
    public class CmChannelAuthoring : EntityBehaviourAuthoringBase
    {
        /// <summary>When enabled, the current camera and blend will be indicated
        /// in the game window, for debugging</summary>
        [Tooltip("When enabled, the current child camera and blend will be indicated in "
            + "the game window, for debugging")]
        public bool ShowDebugText = false;

        /// <summary>
        /// When enabled, shows the camera's frustum in the scene view.
        /// </summary>
        [Tooltip("When enabled, the camera's frustum will be shown at all times in the scene view")]
        public bool ShowCameraFrustum;

        [HideFoldout] [SerializeField]
        [FormerlySerializedAs("Channel")]
        CmChannel m_Channel;

        /// <summary>
        /// Get/set the channel settings
        /// </summary>
        public CmChannel Channel
        {
            get
            {
                if (IsSynchronized)
                    return SynchronizedWorld.EntityManager.GetComponentData<CmChannel>(SynchronizedEntity);
                return m_Channel;
            }
            set
            {
                m_Channel = value;
                if (IsSynchronized)
                    SynchronizedWorld.EntityManager.SetComponentData(SynchronizedEntity, m_Channel);
            }
        }

        /// <summary>
        /// This is the asset which contains custom settings for specific blends.
        /// </summary>
        public CustomBlends CustomBlends;

        /// <summary>API for the Unity Editor.</summary>
        /// <returns>Color used to indicate that a camera is in Solo mode.</returns>
        public static Color GetSoloGUIColor() { return Color.Lerp(Color.red, Color.yellow, 0.8f); }

        /// <summary>Get/set the current solo node.</summary>
        public CmNode SoloCamera
        {
            get { return new ChannelHelper(SynchronizedEntity, SynchronizedWorld).SoloCamera; }
            set { var h = new ChannelHelper(SynchronizedEntity, SynchronizedWorld); h.SoloCamera = value; }
        }

        /// <summary>Get the current state that would be applied to the Camera.</summary>
        public CameraState CameraState { get => new ChannelHelper(SynchronizedEntity, SynchronizedWorld).State; }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            var c = m_Channel;
            c.Settings.Aspect = 1; // placeholder so it's not 0
            context.EntityManager.AddComponentData(entity, c);
            CustomBlends.AddCustomBlendsToEntity(entity, context.EntityManager, CustomBlends);
            context.EntityManager.AddSharedComponentData(entity, new NodeChannelAssignment());
        }

        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            m_Channel = context.EntityManager.GetComponentData<CmChannel>(entity);
        }
        
        protected override void OnValidate()
        {
            m_Channel.Validate();
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Channel = new CmChannel
            {
                Settings = new CmChannel.ChannelSettings { WorldOrientation = quaternion.identity },
                Sorting = CmChannel.SortMode.PriorityThenQuality,
                DefaultBlend = new TransitionDefinition
                {
                    Curve = TransitionCurve.Default,
                    Length = 1
                }
            };
            base.Reset();
        }

        /// <summary>Makes sure the internal child cache is up to date</summary>
        void OnEnable()
        {
#if SHOW_DEBUG_TEXT
            DebugHelpers.OnGUIHandlers -= OnGuiHandler;
            DebugHelpers.OnGUIHandlers += OnGuiHandler;
#endif
        }

        void OnDisable()
        {
#if SHOW_DEBUG_TEXT
            DebugHelpers.OnGUIHandlers -= OnGuiHandler;
#endif
        }


#if SHOW_DEBUG_TEXT
        void OnGUI()
        {
            if (DebugHelpers.OnGUIHandlers != null)
                DebugHelpers.OnGUIHandlers();
        }

        /// Will only be called in Unity Editor - never in build
        void OnGuiHandler()
        {
            if (!ShowDebugText)
                DebugHelpers.ReleaseScreenPos(this);
            else if (IsSynchronized)
            {
                // Show the active camera and blend
                var w = SynchronizedWorld;
                var ch = new ChannelHelper(SynchronizedEntity, w);
                var s = $"{ch.Name}: ";
                bool solo = !ch.SoloCamera.IsNull;
                if (solo)
                    s += "SOLO ";
                s += ch.ActiveBlend.GetDescription(w);

                Color color = GUI.color;
                if (solo)
                    GUI.color = GetSoloGUIColor();
                Rect r = DebugHelpers.GetScreenPos(this, s, GUI.skin.box);
                GUI.Label(r, s, GUI.skin.box);
                GUI.color = color;
            }
        }
#endif
    }
}
