using Unity.Mathematics;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [CameraPipeline(PipelineStage.Body)]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Procedural/Position Control/Follow")]
    public class FollowAuthoring : ComponentAuthoringBase<FollowControl>
    {
        protected override void OnValidate()
        {
            m_Value.Damping = math.max(float3.zero, m_Value.Damping);
            m_Value.AngularDamping = math.max(0, m_Value.AngularDamping);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new FollowControl
            {
                Binding = FollowControlSystem.BindingMode.CameraAxesWithWorldUp,
                FollowOffset = new float3(0, 0, -10f),
                Damping = new float3(1, 1, 1),
                AngularDamping = 1
            };
            base.Reset();
        }
    }
}
