using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.Serialization;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [CameraPipeline(PipelineStage.Body)]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Procedural/Position Control/Composed Follow")]
    public class ComposedFollowAuthoring : ComponentAuthoringBase<ComposedFollow>
    {
        [SerializeField]
        [HideFoldout]
        [FormerlySerializedAs("ComposerZones")]
        private ScreenComposerZones m_ComposerZones;

        public ScreenComposerZones ComposerZones
        {
            get
            {
                if (IsSynchronized)
                    return SynchronizedWorld.EntityManager.GetComponentData<ScreenComposerZones>(SynchronizedEntity);
                return m_ComposerZones;
            }
            set
            {
                m_ComposerZones = value;
                if (IsSynchronized)
                    SynchronizedWorld.EntityManager.SetComponentData(SynchronizedEntity, m_ComposerZones);
            }
        }
        
        protected override void OnValidate()
        {
            m_Value.Lookahead.Validate();
            m_Value.Damping = math.max(float3.zero, m_Value.Damping);
            m_ComposerZones.Validate();
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_ComposerZones = new ScreenComposerZones { SoftZoneSize = new float2(0.6f, 0.6f) };
            m_Value = new ComposedFollow
            {
                Lookahead = new TargetPositionPredictor { Smoothing = 0.2f },
                Damping = new float3(1, 1, 1),
                CameraDistance = new float2(10, 10),
                CenterOnActivate = true
            };
            base.Reset();
        }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            base.PushToEntity(entity, context);
            context.EntityManager.AddComponentData(entity, m_ComposerZones);
        }

        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            base.PullFromEntity(entity, context);
            m_ComposerZones = context.EntityManager.GetComponentData<ScreenComposerZones>(entity);
        }
    }
}
