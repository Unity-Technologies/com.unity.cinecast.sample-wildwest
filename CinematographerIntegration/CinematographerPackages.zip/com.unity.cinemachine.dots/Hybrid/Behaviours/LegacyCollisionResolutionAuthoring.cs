#if CINEMACHINE_LEGACY_PHYSICS

using Unity.Mathematics;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [DisallowMultipleComponent]
    [CameraExtension]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Extensions/Legacy Collision Resolution")]
    public class LegacyCollisionResolutionAuthoring 
        : ComponentAuthoringBase<LegacyCollisionResolution>
    {
        protected override void OnValidate()
        {
            var v = Value;
            v.MinimumDistanceFromTarget = math.max(0.01f, v.MinimumDistanceFromTarget);
            v.MinimumOcclusionTime = math.max(0, v.MinimumOcclusionTime);
            v.CameraRadius = math.max(0.01f, v.CameraRadius);
            v.SmoothingTime = math.max(0, v.SmoothingTime);
            v.Damping = math.max(0, v.Damping);
            v.DampingWhenOccluded = math.max(0, v.DampingWhenOccluded);
            Value = v;
            base.OnValidate();
        }

        protected override void Reset()
        {
            Value = new LegacyCollisionResolution
            {
                CollideAgainst = 1,
                MinimumDistanceFromTarget = 0.2f,
                MinimumOcclusionTime = 0.2f,
                CameraRadius = 0.01f,
                SmoothingTime = 0.5f,
                Damping = 0.5f,
                DampingWhenOccluded = 0.2f
            };
            base.Reset();
        }
    }
}
#endif
