using UnityEngine;
using Unity.Mathematics;
using Unity.Entities;
using System.Collections.Generic;
using System;
using UnityEngine.Serialization;
using Unity.Entities.Hybrid;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    /// <summary>
    /// Cm Mixer is a "manager camera" that takes on the state of
    /// the weighted average of the states of its managed nodes.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(CmChannelBindingKey))]
    [AddComponentMenu("Cinemachine/Channels/Cm Mixer")]
    public class CmMixerAuthoring : CmNodeAuthoringBase
    {
        /// <summary>Input node definition for the Cm Mixer</summary>
        [Serializable]
        public class InputNode
        {
            /// <summary>The node to to add to the mix</summary>
            [Tooltip("The node to add to the mix")]
            public StableReference<CmNodeBindingKey> Node = new StableReference<CmNodeBindingKey>();

            /// <summary>The strength of this node's participation in the mix.  Percentage will 
            /// be this value divided by the sum of all node weights</summary>
            [Tooltip("The strength of this node's participation in the mix.  Percentage will "
            + "be this value divided by the sum of all node weights")]
            public float Weight;

            public void Validate()
            {
                Weight = math.max(0, Weight);
            }
        }

        [SerializeField]
        [FormerlySerializedAs("Instructions")]
        [Tooltip("The target objects together with their weights that will contribute to "
            + "the group's average position, orientation, and size.")]
        internal List<InputNode> m_InputNodes = new List<InputNode>();

        /// <summary>The input objects, together with their weights, that will
        /// contribute to the group's average position, orientation, and size</summary>
        public List<InputNode> InputNodes 
        {
            get
            {
                if (!IsSynchronized)
                    return m_InputNodes;
                Synchronize(SynchronizedEntity, SynchronizedWorld.EntityManager, 
                    EntityConversionContext, m_InputNodes, false);
                return m_InputNodes;
            }
            set
            {
                m_InputNodes = value;
                if (IsSynchronized)
                    Synchronize(SynchronizedEntity, SynchronizedWorld.EntityManager, 
                        EntityConversionContext, m_InputNodes, true);
            }
        }
        
        protected override void Reset()
        {
            m_InputNodes.Clear();
            base.Reset();
        }

        protected override void OnValidate()
        {
            for (int i = 0; i < m_InputNodes.Count; ++i)
            {
                var inst = m_InputNodes[i];
                inst.Validate();
                m_InputNodes[i] = inst;
            }
            base.OnValidate();
        }

        void Synchronize(
            Entity entity, EntityManager m, ConversionContext context, 
            List<InputNode> targets, bool pushToEntity)
        {
            if (pushToEntity)
            {
                var count = targets.Count;

                // Make sure any structural changes happen before we call GetBuffer()
                for (int i = 0; i < count; ++i)
                    context.GetPrimaryEntity(targets[i].Node.GameObject);

                var buffer = m.GetBuffer<CmMixerInstruction>(entity);
                buffer.Clear();
                buffer.Capacity = count;
                for (int i = 0; i < count; ++i)
                {
                    var go = targets[i].Node.GameObject;
                    if (go != null)
                    {
                        buffer.Add(new CmMixerInstruction
                        {
                            Node = context.GetPrimaryEntity(go),
                            Weight = targets[i].Weight
                        });
                    }
                }
            }
            else
            {
                // Pull the weights only  // GML TODO: is this right?
                var buffer = m.GetBuffer<CmMixerInstruction>(entity);
                int count = Mathf.Min(buffer.Length, targets.Count);
                for (int i = 0; i < count; ++i)
                {
                    var t = targets[i];
                    t.Weight = buffer[i].Weight;
                    targets[i] = t;
                }
            }
        }
        
        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            base.PushToEntity(entity, context);
            context.EntityManager.AddComponentData(entity, new CmChannel
            {
                Settings = new CmChannel.ChannelSettings { WorldOrientation = quaternion.identity },
                Sorting = CmChannel.SortMode.Custom,
            });
            context.EntityManager.AddBuffer<CmMixerInstruction>(entity);
            Synchronize(entity, context.EntityManager, context, m_InputNodes, true);
        }

        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            base.PullFromEntity(entity, context);
            Synchronize(entity, context.EntityManager, context, m_InputNodes, false);
        }
    }
}
