#if CINEMACHINE_UNITY_PHYSICS

using Unity.Mathematics;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [CameraExtension]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Extensions/Camera Decollider")]
    public class CameraDecolliderAuthoring : ComponentAuthoringBase<CameraDecollider>
    {
        protected override void OnValidate()
        {
            m_Value.CameraRadius = math.max(0.01f, m_Value.CameraRadius);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new CameraDecollider
            {
                CollideAgainst = ~0,
                CameraRadius = 0.1f,
            };
            base.Reset();
        }
    }
}
#endif
