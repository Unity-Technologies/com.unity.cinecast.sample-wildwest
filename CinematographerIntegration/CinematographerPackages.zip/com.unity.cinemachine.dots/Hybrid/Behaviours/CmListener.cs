using System;
using System.Collections.Generic;
using Unity.Entities;
using UnityEngine;
using UnityEngine.Events;
using Unity.Entities.Hybrid;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    [DisallowMultipleComponent]
    [ExecuteAlways]
    [AddComponentMenu("Cinemachine/Cm Listener")]
    public class CmListener : MonoBehaviour
    {
        /// <summary>What channel is driving this Camera.  Leave empty for default channel</summary>
        [Tooltip("What channel is driving this Camera.  Leave empty for default channel")]
        public StableReference<CmChannelBindingKey> ChannelOverride = new StableReference<CmChannelBindingKey>();

        /// <summary>This enum defines the options available for the Camera Transform update time.</summary>
        public enum UpdateMethodType
        {
            /// <summary>Camera's transform is updated in FixedUpdate</summary>
            FixedUpdate,
            /// <summary>Camera's transform is updated in Update</summary>
            Update,
            /// <summary>Camera's transform is updated in LateUpdate</summary>
            LateUpdate,
            /// <summary>Camera's transform is updated in OnPreCull</summary>
            OnPreCull
        };

        /// <summary>When the Camera gets positioned by the CmNode.</summary>
        [Tooltip("When the Camera gets positioned by the CmNode")]
        public UpdateMethodType UpdateMethod;

        /// <summary>Called when the current live node changes.  If a blend is involved,
        /// then this will be called on the first frame of the blend.
        /// Parameters are: incoming node, outgoing node, isCut</summary>
        [Serializable] public class ActivationEvent : UnityEvent<CmNode, CmNode, bool> {}

        /// <summary>Event with a CmListener parameter</summary>
        [Serializable] public class Event : UnityEvent<CmListener> {}

        /// <summary>
        /// A container to hold eventsa that the listener can generate.
        /// </summary>
        [Serializable]
        public struct ListenerEvents
        {
            /// <summary>Invoked when the current live node changes.  If a blend is involved,
            /// then this will be called on the first frame of the blend.
            /// Parameters are: incoming node, outgoing node, isCut</summary>
            public ActivationEvent NodeActivated;

            /// <summary>This event will fire after a listener updates its Camera</summary>
            public Event CameraUpdated;
        }
        public ListenerEvents Events;

        /// <summary>
        /// Get the Unity Camera that is attached to this GameObject.  This is the camera
        /// that will be controlled by the listener.
        /// </summary>
        public Camera OutputCamera
        {
            get
            {
                if (m_outputCamera == null && !Application.isPlaying)
                    TryGetComponent(out m_outputCamera);
                return m_outputCamera;
            }
        }
        Camera m_outputCamera = null; // never use directly - use accessor

        /// <summary>
        /// List of all CmListeners currently instantiated
        /// </summary>
        static List<CmListener> sAllListeners = new List<CmListener>();

        /// <summary>
        /// Find the first CmListener that is listening to a given channel
        /// </summary>
        /// <param name="channelId">The ID of the channel for which a listener is sought</param>
        /// <returns>The first CmListenr that is listening to the channel, or null if none.</returns>
        public static CmListener FindListener(StableKey channelId)
        {
            for (int i = 0; i < sAllListeners.Count; ++i)
                if (!sAllListeners[i].ChannelOverride.Referent.IsValid
                        || sAllListeners[i].ChannelOverride.Referent == channelId)
                    return sAllListeners[i];
            return null;
        }

        World World { get => ClientHooks.DefaultWorld; }

        ChannelHelper ChannelHelper { get => new ChannelHelper(ChannelOverride.Referent, World); }

        /// <summary>Get the current state that would be applied to the Camera.</summary>
        public CameraState CameraState { get => ChannelHelper.State; }

        void Awake()
        {
            sAllListeners.Add(this);
        }

        void OnDestroy()
        {
            for (int i = sAllListeners.Count-1; i >= 0; --i)
                if (sAllListeners[i] = this)
                    sAllListeners.RemoveAt(i);
        }

        void Reset()
        {
            UpdateMethod = UpdateMethodType.LateUpdate;
        }

        void OnEnable()
        {
            m_outputCamera = GetComponent<Camera>();
            liveNodesPreviousFrame.Clear();
        }

        void FixedUpdate()
        {
            if (UpdateMethod == UpdateMethodType.FixedUpdate)
                ProcessActiveNode();
        }

        void Update()
        {
            // Update the channel settings to match our camera and aspect
            var camera = OutputCamera;
            if (camera != null)
            {
                var ch = ChannelHelper;
                CmChannel.ChannelSettings.ProjectionType p = camera.orthographic
                    ? CmChannel.ChannelSettings.ProjectionType.Orthographic
                    : CmChannel.ChannelSettings.ProjectionType.Perspective;
                var w = World;
                var c = ch.ChannelData;
                if (c.Settings.Aspect != camera.aspect || c.Settings.Projection != p)
                {
                    c.Settings.Aspect = camera.aspect;
                    c.Settings.Projection = p;
                    w.SafeSetComponentData(ch.Entity, c);
                }
            }
            if (UpdateMethod == UpdateMethodType.Update)
                ProcessActiveNode();
        }

        void LateUpdate()
        {
            if (UpdateMethod == UpdateMethodType.LateUpdate)
                ProcessActiveNode();
        }

        void OnPreCull()
        {
            if (UpdateMethod == UpdateMethodType.OnPreCull)
                ProcessActiveNode();
        }

        // We keep track of the live cameras so we can send activation events
        List<CmNode> liveNodesPreviousFrame = new List<CmNode>();
        List<CmNode> scratchList = new List<CmNode>();

        void ProcessActiveNode()
        {
            var ch = ChannelHelper;
            var state = ch.State;

            // Send activation events
            var channelSystem = ch.ChannelSystem;
            if (channelSystem != null && Events.NodeActivated != null)
            {
                scratchList.Clear();
                channelSystem.GetLiveNodes(ch.StableKey, scratchList, true); // deep

                // Send transition notification to observers
                for (int i = scratchList.Count - 1; i >= 0; --i)
                {
                    var node = scratchList[i];
                    if (!node.IsNull && !liveNodesPreviousFrame.Contains(node))
                    {
                        var ch1 = new ChannelHelper(node.GetChannelAssignment(), World);
                        var previous = CmNode.FromEntity(ch1.ChannelState.PreviousActiveNode, World);
                        Events.NodeActivated.Invoke(node, previous, ch.ChannelState.IsCut);
                    }
                }
                var temp = liveNodesPreviousFrame;
                liveNodesPreviousFrame = scratchList;
                scratchList = temp;
            }

            // If there is no current node, preserve the current camera state
            if (ch.ActiveNode.IsValidNode())
                PushStateToUnityCamera(state);
        }

        /// <summary> Apply a CameraState to the game object and Camera component</summary>
        private void PushStateToUnityCamera(CameraState state)
        {
            if ((state.BlendHint & NodeBlendHint.BlendHintValue.NoPosition) == 0)
                transform.position = state.FinalPosition;
            if ((state.BlendHint & NodeBlendHint.BlendHintValue.NoOrientation) == 0)
                transform.rotation = state.FinalOrientation;
            if ((state.BlendHint & NodeBlendHint.BlendHintValue.NoLens) == 0)
            {
                Camera cam = OutputCamera;
                if (cam != null)
                {
                    cam.nearClipPlane = state.Lens.NearClipPlane;
                    cam.farClipPlane = state.Lens.FarClipPlane;
                    cam.fieldOfView = state.Lens.FieldOfView;
                    if (cam.orthographic)
                        cam.orthographicSize = state.Lens.OrthographicSize;
                    else
                    {
                        cam.usePhysicalProperties = state.Lens.IsPhysicalCamera;
                        cam.lensShift = state.Lens.LensShift;
                    }
                }
            }
            if (Events.CameraUpdated != null)
                Events.CameraUpdated.Invoke(this);
        }
    }
}
