using System;
using UnityEngine;
using Unity.Entities;
using System.Collections.Generic;
using Unity.Mathematics;
using Unity.Collections;
using UnityEngine.Serialization;
using Unity.Entities.Hybrid;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    /// <summary>Defines a group of target objects, each with a weight.
    /// The weight is used when calculating the average position of the target group.
    /// Higher-weighted members of the group will count more.
    /// The bounding box is calculated by taking the member positions, weight,
    /// and radii into account.
    /// </summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [RequireComponent(typeof(CmTargetBindingKey))]
    [AddComponentMenu("Cinemachine/Cm Target Group")]
    public class CmTargetGroupAuthoring : EntityBehaviourAuthoringBase
    {
        /// <summary>
        /// An item in the target group's list of targets
        /// </summary>
        [Serializable] public class Target
        {
            /// <summary>The target object.  This object's position and orientation will contribute to the
            /// group's average position and orientation, in accordance with its weight</summary>
            [Tooltip("The target object.  This object's position and orientation will contribute to"
                + "the group's average position and orientation, in accordance with its weight")]
            public StableReference<CmTargetBindingKey> TargetObject = new StableReference<CmTargetBindingKey>();

            /// <summary>How much weight to give the target when averaging.  Cannot be negative</summary>
            [Tooltip("How much weight to give the target when averaging.  Cannot be negative")]
            public float Weight;
        }

        /// <summary>The target objects together with their weights that will
        /// contribute to the group's average position, orientation, and size</summary>
        [SerializeField]
        [FormerlySerializedAs("Targets")]
        [Tooltip("The target objects together with their weights that will contribute to "
            + "the group's average position, orientation, and size.")]
        internal List<Target> m_Targets = new List<Target>();

        public List<Target> Targets 
        {
            get
            {
                if (!IsSynchronized)
                    return m_Targets;
                Synchronize(SynchronizedEntity, SynchronizedWorld.EntityManager, m_TargetsCache, false);
                return m_TargetsCache;
            }
            set
            {
                m_Targets = value;
                if (IsSynchronized)
                    Synchronize(SynchronizedEntity, SynchronizedWorld.EntityManager, m_Targets, true);
            }
        }

        protected override void OnValidate()
        {
            for (int i = 0; i < m_Targets.Count; ++i)
            {
                var t = m_Targets[i];
                t.Weight = math.max(0, t.Weight);
                m_Targets[i] = t;
            }
            base.OnValidate();
        }

        List<Target> m_TargetsCache = new List<Target>();
        void Synchronize(Entity entity, EntityManager m, List<Target> targets, bool pushToEntity)
        {
            if (pushToEntity)
            {
                var count = targets.Count;
                var buffer = m.GetBuffer<CmTargetGroupBufferElement>(entity);
                buffer.Clear();
                buffer.Capacity = count;
                for (int i = 0; i < count; ++i)
                {
                    var t = targets[i];
                    buffer.Add(new CmTargetGroupBufferElement
                    {
                        StableKey = t.TargetObject.Referent,
                        Weight = t.Weight
                    });
                }
            }
            else
            {
                // Pull the weights only  // GML TODO: is this right?
                var buffer = m.GetBuffer<CmTargetGroupBufferElement>(entity);
                int count = Mathf.Min(buffer.Length, targets.Count);
                for (int i = 0; i < count; ++i)
                {
                    var t = targets[i];
                    t.Weight = buffer[i].Weight;
                    targets[i] = t;
                }
            }
        }

        /// <summary>Standard EntityBehaviour implementation</summary>
        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            context.EntityManager.AddComponentData(entity, new CmTarget());
            context.EntityManager.AddBuffer<CmTargetGroupBufferElement>(entity);
            Synchronize(entity, context.EntityManager, m_Targets, true);
        }

        /// <summary>Standard EntityBehaviour implementation</summary>
        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            Synchronize(entity, context.EntityManager, m_Targets, false);
        }

        /// <summary>Return true if there are no members with weight > 0</summary>
        public bool IsEmpty
        {
            get
            {
                if (IsSynchronized)
                    Synchronize(SynchronizedEntity, SynchronizedWorld.EntityManager, m_TargetsCache, false);
                var count = m_TargetsCache.Count;
                for (int i = 0; i < count; ++i)
                    if (m_TargetsCache[i].TargetObject.Referent.IsValid
                            && m_TargetsCache[i].Weight > MathHelpers.Epsilon)
                        return false;
                return true;
            }
        }

        /// <summary>Add a member to the group</summary>
        public void AddMember(CmTargetAuthoring t, float weight)
        {
            if (IsSynchronized)
                Synchronize(SynchronizedEntity, SynchronizedWorld.EntityManager, m_Targets, false);
            m_Targets.Add(new Target
                {
                    TargetObject = new StableReference<CmTargetBindingKey> { Referent = t.StableKey },
                    Weight = math.max(0, weight)
                });
            if (IsSynchronized)
                Synchronize(SynchronizedEntity, SynchronizedWorld.EntityManager, m_Targets, true);
            CancelBlend();
        }

        /// <summary>Remove a member from the group</summary>
        public void RemoveMember(CmTargetAuthoring t)
        {
            int index = FindMember(t);
            if (index >= 0)
            {
                m_Targets.RemoveAt(index);
                CancelBlend();
                if (IsSynchronized)
                    Synchronize(SynchronizedEntity, SynchronizedWorld.EntityManager, m_Targets, true);
            }
        }

        /// <summary>Locate a member's index in the group. Returns -1 if not a member</summary>
        public int FindMember(CmTargetAuthoring t)
        {
            if (IsSynchronized)
                Synchronize(SynchronizedEntity, SynchronizedWorld.EntityManager, m_Targets, false);
            if (m_Targets != null)
            {
                var count = m_Targets.Count;
                for (int i = 0; i < count; ++i)
                    if (m_Targets[i].TargetObject.Referent == t.StableKey)
                        return i;
            }
            return -1;
        }

        List<CmTargetGroupBufferElement> m_BufferElementCache;
        List<CmTargetGroupBufferElement> GetComponentValues(List<Target> targets)
        {
            var count = m_Targets.Count;
            if (m_BufferElementCache == null)
                m_BufferElementCache = new List<CmTargetGroupBufferElement>(count);
            m_BufferElementCache.Clear();
            m_BufferElementCache.Capacity = count;
            for (int i = 0; i < count; ++i)
            {
                var t = targets[i];
                m_BufferElementCache.Add(new CmTargetGroupBufferElement
                {
                    StableKey = t.TargetObject.Referent,
                    Weight = t.Weight
                });
            }
            return m_BufferElementCache;
        }
        
        /// <summary>
        /// Blend a group to a new member set.  Will do nothing if the same blend is already
        /// in progress, or if the target configuration is the same as the current configuration.
        /// Checking for this can be slow if the group has many members.
        ///
        /// It's best to use this to add or remove members from a group, rather thar completely
        /// swapping out all the members, because in the latter case there will be a mid-blend
        /// position that equally includes everyone, which may not produce the desired visual results.
        /// </summary>
        /// <param name="newMembers">The final members and weights of the group</param>
        /// <param name="blendTime">The time in seconds over which to blend</param>
        /// <param name="blendCurve">The shape of the blend curve over blendTime</param>
        public void BlendTo(List<Target> newMembers, float blendTime, TransitionCurve blendCurve)
        {
            var groupBlendSystem = SynchronizedWorld?.GetOrCreateSystem<CmTargetGroupBlendSystem>();
            if (groupBlendSystem != null)
            {
                var members = new NativeList<CmTargetGroupBufferElement>(newMembers.Count, Allocator.Temp);
                for (int i = 0; i < newMembers.Count; ++i)
                {
                    var m = newMembers[i];
                    members.Add(new CmTargetGroupBufferElement
                    {
                        StableKey = m.TargetObject.Referent,
                        Weight = m.Weight
                    });
                }
                groupBlendSystem.BlendGroupTo(SynchronizedEntity, members, blendTime);
                members.Dispose();
            }
        }

        /// <summary>
        /// Cancel any member blend in progress
        /// </summary>
        public void CancelBlend()
        {
            var groupBlendSystem = SynchronizedWorld?.GetOrCreateSystem<CmTargetGroupBlendSystem>();
            if (groupBlendSystem != null)
                groupBlendSystem.CancelBlend(SynchronizedEntity);
        }

        /// <summary>
        /// Is a group member blend currently in progress?
        /// </summary>
        public bool IsBlending()
        {
            var groupBlendSystem = SynchronizedWorld?.GetOrCreateSystem<CmTargetGroupBlendSystem>();
            return groupBlendSystem != null && groupBlendSystem.IsBlending(SynchronizedEntity);
        }
    }
}
