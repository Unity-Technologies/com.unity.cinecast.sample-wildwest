#if CINEMACHINE_LEGACY_PHYSICS
using Unity.Mathematics;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [CameraExtension]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Extensions/Legacy Raycast Shot Quality")]
    public class LegacyRaycastShotQualityAuthoring : ComponentAuthoringBase<LegacyRaycastShotQuality>
    {
        protected override void OnValidate()
        {
            m_Value.TargetRadius = math.max(0, m_Value.TargetRadius);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new LegacyRaycastShotQuality
            {
                LayerMask = 1,
                TargetRadius = 0
            };
            base.Reset();
        }
    }
}
#endif
