using UnityEngine;
using Unity.Entities;
using Unity.Entities.Hybrid;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    [DisallowMultipleComponent]
    [AddComponentMenu("Cinemachine/Paths/Dolly Cart")]
    public class DollyCartAuthoring : ComponentAuthoringBase<DollyCart>
    {
        /// <summary>The path to which the camera will be constrained.  This must be non-null.</summary>
        [Tooltip("The path to which the cart will be constrained.  This must be non-null.")]
        public StableReference<CmPathBindingKey> Path = new StableReference<CmPathBindingKey>();

        protected override void Reset()
        {
            m_Value = new DollyCart
            {
                PositionUnits = TCBSplinePathSystem.PositionUnits.Distance
            };
            base.Reset();
        }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            // Don't call the base class because of the reference
            var v = m_Value;
            v.PathKey.StableKey = Path.Referent;
            context.EntityManager.AddComponentData(entity, v);
        }

        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            // Don't call the base class because of the reference
            m_Value = context.EntityManager.GetComponentData<DollyCart>(entity);
            m_Value.PathKey = default;
        }
    }
}
