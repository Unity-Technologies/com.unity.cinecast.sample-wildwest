using UnityEngine;
using Unity.Mathematics;
using Unity.Entities;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    /// <summary>
    /// Cinemachine ClearShot is a "manager camera" that owns and manages a set of
    /// Cm Cameras or other Cm nodes.  When Live, the ClearShot will check the
    /// managed nodes, and choose the one with the best quality shot and make it Live.
    ///
    /// This can be a very powerful tool.  If the managed nodes have shot quality evaluation
    /// extensions, they will analyze the scene for target obstructions, optimal target
    /// distance, and other items, and report their assessment of shot quality back to
    /// the ClearShot parent, who will then choose the best one.  You can use this to set
    /// up complex multi-camera coverage of a scene, and be assured that a clear shot of
    /// the target will always be available.
    ///
    /// If multiple child cameras have the same shot quality, the one with the highest
    /// priority will be chosen.
    ///
    /// You can also define custom blends between the ClearShot-managed nodes.
    /// </summary>
    [DisallowMultipleComponent]
    [AddComponentMenu("Cinemachine/Channels/Cm ClearShot")]
    public class CmClearShotAuthoring : CmChannelNodeBase
    {
        /// <summary>
        /// This is the asset containing custom settings for specific blends.
        /// </summary>
        public CustomBlends CustomBlends;

        protected override void Reset()
        {
            m_Channel = new CmChannel
            {
                Settings = new CmChannel.ChannelSettings { WorldOrientation = quaternion.identity },
                Sorting = CmChannel.SortMode.QualityThenPriority,
                DefaultBlend = new TransitionDefinition
                {
                    Curve = TransitionCurve.Default,
                    Length = 0
                }
            };
            base.Reset();
        }

        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            base.PushToEntity(entity, context);
            CustomBlends.AddCustomBlendsToEntity(entity, context.EntityManager, CustomBlends);
        }
    }
}
