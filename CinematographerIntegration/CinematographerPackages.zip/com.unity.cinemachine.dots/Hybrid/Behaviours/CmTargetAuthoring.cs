using Unity.Mathematics;
using UnityEngine;
using Unity.Entities.Hybrid;
using Unity.Entities;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    /// <summary>
    /// This component is required on all objects that can be targeted by Cinemachine Cameras.
    /// Because it is built on top of StableID, it it possible for Cinemachine Cameras to
    /// reference targets in other scenes.
    /// </summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [RequireComponent(typeof(CmTargetBindingKey))]
    [AddComponentMenu("Cinemachine/Cm Target")]
    public class CmTargetAuthoring : ComponentAuthoringBase<CmTarget>
    {
        public StableKey StableKey => GetComponent<StableID>().Value;

        protected override void OnValidate()
        {
            m_Value.Radius = math.max(0, m_Value.Radius);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new CmTarget
            {
                Offset = float3.zero,
                Radius = 0
            };
            base.Reset();
        }
    }
}
