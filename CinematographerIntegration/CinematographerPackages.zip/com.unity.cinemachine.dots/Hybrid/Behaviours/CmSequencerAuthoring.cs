using UnityEngine;
using Unity.Mathematics;
using Unity.Entities;
using System.Collections.Generic;
using System;
using Unity.Entities.Hybrid;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    /// <summary>
    /// This is a Cm camera "manager" that owns and manages a collection
    /// of child Cm Cameras.  When this camera goes live, these managed cameras
    /// are enabled, one after another, holding each camera for a designated time.
    /// Blends between cameras are specified.
    /// RepeatMode controls what happends after the last camera is activated.
    /// </summary>
    [DisallowMultipleComponent]
    [AddComponentMenu("Cinemachine/Channels/Cm Sequencer")]
    public class CmSequencerAuthoring : CmChannelNodeBase
    {
        /// <summary>
        /// How the sequence repeats as the live time extends beyong the instructions
        /// </summary>
        public CmSequencer.RepeatMode RepeatMode;

        /// <summary>
        /// This is a single entry in the sequencer's list of cameras
        /// </summary>
        [Serializable]
        public class Instruction
        {
            /// <summary>How to blend to the this node in the list</summary>
            [Tooltip("How to blend to the this node in the list")]
            [TransitionDefinitionUnitsLabel("s", "The duration (in seconds) of the blend")]
            public TransitionDefinition Blend;

            /// <summary>The node to activate when this instruction becomes active</summary>
            [Tooltip("The node to activate when this instruction becomes active")]
            public StableReference<CmNodeBindingKey> Node = new StableReference<CmNodeBindingKey>();

            /// <summary>How long to wait (in seconds) before activating the next node in the list (if any)</summary>
            [Tooltip("How long to wait (in seconds) before activating the next node in the list (if any)")]
            public float Hold;

            public void Validate()
            {
                Blend.Length = math.max(0, Blend.Length);
                Hold = math.max(0, Hold);
            }
        }

        /// <summary>The sequence of cameras that will be played</summary>
        [Tooltip("The sequence of cameras that will be played")]
        public List<Instruction> Instructions = new List<Instruction>();

        /// <summary>Standard EntityBehaviour implementation</summary>
        protected override void Reset()
        {
            m_Channel = new CmChannel
            {
                Settings = new CmChannel.ChannelSettings { WorldOrientation = quaternion.identity },
                Sorting = CmChannel.SortMode.Custom,
                DefaultBlend = new TransitionDefinition
                {
                    Curve = TransitionCurve.Default,
                    Length = 0
                }
            };
            Instructions.Clear();
            RepeatMode = CmSequencer.RepeatMode.None;
            base.Reset();
        }

        /// <summary>Standard EntityBehaviour implementation</summary>
        protected override void OnValidate()
        {
            for (int i = 0; i < Instructions.Count; ++i)
            {
                var inst = Instructions[i];
                inst.Validate();
                Instructions[i] = inst;
            }
            base.OnValidate();
        }

        /// <summary>Standard EntityBehaviour implementation</summary>
        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            base.PushToEntity(entity, context);

            var count = Instructions.Count;

            // Make sure any structural changes happen before we call GetBuffer()
            for (int i = 0; i < count; ++i)
                if (Instructions[i].Node.Referent.IsValid)
                    context.GetPrimaryEntity(Instructions[i].Node.GameObject);

            var buffer = context.EntityManager.AddBuffer<CmSequencerInstruction>(entity);
            for (int i = 0; i < Instructions.Count; ++i)
            {
                if (Instructions[i].Node.Referent.IsValid)
                {
                    var go = Instructions[i].Node.GameObject;
                    if (go != null)
                    {
                        buffer.Add(new CmSequencerInstruction
                        {
                            Blend = Instructions[i].Blend,
                            Node = context.GetPrimaryEntity(go),
                            Hold = Instructions[i].Hold
                        });
                    }
                }
            }
            context.EntityManager.AddComponentData(entity, new CmSequencer { Repeat = RepeatMode });
        }
    }
}
