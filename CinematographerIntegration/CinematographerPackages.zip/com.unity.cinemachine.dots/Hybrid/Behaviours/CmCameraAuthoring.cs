using UnityEngine;
using Unity.Entities;
using Unity.Entities.Hybrid;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    /// <summary>
    /// Stages in the Cinemachine Camera pipeline, used for
    /// UI organization>.  This enum defines the pipeline order.
    /// </summary>
    public enum PipelineStage
    {
        /// <summary>Second stage: position the camera in space</summary>
        Body,

        /// <summary>Third stage: orient the camera to point at the target</summary>
        Aim,

        /// <summary>Final pipeline stage: apply noise (this is done separately, in the
        /// Noise channel of the CameraState)</summary>
        Noise,

        /// <summary>Not a pipeline stage.  This is invoked on all node
        /// types, after the pipeline is complete</summary>
        Finalize
    };

    /// <summary>
    /// Attribute used by camera pipeline authoring components to indicate
    /// which stage of the pipeline they belong in.
    /// </summary>
    public sealed class CameraPipelineAttribute : System.Attribute
    {
        /// <summary>Get the stage in the Camera Pipeline in which to position this component</summary>
        public PipelineStage Stage { get; private set; }

        /// <summary>Constructor: Pipeline Stage is defined here.</summary>
        /// <param name="stage">The stage in the Camera Pipeline in which to position this component</param>
        public CameraPipelineAttribute(PipelineStage stage) { Stage = stage; }
    }

    /// <summary>
    /// Attribute used to indicate that an authoring component is a Camera Pipeline extension
    /// </summary>
    public sealed class CameraExtensionAttribute : System.Attribute {}

    /// <summary>
    /// This behaviour is intended to be attached to an empty Transform GameObject,
    /// and it represents a Cinemachine Camera within the Unity scene.
    ///
    /// The Cinemachine Camera holds lens settinga and a transform, which will drive the Main Camera
    /// while the Cinemachine Camera is Live.  This is accomplished by putting a CmListener
    /// component on the Main Camera.
    /// 
    /// A Cinemachine Camera is not a camera. Instead, it can be thought of as a camera controller,
    /// not unlike a cameraman. It can drive the Unity Camera and control its position,
    /// orientation, lens settings, and PostProcessing effects. Each Cinemachine Camera holds
    /// its own Cinemachine Component Pipeline, through which you provide the instructions
    /// for dynamically tracking specific game objects.
    ///
    /// When procedural components are set up on the Cinemachine Camera, it will animate its
    /// Transform according to the rules contained in its Cinemachine Component pipeline.
    ///
    /// A Cinemachine camera is very lightweight, and does no rendering of its own. It merely
    /// tracks interesting GameObjects, and positions itself accordingly. A typical game
    /// can have dozens of Cinemachine cameras, each set up to follow a particular character
    /// or capture a particular event.
    ///
    /// A Cinemachine Camera can be in any of three states:
    ///
    /// * **Live**: The Cinemachine camera is actively controlling the Unity Camera. The
    /// Cinemachine camera is tracking its targets and being updated every frame.
    /// * **Standby**: The Cinemachine camera is tracking its targets and being updated
    /// every frame, but no Unity Camera is actively being controlled by it. This is
    /// the state of a Cinemachine camera that is enabled in the scene but perhaps at a
    /// lower priority than the Live Cinemachine camera.
    /// * **Disabled**: The Cinemachine camera is present but disabled in the scene. It is
    /// not actively tracking its targets and so consumes no processing power. However,
    /// the Cinemachine camera can be made live from the Timeline.
    ///
    /// The Unity Camera can be driven by any Cinemachine camera in the scene. The game
    /// logic can choose the Cinemachine camera to make live by manipulating the Cinemachine
    /// cameras' enabled flags and their priorities, based on game logic.
    ///
    /// In order to be driven by a Cinemachine camera, the Unity Camera must have a Cm Listener
    /// behaviour, which will select the most eligible Cinemachine camera based on its priority
    /// or on other criteria, and will manage blending.
    /// </summary>
    [DisallowMultipleComponent]
    [AddComponentMenu("Cinemachine/Cm Camera")]
    public class CmCameraAuthoring : CmNodeAuthoringBase
    {
        /// <summary>Object for the camera to move with (the body target)</summary>
        [Tooltip("Object for the camera to move with (the body target).")]
        public StableReference<CmTargetBindingKey> FollowTarget = new StableReference<CmTargetBindingKey>();

        /// <summary>Object for the camera to look at (the aim target)</summary>
        [Tooltip("Object for the camera to look at (the aim target).")]
        public StableReference<CmTargetBindingKey> LookAtTarget = new StableReference<CmTargetBindingKey>();

        /// <summary>Specifies the LensSettings of this CmNode.
        /// These settings will be transferred to the Unity camera when the node is live.</summary>
        [Header("Camera")]
        [Tooltip("Specifies the lens properties of this CmNode.  This generally mirrors "
            + "the Unity Camera's lens settings, and will be used to drive the Unity camera when "
            + "the node is active.")]
        [LensSettingsProperty] [SerializeField] [HideFoldout]
        LensSettings m_Lens;

        /// <summary>Get and set the Lens parameters for this camera</summary>
        public LensSettings Lens
        {
            get
            {
                if (IsSynchronized)
                    return LensSettingsFromLensData(SynchronizedEntity, SynchronizedWorld.EntityManager);
                return m_Lens;
            }
            set
            {
                m_Lens = value;
                if (IsSynchronized)
                    SynchronizedWorld.EntityManager.SetComponentData(SynchronizedEntity, LensDataFromLensSettings());
            }
        }

        /// <summary>EntityBehaviour implementation: reset the state to default.</summary>
        protected override void Reset()
        {
            FollowTarget = new StableReference<CmTargetBindingKey>();
            LookAtTarget = new StableReference<CmTargetBindingKey>();
            m_Lens = LensSettings.Default;
            base.Reset();
        }

        /// <summary>EntityBehaviour implementation: convert to entity components.</summary>
        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            base.PushToEntity(entity, context);
            context.EntityManager.AddComponentData(
                entity, new FollowTarget { Target = FollowTarget.Referent });
            context.EntityManager.AddComponentData(
                entity, new LookAtTarget { Target = LookAtTarget.Referent });
            context.EntityManager.AddComponentData(entity, LensDataFromLensSettings());
        }

        /// <summary>EntityBehaviour implementation: convert from entity components.</summary>
        protected override void PullFromEntity(Entity entity, ConversionContext context)
        {
            base.PullFromEntity(entity, context);
            LensSettingsFromLensData(entity, context.EntityManager);
        }

        LensData LensDataFromLensSettings()
        {
            return new LensData
            {
                FOV = m_Lens.Orthographic ? m_Lens.OrthographicSize : m_Lens.FieldOfView,
                NearClip = m_Lens.NearClipPlane,
                FarClip = m_Lens.FarClipPlane,
                Dutch = m_Lens.Dutch,
                LensShift = m_Lens.LensShift
            };
        }

        LensSettings LensSettingsFromLensData(Entity entity, EntityManager entityManager)
        {
            var lens = m_Lens;
            var tl = entityManager.GetComponentData<LensData>(entity);
            if (lens.Orthographic)
                lens.OrthographicSize = tl.FOV;
            else
                lens.FieldOfView = tl.FOV;

             lens.NearClipPlane = tl.NearClip;
             lens.FarClipPlane = tl.FarClip;
             lens.Dutch = tl.Dutch;
             lens.LensShift = tl.LensShift;
             return lens;
        }
    }
}
