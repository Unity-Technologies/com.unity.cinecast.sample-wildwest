#if CINEMACHINE_UNITY_PHYSICS

using Unity.Mathematics;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [CameraExtension]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Extensions/Simple Shot Quality")]
    public class RaycastShotQualityAuthoring : ComponentAuthoringBase<RaycastShotQuality>
    {
        protected override void OnValidate()
        {
            m_Value.TargetRadius = math.max(0, m_Value.TargetRadius);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new RaycastShotQuality
            {
                LayerMask = -1, // all 1s, so all layers, collide with everything
                TargetRadius = 0.1f
            };
            base.Reset();
        }
    }
}

#endif
