#if CINEMACHINE_UNITY_PHYSICS

using Unity.Mathematics;
using Unity.Entities;
using UnityEngine;
using Unity.Cinemachine.Core;
using Unity.Entities.Hybrid;

namespace Unity.Cinemachine.Hybrid
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [CameraExtension]
    [RequireComponent(typeof(CmCameraAuthoring))]
    [AddComponentMenu("Cinemachine/Extensions/Collision Resolution")]
    public class CollisionResolutionAuthoring 
        : ComponentAuthoringBase<CollisionResolution>, CmNodeDebugGizmoDrawer
    {
#if UNITY_EDITOR // GML used for debugging only
        protected override void PushToEntity(Entity entity, ConversionContext context)
        {
            base.PushToEntity(entity, context);
            context.EntityManager.AddBuffer<CollisionResolutionDebugElement>(entity);
        }

        public void DrawDebugGizmosForNode()
        {
            var w = SynchronizedWorld;
            if (Application.isPlaying && w != null)
            {
                var e = SynchronizedEntity;
                if (w.EntityManager.HasComponent<CollisionResolutionDebugElement>(e))
                {
                    var debug = w.EntityManager.GetBuffer<CollisionResolutionDebugElement>(e);
                    if (debug.Length > 1)
                    {
                        float3 p0 = debug[0].pathPoint;
                        for (int i = 1; i < debug.Length; ++i)
                        {
                            Gizmos.color = Color.yellow;
                            var p = debug[i].pathPoint;
                            Gizmos.DrawLine(p0, p);
                            p0 = p;
                        }
                    }
                }
            }
        }
#else
        public void DrawDebugGizmosForNode() {}
#endif

        protected override void OnValidate()
        {
            m_Value.MinimumDistanceFromTarget = math.max(0.01f, m_Value.MinimumDistanceFromTarget);
            m_Value.DistanceLimit = math.max(0, m_Value.DistanceLimit);
            m_Value.MinimumOcclusionTime = math.max(0, m_Value.MinimumOcclusionTime);
            m_Value.CameraRadius = math.max(0.01f, m_Value.CameraRadius);
            m_Value.MaximumEffort = math.clamp(m_Value.MaximumEffort, 1, 20);
            m_Value.SmoothingTime = math.max(0, m_Value.SmoothingTime);
            m_Value.Damping = math.max(0, m_Value.Damping);
            m_Value.DampingWhenOccluded = math.max(0, m_Value.DampingWhenOccluded);
            base.OnValidate();
        }

        protected override void Reset()
        {
            m_Value = new CollisionResolution
            {
                CollideAgainst = ~0,
                TransparentLayers = 0,
                MinimumDistanceFromTarget = 0.2f,
                DistanceLimit = 0,
                MinimumOcclusionTime = 0.2f,
                CameraRadius = 0.01f,
                Strategy = CollisionResolution.ResolutionStrategy.PreserveCameraHeight,
                MaximumEffort = 4,
                SmoothingTime = 0.5f,
                Damping = 0.5f,
                DampingWhenOccluded = 0.2f
            };
            base.Reset();
        }
    }
}
#endif
