using UnityEngine;
using System;
using System.Collections.Generic;
using Unity.Entities;
using Unity.Entities.Hybrid;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    /// <summary>
    /// Asset that defines the rules for blending between CmNodes.
    /// </summary>
    [Serializable]
    public class CustomBlends : ScriptableObject
    {
        /// <summary>
        /// Container specifying how two specific Cinemachine Nodes
        /// blend together.
        /// </summary>
        [Serializable]
        public class Item
        {
            /// <summary>When blending from this node</summary>
            [Tooltip("When blending from this node).")]
            public StableReference<CmNodeBindingKey> From = new StableReference<CmNodeBindingKey>();

            /// <summary>When blending to this node</summary>
            [Tooltip("When blending to this node).")]
            public StableReference<CmNodeBindingKey> To = new StableReference<CmNodeBindingKey>();

            /// <summary>If enabled, use this blend for the inverse transition also</summary>
            [Tooltip("If enabled, use this blend for the inverse transition also.")]
            public bool Bidirectional;
        
            /// <summary>How to blend between these nodes</summary>
            [Tooltip("How to blend between these nodes")]
            [TransitionDefinitionUnitsLabel("s", "The duration (in seconds) of the blend")]
            public TransitionDefinition Blend;
        }
        /// <summary>The explicitly defined blends between two Nodes</summary>
        [Tooltip("The explicitly defined blends between two Nodes")]
        public List<Item> Blends = new List<Item>();

        /// <summary>
        /// Convenience for conversion: call from convert to create your custom blends
        /// </summary>
        /// <param name="entity">Owner of the custom blends</param>
        /// <param name="dstManager">entity manager for conversion</param>
        /// <param name="customBlends">CustomBlends asset - may be null</param>
        public static void AddCustomBlendsToEntity(
            Entity entity, EntityManager dstManager, CustomBlends customBlends)
        {
            if (!dstManager.HasComponent<CustomNodeBlendElement>(entity))
                dstManager.AddBuffer<CustomNodeBlendElement>(entity);
            var b = dstManager.GetBuffer<CustomNodeBlendElement>(entity);
            b.Clear();
            if (customBlends != null && customBlends.Blends != null)
            {
                for (int i = 0; i < customBlends.Blends.Count; ++i)
                {
                    var blend = customBlends.Blends[i];
                    b.Add (new CustomNodeBlendElement 
                    { 
                        From = blend.From.Referent, 
                        To = blend.To.Referent, 
                        Blend = blend.Blend
                    });
                    if (blend.Bidirectional)
                    {
                        b.Add (new CustomNodeBlendElement 
                        { 
                            From = blend.To.Referent, 
                            To = blend.From.Referent, 
                            Blend = blend.Blend
                        });
                    }
                }
            }
        }
    }
}
