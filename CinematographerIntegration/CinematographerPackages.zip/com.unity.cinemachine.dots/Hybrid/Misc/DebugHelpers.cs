using UnityEngine;
using System.Collections.Generic;
using Unity.Entities;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    /// <summary>Manages onscreen positions for Cinemachine debugging output</summary>
    public class DebugHelpers
    {
        static List<Object> m_ScreenPosClients;

        /// <summary>Release a screen rectangle previously obtained through GetScreenPos()</summary>
        /// <param name="client">The client caller.  Used as a handle.</param>
        public static void ReleaseScreenPos(Object client)
        {
            if (m_ScreenPosClients != null && m_ScreenPosClients.Contains(client))
                m_ScreenPosClients.Remove(client);
        }

        /// <summary>Reserve an on-screen rectangle for debugging output.</summary>
        /// <param name="client">The client caller.  This is used as a handle.</param>
        /// <param name="text">Sample text, for determining rectangle size</param>
        /// <param name="style">What style will be used to draw, used here for
        /// determining rect size</param>
        /// <returns>An area on the game screen large enough to print the text
        /// in the style indicated</returns>
        public static Rect GetScreenPos(Object client, string text, GUIStyle style)
        {
            if (m_ScreenPosClients == null)
                m_ScreenPosClients = new List<Object>();

            Vector2 pos = new Vector2(0, 0);
            Vector2 size = style.CalcSize(new GUIContent(text));
            int count = m_ScreenPosClients.Count;
            for (int i = 0; i < count; ++i)
            {
                var c = m_ScreenPosClients[i];
                if (c == null)
                    continue; // client deleted but not released (shame!)
                if (c == client)
                    return new Rect(pos, size);
                pos.y += size.y;
            }
            m_ScreenPosClients.Add(client);
            return new Rect(pos, size);
        }

        /// <summary>
        /// Delegate for OnGUI debugging.
        /// This will be called by the CmListener in its OnGUI (editor only)
        /// </summary>
        public delegate void OnGUIDelegate();

        /// <summary>
        /// Delegate for OnGUI debugging.
        /// This will be called by the CinemachineBrain in its OnGUI (editor only)
        /// </summary>
        public static OnGUIDelegate OnGUIHandlers;
    }

    public static class DescriptionProvider
    {
        // Recursion protection
        static List<Entity> m_visited = new List<Entity>();

        static string InternalGetDescription(CmNode node, World w)
        {
            if (node.Entity == Entity.Null)
                return "(none)";
            var s = node.GetName();
            var ch = new ChannelHelper(node.Entity, w);
            if (ch.IsChannel)
                s += $" [{InternalGetDescription(ch.ActiveBlend, w)}]";
            return s;
        }

        /// <summary>Text description of a blend, for debugging</summary>
        static string InternalGetDescription(BlendState b, World w)
        {
            var node = CmNode.FromEntity(b.Node, w);
            if (m_visited.Contains(b.Node))
                return $" ! RECURSION of {node.GetName()}";
            m_visited.Add(b.Node);
            var s = InternalGetDescription(node, w);
            if (b.Weight != 0 && b.Weight != 1)
                s += $" [{(int)(b.Weight * 100f)}% "
                    + $"from {InternalGetDescription(CmNode.FromEntity(b.OutgoingNode, w), w)}]";
            m_visited.Remove(b.Node);
            return s;
        }

        public static string GetDescription(this CmNode node, World w)
        {
            m_visited.Clear();
            return InternalGetDescription(node, w);
        }

        /// <summary>Text description of a blend, for debugging</summary>
        public static string GetDescription(this BlendState b, World w)
        {
            m_visited.Clear();
            return InternalGetDescription(b, w);
        }
    }
}
