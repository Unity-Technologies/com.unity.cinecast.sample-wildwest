using UnityEngine;
using System;
using Unity.Mathematics;
using Unity.Collections;
using Unity.Cinemachine.Core;

namespace Unity.Cinemachine.Hybrid
{
    /// <summary>
    /// This is an asset that defines a noise profile.  A noise profile is the
    /// shape of the noise signal as a function of time.  You can build arbitrarily complex shapes by
    /// combining different base perlin noise frequencies at different amplitudes.
    ///
    /// The frequencies and amplitudes should be chosen with care, to ensure an interesting
    /// noise quality that is not obviously repetitive.
    ///
    /// As a mathematical side-note, any arbitrary periodic curve can be broken down into a
    /// series of fixed-amplitude sine-waves added together.  This is called fourier decomposition,
    /// and is the basis of much signal processing.  It doesn't really have much to do with this
    /// asset, but it's super interesting!
    /// </summary>
    public class GeneratedWaveProfile : ScriptableObject
    {
        /// <summary>Describes the behaviour for a channel of noise</summary>
        [Serializable]
        public struct NoiseParams
        {
            /// <summary>The frequency of noise for this channel.  Higher magnitudes vibrate faster</summary>
            [Tooltip("The frequency of noise for this channel.  Higher magnitudes vibrate faster.")]
            public float Frequency;

            /// <summary>The amplitude of the noise for this channel.  Larger numbers vibrate higher</summary>
            [Tooltip("The amplitude of the noise for this channel.  Larger numbers vibrate higher.")]
            public float Amplitude;

            /// <summary>If checked, then the amplitude and frequency will not be randomized</summary>
            [Tooltip("If checked, then the amplitude and frequency will not be randomized.")]
            public bool Constant;

            /// <summary>Return true if amplitude is zero</summary>
            public bool IsZero { get { return math.abs(Amplitude) < MathHelpers.Epsilon; } }

            /// <summary>Convert to AdditiveNoiseElement</summary>
            public AdditiveNoiseElement AsAdditiveNoisElement(int axis)
            {
                return new AdditiveNoiseElement
                {
                    Frequency = Frequency,
                    Amplitude = Amplitude,
                    Randomize = !Constant,
                    Axis = (byte)math.clamp(axis, 0, 2)
                };
            }
        }

        /// <summary>
        /// Contains the behaviour of noise for the noise module for all 3 cardinal axes of the camera
        /// </summary>
        [Serializable]
        public struct TransformNoiseParams
        {
            /// <summary>Noise definition for X-axis</summary>
            [Tooltip("Noise definition for X-axis")]
            public NoiseParams X;
            /// <summary>Noise definition for Y-axis</summary>
            [Tooltip("Noise definition for Y-axis")]
            public NoiseParams Y;
            /// <summary>Noise definition for Z-axis</summary>
            [Tooltip("Noise definition for Z-axis")]
            public NoiseParams Z;

            /// <summary>Get the signal value at a given time, offset by a given amount</summary>
            public float3 GetValueAt(float time, float3 timeOffsets)
            {
                return new float3(
                    X.AsAdditiveNoisElement(0).GetValueAt(time, timeOffsets.x),
                    Y.AsAdditiveNoisElement(1).GetValueAt(time, timeOffsets.y),
                    Z.AsAdditiveNoisElement(2).GetValueAt(time, timeOffsets.z));
            }
        }

        /// <summary>The array of positional noise channels for this <c>NoiseSettings</c></summary>
        [Tooltip("These are the noise channels for the node's position. Convincing noise setups typically mix low, medium and high frequencies together, so start with a size of 3")]
        public TransformNoiseParams[] PositionNoise = new TransformNoiseParams[0];

        /// <summary>The array of orientation noise channels for this <c>NoiseSettings</c></summary>
        [Tooltip("These are the noise channels for the node's orientation. Convincing noise setups typically mix low, medium and high frequencies together, so start with a size of 3")]
        public TransformNoiseParams[] OrientationNoise = new TransformNoiseParams[0];

        /// <summary>
        /// Get the noise as native array for use in jobs
        /// </summary>
        /// <param name="allocator">How to allocate the array</param>
        /// <returns>A native array that caller must dispose</returns>
        public static NativeArray<AdditiveNoiseElement> ToNoiseArray(
            Allocator allocator, in TransformNoiseParams[] noise)
        {
            int count = 0;
            for (int i = 0; i < noise.Length; ++i)
            {
                if (!noise[i].X.IsZero)
                    ++count;
                if (!noise[i].Y.IsZero)
                    ++count;
                if (!noise[i].Z.IsZero)
                    ++count;
            }

            var a = new NativeArray<AdditiveNoiseElement>(count, allocator);
            count = 0;
            for (int i = 0; i < noise.Length; ++i)
            {
                var n = noise[i];
                if (!n.X.IsZero)
                    a[count++] = n.X.AsAdditiveNoisElement(0);
                if (!n.Y.IsZero)
                    a[count++] = n.Y.AsAdditiveNoisElement(1);
                if (!n.Z.IsZero)
                    a[count++] = n.Z.AsAdditiveNoisElement(2);
            }
            return a; 
        }

        /// <summary>Get the noise signal value at a specific time</summary>
        /// <param name="noiseParams">The parameters that define the noise function</param>
        /// <param name="time">The time at which to sample the noise function</param>
        /// <param name="timeOffsets">Start time offset for each channel</param>
        /// <returns>The 3-channel noise signal value at the specified time</returns>
        public static float3 GetNoiseValue(
            TransformNoiseParams[] noiseParams, float time, float3 timeOffsets)
        {
            float3 pos = float3.zero;
            if (noiseParams != null)
                for (int i = 0; i < noiseParams.Length; ++i)
                    pos += noiseParams[i].GetValueAt(time, timeOffsets);
            return pos;
        }
    }
}
