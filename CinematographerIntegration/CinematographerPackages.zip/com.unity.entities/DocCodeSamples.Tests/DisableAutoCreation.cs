[assembly: Unity.Entities.DisableAutoCreation]
//This declaration prevents the systems in the documentation sample source from being auto-created.
