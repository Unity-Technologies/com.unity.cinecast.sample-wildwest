using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Entities.Hybrid.CodeGen.Tests")]
