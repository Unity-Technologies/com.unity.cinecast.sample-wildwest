using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo(assemblyName: "Unity.Entities.Hybrid.CodeGen.Tests")]
[assembly: InternalsVisibleTo(assemblyName: "Unity.Entities.CodeGen.Tests")]
