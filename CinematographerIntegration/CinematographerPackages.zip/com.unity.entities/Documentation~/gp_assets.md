---
uid: gameplay-assets
---
# Assets and resources

> Synopsis: Considerations for using Unity assets and loading resources in an ECS-based project.

Note, this is a placeholder for work that has not been completed yet.