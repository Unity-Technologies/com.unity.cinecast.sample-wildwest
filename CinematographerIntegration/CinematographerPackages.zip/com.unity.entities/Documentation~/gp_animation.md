---
uid: gameplay-animation
---
# Animation

> Synopsis: How to use Unity's animation features with ECS. How to optimize animation with ECS.

Note, this is a placeholder for work that has not been completed yet.