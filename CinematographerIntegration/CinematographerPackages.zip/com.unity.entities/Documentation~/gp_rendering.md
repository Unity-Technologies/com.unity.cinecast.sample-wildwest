---
uid: gameplay-rendering
---
# Rendering


The Hybrid.Rendering package provides a ECS system to render 3D objects.

See [DOTS Hybrid Renderer](https://docs.unity3d.com/Packages/com.unity.rendering.hybrid@latest/index.html) for information about the current DOTS-compatible rendering API.