---
uid: gameplay-text
---
# Handling text

> Synopsis: Handling text in a performant way

Note, this is a placeholder for work that has not been completed yet.