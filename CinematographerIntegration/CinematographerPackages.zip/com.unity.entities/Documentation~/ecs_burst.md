---
uid: ecs-burst
---
# Using Burst

> Synopsis: Cover how, when, and why to use the Burst compiler with ECS. Everything burst -elated within ECS should go here.

