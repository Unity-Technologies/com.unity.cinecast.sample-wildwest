---
uid: ecs-building
---
# Building your project

> Synopsis: Cover any unique aspects for building ECS projects, including any cross-platform details.

