---
uid: ecs-profiling
---
# Profiling

> Synopsis: All about profiling ECS programs

