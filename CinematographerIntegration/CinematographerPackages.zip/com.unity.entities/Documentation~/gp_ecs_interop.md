---
uid: gameplay-interop
---
# Sharing data between ECS and MonoBehaviours

> Synopsis: interoperation between ECS components and systems and MonoBehaviours or other managed code.

Note, this is a placeholder for work that has not been completed yet.