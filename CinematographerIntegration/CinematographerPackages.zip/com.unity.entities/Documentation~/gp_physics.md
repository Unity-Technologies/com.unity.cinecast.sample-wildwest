---
uid: gameplay-physics
---
# Physics

> Synopsis: How to use Unity's physics features with ECS. How to optimize physics with ECS.

Note, this is a placeholder for work that has not been completed yet.

See the [Unity Physics](https://docs.unity3d.com/Packages/com.unity.physics@latest/index.html) and [Havok Physics](https://docs.unity3d.com/Packages/com.havok.physics@latest/index.html) packages for information about the DOTS-compatible physics APIs.