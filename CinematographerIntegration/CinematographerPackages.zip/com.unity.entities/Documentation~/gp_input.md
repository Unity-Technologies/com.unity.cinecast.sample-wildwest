---
uid: gameplay-input
---
# Player input

> Synopsis: How to use Unity's input features with ECS. How to optimize input with ECS.

Note, this is a placeholder for work that has not been completed yet.