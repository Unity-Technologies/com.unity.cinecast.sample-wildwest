namespace Unity.Entities.Editor.PerformanceTests
{
    public static class Categories
    {
        public const string Performance = "Performance";
    }
}
