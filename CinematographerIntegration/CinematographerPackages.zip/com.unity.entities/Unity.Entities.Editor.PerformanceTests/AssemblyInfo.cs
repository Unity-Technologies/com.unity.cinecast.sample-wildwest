using Unity.Entities;

[assembly: DisableAutoCreation]
