using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Entities.Editor.Properties")]
