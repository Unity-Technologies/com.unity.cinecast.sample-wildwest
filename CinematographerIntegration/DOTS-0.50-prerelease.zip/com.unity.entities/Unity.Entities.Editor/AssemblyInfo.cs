using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Entities.Editor.Tests")]
[assembly: InternalsVisibleTo("Unity.Entities.Editor.PerformanceTests")]
