﻿
using Unity.Build;

namespace Unity.Entities
{
    internal class EnableEntityNames : IBuildComponent
    {}
}
