using System.Collections.Generic;
using UnityEditor;
using UnityEditor.IMGUI.Controls;
using UnityEngine;

namespace Unity.Entities.Editor
{
    internal delegate void CallbackAction();

    internal class ComponentTypeChooser : EditorWindow
    {
        private static List<ComponentType> types;
        private static HashSet<ComponentType> typeSelections;
        static List<ComponentType> previouslySelected;

        private static CallbackAction callback;

        private static readonly Vector2 kDefaultSize = new Vector2(300f, 400f);

        public static void Open(Vector2 screenPosition, List<ComponentType> types, HashSet<ComponentType> typeSelections, List<ComponentType> previouslySelected, CallbackAction callback)
        {
            ComponentTypeChooser.callback = callback;
            ComponentTypeChooser.types = types;
            ComponentTypeChooser.typeSelections = typeSelections;
            ComponentTypeChooser.previouslySelected = previouslySelected;
            GetWindowWithRect<ComponentTypeChooser>(new Rect(screenPosition, kDefaultSize), true, "Choose Component", true);
        }

        private SearchField searchField;
        private ComponentTypeListView typeListView;

        private void OnEnable()
        {
            searchField = new SearchField();
            searchField.SetFocus();
            typeListView = new ComponentTypeListView(new TreeViewState(), types, typeSelections, previouslySelected, ComponentFilterChanged);
        }

        public void ComponentFilterChanged()
        {
            callback();
        }

        private void OnGUI()
        {
            typeListView.searchString = searchField.OnGUI(typeListView.searchString, GUILayout.Height(20f), GUILayout.ExpandWidth(true));
            typeListView.OnGUI(GUIHelpers.GetExpandingRect());
        }

        private void OnLostFocus()
        {
            EditorApplication.delayCall += Close;
        }
    }
}
