using System.Runtime.CompilerServices;
using Unity.Entities;

[assembly: DisableAutoCreation]
[assembly: InternalsVisibleTo("Unity.Entities.Editor.PerformanceTests")]
