---
uid: gameplay-ai
---
# Pathfinding and AI

> Synopsis: Describe how to do pathfinding  and other AI tasks. At the very least, this topic must cover using existing Unity constructs such as the Nav Mesh. Ideally, the topic also covers data-oriented approaches to AI systems or provides resources for developers tackling the problem.


Note, this is a placeholder for work that has not been completed yet.

Also, see the [AI Planner](https://docs.unity3d.com/Packages/com.unity.ai.planner@latest/index.html) package.