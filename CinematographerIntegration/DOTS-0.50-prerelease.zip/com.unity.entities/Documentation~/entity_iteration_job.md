# Using IJobForEach jobs

The IJobForEach class is deprecated in favor of [SystemBase] and [Entities.ForEach]. See [Creating systems] for more information on programming systems.

[Entities.ForEach]: xref:Unity.Entities.SystemBase.Entities
[Creating systems]: ecs_creating_systems.md
[SystemBase]: xref:Unity.Entities.SystemBase
