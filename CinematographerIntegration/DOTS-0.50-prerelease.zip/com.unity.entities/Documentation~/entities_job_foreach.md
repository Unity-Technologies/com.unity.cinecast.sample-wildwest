# SystemBase lambda functions

This documentation has been moved to the [SystemBase] class documentation. Also, see [Creating systems] for more information on programming systems.


[Creating systems]: ecs_creating_systems.md
[SystemBase]: xref:Unity.Entities.SystemBase
