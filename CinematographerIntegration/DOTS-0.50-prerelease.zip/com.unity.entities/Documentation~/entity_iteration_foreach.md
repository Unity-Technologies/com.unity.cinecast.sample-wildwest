---
uid: ecs-fluent-query
---

# Using ComponentSystem methods

The ComponentSystem class is being phased out in favor of [SystemBase]. See [Creating systems] for more information on programming systems.


[Creating systems]: ecs_creating_systems.md
[SystemBase]: xref:Unity.Entities.SystemBase
