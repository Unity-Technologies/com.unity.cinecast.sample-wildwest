---
uid: gameplay-multiplayer
---
# Networking and Multiplayer

> Synopsis: How to use Unity's networking and multiplayer features with ECS. How to optimize networking and multiplayer with ECS. 

Note, this is a placeholder for work that has not been completed yet.