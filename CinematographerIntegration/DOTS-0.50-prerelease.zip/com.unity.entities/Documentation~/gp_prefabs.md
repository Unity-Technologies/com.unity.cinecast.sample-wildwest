---
uid: gameplay-prefabs
---
# Prefabs

> Synopsis: Using prefabs in ECS-based programs

Note, this is a placeholder for work that has not been completed yet.