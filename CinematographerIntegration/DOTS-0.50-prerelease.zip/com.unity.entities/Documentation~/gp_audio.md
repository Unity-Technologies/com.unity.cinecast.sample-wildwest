---
uid: gameplay-audio
---
# Audio

> Synopsis: How to use Unity's audio features with ECS. How to optimize audio with ECS.


Note, this is a placeholder for work that has not been completed yet.