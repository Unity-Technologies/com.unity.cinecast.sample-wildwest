using System;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Entities.Runtime.Build")]
[assembly: InternalsVisibleTo("Unity.Entities.Runtime")]
[assembly: InternalsVisibleTo("Unity.Tiny.Scenes")]
[assembly: InternalsVisibleTo("Unity.Tiny.Codec.Tests")]
